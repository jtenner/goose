(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 368)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 80
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 88
        i32.const 80
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i64 i64 i32)
    block ;; label = @1
      call 0
      local.set 2
      local.get 2
      i32.const 168
      i32.const 6
      call 4
      local.get 2
      call 5
      i64.const 0
      local.set 3
      i64.const 2
      local.set 4
      block ;; label = @2
        loop ;; label = @3
          local.get 3
          local.get 4
          i64.ge_s
          br_if 1 (;@2;)
          local.get 3
          local.set 1
          block ;; label = @4
            call $apply.1
            i64.const 623
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 174
              i32.const 80
              i32.const 1
              call 6
              unreachable
            end
            call 0
            local.set 5
            local.get 5
            i32.const 254
            i32.const 5
            call 4
            local.get 5
            call 5
          end
          local.get 3
          i64.const 1
          i64.add
          local.set 3
          br 0 (;@3;)
        end
      end
    end
  )
  (func $apply.1 (;12;) (type 11) (result i64)
    (local i32 i32 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64)
    block ;; label = @1
      i32.const 11
      call $goose.reserve_frame
      local.set 5
      local.get 5
      local.set 6
      local.get 6
      call $make.2
      local.get 5
      i32.const 1
      i32.add
      local.set 1
      call $noise.3
      local.set 2
      call 0
      local.set 7
      local.get 7
      i32.const 259
      i32.const 9
      call 4
      local.get 7
      call 5
      local.get 1
      local.tee 8
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 268
        i32.const 80
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.load align=1
      local.get 2
      i64.add
      local.set 9
      local.get 9
      local.set 10
      local.get 10
      local.set 4
      local.get 5
      global.set 0
      local.get 4
      local.set 11
      local.get 11
      local.set 3
    end
    local.get 3
  )
  (func $make.2 (;13;) (type 5) (param i32)
    (local i32)
    block ;; label = @1
      local.get 0
      i64.const 17
      i64.store8
      local.get 0
      i64.const 700
      i64.store offset=1 align=1
      local.get 0
      i64.const 4660
      i64.store16 offset=9 align=1
      br 0 (;@1;)
    end
  )
  (func $noise.3 (;14;) (type 11) (result i64)
    (local i32 i64 i32 i32 i32)
    i32.const 11
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 2
      local.get 2
      i64.const 99
      i64.store8
      local.get 2
      i64.const -77
      i64.store offset=1 align=1
      local.get 2
      i64.const 88
      i64.store16 offset=9 align=1
      call 0
      local.set 3
      local.get 3
      i32.const 348
      i32.const 13
      call 4
      local.get 3
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 4
      local.get 4
      i64.load offset=1 align=1
      local.set 1
      br 0 (;@1;)
    end
    local.get 0
    global.set 0
    local.get 1
  )
  (func $goose.init (;15;) (type 10)
    (local i32)
  )
  (func $goose.start (;16;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_callback_borrow_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_callback_borrow_owner.goosebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_callback_borrow_owner.gooseafterbody-live/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_callback_borrow_owner.gooseargument-live")
  (export "test_stack_top_0" (global 0))
)
