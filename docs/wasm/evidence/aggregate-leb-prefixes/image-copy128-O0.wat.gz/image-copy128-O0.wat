(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i32)))
  (type (;12;) (func (param i64) (result i64 i32)))
  (type (;13;) (func (param i32 i32) (result i32)))
  (type (;14;) (func (param i64 i64 i32)))
  (type (;15;) (func (param i64) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (global (;0;) (mut i32) i32.const 1152)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 86
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 94
        i32.const 86
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i32 i64 i64 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 1
      local.set 3
      i32.const 1410
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i32.wrap_i64
      i64.const 128
      i64.store8 1
      local.get 5
      i32.wrap_i64
      i64.const 1
      i64.store8 1 offset=1
      i32.const 11
      call $goose.reserve_frame
      local.set 6
      local.get 6
      i64.const 34
      i64.store8
      local.get 6
      i64.const -8
      i64.store offset=1 align=1
      local.get 6
      i64.const 900
      i64.store16 offset=9 align=1
      i64.const 0
      local.set 7
      block ;; label = @2
        loop ;; label = @3
          local.get 7
          i64.const 128
          i64.ge_u
          br_if 1 (;@2;)
          local.get 5
          local.get 7
          i64.const 11
          i64.mul
          i64.add
          i64.const 2
          i64.add
          local.set 8
          local.get 8
          i32.wrap_i64
          local.get 6
          i32.const 11
          memory.copy 1 0
          local.get 7
          i64.const 1
          i64.add
          local.set 7
          br 0 (;@3;)
        end
      end
      local.get 6
      global.set 0
      local.get 1
      i32.const 1
      call $receive.1
      call 0
      local.set 9
      local.get 9
      i32.const 180
      i32.const 7
      call 4
      local.get 9
      call 5
      i32.const 2
      local.set 10
      i32.const 5
      call $goose.reserve_memory.2
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 12
      local.get 12
      local.set 2
      local.get 12
      i64.const 1
      local.set 13
      i32.wrap_i64
      local.get 13
      i64.store32 2 align=1
      i64.const 91
      local.set 14
      local.get 11
      i32.const 4
      i32.add
      local.get 14
      i64.store8 2
      local.get 1
      i32.const 2
      call $receive.1
      call 0
      local.set 15
      local.get 15
      i32.const 187
      i32.const 4
      call 4
      local.get 15
      call 5
      local.get 2
      local.set 16
      local.get 16
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 17
      i64.const 0
      local.set 18
      local.get 16
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 18
      i64.const 1
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 191
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      i32.wrap_i64
      i64.load8_u 2
      i64.const 91
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 277
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 11
      global.set 2
      local.get 4
      global.set 1
    end
  )
  (func $receive.1 (;12;) (type 11) (param i64 i32)
    (local i32 i64 i32 i64 i64 i32 i64 i32 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64)
    block ;; label = @1
      call 0
      local.set 4
      local.get 4
      i32.const 363
      i32.const 6
      call 4
      local.get 4
      call 5
      local.get 0
      local.tee 5
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 369
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      local.set 6
      local.get 6
      call $goose.read_array_prefix
      local.set 9
      local.set 10
      local.get 10
      i64.const 390451572
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 455
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const 11
      i64.mul
      local.get 9
      i64.extend_i32_u
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 541
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 11
      i32.wrap_i64
      local.set 7
      local.get 6
      local.set 8
      local.get 1
      i32.const 1
      i32.add
      local.set 13
      local.get 13
      local.get 7
      call $goose.reserve_data
      local.set 14
      local.get 13
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 14
      i64.extend_i32_u
      i64.or
      local.set 12
      local.get 12
      local.set 3
      local.get 12
      local.get 8
      local.get 7
      call $goose.copy_memory
      call 0
      local.set 15
      local.get 15
      i32.const 627
      i32.const 5
      call 4
      local.get 15
      call 5
      local.get 3
      local.set 16
      local.get 16
      call $goose.read_array_prefix
      drop
      i64.const 128
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 632
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 17
      local.get 17
      call $goose.read_array_prefix
      local.set 20
      local.set 18
      i64.const 127
      local.set 19
      local.get 17
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      local.get 20
      i64.extend_i32_u
      i64.add
      local.get 19
      i64.const 11
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 718
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      local.set 23
      local.get 23
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 24
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 804
        i32.const 86
        i32.const 0
        call 6
        unreachable
      end
      local.get 23
      i64.const -4294967296
      i64.and
      local.get 24
      i64.or
      call $goose.memory_op.41
      i64.const -8
      i64.eq
      if (result i32) ;; label = @2
        local.get 3
        local.set 25
        local.get 25
        call $goose.read_array_prefix
        local.set 28
        local.set 26
        i64.const 0
        local.set 27
        local.get 25
        local.set 29
        local.get 29
        i64.const 4294967295
        i64.and
        local.get 28
        i64.extend_i32_u
        i64.add
        local.get 27
        i64.const 11
        i64.mul
        i64.add
        local.tee 30
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 890
          i32.const 86
          i32.const 1
          call 6
          unreachable
        end
        local.get 29
        i64.const -4294967296
        i64.and
        local.get 30
        i64.or
        local.set 31
        local.get 31
        i64.const 4294967295
        i64.and
        i64.const 9
        i64.add
        local.tee 24
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 976
          i32.const 86
          i32.const 0
          call 6
          unreachable
        end
        local.get 31
        i64.const -4294967296
        i64.and
        local.get 24
        i64.or
        call $goose.memory_op.51
        i64.const 900
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1062
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 13
      local.get 14
      call $goose.restore_data
    end
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.read_array_prefix (;17;) (type 12) (param i64) (result i64 i32)
    (local i64 i32 i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u
              local.tee 3
              i64.const 128
              i64.lt_u
              if ;; label = @6
                local.get 3
                local.set 1
                i32.const 1
                local.set 2
              else
                local.get 3
                i64.const 127
                i64.and
                local.set 1
                i32.const 1
                local.set 2
                block ;; label = @7
                  loop ;; label = @8
                    local.get 0
                    i64.const 4294967295
                    i64.and
                    local.get 2
                    i64.extend_i32_u
                    i64.add
                    local.tee 4
                    i64.const 4294967295
                    i64.gt_u
                    if ;; label = @9
                      i32.const 11
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 4
                    i32.wrap_i64
                    i64.load8_u
                    local.set 3
                    local.get 2
                    i32.const 9
                    i32.eq
                    local.get 3
                    i64.const 1
                    i64.gt_u
                    i32.and
                    local.get 3
                    i64.eqz
                    i32.or
                    if ;; label = @9
                      i32.const 13
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 1
                    local.get 3
                    i64.const 127
                    i64.and
                    local.get 2
                    i32.const 7
                    i32.mul
                    i64.extend_i32_u
                    i64.shl
                    i64.or
                    local.set 1
                    local.get 2
                    i32.const 1
                    i32.add
                    local.set 2
                    local.get 3
                    i64.const 128
                    i64.and
                    i64.eqz
                    br_if 1 (;@7;)
                    br 0 (;@8;)
                  end
                end
              end
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 1
            local.tee 3
            i64.const 128
            i64.lt_u
            if ;; label = @5
              local.get 3
              local.set 1
              i32.const 1
              local.set 2
            else
              local.get 3
              i64.const 127
              i64.and
              local.set 1
              i32.const 1
              local.set 2
              block ;; label = @6
                loop ;; label = @7
                  local.get 0
                  i64.const 4294967295
                  i64.and
                  local.get 2
                  i64.extend_i32_u
                  i64.add
                  local.tee 4
                  i64.const 4294967295
                  i64.gt_u
                  if ;; label = @8
                    i32.const 11
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 4
                  i32.wrap_i64
                  i64.load8_u 1
                  local.set 3
                  local.get 2
                  i32.const 9
                  i32.eq
                  local.get 3
                  i64.const 1
                  i64.gt_u
                  i32.and
                  local.get 3
                  i64.eqz
                  i32.or
                  if ;; label = @8
                    i32.const 13
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 1
                  local.get 3
                  i64.const 127
                  i64.and
                  local.get 2
                  i32.const 7
                  i32.mul
                  i64.extend_i32_u
                  i64.shl
                  i64.or
                  local.set 1
                  local.get 2
                  i32.const 1
                  i32.add
                  local.set 2
                  local.get 3
                  i64.const 128
                  i64.and
                  i64.eqz
                  br_if 1 (;@6;)
                  br 0 (;@7;)
                end
              end
            end
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 2
          local.tee 3
          i64.const 128
          i64.lt_u
          if ;; label = @4
            local.get 3
            local.set 1
            i32.const 1
            local.set 2
          else
            local.get 3
            i64.const 127
            i64.and
            local.set 1
            i32.const 1
            local.set 2
            block ;; label = @5
              loop ;; label = @6
                local.get 0
                i64.const 4294967295
                i64.and
                local.get 2
                i64.extend_i32_u
                i64.add
                local.tee 4
                i64.const 4294967295
                i64.gt_u
                if ;; label = @7
                  i32.const 11
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 4
                i32.wrap_i64
                i64.load8_u 2
                local.set 3
                local.get 2
                i32.const 9
                i32.eq
                local.get 3
                i64.const 1
                i64.gt_u
                i32.and
                local.get 3
                i64.eqz
                i32.or
                if ;; label = @7
                  i32.const 13
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 1
                local.get 3
                i64.const 127
                i64.and
                local.get 2
                i32.const 7
                i32.mul
                i64.extend_i32_u
                i64.shl
                i64.or
                local.set 1
                local.get 2
                i32.const 1
                i32.add
                local.set 2
                local.get 3
                i64.const 128
                i64.and
                i64.eqz
                br_if 1 (;@5;)
                br 0 (;@6;)
              end
            end
          end
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 3
        local.tee 3
        i64.const 128
        i64.lt_u
        if ;; label = @3
          local.get 3
          local.set 1
          i32.const 1
          local.set 2
        else
          local.get 3
          i64.const 127
          i64.and
          local.set 1
          i32.const 1
          local.set 2
          block ;; label = @4
            loop ;; label = @5
              local.get 0
              i64.const 4294967295
              i64.and
              local.get 2
              i64.extend_i32_u
              i64.add
              local.tee 4
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 4
              i32.wrap_i64
              i64.load8_u 3
              local.set 3
              local.get 2
              i32.const 9
              i32.eq
              local.get 3
              i64.const 1
              i64.gt_u
              i32.and
              local.get 3
              i64.eqz
              i32.or
              if ;; label = @6
                i32.const 13
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 1
              local.get 3
              i64.const 127
              i64.and
              local.get 2
              i32.const 7
              i32.mul
              i64.extend_i32_u
              i64.shl
              i64.or
              local.set 1
              local.get 2
              i32.const 1
              i32.add
              local.set 2
              local.get 3
              i64.const 128
              i64.and
              i64.eqz
              br_if 1 (;@4;)
              br 0 (;@5;)
            end
          end
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 1
    local.get 2
  )
  (func $goose.reserve_data (;18;) (type 13) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            call $goose.reserve_memory.1
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.2
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.3 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.copy_memory (;20;) (type 14) (param i64 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          local.get 1
                          i64.const 32
                          i64.shr_u
                          i32.wrap_i64
                          br_table 0 (;@11;) 1 (;@10;) 2 (;@9;) 3 (;@8;) 4 (;@7;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy
                        br 4 (;@6;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 0 1
                      br 3 (;@6;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 0 2
                    br 2 (;@6;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 0 3
                  br 1 (;@6;)
                end
                i32.const 7
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              br 4 (;@1;)
            end
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 1
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 1 0
                      br 4 (;@5;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 1 1
                    br 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 1 2
                  br 2 (;@5;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 1 3
                br 1 (;@5;)
              end
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            br 3 (;@1;)
          end
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      local.get 1
                      i64.const 32
                      i64.shr_u
                      i32.wrap_i64
                      br_table 0 (;@9;) 1 (;@8;) 2 (;@7;) 3 (;@6;) 4 (;@5;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 2 0
                    br 4 (;@4;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 2 1
                  br 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 2 2
                br 2 (;@4;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 2 3
              br 1 (;@4;)
            end
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          br 2 (;@1;)
        end
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    local.get 1
                    i64.const 32
                    i64.shr_u
                    i32.wrap_i64
                    br_table 0 (;@8;) 1 (;@7;) 2 (;@6;) 3 (;@5;) 4 (;@4;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 3 0
                  br 4 (;@3;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 3 1
                br 3 (;@3;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 3 2
              br 2 (;@3;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 3 3
            br 1 (;@3;)
          end
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;21;) (type 15) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.51 (;22;) (type 15) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load16_u align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load16_u 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load16_u 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load16_u 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;23;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            i32.eqz
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            i64.extend_i32_u
            memory.size 1
            i64.extend_i32_u
            i64.const 16
            i64.shl
            i64.gt_u
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            global.set 1
            br 3 (;@1;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 2
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 2
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 3
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goosebetweendone/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goosebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.gooseafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_leb_image_copy128.goose")
)
