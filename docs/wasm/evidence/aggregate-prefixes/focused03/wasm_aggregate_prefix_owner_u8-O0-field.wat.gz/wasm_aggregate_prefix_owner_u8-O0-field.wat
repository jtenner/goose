(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i32)))
  (type (;12;) (func (param i64) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (global (;0;) (mut i32) i32.const 2544)
  (global (;1;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 84
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 92
        i32.const 84
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      call 0
      local.set 2
      local.get 2
      i32.const 176
      i32.const 6
      call 4
      local.get 2
      call 5
      i32.const 1
      local.set 3
      i32.const 27
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i64.const 2
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1
      local.get 5
      i32.wrap_i64
      i64.const 1
      i64.store8 1 offset=1
      local.get 5
      i32.wrap_i64
      i32.const 3
      i32.add
      i32.const 0
      i32.add
      i64.const 11
      i64.store16 1 align=1
      local.get 5
      i32.wrap_i64
      i32.const 2
      i32.add
      i32.const 2
      i32.add
      i64.const 22
      i64.store16 1 align=1
      local.get 5
      i64.const 0
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=6
      i64.const 33
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load8_u 1 offset=6
      local.set 8
      local.get 8
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 182
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 6
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 266
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 350
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=6
      i64.const 44
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load8_u 1 offset=6
      local.set 8
      local.get 8
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 434
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 6
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 518
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 602
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=6
      local.get 5
      i32.wrap_i64
      i32.const 11
      i32.add
      i32.const 0
      i32.const 2
      memory.fill 1
      local.get 5
      i32.wrap_i64
      i64.const 2
      i64.store8 1 offset=13
      local.get 5
      i32.wrap_i64
      i64.const 3
      i64.store8 1 offset=14
      local.get 5
      i32.wrap_i64
      i32.const 15
      i32.add
      i32.const 0
      i32.add
      i64.const 55
      i64.store16 1 align=1
      local.get 5
      i32.wrap_i64
      i32.const 15
      i32.add
      i32.const 2
      i32.add
      i64.const 66
      i64.store16 1 align=1
      local.get 5
      i64.const 0
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=19
      local.get 5
      i32.wrap_i64
      i32.const 20
      i32.add
      i32.const 0
      i32.const 6
      memory.fill 1
      local.get 5
      i32.wrap_i64
      i64.const 4
      i64.store8 1 offset=26
      call 0
      local.set 13
      local.get 13
      i32.const 686
      i32.const 5
      call 4
      local.get 13
      call 5
      local.get 1
      call $check.1
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 691
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 4
      global.set 1
    end
  )
  (func $check.1 (;12;) (type 11) (param i64) (result i32)
    (local i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 775
        i32.const 84
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      local.get 4
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      if (result i32) ;; label = @2
        local.get 0
        local.tee 5
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 859
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 5
        local.set 6
        local.get 6
        call $goose.memory_op.49
        local.set 7
        i64.const 0
        local.set 8
        local.get 6
        local.set 9
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 8
        i64.const 13
        i64.mul
        i64.add
        local.tee 10
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 943
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 10
        i64.or
        local.set 11
        local.get 11
        call $goose.memory_op.49
        i64.const 1
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 0
        local.tee 12
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1027
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 12
        local.set 13
        local.get 13
        call $goose.memory_op.49
        local.set 14
        i64.const 0
        local.set 15
        local.get 13
        local.set 16
        local.get 16
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 15
        i64.const 13
        i64.mul
        i64.add
        local.tee 17
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1111
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 16
        i64.const -4294967296
        i64.and
        local.get 17
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1195
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 20
        i64.const 2
        local.set 21
        i64.const 1
        local.set 22
        local.get 20
        local.set 23
        local.get 23
        i64.const 4294967295
        i64.and
        local.get 22
        i64.const 2
        i64.mul
        i64.add
        local.tee 24
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1279
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 23
        i64.const -4294967296
        i64.and
        local.get 24
        i64.or
        call $goose.memory_op.51
        i64.const 22
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 0
        local.tee 25
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1363
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 25
        local.set 26
        local.get 26
        call $goose.memory_op.49
        local.set 27
        i64.const 0
        local.set 28
        local.get 26
        local.set 29
        local.get 29
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 28
        i64.const 13
        i64.mul
        i64.add
        local.tee 30
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1447
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 29
        i64.const -4294967296
        i64.and
        local.get 30
        i64.or
        local.set 31
        local.get 31
        i64.const 4294967295
        i64.and
        i64.const 5
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1531
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 31
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 32
        local.get 32
        call $goose.memory_op.49
        i64.const 2
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 0
        local.tee 33
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1615
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 33
        local.set 34
        local.get 34
        call $goose.memory_op.49
        local.set 35
        i64.const 0
        local.set 36
        local.get 34
        local.set 37
        local.get 37
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 36
        i64.const 13
        i64.mul
        i64.add
        local.tee 38
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1699
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 37
        i64.const -4294967296
        i64.and
        local.get 38
        i64.or
        local.set 39
        local.get 39
        i64.const 4294967295
        i64.and
        i64.const 5
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1783
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 39
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 40
        local.get 40
        call $goose.memory_op.49
        local.set 41
        i64.const 1
        local.set 42
        local.get 42
        local.get 41
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 1867
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 40
        local.set 43
        local.get 43
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 42
        i64.const 2
        i64.mul
        i64.add
        local.tee 44
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1951
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 43
        i64.const -4294967296
        i64.and
        local.get 44
        i64.or
        call $goose.memory_op.51
        i64.const 44
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 0
        local.tee 45
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2035
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 45
        local.set 46
        local.get 46
        call $goose.memory_op.49
        local.set 47
        i64.const 1
        local.set 48
        local.get 46
        local.set 49
        local.get 49
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 48
        i64.const 13
        i64.mul
        i64.add
        local.tee 50
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2119
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 49
        i64.const -4294967296
        i64.and
        local.get 50
        i64.or
        local.set 51
        local.get 51
        i64.const 4294967295
        i64.and
        i64.const 5
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2203
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 51
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 52
        local.get 52
        call $goose.memory_op.49
        i64.const 0
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 0
        local.tee 53
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2287
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 53
        local.set 54
        local.get 54
        call $goose.memory_op.49
        local.set 55
        i64.const 1
        local.set 56
        local.get 54
        local.set 57
        local.get 57
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 56
        i64.const 13
        i64.mul
        i64.add
        local.tee 58
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2371
          i32.const 84
          i32.const 1
          call 6
          unreachable
        end
        local.get 57
        i64.const -4294967296
        i64.and
        local.get 58
        i64.or
        local.set 59
        local.get 59
        i64.const 4294967295
        i64.and
        i64.const 12
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2455
          i32.const 84
          i32.const 0
          call 6
          unreachable
        end
        local.get 59
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        call $goose.memory_op.49
        i64.const 4
        i64.eq
      else
        i32.const 0
      end
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.49 (;16;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.51 (;17;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          i64.load16_u align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load16_u 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goosebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.gooseafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_u8.goose")
  (export "test_stack_top_0" (global 0))
  (export "test_stack_top_1" (global 1))
)
