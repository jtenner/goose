(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i32) (result i64)))
  (type (;12;) (func (param i32 i32) (result i32)))
  (type (;13;) (func (param i64 i64)))
  (type (;14;) (func (param i64) (result i64)))
  (type (;15;) (func (param i64 i32 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 2528)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 89
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 97
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i64.const 0
      i32.const 0
      call $produce.1
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 186
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      i32.const 1
      local.set 2
      i32.const 5
      call $goose.reserve_memory.1
      local.set 3
      local.get 2
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 3
      i64.extend_i32_u
      i64.or
      local.set 4
      local.get 4
      local.set 1
      local.get 4
      i64.const 1
      local.set 5
      i32.wrap_i64
      local.get 5
      i64.store32 1 align=1
      i64.const 91
      local.set 6
      local.get 3
      i32.const 4
      i32.add
      local.get 6
      i64.store8 1
      i64.const 1
      i32.const 1
      call $produce.1
      i64.const 8
      i64.eq
      if (result i32) ;; label = @2
        local.get 1
        local.set 7
        local.get 7
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 8
        i64.const 0
        local.set 9
        local.get 7
        local.set 10
        local.get 10
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 9
        i64.const 1
        i64.mul
        i64.add
        local.tee 11
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 275
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 10
        i64.const -4294967296
        i64.and
        local.get 11
        i64.or
        i32.wrap_i64
        i64.load8_u 1
        i64.const 91
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 364
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      call 0
      local.set 12
      local.get 12
      i32.const 453
      i32.const 4
      call 4
      local.get 12
      call 5
      local.get 3
      global.set 1
    end
  )
  (func $produce.1 (;12;) (type 11) (param i64 i32) (result i64)
    (local i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      call 0
      local.set 5
      local.get 5
      i32.const 457
      i32.const 6
      call 4
      local.get 5
      call 5
      local.get 1
      i32.const 1
      i32.add
      local.set 6
      local.get 6
      i32.const 30
      call $goose.reserve_data
      local.set 7
      local.get 6
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 7
      i64.extend_i32_u
      i64.or
      local.set 8
      local.get 8
      local.set 3
      local.get 8
      i64.const 2
      call $goose.memory_op.62
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 463
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 1
      call $goose.memory_op.60
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 552
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 0
      i64.add
      i64.const 11
      call $goose.memory_op.61
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 641
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 2
      i64.add
      i64.const 22
      call $goose.memory_op.61
      local.get 8
      i64.const 9
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 33
      local.set 10
      local.get 8
      i64.const 9
      i64.add
      call $goose.memory_op.49
      local.set 11
      local.get 11
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 730
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 9
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 819
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 11
      i64.const 2
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 908
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.tee 12
      local.get 10
      call $goose.memory_op.61
      local.get 8
      i64.const 9
      i64.add
      local.get 11
      i64.const 1
      i64.add
      call $goose.memory_op.60
      i64.const 44
      local.set 10
      local.get 8
      i64.const 9
      i64.add
      call $goose.memory_op.49
      local.set 11
      local.get 11
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 997
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 9
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1086
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 11
      i64.const 2
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1175
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.tee 12
      local.get 10
      call $goose.memory_op.61
      local.get 8
      i64.const 9
      i64.add
      local.get 11
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 14
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1264
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i32.const 0
      i32.const 2
      call $goose.fill_memory
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 16
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1353
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 2
      call $goose.memory_op.60
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 17
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1442
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 3
      call $goose.memory_op.60
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 18
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1531
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 0
      i64.add
      i64.const 55
      call $goose.memory_op.61
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 18
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1620
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 2
      i64.add
      i64.const 66
      call $goose.memory_op.61
      local.get 8
      i64.const 22
      i64.add
      i64.const 0
      call $goose.memory_op.60
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 23
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1709
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i32.const 0
      i32.const 6
      call $goose.fill_memory
      local.get 8
      i64.const 4294967295
      i64.and
      i64.const 29
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1798
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      i64.const 4
      call $goose.memory_op.60
      call 0
      local.set 15
      local.get 15
      i32.const 1887
      i32.const 5
      call 4
      local.get 15
      call 5
      local.get 3
      local.set 16
      local.get 16
      call $goose.memory_op.53
      local.set 17
      i64.const 0
      local.set 18
      local.get 16
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 18
      i64.const 13
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1892
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1981
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 22
      local.get 22
      call $goose.memory_op.49
      local.set 23
      i64.const 1
      local.set 24
      local.get 24
      local.get 23
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2070
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 22
      local.set 25
      local.get 25
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 24
      i64.const 2
      i64.mul
      i64.add
      local.tee 26
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2159
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 25
      i64.const -4294967296
      i64.and
      local.get 26
      i64.or
      call $goose.memory_op.51
      i64.const 44
      i64.eq
      if (result i32) ;; label = @2
        local.get 3
        local.set 27
        local.get 27
        call $goose.memory_op.53
        local.set 28
        i64.const 1
        local.set 29
        local.get 27
        local.set 30
        local.get 30
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 29
        i64.const 13
        i64.mul
        i64.add
        local.tee 31
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2248
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 30
        i64.const -4294967296
        i64.and
        local.get 31
        i64.or
        local.set 32
        local.get 32
        i64.const 4294967295
        i64.and
        i64.const 12
        i64.add
        local.tee 9
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2337
          i32.const 89
          i32.const 0
          call 6
          unreachable
        end
        local.get 32
        i64.const -4294967296
        i64.and
        local.get 9
        i64.or
        call $goose.memory_op.49
        i64.const 4
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2426
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 0
      i64.const 7
      i64.add
      local.set 4
      local.get 6
      local.get 7
      call $goose.restore_data
      br 0 (;@1;)
      local.get 6
      local.get 7
      call $goose.restore_data
    end
    local.get 4
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_data (;16;) (type 12) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i32.const 1
            i32.sub
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 1
          call $goose.reserve_memory.1
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.62 (;18;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store32 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store32 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store32 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;19;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.61 (;20;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store16 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store16 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store16 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;21;) (type 14) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.fill_memory (;22;) (type 15) (param i64 i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 33
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            local.get 2
            memory.fill
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          local.get 2
          memory.fill 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        local.get 2
        memory.fill 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;23;) (type 14) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.51 (;24;) (type 14) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load16_u align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load16_u 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load16_u 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;25;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i32.const 1
            i32.sub
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 1
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 1
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 2
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goosedonebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.gooseafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_prefix_owner_dynamic.goose")
  (export "test_stack_top_0" (global 0))
  (export "test_stack_top_1" (global 1))
  (export "test_stack_top_2" (global 2))
)
