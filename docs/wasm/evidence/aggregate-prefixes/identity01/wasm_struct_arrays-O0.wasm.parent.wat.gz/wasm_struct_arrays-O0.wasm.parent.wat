(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (type (;12;) (func (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 16 65536)
  (global (;0;) (mut i32) i32.const 1002032)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 1000028
      i32.const 72
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 1000100
        i32.const 72
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i32 i64 i32 i64 i64 i32 i32 i32 i64 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32)
    i32.const 1911
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 4
      local.get 4
      call $tick.1
      i64.store align=1
      local.get 4
      i32.const 8
      i32.add
      i32.const 1000172
      i32.const 3
      memory.copy
      local.get 4
      i64.const 0
      i64.store16 offset=11 align=1
      i64.const 4
      local.set 5
      local.get 4
      i64.load16_u offset=11 align=1
      local.set 6
      local.get 6
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1000175
        i32.const 72
        i32.const 8
        call 6
        unreachable
      end
      local.get 4
      i32.const 11
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 8
      local.get 8
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 2
      i64.mul
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000247
        i32.const 72
        i32.const 8
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 7
      local.get 7
      i32.wrap_i64
      local.get 5
      i64.store16 align=1
      local.get 4
      local.get 6
      i64.const 1
      i64.add
      i64.store16 offset=11 align=1
      i64.const 5
      local.set 5
      local.get 4
      i64.load16_u offset=11 align=1
      local.set 6
      local.get 6
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1000319
        i32.const 72
        i32.const 8
        call 6
        unreachable
      end
      local.get 4
      i32.const 11
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 8
      local.get 8
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 2
      i64.mul
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000391
        i32.const 72
        i32.const 8
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 7
      local.get 7
      i32.wrap_i64
      local.get 5
      i64.store16 align=1
      local.get 4
      local.get 6
      i64.const 1
      i64.add
      i64.store16 offset=11 align=1
      local.get 4
      call $tick.1
      i64.store offset=613 align=1
      local.get 4
      i32.const 0
      i64.extend_i32_u
      i64.store offset=621 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i64.load align=1
      local.set 11
      local.get 0
      i32.const 0
      i32.add
      local.set 12
      local.get 12
      i64.load offset=613 align=1
      local.set 13
      i32.const 8
      i64.load align=1
      local.set 14
      call 0
      local.set 15
      local.get 15
      i32.const 1000463
      i32.const 6
      call 4
      local.get 15
      local.get 11
      i32.const 0
      call 1
      local.get 15
      i32.const 1000469
      i32.const 1
      call 4
      local.get 15
      local.get 13
      i32.const 0
      call 1
      local.get 15
      i32.const 1000470
      i32.const 1
      call 4
      local.get 15
      local.get 14
      i32.const 0
      call 1
      local.get 15
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 16
      local.get 16
      i32.const 11
      i32.add
      local.set 17
      i64.const 6
      local.set 18
      local.get 17
      i64.load16_u align=1
      local.set 19
      local.get 19
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1000471
        i32.const 72
        i32.const 10
        call 6
        unreachable
      end
      local.get 17
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      local.get 19
      i64.const 2
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000543
        i32.const 72
        i32.const 10
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      local.tee 23
      local.get 18
      local.set 24
      i32.wrap_i64
      local.get 24
      i64.store16 align=1
      local.get 17
      local.get 19
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 23
      i32.wrap_i64
      i64.load16_u align=1
      drop
      local.get 0
      i32.const 0
      i32.add
      local.set 25
      local.get 25
      i32.const 11
      i32.add
      local.set 26
      local.get 26
      i64.load16_u align=1
      local.set 27
      i64.const 0
      local.set 28
      local.get 26
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      local.get 28
      i64.const 2
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000615
        i32.const 72
        i32.const 10
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      local.set 31
      local.get 31
      i32.wrap_i64
      i64.load16_u align=1
      i64.const 3
      i64.add
      i64.const 65535
      i64.and
      local.set 32
      local.get 31
      local.get 32
      local.set 33
      i32.wrap_i64
      local.get 33
      i64.store16 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 34
      local.get 34
      i32.const 8
      i32.add
      local.set 35
      local.get 35
      local.set 36
      i64.const 3
      local.set 37
      i64.const 0
      local.set 38
      local.get 36
      i64.extend_i32_u
      local.set 39
      local.get 39
      i64.const 4294967295
      i64.and
      local.get 38
      i64.const 1
      i64.mul
      i64.add
      local.tee 40
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000687
        i32.const 72
        i32.const 10
        call 6
        unreachable
      end
      local.get 39
      i64.const -4294967296
      i64.and
      local.get 40
      i64.or
      local.set 41
      local.get 41
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 41
      i32.wrap_i64
      local.get 37
      i32.wrap_i64
      call 10
      local.set 42
      local.get 0
      i32.const 0
      i32.add
      local.set 43
      local.get 43
      i32.const 11
      i32.add
      local.set 44
      local.get 44
      i64.load16_u align=1
      local.set 45
      local.get 0
      i32.const 0
      i32.add
      local.set 46
      local.get 46
      i32.const 11
      i32.add
      local.set 47
      i64.const 300
      local.set 48
      local.get 0
      i32.const 0
      i32.add
      local.set 49
      local.get 49
      i32.const 11
      i32.add
      local.set 50
      local.get 50
      i64.load16_u align=1
      local.set 51
      local.get 51
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1000759
        i32.const 72
        i32.const 10
        call 6
        unreachable
      end
      local.get 51
      i64.const 1
      i64.sub
      local.set 51
      local.get 50
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 52
      local.get 52
      i64.const 4294967295
      i64.and
      local.get 51
      i64.const 2
      i64.mul
      i64.add
      local.tee 53
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000831
        i32.const 72
        i32.const 10
        call 6
        unreachable
      end
      local.get 52
      i64.const -4294967296
      i64.and
      local.get 53
      i64.or
      local.set 54
      local.get 54
      i32.wrap_i64
      i64.load16_u align=1
      local.set 55
      local.get 50
      local.get 51
      i64.store16 align=1
      local.get 55
      local.set 56
      call 0
      local.set 57
      local.get 57
      local.get 42
      call 11
      local.get 57
      i32.const 1000903
      i32.const 1
      call 4
      local.get 57
      local.get 45
      i32.const 0
      call 1
      local.get 57
      i32.const 1000904
      i32.const 1
      call 4
      local.get 57
      local.get 48
      i32.const 0
      call 1
      local.get 57
      i32.const 1000905
      i32.const 1
      call 4
      local.get 57
      local.get 56
      i32.const 1
      call 1
      local.get 57
      call 5
      local.get 0
      i32.const 629
      i32.add
      local.set 58
      local.get 0
      i32.const 0
      i32.add
      local.set 59
      local.get 58
      i64.extend_i32_u
      local.set 60
      local.get 59
      i64.extend_i32_u
      local.set 61
      i32.const 629
      local.set 62
      local.get 60
      i32.wrap_i64
      local.get 61
      i32.wrap_i64
      local.get 62
      memory.copy
      local.get 0
      i32.const 629
      i32.add
      local.set 63
      local.get 63
      i32.const 8
      i32.add
      local.set 64
      i64.const 3
      local.set 65
      i64.const 0
      local.set 66
      local.get 64
      i64.extend_i32_u
      local.set 67
      local.get 67
      i64.const 4294967295
      i64.and
      local.get 66
      i64.const 1
      i64.mul
      i64.add
      local.tee 68
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000906
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 67
      i64.const -4294967296
      i64.and
      local.get 68
      i64.or
      local.set 69
      i64.const 90
      local.set 70
      local.get 69
      local.get 70
      local.set 71
      i32.wrap_i64
      local.get 71
      i64.store8
      local.get 0
      i32.const 629
      i32.add
      local.set 72
      local.get 72
      i32.const 11
      i32.add
      local.set 73
      local.get 73
      i64.load16_u align=1
      local.set 74
      i64.const 0
      local.set 74
      local.get 73
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 75
      local.get 75
      i64.const 4294967295
      i64.and
      local.get 74
      i64.const 2
      i64.mul
      i64.add
      local.tee 76
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1000978
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 75
      i64.const -4294967296
      i64.and
      local.get 76
      i64.or
      local.set 77
      local.get 73
      local.get 74
      i64.store16 align=1
      local.get 0
      i32.const 629
      i32.add
      local.set 78
      local.get 78
      i32.const 11
      i32.add
      local.set 79
      i64.const 10
      local.set 80
      local.get 79
      i64.load16_u align=1
      local.set 81
      local.get 81
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1001050
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 79
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 83
      local.get 83
      i64.const 4294967295
      i64.and
      local.get 81
      i64.const 2
      i64.mul
      i64.add
      local.tee 84
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001122
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 83
      i64.const -4294967296
      i64.and
      local.get 84
      i64.or
      local.tee 85
      local.get 80
      local.set 86
      i32.wrap_i64
      local.get 86
      i64.store16 align=1
      local.get 79
      local.get 81
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 85
      i32.wrap_i64
      i64.load16_u align=1
      drop
      local.get 0
      i32.const 0
      i32.add
      local.set 87
      local.get 87
      i32.const 8
      i32.add
      local.set 88
      local.get 88
      local.set 89
      i64.const 3
      local.set 90
      i64.const 0
      local.set 91
      local.get 89
      i64.extend_i32_u
      local.set 92
      local.get 92
      i64.const 4294967295
      i64.and
      local.get 91
      i64.const 1
      i64.mul
      i64.add
      local.tee 93
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001194
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 92
      i64.const -4294967296
      i64.and
      local.get 93
      i64.or
      local.set 94
      local.get 94
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 94
      i32.wrap_i64
      local.get 90
      i32.wrap_i64
      call 10
      local.set 95
      local.get 0
      i32.const 629
      i32.add
      local.set 96
      local.get 96
      i32.const 8
      i32.add
      local.set 97
      local.get 97
      local.set 98
      i64.const 3
      local.set 99
      i64.const 0
      local.set 100
      local.get 98
      i64.extend_i32_u
      local.set 101
      local.get 101
      i64.const 4294967295
      i64.and
      local.get 100
      i64.const 1
      i64.mul
      i64.add
      local.tee 102
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001266
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 101
      i64.const -4294967296
      i64.and
      local.get 102
      i64.or
      local.set 103
      local.get 103
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 103
      i32.wrap_i64
      local.get 99
      i32.wrap_i64
      call 10
      local.set 104
      local.get 0
      i32.const 0
      i32.add
      local.set 105
      local.get 105
      i32.const 11
      i32.add
      local.set 106
      local.get 106
      i64.load16_u align=1
      local.set 107
      local.get 0
      i32.const 629
      i32.add
      local.set 108
      local.get 108
      i32.const 11
      i32.add
      local.set 109
      local.get 109
      i64.load16_u align=1
      local.set 110
      i64.const 0
      local.set 111
      local.get 109
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 112
      local.get 112
      i64.const 4294967295
      i64.and
      local.get 111
      i64.const 2
      i64.mul
      i64.add
      local.tee 113
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001338
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 112
      i64.const -4294967296
      i64.and
      local.get 113
      i64.or
      i32.wrap_i64
      i64.load16_u align=1
      local.set 114
      call 0
      local.set 115
      local.get 115
      local.get 95
      call 11
      local.get 115
      i32.const 1001410
      i32.const 1
      call 4
      local.get 115
      local.get 104
      call 11
      local.get 115
      i32.const 1001411
      i32.const 1
      call 4
      local.get 115
      local.get 107
      i32.const 0
      call 1
      local.get 115
      i32.const 1001412
      i32.const 1
      call 4
      local.get 115
      local.get 114
      i32.const 1
      call 1
      local.get 115
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 116
      local.get 116
      i32.const 8
      i32.add
      local.set 117
      i32.const 3
      local.set 118
      local.get 117
      i64.extend_i32_u
      local.set 119
      local.get 0
      i32.const 1258
      i32.add
      i64.extend_i32_u
      local.set 120
      local.get 120
      i32.wrap_i64
      local.get 119
      i32.wrap_i64
      local.get 118
      memory.copy
      local.get 0
      i32.const 1258
      i32.add
      local.set 121
      i64.const 3
      local.set 122
      i64.const 2
      local.set 123
      local.get 121
      i64.extend_i32_u
      local.set 124
      local.get 124
      i64.const 4294967295
      i64.and
      local.get 123
      i64.const 1
      i64.mul
      i64.add
      local.tee 125
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001413
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 124
      i64.const -4294967296
      i64.and
      local.get 125
      i64.or
      local.set 126
      i64.const 33
      local.set 127
      local.get 126
      local.get 127
      local.set 128
      i32.wrap_i64
      local.get 128
      i64.store8
      local.get 0
      i32.const 1258
      i32.add
      local.set 129
      i64.const 3
      local.set 130
      i64.const 0
      local.set 131
      local.get 129
      i64.extend_i32_u
      local.set 132
      local.get 132
      i64.const 4294967295
      i64.and
      local.get 131
      i64.const 1
      i64.mul
      i64.add
      local.tee 133
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001485
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 132
      i64.const -4294967296
      i64.and
      local.get 133
      i64.or
      local.set 134
      local.get 134
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 134
      i32.wrap_i64
      local.get 130
      i32.wrap_i64
      call 10
      local.set 135
      local.get 0
      i32.const 0
      i32.add
      local.set 136
      local.get 136
      i32.const 8
      i32.add
      local.set 137
      local.get 137
      local.set 138
      i64.const 3
      local.set 139
      i64.const 0
      local.set 140
      local.get 138
      i64.extend_i32_u
      local.set 141
      local.get 141
      i64.const 4294967295
      i64.and
      local.get 140
      i64.const 1
      i64.mul
      i64.add
      local.tee 142
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001557
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 141
      i64.const -4294967296
      i64.and
      local.get 142
      i64.or
      local.set 143
      local.get 143
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 143
      i32.wrap_i64
      local.get 139
      i32.wrap_i64
      call 10
      local.set 144
      call 0
      local.set 145
      local.get 145
      local.get 135
      call 11
      local.get 145
      i32.const 1001629
      i32.const 1
      call 4
      local.get 145
      local.get 144
      call 11
      local.get 145
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 146
      local.get 146
      i32.const 11
      i32.add
      local.set 1
      i64.const 0
      local.set 2
      i64.const 0
      local.set 148
      block ;; label = @2
        loop ;; label = @3
          local.get 1
          local.tee 149
          i32.eqz
          if ;; label = @4
            i32.const 4
            i32.const 1001630
            i32.const 72
            i32.const 14
            call 6
            unreachable
          end
          local.get 149
          local.set 150
          local.get 150
          local.set 147
          local.get 148
          local.get 147
          i64.load16_u align=1
          i64.ge_u
          br_if 1 (;@2;)
          local.get 147
          i32.const 2
          i32.add
          i64.extend_i32_u
          local.set 151
          local.get 151
          i64.const 4294967295
          i64.and
          local.get 148
          i64.const 2
          i64.mul
          i64.add
          local.tee 152
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1001702
            i32.const 72
            i32.const 14
            call 6
            unreachable
          end
          local.get 151
          i64.const -4294967296
          i64.and
          local.get 152
          i64.or
          i32.wrap_i64
          i64.load16_u align=1
          local.set 3
          block ;; label = @4
            local.get 2
            local.get 3
            i64.add
            local.set 2
          end
          local.get 148
          i64.const 1
          i64.add
          local.set 148
          br 0 (;@3;)
        end
      end
      local.get 2
      local.set 153
      call 0
      local.set 154
      local.get 154
      i32.const 1001774
      i32.const 5
      call 4
      local.get 154
      local.get 153
      i32.const 0
      call 1
      local.get 154
      call 5
      local.get 0
      i32.const 1261
      i32.add
      local.set 155
      local.get 155
      call $tick.1
      i64.store align=1
      local.get 155
      i32.const 8
      i32.add
      i32.const 0
      i32.const 3
      memory.fill
      local.get 155
      i64.const 0
      i64.store16 offset=11 align=1
      local.get 155
      call $tick.1
      i64.store offset=613 align=1
      local.get 155
      i32.const 0
      i64.extend_i32_u
      i64.store offset=621 align=1
      local.get 0
      i32.const 1261
      i32.add
      local.set 156
      local.get 156
      i64.load align=1
      local.set 157
      local.get 0
      i32.const 1261
      i32.add
      local.set 158
      local.get 158
      i64.load offset=613 align=1
      local.set 159
      local.get 0
      i32.const 1261
      i32.add
      local.set 160
      local.get 160
      i32.const 8
      i32.add
      local.set 161
      i64.const 3
      local.set 162
      i64.const 0
      local.set 163
      local.get 161
      i64.extend_i32_u
      local.set 164
      local.get 164
      i64.const 4294967295
      i64.and
      local.get 163
      i64.const 1
      i64.mul
      i64.add
      local.tee 165
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001779
        i32.const 72
        i32.const 15
        call 6
        unreachable
      end
      local.get 164
      i64.const -4294967296
      i64.and
      local.get 165
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 166
      local.get 0
      i32.const 1261
      i32.add
      local.set 167
      local.get 167
      i32.const 11
      i32.add
      local.set 168
      local.get 168
      i64.load16_u align=1
      local.set 169
      local.get 0
      i32.const 1261
      i32.add
      local.set 170
      local.get 170
      i64.load offset=621 align=1
      i32.wrap_i64
      local.set 171
      i32.const 0
      local.set 172
      local.get 172
      local.get 171
      i32.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 172
      else
        local.get 171
        local.set 173
      end
      local.get 172
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 1001851
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 174
        i64.const 0
        local.set 175
        local.get 173
        i64.extend_i32_u
        local.set 176
        local.get 176
        i64.const 4294967295
        i64.and
        local.get 175
        i64.const 1
        i64.mul
        i64.add
        local.tee 177
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1001855
          i32.const 72
          i32.const 15
          call 6
          unreachable
        end
        local.get 176
        i64.const -4294967296
        i64.and
        local.get 177
        i64.or
        local.set 178
        local.get 178
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 178
        i32.wrap_i64
        local.get 174
        i32.wrap_i64
        call 10
      end
      local.set 179
      call 0
      local.set 180
      local.get 180
      i32.const 1001927
      i32.const 8
      call 4
      local.get 180
      local.get 157
      i32.const 0
      call 1
      local.get 180
      i32.const 1001935
      i32.const 1
      call 4
      local.get 180
      local.get 159
      i32.const 0
      call 1
      local.get 180
      i32.const 1001936
      i32.const 1
      call 4
      local.get 180
      local.get 166
      i32.const 1
      call 1
      local.get 180
      i32.const 1001937
      i32.const 1
      call 4
      local.get 180
      local.get 169
      i32.const 0
      call 1
      local.get 180
      i32.const 1001938
      i32.const 1
      call 4
      local.get 180
      local.get 179
      call 11
      local.get 180
      call 5
      local.get 0
      i32.const 1890
      i32.add
      local.set 181
      local.get 181
      i64.const 0
      i64.store8
      call $tick.1
      local.set 183
      local.get 181
      i64.const 42
      i64.store offset=9 align=1
      local.get 0
      i32.const 1890
      i32.add
      local.set 184
      local.get 184
      local.set 185
      local.get 185
      i64.load8_u
      local.set 186
      local.get 0
      i32.const 1890
      i32.add
      local.set 187
      local.get 187
      i64.load offset=9 align=1
      local.set 188
      i32.const 8
      i64.load align=1
      local.set 189
      call 0
      local.set 190
      local.get 190
      i32.const 1001939
      i32.const 5
      call 4
      local.get 190
      local.get 186
      i32.const 0
      call 1
      local.get 190
      i32.const 1001944
      i32.const 1
      call 4
      local.get 190
      local.get 188
      i32.const 0
      call 1
      local.get 190
      i32.const 1001945
      i32.const 1
      call 4
      local.get 190
      local.get 189
      i32.const 0
      call 1
      local.get 190
      call 5
      i32.const 16
      local.set 191
      local.get 191
      local.set 192
      local.get 192
      i64.load32_u align=1
      local.set 193
      i32.const 16
      local.set 194
      local.get 194
      i64.load offset=1000004 align=1
      local.set 195
      call 0
      local.set 196
      local.get 196
      i32.const 1001946
      i32.const 7
      call 4
      local.get 196
      local.get 193
      i32.const 0
      call 1
      local.get 196
      i32.const 1001953
      i32.const 1
      call 4
      local.get 196
      local.get 195
      i32.const 0
      call 1
      local.get 196
      call 5
      local.get 0
      i32.const 1907
      i32.add
      local.set 197
      local.get 197
      i32.const 0
      i32.const 4
      memory.fill
      local.get 0
      i32.const 1907
      i32.add
      local.set 198
      i64.const 4
      local.set 199
      i64.const 3
      local.set 200
      local.get 198
      i64.extend_i32_u
      local.set 201
      local.get 201
      i64.const 4294967295
      i64.and
      local.get 200
      i64.const 1
      i64.mul
      i64.add
      local.tee 202
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1001954
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 201
      i64.const -4294967296
      i64.and
      local.get 202
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 203
      call 0
      local.set 204
      local.get 204
      i32.const 1002026
      i32.const 6
      call 4
      local.get 204
      local.get 203
      i32.const 1
      call 1
      local.get 204
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $tick.1 (;15;) (type 12) (result i64)
    (local i32 i64 i64)
    block ;; label = @1
      i32.const 8
      i64.load align=1
      i64.const 1
      i64.add
      local.set 2
      i32.const 8
      local.get 2
      i64.store align=1
      i32.const 8
      i64.load align=1
      local.set 1
      br 0 (;@1;)
    end
    local.get 1
  )
  (func $goose.init (;16;) (type 11)
    (local i32 i64 i32)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
    i32.const 16
    local.set 2
    local.get 2
    i64.const 0
    i64.store32 align=1
    local.get 2
    i64.const 99
    i64.store offset=1000004 align=1
  )
  (func $goose.start (;17;) (type 11)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 1000028) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goosea\00b/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.gooseorder=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.gooseloop=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goosenull/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.goosedefault=,,,,zero=,,sparse=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_arrays.gooseplain=")
)
