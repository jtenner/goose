(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32) (result i64)))
  (type (;12;) (func (param i64) (result i64)))
  (type (;13;) (func (param i64 i64)))
  (type (;14;) (func (param i32 i32) (result i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (memory (;5;) 1 65536)
  (memory (;6;) 1 65536)
  (memory (;7;) 1 65536)
  (memory (;8;) 1 65536)
  (memory (;9;) 1 65536)
  (memory (;10;) 1 65536)
  (memory (;11;) 1 65536)
  (memory (;12;) 1 65536)
  (memory (;13;) 1 65536)
  (memory (;14;) 1 65536)
  (global (;0;) (mut i32) i32.const 2624)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (global (;5;) (mut i32) i32.const 1)
  (global (;6;) (mut i32) i32.const 1)
  (global (;7;) (mut i32) i32.const 1)
  (global (;8;) (mut i32) i32.const 1)
  (global (;9;) (mut i32) i32.const 1)
  (global (;10;) (mut i32) i32.const 1)
  (global (;11;) (mut i32) i32.const 1)
  (global (;12;) (mut i32) i32.const 1)
  (global (;13;) (mut i32) i32.const 1)
  (global (;14;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "data_memory_5" (memory 5))
  (export "data_memory_6" (memory 6))
  (export "data_memory_7" (memory 7))
  (export "data_memory_8" (memory 8))
  (export "data_memory_9" (memory 9))
  (export "data_memory_10" (memory 10))
  (export "data_memory_11" (memory 11))
  (export "data_memory_12" (memory 12))
  (export "data_memory_13" (memory 13))
  (export "data_memory_14" (memory 14))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 24
      i32.const 70
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 94
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 f32 i64 i64 i32 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 f32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 155
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 0
      call $large.1
      local.set 10
      call 0
      local.set 11
      local.get 11
      i32.const 164
      i32.const 7
      call 4
      local.get 11
      local.get 10
      i32.const 0
      call 1
      local.get 11
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 13
      local.get 13
      i64.extend_i32_u
      local.set 12
      i32.const 0
      call $tick.2
      local.set 14
      i64.const 0
      local.set 15
      block ;; label = @2
        loop ;; label = @3
          local.get 15
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 12
          i32.wrap_i64
          local.get 15
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 14
          i64.store align=1
          local.get 15
          i64.const 1
          i64.add
          local.set 15
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 24
      i32.add
      local.set 17
      local.get 17
      i64.const 2
      i64.store8
      local.get 17
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 16
      i32.const 0
      call $tick.2
      local.set 18
      i64.const 0
      local.set 19
      block ;; label = @2
        loop ;; label = @3
          local.get 19
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 16
          i32.wrap_i64
          local.get 19
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 18
          i64.store align=1
          local.get 19
          i64.const 1
          i64.add
          local.set 19
          br 0 (;@3;)
        end
      end
      local.get 17
      i32.const 17
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      i32.const 1
      local.set 21
      i32.const 25
      call $goose.reserve_memory.1
      local.set 22
      local.get 21
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 22
      i64.extend_i32_u
      i64.or
      local.set 20
      local.get 20
      local.set 1
      local.get 20
      i64.const 3
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store8 1
      i32.const 1
      call $tick.2
      local.set 24
      i64.const 0
      local.set 25
      block ;; label = @2
        loop ;; label = @3
          local.get 25
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 20
          i32.wrap_i64
          local.get 25
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 1
          i32.add
          local.get 24
          i64.store 1 align=1
          local.get 25
          i64.const 1
          i64.add
          local.set 25
          br 0 (;@3;)
        end
      end
      i32.const 2
      local.set 27
      i32.const 24
      call $goose.reserve_memory.2
      local.set 28
      local.get 27
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 28
      i64.extend_i32_u
      i64.or
      local.set 26
      local.get 0
      i32.const 57
      i32.add
      local.get 26
      i64.store align=1
      local.get 0
      i32.const 57
      i32.add
      i64.const 3
      i64.store offset=8 align=1
      i32.const 2
      call $tick.2
      local.set 29
      i64.const 0
      local.set 30
      block ;; label = @2
        loop ;; label = @3
          local.get 30
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 26
          i32.wrap_i64
          local.get 30
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 29
          i64.store 2 align=1
          local.get 30
          i64.const 1
          i64.add
          local.set 30
          br 0 (;@3;)
        end
      end
      i32.const 3
      local.set 32
      i32.const 16
      call $goose.reserve_memory.3
      local.set 33
      local.get 32
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 33
      i64.extend_i32_u
      i64.or
      local.set 31
      local.get 0
      i32.const 73
      i32.add
      local.get 31
      i64.store align=1
      local.get 0
      i32.const 73
      i32.add
      i64.const 2
      i64.store offset=8 align=1
      i32.const 3
      call $tick.2
      local.set 34
      i64.const 0
      local.set 35
      block ;; label = @2
        loop ;; label = @3
          local.get 35
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 31
          i32.wrap_i64
          local.get 35
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 34
          i64.store 3 align=1
          local.get 35
          i64.const 1
          i64.add
          local.set 35
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 36
      i64.const 11
      local.set 37
      local.get 36
      i32.wrap_i64
      i64.load8_u
      local.set 38
      local.get 38
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 171
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 36
      local.set 40
      local.get 40
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 38
      i64.const 8
      i64.mul
      i64.add
      local.tee 41
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 241
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 40
      i64.const -4294967296
      i64.and
      local.get 41
      i64.or
      local.tee 42
      local.get 37
      local.set 43
      i32.wrap_i64
      local.get 43
      i64.store align=1
      local.get 36
      local.get 38
      i64.const 1
      i64.add
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store8
      local.get 42
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 57
      i32.add
      local.set 44
      i64.const 12
      local.set 45
      local.get 44
      i64.load offset=8 align=1
      local.set 46
      i32.const 8
      call $goose.reserve_memory.2
      local.set 47
      local.get 44
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 47
      i64.extend_i32_u
      i64.or
      local.tee 48
      local.get 45
      local.set 49
      i32.wrap_i64
      local.get 49
      i64.store 2 align=1
      local.get 44
      local.get 46
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 48
      i32.wrap_i64
      i64.load 2 align=1
      drop
      local.get 0
      i32.const 73
      i32.add
      local.set 50
      local.get 50
      i64.load offset=8 align=1
      local.set 51
      local.get 51
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 311
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 51
      i64.const 1
      i64.sub
      local.set 51
      local.get 50
      i64.load align=1
      local.set 52
      local.get 52
      i64.const 4294967295
      i64.and
      local.get 51
      i64.const 8
      i64.mul
      i64.add
      local.tee 53
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 381
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 52
      i64.const -4294967296
      i64.and
      local.get 53
      i64.or
      local.set 54
      local.get 54
      i32.wrap_i64
      i64.load 3 align=1
      local.set 55
      local.get 54
      i32.wrap_i64
      global.set 3
      local.get 50
      local.get 51
      i64.store offset=8 align=1
      local.get 55
      drop
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 56
      i64.const 3
      local.set 57
      i64.const 0
      local.set 58
      local.get 56
      local.set 59
      local.get 59
      i64.const 4294967295
      i64.and
      local.get 58
      i64.const 8
      i64.mul
      i64.add
      local.tee 60
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 451
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 59
      i64.const -4294967296
      i64.and
      local.get 60
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 61
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 62
      i64.const 3
      local.set 63
      i64.const 2
      local.set 64
      local.get 62
      local.set 65
      local.get 65
      i64.const 4294967295
      i64.and
      local.get 64
      i64.const 8
      i64.mul
      i64.add
      local.tee 66
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 521
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 65
      i64.const -4294967296
      i64.and
      local.get 66
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 67
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 68
      local.get 68
      i32.wrap_i64
      i64.load8_u
      local.set 69
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 70
      local.get 70
      i32.wrap_i64
      i64.load8_u
      local.set 71
      i64.const 0
      local.set 72
      local.get 70
      local.set 73
      local.get 73
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 72
      i64.const 8
      i64.mul
      i64.add
      local.tee 74
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 591
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 73
      i64.const -4294967296
      i64.and
      local.get 74
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 75
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 76
      local.get 76
      i32.wrap_i64
      i64.load8_u
      local.set 77
      i64.const 2
      local.set 78
      local.get 76
      local.set 79
      local.get 79
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 78
      i64.const 8
      i64.mul
      i64.add
      local.tee 80
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 661
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 79
      i64.const -4294967296
      i64.and
      local.get 80
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 81
      call 0
      local.set 82
      local.get 82
      local.get 61
      i32.const 0
      call 1
      local.get 82
      i32.const 731
      i32.const 1
      call 4
      local.get 82
      local.get 67
      i32.const 0
      call 1
      local.get 82
      i32.const 732
      i32.const 1
      call 4
      local.get 82
      local.get 69
      i32.const 0
      call 1
      local.get 82
      i32.const 733
      i32.const 1
      call 4
      local.get 82
      local.get 75
      i32.const 0
      call 1
      local.get 82
      i32.const 734
      i32.const 1
      call 4
      local.get 82
      local.get 81
      i32.const 0
      call 1
      local.get 82
      call 5
      local.get 1
      local.set 83
      local.get 83
      i32.wrap_i64
      i64.load8_u 1
      local.set 84
      local.get 1
      local.set 85
      local.get 85
      i32.wrap_i64
      i64.load8_u 1
      local.set 86
      i64.const 0
      local.set 87
      local.get 85
      local.set 88
      local.get 88
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 87
      i64.const 8
      i64.mul
      i64.add
      local.tee 89
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 735
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 88
      i64.const -4294967296
      i64.and
      local.get 89
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 90
      local.get 1
      local.set 91
      local.get 91
      i32.wrap_i64
      i64.load8_u 1
      local.set 92
      i64.const 2
      local.set 93
      local.get 91
      local.set 94
      local.get 94
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 93
      i64.const 8
      i64.mul
      i64.add
      local.tee 95
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 805
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 94
      i64.const -4294967296
      i64.and
      local.get 95
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 96
      local.get 0
      i32.const 57
      i32.add
      local.set 97
      local.get 97
      i64.load offset=8 align=1
      local.set 98
      local.get 0
      i32.const 57
      i32.add
      local.set 99
      local.get 99
      i64.load offset=8 align=1
      local.set 100
      i64.const 2
      local.set 101
      local.get 99
      i64.load align=1
      local.set 102
      local.get 102
      i64.const 4294967295
      i64.and
      local.get 101
      i64.const 8
      i64.mul
      i64.add
      local.tee 103
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 875
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 102
      i64.const -4294967296
      i64.and
      local.get 103
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 104
      local.get 0
      i32.const 57
      i32.add
      local.set 105
      local.get 105
      i64.load offset=8 align=1
      local.set 106
      i64.const 3
      local.set 107
      local.get 105
      i64.load align=1
      local.set 108
      local.get 108
      i64.const 4294967295
      i64.and
      local.get 107
      i64.const 8
      i64.mul
      i64.add
      local.tee 109
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 945
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 109
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 110
      call 0
      local.set 111
      local.get 111
      local.get 84
      i32.const 0
      call 1
      local.get 111
      i32.const 1015
      i32.const 1
      call 4
      local.get 111
      local.get 90
      i32.const 0
      call 1
      local.get 111
      i32.const 1016
      i32.const 1
      call 4
      local.get 111
      local.get 96
      i32.const 0
      call 1
      local.get 111
      i32.const 1017
      i32.const 1
      call 4
      local.get 111
      local.get 98
      i32.const 0
      call 1
      local.get 111
      i32.const 1018
      i32.const 1
      call 4
      local.get 111
      local.get 104
      i32.const 0
      call 1
      local.get 111
      i32.const 1019
      i32.const 1
      call 4
      local.get 111
      local.get 110
      i32.const 0
      call 1
      local.get 111
      call 5
      local.get 0
      i32.const 73
      i32.add
      local.set 112
      local.get 112
      i64.load offset=8 align=1
      local.set 113
      local.get 0
      i32.const 73
      i32.add
      local.set 114
      local.get 114
      i64.load offset=8 align=1
      local.set 115
      i64.const 0
      local.set 116
      local.get 114
      i64.load align=1
      local.set 117
      local.get 117
      i64.const 4294967295
      i64.and
      local.get 116
      i64.const 8
      i64.mul
      i64.add
      local.tee 118
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1020
        i32.const 70
        i32.const 22
        call 6
        unreachable
      end
      local.get 117
      i64.const -4294967296
      i64.and
      local.get 118
      i64.or
      i32.wrap_i64
      i64.load 3 align=1
      local.set 119
      i32.const 8
      i64.load align=1
      local.set 120
      call 0
      local.set 121
      local.get 121
      local.get 113
      i32.const 0
      call 1
      local.get 121
      i32.const 1090
      i32.const 1
      call 4
      local.get 121
      local.get 119
      i32.const 0
      call 1
      local.get 121
      i32.const 1091
      i32.const 1
      call 4
      local.get 121
      local.get 120
      i32.const 0
      call 1
      local.get 121
      call 5
      local.get 0
      i32.const 89
      i32.add
      local.set 123
      local.get 123
      i64.extend_i32_u
      local.set 122
      i32.const 3
      call $tick.2
      local.set 124
      local.get 0
      i32.const 90
      i32.add
      local.set 126
      local.get 126
      i64.const 0
      i64.store8
      local.get 126
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 125
      i32.const 3
      call $tick.2
      local.set 127
      local.get 126
      i32.const 1
      i32.add
      i32.const 0
      i32.const 24
      memory.fill
      i32.const 4
      local.set 129
      i32.const 4
      call $goose.reserve_memory.4
      local.set 130
      local.get 129
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 130
      i64.extend_i32_u
      i64.or
      local.set 128
      local.get 128
      local.set 2
      local.get 128
      i64.const 0
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store32 4 align=1
      i32.const 4
      call $tick.2
      local.set 131
      i32.const 5
      local.set 133
      i32.const 0
      call $goose.reserve_memory.5
      local.set 134
      local.get 133
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 134
      i64.extend_i32_u
      i64.or
      local.set 132
      local.get 0
      i32.const 115
      i32.add
      local.get 132
      i64.store align=1
      local.get 0
      i32.const 115
      i32.add
      i64.const 0
      i64.store offset=8 align=1
      i32.const 5
      call $tick.2
      local.set 135
      i64.const 0
      local.set 136
      local.get 0
      i32.const 90
      i32.add
      i64.extend_i32_u
      local.set 137
      local.get 137
      i32.wrap_i64
      i64.load8_u
      local.set 138
      local.get 2
      local.set 139
      local.get 139
      i32.wrap_i64
      i64.load32_u 4 align=1
      local.set 140
      local.get 0
      i32.const 115
      i32.add
      local.set 141
      local.get 141
      i64.load offset=8 align=1
      local.set 142
      i32.const 8
      i64.load align=1
      local.set 143
      call 0
      local.set 144
      local.get 144
      i32.const 1092
      i32.const 6
      call 4
      local.get 144
      local.get 136
      i32.const 0
      call 1
      local.get 144
      i32.const 1098
      i32.const 1
      call 4
      local.get 144
      local.get 138
      i32.const 0
      call 1
      local.get 144
      i32.const 1099
      i32.const 1
      call 4
      local.get 144
      local.get 140
      i32.const 0
      call 1
      local.get 144
      i32.const 1100
      i32.const 1
      call 4
      local.get 144
      local.get 142
      i32.const 0
      call 1
      local.get 144
      i32.const 1101
      i32.const 1
      call 4
      local.get 144
      local.get 143
      i32.const 0
      call 1
      local.get 144
      call 5
      i64.const 20
      local.set 145
      local.get 0
      i32.const 131
      i32.add
      local.get 145
      i64.store align=1
      i32.const 6
      local.set 147
      i32.const 28
      call $goose.reserve_memory.6
      local.set 148
      local.get 147
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 148
      i64.extend_i32_u
      i64.or
      local.set 146
      local.get 146
      local.set 3
      local.get 146
      i64.const 3
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store32 6 align=1
      local.get 0
      i32.const 131
      i32.add
      i64.extend_i32_u
      local.set 149
      i64.const 0
      local.set 150
      block ;; label = @2
        loop ;; label = @3
          local.get 150
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 146
          i32.wrap_i64
          local.get 150
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 4
          i32.add
          local.get 149
          i64.store 6 align=1
          local.get 150
          i64.const 1
          i64.add
          local.set 150
          br 0 (;@3;)
        end
      end
      local.get 3
      local.set 151
      i64.const 0
      local.set 152
      block ;; label = @2
        loop ;; label = @3
          local.get 152
          local.get 151
          i32.wrap_i64
          i64.load32_u 6 align=1
          i64.ge_u
          br_if 1 (;@2;)
          local.get 151
          local.set 153
          local.get 153
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 152
          i64.const 8
          i64.mul
          i64.add
          local.tee 154
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1102
            i32.const 70
            i32.const 30
            call 6
            unreachable
          end
          local.get 153
          i64.const -4294967296
          i64.and
          local.get 154
          i64.or
          i32.wrap_i64
          i64.load 6 align=1
          local.set 4
          block ;; label = @4
            local.get 4
            local.tee 155
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 1172
              i32.const 70
              i32.const 30
              call 6
              unreachable
            end
            local.get 155
            local.set 156
            local.get 156
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 157
            local.get 156
            local.get 157
            call $goose.memory_op.55
          end
          local.get 152
          i64.const 1
          i64.add
          local.set 152
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 131
      i32.add
      i64.load align=1
      local.set 158
      local.get 3
      local.set 159
      local.get 159
      i32.wrap_i64
      i64.load32_u 6 align=1
      local.set 160
      i64.const 0
      local.set 161
      local.get 159
      local.set 162
      local.get 162
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 161
      i64.const 8
      i64.mul
      i64.add
      local.tee 163
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1242
        i32.const 70
        i32.const 31
        call 6
        unreachable
      end
      local.get 162
      i64.const -4294967296
      i64.and
      local.get 163
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.tee 164
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1312
        i32.const 70
        i32.const 29
        call 6
        unreachable
      end
      local.get 164
      call $goose.memory_op.41
      local.set 165
      local.get 3
      local.set 166
      local.get 166
      i32.wrap_i64
      i64.load32_u 6 align=1
      local.set 167
      i64.const 2
      local.set 168
      local.get 166
      local.set 169
      local.get 169
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 168
      i64.const 8
      i64.mul
      i64.add
      local.tee 170
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1382
        i32.const 70
        i32.const 31
        call 6
        unreachable
      end
      local.get 169
      i64.const -4294967296
      i64.and
      local.get 170
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.tee 171
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1452
        i32.const 70
        i32.const 29
        call 6
        unreachable
      end
      local.get 171
      call $goose.memory_op.41
      local.set 172
      call 0
      local.set 173
      local.get 173
      i32.const 1522
      i32.const 5
      call 4
      local.get 173
      local.get 158
      i32.const 0
      call 1
      local.get 173
      i32.const 1527
      i32.const 1
      call 4
      local.get 173
      local.get 165
      i32.const 0
      call 1
      local.get 173
      i32.const 1528
      i32.const 1
      call 4
      local.get 173
      local.get 172
      i32.const 0
      call 1
      local.get 173
      call 5
      local.get 0
      i32.const 139
      i32.add
      local.set 174
      local.get 174
      i32.const 0
      i32.add
      i64.const 8
      i64.store align=1
      local.get 174
      i32.const 8
      i32.add
      i64.const 9
      i64.store align=1
      i32.const 7
      local.set 176
      i32.const 20
      call $goose.reserve_memory.7
      local.set 177
      local.get 176
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 177
      i64.extend_i32_u
      i64.or
      local.set 175
      local.get 175
      local.set 5
      local.get 175
      i64.const 2
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store32 7 align=1
      local.get 0
      i32.const 139
      i32.add
      i64.extend_i32_u
      local.set 178
      i64.const 0
      local.set 179
      block ;; label = @2
        loop ;; label = @3
          local.get 179
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 175
          i32.wrap_i64
          local.get 179
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 4
          i32.add
          local.get 178
          i64.store 7 align=1
          local.get 179
          i64.const 1
          i64.add
          local.set 179
          br 0 (;@3;)
        end
      end
      local.get 5
      local.set 180
      local.get 180
      i32.wrap_i64
      i64.load32_u 7 align=1
      local.set 181
      i64.const 0
      local.set 182
      local.get 180
      local.set 183
      local.get 183
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 182
      i64.const 8
      i64.mul
      i64.add
      local.tee 184
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1529
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 183
      i64.const -4294967296
      i64.and
      local.get 184
      i64.or
      i32.wrap_i64
      i64.load 7 align=1
      local.tee 185
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1599
        i32.const 70
        i32.const 33
        call 6
        unreachable
      end
      local.get 185
      local.set 186
      i64.const 2
      local.set 187
      i64.const 0
      local.set 188
      local.get 186
      local.set 189
      local.get 189
      i64.const 4294967295
      i64.and
      local.get 188
      i64.const 8
      i64.mul
      i64.add
      local.tee 190
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1669
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 189
      i64.const -4294967296
      i64.and
      local.get 190
      i64.or
      local.set 191
      local.get 191
      call $goose.memory_op.41
      i64.const 2
      i64.add
      local.set 192
      local.get 191
      local.get 192
      call $goose.memory_op.55
      local.get 5
      local.set 193
      local.get 193
      i32.wrap_i64
      i64.load32_u 7 align=1
      local.set 194
      i64.const 1
      local.set 195
      local.get 193
      local.set 196
      local.get 196
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 195
      i64.const 8
      i64.mul
      i64.add
      local.tee 197
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1739
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 196
      i64.const -4294967296
      i64.and
      local.get 197
      i64.or
      i32.wrap_i64
      i64.load 7 align=1
      local.tee 198
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1809
        i32.const 70
        i32.const 33
        call 6
        unreachable
      end
      local.get 198
      local.set 199
      i64.const 2
      local.set 200
      i64.const 0
      local.set 201
      local.get 199
      local.set 202
      local.get 202
      i64.const 4294967295
      i64.and
      local.get 201
      i64.const 8
      i64.mul
      i64.add
      local.tee 203
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1879
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 202
      i64.const -4294967296
      i64.and
      local.get 203
      i64.or
      call $goose.memory_op.41
      local.set 204
      call 0
      local.set 205
      local.get 205
      i32.const 1949
      i32.const 5
      call 4
      local.get 205
      local.get 204
      i32.const 0
      call 1
      local.get 205
      call 5
      i32.const 8
      local.set 207
      i32.const 16
      call $goose.reserve_memory.8
      local.set 208
      local.get 207
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 208
      i64.extend_i32_u
      i64.or
      local.set 206
      local.get 206
      local.set 6
      local.get 206
      i64.const 2
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store 8 align=1
      f32.const -0x0p+0 (;=-0;)
      local.set 209
      i64.const 0
      local.set 210
      block ;; label = @2
        loop ;; label = @3
          local.get 210
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 206
          i32.wrap_i64
          local.get 210
          i32.wrap_i64
          i32.const 4
          i32.mul
          i32.add
          i32.const 8
          i32.add
          local.get 209
          f32.store 8 align=1
          local.get 210
          i64.const 1
          i64.add
          local.set 210
          br 0 (;@3;)
        end
      end
      i32.const 9
      local.set 212
      i32.const 5
      call $goose.reserve_memory.9
      local.set 213
      local.get 212
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 213
      i64.extend_i32_u
      i64.or
      local.set 211
      local.get 211
      local.set 7
      local.get 211
      i64.const 3
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store16 9 align=1
      i32.const 1
      local.set 214
      i64.const 0
      local.set 215
      block ;; label = @2
        loop ;; label = @3
          local.get 215
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 211
          i32.wrap_i64
          local.get 215
          i32.wrap_i64
          i32.const 1
          i32.mul
          i32.add
          i32.const 2
          i32.add
          local.get 214
          i32.store8 9
          local.get 215
          i64.const 1
          i64.add
          local.set 215
          br 0 (;@3;)
        end
      end
      i32.const 10
      local.set 217
      i32.const 5
      call $goose.reserve_memory.10
      local.set 218
      local.get 217
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 218
      i64.extend_i32_u
      i64.or
      local.set 216
      local.get 216
      local.set 8
      local.get 216
      i64.const 4
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store8 10
      i64.const 255
      local.set 219
      i64.const 0
      local.set 220
      block ;; label = @2
        loop ;; label = @3
          local.get 220
          i64.const 4
          i64.ge_u
          br_if 1 (;@2;)
          local.get 216
          i32.wrap_i64
          local.get 220
          i32.wrap_i64
          i32.const 1
          i32.mul
          i32.add
          i32.const 1
          i32.add
          local.get 219
          i64.store8 10
          local.get 220
          i64.const 1
          i64.add
          local.set 220
          br 0 (;@3;)
        end
      end
      local.get 6
      local.set 221
      local.get 221
      i32.wrap_i64
      i64.load 8 align=1
      local.set 222
      i64.const 1
      local.set 223
      local.get 221
      local.set 224
      local.get 224
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 223
      i64.const 4
      i64.mul
      i64.add
      local.tee 225
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1954
        i32.const 70
        i32.const 38
        call 6
        unreachable
      end
      local.get 224
      i64.const -4294967296
      i64.and
      local.get 225
      i64.or
      i32.wrap_i64
      f32.load 8 align=1
      local.set 226
      local.get 7
      local.set 227
      local.get 227
      i32.wrap_i64
      i64.load16_u 9 align=1
      local.set 228
      i64.const 2
      local.set 229
      local.get 227
      local.set 230
      local.get 230
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 229
      i64.const 1
      i64.mul
      i64.add
      local.tee 231
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2024
        i32.const 70
        i32.const 38
        call 6
        unreachable
      end
      local.get 230
      i64.const -4294967296
      i64.and
      local.get 231
      i64.or
      i32.wrap_i64
      i32.load8_u 9
      local.set 232
      local.get 8
      local.set 233
      local.get 233
      i32.wrap_i64
      i64.load8_u 10
      local.set 234
      i64.const 3
      local.set 235
      local.get 233
      local.set 236
      local.get 236
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 235
      i64.const 1
      i64.mul
      i64.add
      local.tee 237
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2094
        i32.const 70
        i32.const 38
        call 6
        unreachable
      end
      local.get 236
      i64.const -4294967296
      i64.and
      local.get 237
      i64.or
      i32.wrap_i64
      i64.load8_u 10
      local.set 238
      call 0
      local.set 239
      local.get 239
      i32.const 2164
      i32.const 7
      call 4
      local.get 239
      local.get 226
      f64.promote_f32
      i32.const 32
      call 2
      local.get 239
      i32.const 2171
      i32.const 1
      call 4
      local.get 239
      local.get 232
      call 3
      local.get 239
      i32.const 2172
      i32.const 1
      call 4
      local.get 239
      local.get 238
      i32.const 1
      call 1
      local.get 239
      call 5
      i32.const 11
      local.set 241
      i32.const 72004
      call $goose.reserve_memory.11
      local.set 242
      local.get 241
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 242
      i64.extend_i32_u
      i64.or
      local.set 240
      local.get 240
      local.set 9
      local.get 240
      i64.const 9000
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store32 11 align=1
      i64.const 123
      local.set 243
      i64.const 0
      local.set 244
      block ;; label = @2
        loop ;; label = @3
          local.get 244
          i64.const 9000
          i64.ge_u
          br_if 1 (;@2;)
          local.get 240
          i32.wrap_i64
          local.get 244
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 4
          i32.add
          local.get 243
          i64.store 11 align=1
          local.get 244
          i64.const 1
          i64.add
          local.set 244
          br 0 (;@3;)
        end
      end
      local.get 9
      local.set 245
      local.get 245
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 246
      local.get 9
      local.set 247
      local.get 247
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 248
      i64.const 8999
      local.set 249
      local.get 247
      local.set 250
      local.get 250
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 249
      i64.const 8
      i64.mul
      i64.add
      local.tee 251
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2173
        i32.const 70
        i32.const 40
        call 6
        unreachable
      end
      local.get 250
      i64.const -4294967296
      i64.and
      local.get 251
      i64.or
      i32.wrap_i64
      i64.load 11 align=1
      local.set 252
      call 0
      local.set 253
      local.get 253
      i32.const 2243
      i32.const 7
      call 4
      local.get 253
      local.get 246
      i32.const 0
      call 1
      local.get 253
      i32.const 2250
      i32.const 1
      call 4
      local.get 253
      local.get 252
      i32.const 0
      call 1
      local.get 253
      call 5
      i32.const 11
      call $large.1
      local.set 254
      i32.const 8
      i64.load align=1
      local.set 255
      i32.const 16
      i64.load align=1
      local.set 256
      local.get 256
      i32.wrap_i64
      i64.load8_u 14
      local.set 257
      i32.const 16
      i64.load align=1
      local.set 258
      local.get 258
      i32.wrap_i64
      i64.load8_u 14
      local.set 259
      i64.const 3
      local.set 260
      local.get 260
      local.get 259
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2251
        i32.const 70
        i32.const 41
        call 6
        unreachable
      end
      local.get 258
      local.set 261
      local.get 261
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 260
      i64.const 2
      i64.mul
      i64.add
      local.tee 262
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2321
        i32.const 70
        i32.const 41
        call 6
        unreachable
      end
      local.get 261
      i64.const -4294967296
      i64.and
      local.get 262
      i64.or
      i32.wrap_i64
      i64.load16_s 14 align=1
      local.set 263
      call 0
      local.set 264
      local.get 264
      i32.const 2391
      i32.const 6
      call 4
      local.get 264
      local.get 254
      i32.const 0
      call 1
      local.get 264
      i32.const 2397
      i32.const 1
      call 4
      local.get 264
      local.get 255
      i32.const 0
      call 1
      local.get 264
      i32.const 2398
      i32.const 1
      call 4
      local.get 264
      local.get 257
      i32.const 0
      call 1
      local.get 264
      i32.const 2399
      i32.const 1
      call 4
      local.get 264
      local.get 263
      i32.const 0
      call 1
      local.get 264
      call 5
      local.get 242
      global.set 11
      local.get 218
      global.set 10
      local.get 213
      global.set 9
      local.get 208
      global.set 8
      local.get 177
      global.set 7
      local.get 148
      global.set 6
      local.get 134
      global.set 5
      local.get 130
      global.set 4
      local.get 33
      global.set 3
      local.get 28
      global.set 2
      local.get 22
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $large.1 (;12;) (type 11) (param i32) (result i64)
    (local i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      i32.const 1
      i32.add
      local.set 5
      local.get 5
      i32.const 72002
      call $goose.reserve_data
      local.set 6
      local.get 5
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 6
      i64.extend_i32_u
      i64.or
      local.set 4
      local.get 4
      local.set 2
      local.get 4
      i64.const 9000
      call $goose.memory_op.61
      local.get 0
      i32.const 1
      i32.add
      call $tick.2
      local.set 7
      i64.const 0
      local.set 8
      block ;; label = @2
        loop ;; label = @3
          local.get 8
          i64.const 9000
          i64.ge_u
          br_if 1 (;@2;)
          local.get 4
          local.get 8
          i64.const 8
          i64.mul
          i64.add
          i64.const 2
          i64.add
          local.get 7
          call $goose.memory_op.55
          local.get 8
          i64.const 1
          i64.add
          local.set 8
          br 0 (;@3;)
        end
      end
      local.get 2
      local.set 9
      local.get 9
      call $goose.memory_op.51
      local.set 10
      i64.const 0
      local.set 11
      local.get 9
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 11
      i64.const 8
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2400
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      call $goose.memory_op.41
      local.get 2
      local.set 14
      local.get 14
      call $goose.memory_op.51
      local.set 15
      i64.const 8999
      local.set 16
      local.get 14
      local.set 17
      local.get 17
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 16
      i64.const 8
      i64.mul
      i64.add
      local.tee 18
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2470
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      local.get 17
      i64.const -4294967296
      i64.and
      local.get 18
      i64.or
      call $goose.memory_op.41
      i64.add
      local.set 3
      local.get 5
      local.get 6
      call $goose.restore_data
      br 0 (;@1;)
      local.get 5
      local.get 6
      call $goose.restore_data
    end
    local.get 3
  )
  (func $tick.2 (;13;) (type 11) (param i32) (result i64)
    (local i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 8
      i64.load align=1
      i64.const 1
      i64.add
      local.set 4
      i32.const 8
      local.get 4
      i64.store align=1
      local.get 0
      i32.const 1
      i32.add
      local.set 5
      local.get 5
      i32.const 20
      call $goose.reserve_data
      local.set 6
      local.get 5
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 6
      i64.extend_i32_u
      i64.or
      local.set 7
      local.get 7
      local.set 2
      local.get 7
      i64.const 2
      call $goose.memory_op.62
      i32.const 8
      i64.load align=1
      local.set 8
      local.get 7
      i64.const 4
      i64.add
      local.get 8
      call $goose.memory_op.55
      i64.const 99
      local.set 8
      local.get 7
      i64.const 12
      i64.add
      local.get 8
      call $goose.memory_op.55
      local.get 2
      local.set 9
      local.get 9
      call $goose.memory_op.53
      local.set 10
      i64.const 0
      local.set 11
      local.get 9
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 11
      i64.const 8
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2540
        i32.const 70
        i32.const 6
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      call $goose.memory_op.41
      local.set 3
      local.get 5
      local.get 6
      call $goose.restore_data
      br 0 (;@1;)
      local.get 5
      local.get 6
      call $goose.restore_data
    end
    local.get 3
  )
  (func $goose.init (;14;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
    i32.const 14
    local.set 3
    i32.const 9
    call $goose.reserve_memory.14
    local.set 4
    local.get 3
    i64.extend_i32_u
    i64.const 32
    i64.shl
    local.get 4
    i64.extend_i32_u
    i64.or
    local.set 2
    local.get 2
    local.set 5
    i32.const 16
    local.get 5
    i64.store align=1
    local.get 2
    i64.const 4
    local.set 6
    i32.wrap_i64
    local.get 6
    i64.store8 14
    i64.const 7
    local.set 7
    i64.const 0
    local.set 8
    block ;; label = @1
      loop ;; label = @2
        local.get 8
        i64.const 4
        i64.ge_u
        br_if 1 (;@1;)
        local.get 2
        i32.wrap_i64
        local.get 8
        i32.wrap_i64
        i32.const 2
        i32.mul
        i32.add
        i32.const 1
        i32.add
        local.get 7
        i64.store16 14 align=1
        local.get 8
        i64.const 1
        i64.add
        local.set 8
        br 0 (;@2;)
      end
    end
  )
  (func $goose.start (;15;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.reserve_memory.5 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 5
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 5
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 5
      i32.sub
      memory.grow 5
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 5
    local.get 1
  )
  (func $goose.reserve_memory.6 (;21;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 6
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 6
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 6
      i32.sub
      memory.grow 6
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 6
    local.get 1
  )
  (func $goose.memory_op.41 (;22;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;23;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i64.store align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i64.store 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i64.store 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i64.store 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i64.store 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i64.store 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i64.store 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.7 (;24;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 7
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 7
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 7
      i32.sub
      memory.grow 7
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 7
    local.get 1
  )
  (func $goose.reserve_memory.8 (;25;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 8
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 8
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 8
      i32.sub
      memory.grow 8
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 8
    local.get 1
  )
  (func $goose.reserve_memory.9 (;26;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 9
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 9
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 9
      i32.sub
      memory.grow 9
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 9
    local.get 1
  )
  (func $goose.reserve_memory.10 (;27;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 10
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 10
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 10
      i32.sub
      memory.grow 10
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 10
    local.get 1
  )
  (func $goose.reserve_memory.11 (;28;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 11
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 11
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 11
      i32.sub
      memory.grow 11
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 11
    local.get 1
  )
  (func $goose.reserve_data (;29;) (type 14) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    local.get 0
                                    i32.const 1
                                    i32.sub
                                    br_table 0 (;@16;) 1 (;@15;) 2 (;@14;) 3 (;@13;) 4 (;@12;) 5 (;@11;) 6 (;@10;) 7 (;@9;) 8 (;@8;) 9 (;@7;) 10 (;@6;) 11 (;@5;) 12 (;@4;) 13 (;@3;) 14 (;@2;)
                                  end
                                  local.get 1
                                  call $goose.reserve_memory.1
                                  br 14 (;@1;)
                                end
                                local.get 1
                                call $goose.reserve_memory.2
                                br 13 (;@1;)
                              end
                              local.get 1
                              call $goose.reserve_memory.3
                              br 12 (;@1;)
                            end
                            local.get 1
                            call $goose.reserve_memory.4
                            br 11 (;@1;)
                          end
                          local.get 1
                          call $goose.reserve_memory.5
                          br 10 (;@1;)
                        end
                        local.get 1
                        call $goose.reserve_memory.6
                        br 9 (;@1;)
                      end
                      local.get 1
                      call $goose.reserve_memory.7
                      br 8 (;@1;)
                    end
                    local.get 1
                    call $goose.reserve_memory.8
                    br 7 (;@1;)
                  end
                  local.get 1
                  call $goose.reserve_memory.9
                  br 6 (;@1;)
                end
                local.get 1
                call $goose.reserve_memory.10
                br 5 (;@1;)
              end
              local.get 1
              call $goose.reserve_memory.11
              br 4 (;@1;)
            end
            local.get 1
            call $goose.reserve_memory.12
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.13
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.14
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.12 (;30;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 12
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 12
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 12
      i32.sub
      memory.grow 12
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 12
    local.get 1
  )
  (func $goose.reserve_memory.13 (;31;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 13
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 13
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 13
      i32.sub
      memory.grow 13
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 13
    local.get 1
  )
  (func $goose.reserve_memory.14 (;32;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 14
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 14
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 14
      i32.sub
      memory.grow 14
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 14
    local.get 1
  )
  (func $goose.memory_op.61 (;33;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i64.store16 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i64.store16 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i64.store16 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i64.store16 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i64.store16 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i64.store16 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i64.store16 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store16 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store16 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store16 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store16 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store16 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store16 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store16 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store16 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.51 (;34;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load16_u align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load16_u 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load16_u 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load16_u 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load16_u 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load16_u 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load16_u 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load16_u 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load16_u 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load16_u 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load16_u 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load16_u 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load16_u 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load16_u 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load16_u 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;35;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    local.get 0
                                    i32.const 1
                                    i32.sub
                                    br_table 0 (;@16;) 1 (;@15;) 2 (;@14;) 3 (;@13;) 4 (;@12;) 5 (;@11;) 6 (;@10;) 7 (;@9;) 8 (;@8;) 9 (;@7;) 10 (;@6;) 11 (;@5;) 12 (;@4;) 13 (;@3;) 14 (;@2;)
                                  end
                                  local.get 1
                                  i32.eqz
                                  if ;; label = @16
                                    i32.const 7
                                    i32.const 0
                                    i32.const 0
                                    i32.const 0
                                    call 6
                                    unreachable
                                  end
                                  local.get 1
                                  i64.extend_i32_u
                                  memory.size 1
                                  i64.extend_i32_u
                                  i64.const 16
                                  i64.shl
                                  i64.gt_u
                                  if ;; label = @16
                                    i32.const 7
                                    i32.const 0
                                    i32.const 0
                                    i32.const 0
                                    call 6
                                    unreachable
                                  end
                                  local.get 1
                                  global.set 1
                                  br 14 (;@1;)
                                end
                                local.get 1
                                i32.eqz
                                if ;; label = @15
                                  i32.const 7
                                  i32.const 0
                                  i32.const 0
                                  i32.const 0
                                  call 6
                                  unreachable
                                end
                                local.get 1
                                i64.extend_i32_u
                                memory.size 2
                                i64.extend_i32_u
                                i64.const 16
                                i64.shl
                                i64.gt_u
                                if ;; label = @15
                                  i32.const 7
                                  i32.const 0
                                  i32.const 0
                                  i32.const 0
                                  call 6
                                  unreachable
                                end
                                local.get 1
                                global.set 2
                                br 13 (;@1;)
                              end
                              local.get 1
                              i32.eqz
                              if ;; label = @14
                                i32.const 7
                                i32.const 0
                                i32.const 0
                                i32.const 0
                                call 6
                                unreachable
                              end
                              local.get 1
                              i64.extend_i32_u
                              memory.size 3
                              i64.extend_i32_u
                              i64.const 16
                              i64.shl
                              i64.gt_u
                              if ;; label = @14
                                i32.const 7
                                i32.const 0
                                i32.const 0
                                i32.const 0
                                call 6
                                unreachable
                              end
                              local.get 1
                              global.set 3
                              br 12 (;@1;)
                            end
                            local.get 1
                            i32.eqz
                            if ;; label = @13
                              i32.const 7
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            local.get 1
                            i64.extend_i32_u
                            memory.size 4
                            i64.extend_i32_u
                            i64.const 16
                            i64.shl
                            i64.gt_u
                            if ;; label = @13
                              i32.const 7
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            local.get 1
                            global.set 4
                            br 11 (;@1;)
                          end
                          local.get 1
                          i32.eqz
                          if ;; label = @12
                            i32.const 7
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          local.get 1
                          i64.extend_i32_u
                          memory.size 5
                          i64.extend_i32_u
                          i64.const 16
                          i64.shl
                          i64.gt_u
                          if ;; label = @12
                            i32.const 7
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          local.get 1
                          global.set 5
                          br 10 (;@1;)
                        end
                        local.get 1
                        i32.eqz
                        if ;; label = @11
                          i32.const 7
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        local.get 1
                        i64.extend_i32_u
                        memory.size 6
                        i64.extend_i32_u
                        i64.const 16
                        i64.shl
                        i64.gt_u
                        if ;; label = @11
                          i32.const 7
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        local.get 1
                        global.set 6
                        br 9 (;@1;)
                      end
                      local.get 1
                      i32.eqz
                      if ;; label = @10
                        i32.const 7
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      local.get 1
                      i64.extend_i32_u
                      memory.size 7
                      i64.extend_i32_u
                      i64.const 16
                      i64.shl
                      i64.gt_u
                      if ;; label = @10
                        i32.const 7
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      local.get 1
                      global.set 7
                      br 8 (;@1;)
                    end
                    local.get 1
                    i32.eqz
                    if ;; label = @9
                      i32.const 7
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 1
                    i64.extend_i32_u
                    memory.size 8
                    i64.extend_i32_u
                    i64.const 16
                    i64.shl
                    i64.gt_u
                    if ;; label = @9
                      i32.const 7
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 1
                    global.set 8
                    br 7 (;@1;)
                  end
                  local.get 1
                  i32.eqz
                  if ;; label = @8
                    i32.const 7
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 1
                  i64.extend_i32_u
                  memory.size 9
                  i64.extend_i32_u
                  i64.const 16
                  i64.shl
                  i64.gt_u
                  if ;; label = @8
                    i32.const 7
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 1
                  global.set 9
                  br 6 (;@1;)
                end
                local.get 1
                i32.eqz
                if ;; label = @7
                  i32.const 7
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 1
                i64.extend_i32_u
                memory.size 10
                i64.extend_i32_u
                i64.const 16
                i64.shl
                i64.gt_u
                if ;; label = @7
                  i32.const 7
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 1
                global.set 10
                br 5 (;@1;)
              end
              local.get 1
              i32.eqz
              if ;; label = @6
                i32.const 7
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 1
              i64.extend_i32_u
              memory.size 11
              i64.extend_i32_u
              i64.const 16
              i64.shl
              i64.gt_u
              if ;; label = @6
                i32.const 7
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 1
              global.set 11
              br 4 (;@1;)
            end
            local.get 1
            i32.eqz
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            i64.extend_i32_u
            memory.size 12
            i64.extend_i32_u
            i64.const 16
            i64.shl
            i64.gt_u
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            global.set 12
            br 3 (;@1;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 13
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 13
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 14
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 14
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.62 (;36;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i64.store32 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i64.store32 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i64.store32 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i64.store32 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i64.store32 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i64.store32 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i64.store32 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store32 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store32 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store32 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store32 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store32 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store32 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store32 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store32 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;37;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load32_u align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load32_u 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load32_u 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load32_u 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load32_u 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load32_u 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load32_u 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load32_u 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load32_u 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load32_u 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load32_u 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosebefore=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose,,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose,,empty=,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.gooserefs=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosethin=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosescalar=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosegrowth=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.gooseafter=,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose")
)
