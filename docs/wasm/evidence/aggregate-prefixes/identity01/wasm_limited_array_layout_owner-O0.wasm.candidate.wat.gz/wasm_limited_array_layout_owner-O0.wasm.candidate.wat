(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 368)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 85
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 93
        i32.const 85
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i32 i64 i32 i32 i32 i32 i64 i64 i64 i64 i64)
    i32.const 114
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 1
      local.get 1
      i64.const 2
      i64.store8
      local.get 1
      f32.const 0x1.8p+0 (;=1.5;)
      f32.store offset=1 align=1
      local.get 1
      f64.const -0x1p+1 (;=-2;)
      f64.store offset=7 align=1
      local.get 1
      f32.const 0x1.cp+1 (;=3.5;)
      f32.store offset=15 align=1
      local.get 1
      f64.const 0x1p+2 (;=4;)
      f64.store offset=21 align=1
      local.get 1
      i32.const 29
      i32.add
      i32.const 0
      i32.const 14
      memory.fill
      call 0
      local.set 2
      local.get 2
      i32.const 178
      i32.const 6
      call 4
      local.get 2
      call 5
      local.get 0
      i32.const 43
      i32.add
      local.set 3
      local.get 0
      i32.const 0
      i32.add
      local.set 4
      local.get 4
      i64.load8_u
      local.set 5
      local.get 5
      i64.const 14
      i64.mul
      i32.wrap_i64
      local.set 6
      local.get 3
      i32.const 1
      i32.add
      local.get 4
      i32.const 1
      i32.add
      local.get 6
      memory.copy
      local.get 3
      local.get 5
      i64.store8
      call 0
      local.set 7
      local.get 7
      i32.const 184
      i32.const 5
      call 4
      local.get 7
      call 5
      local.get 0
      i32.const 43
      i32.add
      local.set 8
      local.get 8
      i64.load8_u
      i64.const 2
      i64.eq
      if (result i32) ;; label = @2
        local.get 0
        i32.const 43
        i32.add
        local.set 9
        local.get 9
        i64.load8_u
        local.set 10
        i64.const 1
        local.set 11
        local.get 9
        i32.const 1
        i32.add
        i64.extend_i32_u
        local.set 12
        local.get 12
        i64.const 4294967295
        i64.and
        local.get 11
        i64.const 14
        i64.mul
        i64.add
        local.tee 13
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 189
          i32.const 85
          i32.const 1
          call 6
          unreachable
        end
        local.get 12
        i64.const -4294967296
        i64.and
        local.get 13
        i64.or
        local.set 14
        local.get 14
        i32.wrap_i64
        f32.load align=1
        f32.const 0x1.cp+1 (;=3.5;)
        f32.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 274
        i32.const 85
        i32.const 1
        call 6
        unreachable
      end
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner.goosebeforeafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner.goose")
)
