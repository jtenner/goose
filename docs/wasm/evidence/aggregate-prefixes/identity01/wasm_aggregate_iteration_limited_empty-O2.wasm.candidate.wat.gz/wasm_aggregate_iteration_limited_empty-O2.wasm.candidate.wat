(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1504)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 16
      i32.const 92
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 108
        i32.const 92
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i32 i32 i64 i32 i32 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i32)
    i32.const 133
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      i64.const 2
      i64.store8
      local.get 3
      i64.const 1
      i64.store offset=1 align=1
      local.get 3
      i64.const 2
      i64.store offset=9 align=1
      local.get 3
      i32.const 17
      i32.add
      i32.const 0
      i32.const 8
      memory.fill
      i64.const 0
      local.set 1
      local.get 0
      i32.const 0
      i32.add
      local.set 4
      i64.const 0
      local.set 5
      block ;; label = @2
        loop ;; label = @3
          local.get 5
          local.get 4
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 4
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 6
          local.get 6
          i64.const 4294967295
          i64.and
          local.get 5
          i64.const 8
          i64.mul
          i64.add
          local.tee 7
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 200
            i32.const 92
            i32.const 6
            call 6
            unreachable
          end
          local.get 6
          i64.const -4294967296
          i64.and
          local.get 7
          i64.or
          local.set 8
          local.get 0
          i32.const 25
          i32.add
          local.set 9
          local.get 9
          i64.extend_i32_u
          local.set 10
          local.get 8
          local.set 11
          i32.const 8
          local.set 12
          local.get 10
          i32.wrap_i64
          local.get 11
          i32.wrap_i64
          local.get 12
          memory.copy
          block ;; label = @4
            local.get 0
            i32.const 0
            i32.add
            local.set 13
            local.get 13
            i64.load8_u
            local.set 14
            i64.const 0
            local.set 14
            local.get 13
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 15
            local.get 15
            i64.const 4294967295
            i64.and
            local.get 14
            i64.const 8
            i64.mul
            i64.add
            local.tee 16
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 292
              i32.const 92
              i32.const 6
              call 6
              unreachable
            end
            local.get 15
            i64.const -4294967296
            i64.and
            local.get 16
            i64.or
            local.set 17
            local.get 13
            local.get 14
            i64.store8
            local.get 0
            i32.const 25
            i32.add
            local.set 18
            local.get 18
            i64.load align=1
            i64.const 1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 384
              i32.const 92
              i32.const 6
              call 6
              unreachable
            end
            local.get 1
            local.get 0
            i32.const 25
            i32.add
            local.set 19
            local.get 19
            i64.load align=1
            i64.add
            local.set 1
          end
          local.get 5
          i64.const 1
          i64.add
          local.set 5
          br 0 (;@3;)
        end
      end
      local.get 1
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 476
        i32.const 92
        i32.const 7
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 20
      local.get 20
      i64.load8_u
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 568
        i32.const 92
        i32.const 7
        call 6
        unreachable
      end
      local.get 0
      i32.const 33
      i32.add
      local.set 21
      local.get 0
      i32.const 33
      i32.add
      call $selected.1
      local.tee 22
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 660
        i32.const 92
        i32.const 3
        call 6
        unreachable
      end
      local.get 22
      local.set 23
      i64.const 0
      local.set 24
      block ;; label = @2
        loop ;; label = @3
          local.get 24
          i64.const 0
          i64.ge_u
          br_if 1 (;@2;)
          local.get 23
          i64.extend_i32_u
          local.set 25
          local.get 25
          i64.const 4294967295
          i64.and
          local.get 24
          i64.const 8
          i64.mul
          i64.add
          local.tee 26
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 752
            i32.const 92
            i32.const 8
            call 6
            unreachable
          end
          local.get 25
          i64.const -4294967296
          i64.and
          local.get 26
          i64.or
          local.set 27
          local.get 0
          i32.const 34
          i32.add
          local.set 28
          local.get 28
          i64.extend_i32_u
          local.set 29
          local.get 27
          local.set 30
          i32.const 8
          local.set 31
          local.get 29
          i32.wrap_i64
          local.get 30
          i32.wrap_i64
          local.get 31
          memory.copy
          block ;; label = @4
            i32.const 0
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 844
              i32.const 92
              i32.const 8
              call 6
              unreachable
            end
          end
          local.get 24
          i64.const 1
          i64.add
          local.set 24
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 42
      i32.add
      local.set 32
      local.get 32
      i64.const 0
      i64.store8
      local.get 32
      i32.const 1
      i32.add
      i32.const 0
      i32.const 24
      memory.fill
      local.get 0
      i32.const 42
      i32.add
      local.set 33
      i64.const 0
      local.set 34
      block ;; label = @2
        loop ;; label = @3
          local.get 34
          local.get 33
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 33
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 35
          local.get 35
          i64.const 4294967295
          i64.and
          local.get 34
          i64.const 8
          i64.mul
          i64.add
          local.tee 36
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 936
            i32.const 92
            i32.const 9
            call 6
            unreachable
          end
          local.get 35
          i64.const -4294967296
          i64.and
          local.get 36
          i64.or
          local.set 37
          local.get 0
          i32.const 67
          i32.add
          local.set 38
          local.get 38
          i64.extend_i32_u
          local.set 39
          local.get 37
          local.set 40
          i32.const 8
          local.set 41
          local.get 39
          i32.wrap_i64
          local.get 40
          i32.wrap_i64
          local.get 41
          memory.copy
          block ;; label = @4
            i32.const 0
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 1028
              i32.const 92
              i32.const 9
              call 6
              unreachable
            end
          end
          local.get 34
          i64.const 1
          i64.add
          local.set 34
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 75
      i32.add
      local.set 42
      local.get 42
      i64.const 1
      i64.store8
      local.get 42
      i64.const 1
      i64.store offset=1 align=1
      local.get 42
      i32.const 9
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      local.get 0
      i32.const 100
      i32.add
      local.set 43
      local.get 43
      i64.const 3
      i64.store8
      local.get 43
      i64.const 10
      i64.store offset=1 align=1
      local.get 43
      i64.const 20
      i64.store offset=9 align=1
      local.get 43
      i64.const 30
      i64.store offset=17 align=1
      local.get 0
      i32.const 75
      i32.add
      local.set 2
      i64.const 0
      local.set 1
      i64.const 0
      local.set 45
      block ;; label = @2
        loop ;; label = @3
          local.get 2
          local.tee 46
          i32.eqz
          if ;; label = @4
            i32.const 4
            i32.const 1120
            i32.const 92
            i32.const 11
            call 6
            unreachable
          end
          local.get 46
          local.set 47
          local.get 47
          local.set 44
          local.get 45
          local.get 44
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 44
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 48
          local.get 48
          i64.const 4294967295
          i64.and
          local.get 45
          i64.const 8
          i64.mul
          i64.add
          local.tee 49
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1212
            i32.const 92
            i32.const 12
            call 6
            unreachable
          end
          local.get 48
          i64.const -4294967296
          i64.and
          local.get 49
          i64.or
          local.set 50
          local.get 0
          i32.const 125
          i32.add
          local.set 51
          local.get 51
          i64.extend_i32_u
          local.set 52
          local.get 50
          local.set 53
          i32.const 8
          local.set 54
          local.get 52
          i32.wrap_i64
          local.get 53
          i32.wrap_i64
          local.get 54
          memory.copy
          block ;; label = @4
            local.get 0
            i32.const 100
            i32.add
            local.set 2
            local.get 1
            local.get 0
            i32.const 125
            i32.add
            local.set 55
            local.get 55
            i64.load align=1
            i64.add
            local.set 1
          end
          local.get 45
          i64.const 1
          i64.add
          local.set 45
          br 0 (;@3;)
        end
      end
      local.get 1
      i64.const 51
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1304
        i32.const 92
        i32.const 13
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1396
        i32.const 92
        i32.const 13
        call 6
        unreachable
      end
      local.get 1
      local.set 56
      i32.const 8
      i64.load align=1
      local.set 57
      call 0
      local.set 58
      local.get 58
      i32.const 1488
      i32.const 8
      call 4
      local.get 58
      local.get 56
      i32.const 0
      call 1
      local.get 58
      i32.const 1496
      i32.const 1
      call 4
      local.get 58
      local.get 57
      i32.const 0
      call 1
      local.get 58
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $selected.1 (;12;) (type 9) (param i32) (result i32)
    (local i32 i32 i64)
    block ;; label = @1
      i32.const 8
      i64.load align=1
      i64.const 1
      i64.add
      local.set 3
      i32.const 8
      local.get 3
      i64.store align=1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;13;) (type 10)
    (local i32 i64)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_limited_empty.gooselimited=,")
)
