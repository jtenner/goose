(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i64 i64)))
  (type (;12;) (func (param i32 i64)))
  (type (;13;) (func (param i64) (result i64)))
  (type (;14;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 5200)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 82
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 90
        i32.const 82
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 146
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 7
      global.get 1
      local.set 8
      local.get 0
      i32.const 0
      i32.add
      local.set 9
      local.get 9
      local.get 7
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 8
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 9
      i64.const 0
      i64.store offset=8 align=1
      i64.const 3
      local.set 10
      local.get 9
      i64.load offset=8 align=1
      local.set 11
      i32.const 8
      call $goose.reserve_memory.1
      local.set 12
      local.get 9
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 12
      i64.extend_i32_u
      i64.or
      local.tee 13
      local.get 10
      local.set 14
      i32.wrap_i64
      local.get 14
      i64.store 1 align=1
      local.get 9
      local.get 11
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 15
      local.get 15
      i32.const 0
      i32.add
      i64.const 10
      i64.store align=1
      local.get 15
      i32.const 8
      i32.add
      i64.const 20
      i64.store align=1
      local.get 0
      i32.const 32
      i32.add
      local.set 16
      local.get 16
      i64.const 0
      i64.store8
      i64.const 30
      local.set 17
      local.get 16
      i64.load8_u
      local.set 18
      local.get 18
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 172
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 16
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 254
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      local.tee 22
      local.get 17
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store align=1
      local.get 16
      local.get 18
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.get 0
      i32.const 0
      i32.add
      local.set 24
      local.get 24
      i64.load offset=8 align=1
      local.set 25
      i64.const 0
      local.set 26
      local.get 24
      i64.load align=1
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      local.get 26
      i64.const 8
      i64.mul
      i64.add
      local.tee 28
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 336
        i32.const 82
        i32.const 10
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 28
      i64.or
      call $update.1
      local.get 0
      i32.const 57
      i32.add
      local.set 29
      local.get 29
      i32.const 0
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 30
      i64.const 2
      local.set 31
      i64.const 0
      local.set 32
      local.get 30
      local.set 33
      local.get 33
      i64.const 4294967295
      i64.and
      local.get 32
      i64.const 8
      i64.mul
      i64.add
      local.tee 34
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 418
        i32.const 82
        i32.const 11
        call 6
        unreachable
      end
      local.get 33
      i64.const -4294967296
      i64.and
      local.get 34
      i64.or
      i64.store align=1
      local.get 29
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      local.set 35
      local.get 35
      i64.load offset=8 align=1
      local.set 36
      i64.const 0
      local.set 37
      local.get 35
      i64.load align=1
      local.set 38
      local.get 38
      i64.const 4294967295
      i64.and
      local.get 37
      i64.const 8
      i64.mul
      i64.add
      local.tee 39
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 500
        i32.const 82
        i32.const 11
        call 6
        unreachable
      end
      local.get 38
      i64.const -4294967296
      i64.and
      local.get 39
      i64.or
      i64.store align=1
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 40
      i64.const 2
      local.set 41
      i64.const 0
      local.set 42
      local.get 40
      local.set 43
      local.get 43
      i64.const 4294967295
      i64.and
      local.get 42
      i64.const 8
      i64.mul
      i64.add
      local.tee 44
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 582
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 43
      i64.const -4294967296
      i64.and
      local.get 44
      i64.or
      local.set 45
      local.get 45
      i32.wrap_i64
      i64.load align=1
      local.tee 46
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 664
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 46
      local.set 45
      local.get 45
      call $goose.memory_op.41
      i64.const 1
      i64.add
      local.set 47
      local.get 45
      local.get 47
      call $goose.memory_op.55
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 48
      i64.const 2
      local.set 49
      i64.const 1
      local.set 50
      local.get 48
      local.set 51
      local.get 51
      i64.const 4294967295
      i64.and
      local.get 50
      i64.const 8
      i64.mul
      i64.add
      local.tee 52
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 746
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 51
      i64.const -4294967296
      i64.and
      local.get 52
      i64.or
      local.set 53
      local.get 53
      i32.wrap_i64
      i64.load align=1
      local.tee 54
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 828
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 54
      local.set 53
      local.get 53
      call $goose.memory_op.41
      i64.const 2
      i64.add
      local.set 55
      local.get 53
      local.get 55
      call $goose.memory_op.55
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 56
      i64.const 0
      local.set 57
      block ;; label = @2
        loop ;; label = @3
          local.get 57
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 56
          local.set 58
          local.get 58
          i64.const 4294967295
          i64.and
          local.get 57
          i64.const 8
          i64.mul
          i64.add
          local.tee 59
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 910
            i32.const 82
            i32.const 13
            call 6
            unreachable
          end
          local.get 58
          i64.const -4294967296
          i64.and
          local.get 59
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 1
          block ;; label = @4
            local.get 1
            local.tee 60
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 992
              i32.const 82
              i32.const 13
              call 6
              unreachable
            end
            local.get 60
            local.set 61
            local.get 61
            call $goose.memory_op.41
            i64.const 10
            i64.add
            local.set 62
            local.get 61
            local.get 62
            call $goose.memory_op.55
          end
          local.get 57
          i64.const 1
          i64.add
          local.set 57
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 63
      i64.const 2
      local.set 64
      i64.const 1
      local.set 65
      local.get 63
      local.set 66
      local.get 66
      i64.const 4294967295
      i64.and
      local.get 65
      i64.const 8
      i64.mul
      i64.add
      local.tee 67
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1074
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 66
      i64.const -4294967296
      i64.and
      local.get 67
      i64.or
      local.set 68
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 69
      i64.const 2
      local.set 70
      i64.const 1
      local.set 71
      local.get 69
      local.set 72
      local.get 72
      i64.const 4294967295
      i64.and
      local.get 71
      i64.const 8
      i64.mul
      i64.add
      local.tee 73
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1156
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 72
      i64.const -4294967296
      i64.and
      local.get 73
      i64.or
      local.set 74
      local.get 68
      local.get 74
      local.set 75
      i32.wrap_i64
      local.get 75
      i64.store align=1
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 76
      i64.const 2
      local.set 77
      i64.const 1
      local.set 78
      local.get 76
      local.set 79
      local.get 79
      i64.const 4294967295
      i64.and
      local.get 78
      i64.const 8
      i64.mul
      i64.add
      local.tee 80
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1238
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 79
      i64.const -4294967296
      i64.and
      local.get 80
      i64.or
      local.set 81
      local.get 81
      i32.wrap_i64
      i64.load align=1
      local.tee 82
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1320
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 82
      local.set 81
      local.get 81
      call $goose.memory_op.41
      i64.const 1
      i64.add
      local.set 83
      local.get 81
      local.get 83
      call $goose.memory_op.55
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 84
      i64.const 2
      local.set 85
      i64.const 0
      local.set 86
      local.get 84
      local.set 87
      local.get 87
      i64.const 4294967295
      i64.and
      local.get 86
      i64.const 8
      i64.mul
      i64.add
      local.tee 88
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1402
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 87
      i64.const -4294967296
      i64.and
      local.get 88
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 89
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 90
      i64.const 2
      local.set 91
      i64.const 1
      local.set 92
      local.get 90
      local.set 93
      local.get 93
      i64.const 4294967295
      i64.and
      local.get 92
      i64.const 8
      i64.mul
      i64.add
      local.tee 94
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1484
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 94
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 95
      local.get 0
      i32.const 0
      i32.add
      local.set 96
      local.get 96
      i64.load offset=8 align=1
      local.set 97
      i64.const 0
      local.set 98
      local.get 96
      i64.load align=1
      local.set 99
      local.get 99
      i64.const 4294967295
      i64.and
      local.get 98
      i64.const 8
      i64.mul
      i64.add
      local.tee 100
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1566
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 99
      i64.const -4294967296
      i64.and
      local.get 100
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 101
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 102
      local.get 102
      i32.wrap_i64
      i64.load8_u
      local.set 103
      i64.const 1
      local.set 104
      local.get 104
      local.get 103
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1648
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 102
      local.set 105
      local.get 105
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 104
      i64.const 8
      i64.mul
      i64.add
      local.tee 106
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1730
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 105
      i64.const -4294967296
      i64.and
      local.get 106
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 107
      call 0
      local.set 108
      local.get 108
      local.get 89
      i32.const 0
      call 1
      local.get 108
      i32.const 1812
      i32.const 1
      call 4
      local.get 108
      local.get 95
      i32.const 0
      call 1
      local.get 108
      i32.const 1813
      i32.const 1
      call 4
      local.get 108
      local.get 101
      i32.const 0
      call 1
      local.get 108
      i32.const 1814
      i32.const 1
      call 4
      local.get 108
      local.get 107
      i32.const 0
      call 1
      local.get 108
      call 5
      local.get 0
      i32.const 73
      i32.add
      local.set 109
      local.get 109
      i32.const 0
      i32.add
      i64.const 40
      i64.store align=1
      local.get 109
      i32.const 8
      i32.add
      i64.const 50
      i64.store align=1
      local.get 0
      i32.const 89
      i32.add
      local.set 110
      local.get 110
      i32.const 0
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 110
      i32.const 8
      i32.add
      local.get 0
      i32.const 73
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 89
      i32.add
      i64.extend_i32_u
      local.set 111
      i64.const 0
      local.set 112
      block ;; label = @2
        loop ;; label = @3
          local.get 112
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 111
          local.set 113
          local.get 113
          i64.const 4294967295
          i64.and
          local.get 112
          i64.const 8
          i64.mul
          i64.add
          local.tee 114
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1815
            i32.const 82
            i32.const 18
            call 6
            unreachable
          end
          local.get 113
          i64.const -4294967296
          i64.and
          local.get 114
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 2
          block ;; label = @4
            local.get 2
            local.tee 115
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 1897
              i32.const 82
              i32.const 17
              call 6
              unreachable
            end
            local.get 115
            local.set 116
            i64.const 2
            local.set 117
            i64.const 0
            local.set 118
            local.get 116
            local.set 119
            local.get 119
            i64.const 4294967295
            i64.and
            local.get 118
            i64.const 8
            i64.mul
            i64.add
            local.tee 120
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1979
              i32.const 82
              i32.const 18
              call 6
              unreachable
            end
            local.get 119
            i64.const -4294967296
            i64.and
            local.get 120
            i64.or
            local.set 121
            local.get 121
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 122
            local.get 121
            local.get 122
            call $goose.memory_op.55
            local.get 2
            local.tee 123
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2061
              i32.const 82
              i32.const 17
              call 6
              unreachable
            end
            local.get 123
            local.set 124
            i64.const 2
            local.set 125
            i64.const 0
            local.set 126
            local.get 124
            local.set 127
            local.get 127
            i64.const 4294967295
            i64.and
            local.get 126
            i64.const 8
            i64.mul
            i64.add
            local.tee 128
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2143
              i32.const 82
              i32.const 18
              call 6
              unreachable
            end
            local.get 127
            i64.const -4294967296
            i64.and
            local.get 128
            i64.or
            call $goose.memory_op.41
            local.set 129
            local.get 2
            local.tee 130
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2225
              i32.const 82
              i32.const 17
              call 6
              unreachable
            end
            local.get 130
            local.set 131
            i64.const 2
            local.set 132
            i64.const 1
            local.set 133
            local.get 131
            local.set 134
            local.get 134
            i64.const 4294967295
            i64.and
            local.get 133
            i64.const 8
            i64.mul
            i64.add
            local.tee 135
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2307
              i32.const 82
              i32.const 18
              call 6
              unreachable
            end
            local.get 134
            i64.const -4294967296
            i64.and
            local.get 135
            i64.or
            call $goose.memory_op.41
            local.set 136
            call 0
            local.set 137
            local.get 137
            local.get 129
            i32.const 0
            call 1
            local.get 137
            i32.const 2389
            i32.const 1
            call 4
            local.get 137
            local.get 136
            i32.const 0
            call 1
            local.get 137
            call 5
          end
          local.get 112
          i64.const 1
          i64.add
          local.set 112
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 105
      i32.add
      local.set 138
      local.get 138
      i64.const 0
      i64.store8
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 139
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 140
      i64.const 2
      local.set 141
      i64.const 0
      local.set 142
      local.get 140
      local.set 143
      local.get 143
      i64.const 4294967295
      i64.and
      local.get 142
      i64.const 8
      i64.mul
      i64.add
      local.tee 144
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2390
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 143
      i64.const -4294967296
      i64.and
      local.get 144
      i64.or
      local.set 145
      local.get 139
      i32.wrap_i64
      i64.load8_u
      local.set 146
      local.get 146
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2472
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 139
      local.set 148
      local.get 148
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 146
      i64.const 8
      i64.mul
      i64.add
      local.tee 149
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2554
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 148
      i64.const -4294967296
      i64.and
      local.get 149
      i64.or
      local.tee 150
      local.get 145
      local.set 151
      i32.wrap_i64
      local.get 151
      i64.store align=1
      local.get 139
      local.get 146
      i64.const 1
      i64.add
      local.set 152
      i32.wrap_i64
      local.get 152
      i64.store8
      local.get 150
      i32.wrap_i64
      i64.load align=1
      local.tee 153
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2636
        i32.const 82
        i32.const 19
        call 6
        unreachable
      end
      local.get 153
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 154
      local.get 0
      i32.const 0
      i32.add
      local.set 155
      local.get 155
      i64.load offset=8 align=1
      local.set 156
      i64.const 0
      local.set 157
      local.get 155
      i64.load align=1
      local.set 158
      local.get 158
      i64.const 4294967295
      i64.and
      local.get 157
      i64.const 8
      i64.mul
      i64.add
      local.tee 159
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2718
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 158
      i64.const -4294967296
      i64.and
      local.get 159
      i64.or
      local.set 160
      local.get 154
      i32.wrap_i64
      i64.load8_u
      local.set 161
      local.get 161
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2800
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 154
      local.set 163
      local.get 163
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 161
      i64.const 8
      i64.mul
      i64.add
      local.tee 164
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2882
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 163
      i64.const -4294967296
      i64.and
      local.get 164
      i64.or
      local.tee 165
      local.get 160
      local.set 166
      i32.wrap_i64
      local.get 166
      i64.store align=1
      local.get 154
      local.get 161
      i64.const 1
      i64.add
      local.set 152
      i32.wrap_i64
      local.get 152
      i64.store8
      local.get 165
      i32.wrap_i64
      i64.load align=1
      local.tee 167
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2964
        i32.const 82
        i32.const 19
        call 6
        unreachable
      end
      local.get 167
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 168
      i64.const 0
      local.set 169
      block ;; label = @2
        loop ;; label = @3
          local.get 169
          local.get 168
          i32.wrap_i64
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 168
          local.set 170
          local.get 170
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.get 169
          i64.const 8
          i64.mul
          i64.add
          local.tee 171
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 3046
            i32.const 82
            i32.const 21
            call 6
            unreachable
          end
          local.get 170
          i64.const -4294967296
          i64.and
          local.get 171
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 3
          block ;; label = @4
            local.get 3
            local.tee 172
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 3128
              i32.const 82
              i32.const 21
              call 6
              unreachable
            end
            local.get 172
            local.set 173
            local.get 173
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 174
            local.get 173
            local.get 174
            call $goose.memory_op.55
          end
          local.get 169
          i64.const 1
          i64.add
          local.set 169
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 175
      i64.const 2
      local.set 176
      i64.const 0
      local.set 177
      local.get 175
      local.set 178
      local.get 178
      i64.const 4294967295
      i64.and
      local.get 177
      i64.const 8
      i64.mul
      i64.add
      local.tee 179
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3210
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 178
      i64.const -4294967296
      i64.and
      local.get 179
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 180
      local.get 0
      i32.const 0
      i32.add
      local.set 181
      local.get 181
      i64.load offset=8 align=1
      local.set 182
      i64.const 0
      local.set 183
      local.get 181
      i64.load align=1
      local.set 184
      local.get 184
      i64.const 4294967295
      i64.and
      local.get 183
      i64.const 8
      i64.mul
      i64.add
      local.tee 185
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3292
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 184
      i64.const -4294967296
      i64.and
      local.get 185
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 186
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 187
      local.get 187
      i32.wrap_i64
      i64.load8_u
      local.set 188
      local.get 188
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 3374
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 188
      i64.const 1
      i64.sub
      local.set 188
      local.get 187
      local.set 189
      local.get 189
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 188
      i64.const 8
      i64.mul
      i64.add
      local.tee 190
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3456
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 189
      i64.const -4294967296
      i64.and
      local.get 190
      i64.or
      local.set 191
      local.get 191
      i32.wrap_i64
      i64.load align=1
      local.set 192
      local.get 187
      local.get 188
      local.set 152
      i32.wrap_i64
      local.get 152
      i64.store8
      local.get 192
      local.tee 193
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3538
        i32.const 82
        i32.const 19
        call 6
        unreachable
      end
      local.get 193
      call $goose.memory_op.41
      local.set 194
      call 0
      local.set 195
      local.get 195
      local.get 180
      i32.const 0
      call 1
      local.get 195
      i32.const 3620
      i32.const 1
      call 4
      local.get 195
      local.get 186
      i32.const 0
      call 1
      local.get 195
      i32.const 3621
      i32.const 1
      call 4
      local.get 195
      local.get 194
      i32.const 0
      call 1
      local.get 195
      call 5
      i32.const 2
      local.set 196
      global.get 2
      local.set 197
      local.get 0
      i32.const 130
      i32.add
      local.set 198
      local.get 198
      local.get 196
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 197
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 198
      i64.const 0
      i64.store offset=8 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 199
      local.get 198
      i64.load offset=8 align=1
      local.set 200
      i32.const 8
      call $goose.reserve_memory.2
      local.set 201
      local.get 198
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 201
      i64.extend_i32_u
      i64.or
      local.tee 202
      local.get 199
      local.set 203
      i32.wrap_i64
      local.get 203
      i64.store 2 align=1
      local.get 198
      local.get 200
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 130
      i32.add
      local.get 0
      i32.const 73
      i32.add
      i64.extend_i32_u
      call $rebind.2
      local.get 0
      i32.const 130
      i32.add
      local.set 204
      local.get 204
      i64.load offset=8 align=1
      local.set 205
      i64.const 0
      local.set 206
      local.get 206
      local.get 205
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3622
        i32.const 82
        i32.const 24
        call 6
        unreachable
      end
      local.get 204
      i64.load align=1
      local.set 207
      local.get 207
      i64.const 4294967295
      i64.and
      local.get 206
      i64.const 8
      i64.mul
      i64.add
      local.tee 208
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3704
        i32.const 82
        i32.const 24
        call 6
        unreachable
      end
      local.get 207
      i64.const -4294967296
      i64.and
      local.get 208
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      call $first.3
      local.set 209
      call 0
      local.set 210
      local.get 210
      i32.const 3786
      i32.const 9
      call 4
      local.get 210
      local.get 209
      i32.const 0
      call 1
      local.get 210
      call 5
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 4
      i64.const 0
      local.set 212
      block ;; label = @2
        loop ;; label = @3
          local.get 4
          local.tee 213
          i64.eqz
          if ;; label = @4
            i32.const 4
            i32.const 3795
            i32.const 82
            i32.const 25
            call 6
            unreachable
          end
          local.get 213
          local.set 214
          local.get 214
          local.set 211
          local.get 212
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 211
          local.set 215
          local.get 215
          i64.const 4294967295
          i64.and
          local.get 212
          i64.const 8
          i64.mul
          i64.add
          local.tee 216
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 3877
            i32.const 82
            i32.const 26
            call 6
            unreachable
          end
          local.get 215
          i64.const -4294967296
          i64.and
          local.get 216
          i64.or
          local.set 5
          local.get 212
          local.set 6
          block ;; label = @4
            local.get 6
            i64.const 0
            i64.eq
            if ;; label = @5
              local.get 0
              i32.const 73
              i32.add
              i64.extend_i32_u
              local.set 4
            end
            local.get 5
            local.tee 217
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 3959
              i32.const 82
              i32.const 26
              call 6
              unreachable
            end
            local.get 217
            local.set 218
            local.get 218
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 219
            local.get 218
            local.get 219
            call $goose.memory_op.55
          end
          local.get 212
          i64.const 1
          i64.add
          local.set 212
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 220
      i64.const 2
      local.set 221
      i64.const 0
      local.set 222
      local.get 220
      local.set 223
      local.get 223
      i64.const 4294967295
      i64.and
      local.get 222
      i64.const 8
      i64.mul
      i64.add
      local.tee 224
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4041
        i32.const 82
        i32.const 27
        call 6
        unreachable
      end
      local.get 223
      i64.const -4294967296
      i64.and
      local.get 224
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 225
      local.get 0
      i32.const 73
      i32.add
      i64.extend_i32_u
      local.set 226
      i64.const 2
      local.set 227
      i64.const 1
      local.set 228
      local.get 226
      local.set 229
      local.get 229
      i64.const 4294967295
      i64.and
      local.get 228
      i64.const 8
      i64.mul
      i64.add
      local.tee 230
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4123
        i32.const 82
        i32.const 27
        call 6
        unreachable
      end
      local.get 229
      i64.const -4294967296
      i64.and
      local.get 230
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 231
      call 0
      local.set 232
      local.get 232
      local.get 225
      i32.const 0
      call 1
      local.get 232
      i32.const 4205
      i32.const 1
      call 4
      local.get 232
      local.get 231
      i32.const 0
      call 1
      local.get 232
      call 5
      local.get 197
      global.set 2
      local.get 8
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $update.1 (;12;) (type 11) (param i64 i64 i64)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4206
        i32.const 82
        i32.const 1
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      i64.const 2
      local.set 6
      i64.const 0
      local.set 7
      local.get 5
      local.set 8
      local.get 8
      i64.const 4294967295
      i64.and
      local.get 7
      i64.const 8
      i64.mul
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4288
        i32.const 82
        i32.const 2
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 10
      local.get 10
      call $goose.memory_op.41
      local.get 2
      local.tee 11
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4370
        i32.const 82
        i32.const 2
        call 6
        unreachable
      end
      local.get 11
      call $goose.memory_op.41
      i64.add
      local.set 12
      local.get 10
      local.get 12
      call $goose.memory_op.55
      local.get 1
      local.tee 13
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4452
        i32.const 82
        i32.const 1
        call 6
        unreachable
      end
      local.get 13
      local.set 14
      local.get 0
      local.tee 15
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4534
        i32.const 82
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      local.set 16
      i64.const 2
      local.set 17
      i64.const 0
      local.set 18
      local.get 16
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4616
        i32.const 82
        i32.const 2
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      call $goose.memory_op.41
      local.set 21
      local.get 14
      call $goose.memory_op.49
      local.set 22
      local.get 22
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 4698
        i32.const 82
        i32.const 2
        call 6
        unreachable
      end
      local.get 14
      local.set 24
      local.get 24
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 22
      i64.const 8
      i64.mul
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4780
        i32.const 82
        i32.const 2
        call 6
        unreachable
      end
      local.get 24
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.tee 26
      local.get 21
      call $goose.memory_op.55
      local.get 14
      local.get 22
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 26
      call $goose.memory_op.41
      drop
    end
  )
  (func $rebind.2 (;13;) (type 12) (param i32 i64)
    (local i32 i32 i32 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4862
        i32.const 82
        i32.const 4
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      local.get 4
      i64.load offset=8 align=1
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      i64.load align=1
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 8
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4944
        i32.const 82
        i32.const 4
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      local.get 1
      local.set 10
      local.get 9
      local.get 10
      call $goose.memory_op.55
    end
  )
  (func $first.3 (;14;) (type 13) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5026
        i32.const 82
        i32.const 5
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 2
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 8
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5108
        i32.const 82
        i32.const 5
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      call $goose.memory_op.41
      local.set 9
      local.get 9
      local.set 2
    end
    local.get 2
  )
  (func $goose.init (;15;) (type 10)
    (local i32)
  )
  (func $goose.start (;16;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.41 (;18;) (type 13) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;19;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.49 (;21;) (type 13) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;22;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.gooseselected=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose")
)
