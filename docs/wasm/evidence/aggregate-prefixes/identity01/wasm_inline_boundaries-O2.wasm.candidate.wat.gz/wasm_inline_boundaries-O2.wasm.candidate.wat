(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1712)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 76
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 84
        i32.const 76
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i64 i64 i32 i32 i32 i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32)
    i32.const 131593
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 5
      local.get 0
      i32.const 1
      i32.add
      local.set 6
      block ;; label = @2
        local.get 0
        i32.const 0
        i32.add
        local.set 1
        local.get 0
        i32.const 1
        i32.add
        local.set 2
        local.get 1
        local.get 2
        i32.ne
        local.set 7
        call 0
        local.set 8
        local.get 8
        i32.const 160
        i32.const 9
        call 4
        local.get 8
        local.get 7
        call 3
        local.get 8
        call 5
        i64.const 0
        local.set 9
        i64.const 0
        local.set 10
        call 0
        local.set 11
        local.get 11
        i32.const 169
        i32.const 5
        call 4
        local.get 11
        local.get 9
        i32.const 0
        call 1
        local.get 11
        i32.const 174
        i32.const 1
        call 4
        local.get 11
        local.get 10
        i32.const 0
        call 1
        local.get 11
        call 5
      end
      local.get 0
      i32.const 2
      i32.add
      local.set 12
      local.get 12
      i64.const 0
      i64.store8
      local.get 12
      i32.const 1
      i32.add
      i32.const 0
      i32.const 255
      memory.fill
      local.get 0
      i32.const 258
      i32.add
      local.set 13
      local.get 13
      i64.const 0
      i64.store16 align=1
      local.get 13
      i32.const 2
      i32.add
      i32.const 0
      i32.const 256
      memory.fill
      i64.const 0
      local.set 14
      i64.const 255
      local.set 15
      block ;; label = @2
        loop ;; label = @3
          local.get 14
          local.get 15
          i64.ge_s
          br_if 1 (;@2;)
          local.get 14
          local.set 3
          block ;; label = @4
            local.get 0
            i32.const 2
            i32.add
            local.set 16
            local.get 3
            i64.const 255
            i64.and
            local.set 17
            local.get 16
            i64.load8_u
            local.set 18
            local.get 18
            i64.const 255
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 175
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 16
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 20
            local.get 20
            i64.const 4294967295
            i64.and
            local.get 18
            i64.const 1
            i64.mul
            i64.add
            local.tee 21
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 251
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 20
            i64.const -4294967296
            i64.and
            local.get 21
            i64.or
            local.tee 22
            local.get 17
            local.set 23
            i32.wrap_i64
            local.get 23
            i64.store8
            local.get 16
            local.get 18
            i64.const 1
            i64.add
            i64.store8
            local.get 22
            i32.wrap_i64
            i64.load8_u
            drop
            local.get 0
            i32.const 258
            i32.add
            local.set 24
            local.get 3
            i64.const 255
            i64.and
            local.set 25
            local.get 24
            i64.load16_u align=1
            local.set 26
            local.get 26
            i64.const 256
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 327
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 24
            i32.const 2
            i32.add
            i64.extend_i32_u
            local.set 28
            local.get 28
            i64.const 4294967295
            i64.and
            local.get 26
            i64.const 1
            i64.mul
            i64.add
            local.tee 29
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 403
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 28
            i64.const -4294967296
            i64.and
            local.get 29
            i64.or
            local.tee 30
            local.get 25
            local.set 31
            i32.wrap_i64
            local.get 31
            i64.store8
            local.get 24
            local.get 26
            i64.const 1
            i64.add
            i64.store16 align=1
            local.get 30
            i32.wrap_i64
            i64.load8_u
            drop
          end
          local.get 14
          i64.const 1
          i64.add
          local.set 14
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 258
      i32.add
      local.set 32
      i64.const 255
      local.set 33
      local.get 32
      i64.load16_u align=1
      local.set 34
      local.get 34
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 479
        i32.const 76
        i32.const 10
        call 6
        unreachable
      end
      local.get 32
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 36
      local.get 36
      i64.const 4294967295
      i64.and
      local.get 34
      i64.const 1
      i64.mul
      i64.add
      local.tee 37
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 555
        i32.const 76
        i32.const 10
        call 6
        unreachable
      end
      local.get 36
      i64.const -4294967296
      i64.and
      local.get 37
      i64.or
      local.tee 38
      local.get 33
      local.set 39
      i32.wrap_i64
      local.get 39
      i64.store8
      local.get 32
      local.get 34
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 38
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 2
      i32.add
      local.set 40
      local.get 40
      i64.load8_u
      local.set 41
      local.get 0
      i32.const 2
      i32.add
      local.set 42
      local.get 42
      i64.load8_u
      local.set 43
      i64.const 254
      local.set 44
      local.get 42
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 45
      local.get 45
      i64.const 4294967295
      i64.and
      local.get 44
      i64.const 1
      i64.mul
      i64.add
      local.tee 46
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 631
        i32.const 76
        i32.const 11
        call 6
        unreachable
      end
      local.get 45
      i64.const -4294967296
      i64.and
      local.get 46
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 47
      local.get 0
      i32.const 258
      i32.add
      local.set 48
      local.get 48
      i64.load16_u align=1
      local.set 49
      local.get 0
      i32.const 258
      i32.add
      local.set 50
      local.get 50
      i64.load16_u align=1
      local.set 51
      i64.const 255
      local.set 52
      local.get 50
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 53
      local.get 53
      i64.const 4294967295
      i64.and
      local.get 52
      i64.const 1
      i64.mul
      i64.add
      local.tee 54
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 707
        i32.const 76
        i32.const 11
        call 6
        unreachable
      end
      local.get 53
      i64.const -4294967296
      i64.and
      local.get 54
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 55
      call 0
      local.set 56
      local.get 56
      local.get 41
      i32.const 0
      call 1
      local.get 56
      i32.const 783
      i32.const 1
      call 4
      local.get 56
      local.get 47
      i32.const 1
      call 1
      local.get 56
      i32.const 784
      i32.const 1
      call 4
      local.get 56
      local.get 49
      i32.const 0
      call 1
      local.get 56
      i32.const 785
      i32.const 1
      call 4
      local.get 56
      local.get 55
      i32.const 1
      call 1
      local.get 56
      call 5
      local.get 0
      i32.const 516
      i32.add
      local.set 57
      local.get 57
      i64.const 0
      i64.store16 align=1
      local.get 57
      i32.const 2
      i32.add
      i32.const 0
      i32.const 65535
      memory.fill
      local.get 0
      i32.const 66053
      i32.add
      local.set 58
      local.get 58
      i64.const 0
      i64.store32 align=1
      local.get 58
      i32.const 4
      i32.add
      i32.const 0
      i32.const 65536
      memory.fill
      i64.const 0
      local.set 59
      i64.const 65535
      local.set 60
      block ;; label = @2
        loop ;; label = @3
          local.get 59
          local.get 60
          i64.ge_s
          br_if 1 (;@2;)
          local.get 59
          local.set 4
          block ;; label = @4
            local.get 0
            i32.const 516
            i32.add
            local.set 61
            local.get 4
            i64.const 255
            i64.and
            local.set 62
            local.get 61
            i64.load16_u align=1
            local.set 63
            local.get 63
            i64.const 65535
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 786
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 61
            i32.const 2
            i32.add
            i64.extend_i32_u
            local.set 65
            local.get 65
            i64.const 4294967295
            i64.and
            local.get 63
            i64.const 1
            i64.mul
            i64.add
            local.tee 66
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 862
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 65
            i64.const -4294967296
            i64.and
            local.get 66
            i64.or
            local.tee 67
            local.get 62
            local.set 68
            i32.wrap_i64
            local.get 68
            i64.store8
            local.get 61
            local.get 63
            i64.const 1
            i64.add
            i64.store16 align=1
            local.get 67
            i32.wrap_i64
            i64.load8_u
            drop
            local.get 0
            i32.const 66053
            i32.add
            local.set 69
            local.get 4
            i64.const 255
            i64.and
            local.set 70
            local.get 69
            i64.load32_u align=1
            local.set 71
            local.get 71
            i64.const 65536
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 938
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 69
            i32.const 4
            i32.add
            i64.extend_i32_u
            local.set 73
            local.get 73
            i64.const 4294967295
            i64.and
            local.get 71
            i64.const 1
            i64.mul
            i64.add
            local.tee 74
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1014
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 73
            i64.const -4294967296
            i64.and
            local.get 74
            i64.or
            local.tee 75
            local.get 70
            local.set 76
            i32.wrap_i64
            local.get 76
            i64.store8
            local.get 69
            local.get 71
            i64.const 1
            i64.add
            i64.store32 align=1
            local.get 75
            i32.wrap_i64
            i64.load8_u
            drop
          end
          local.get 59
          i64.const 1
          i64.add
          local.set 59
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 66053
      i32.add
      local.set 77
      i64.const 255
      local.set 78
      local.get 77
      i64.load32_u align=1
      local.set 79
      local.get 79
      i64.const 65536
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1090
        i32.const 76
        i32.const 14
        call 6
        unreachable
      end
      local.get 77
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 81
      local.get 81
      i64.const 4294967295
      i64.and
      local.get 79
      i64.const 1
      i64.mul
      i64.add
      local.tee 82
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1166
        i32.const 76
        i32.const 14
        call 6
        unreachable
      end
      local.get 81
      i64.const -4294967296
      i64.and
      local.get 82
      i64.or
      local.tee 83
      local.get 78
      local.set 84
      i32.wrap_i64
      local.get 84
      i64.store8
      local.get 77
      local.get 79
      i64.const 1
      i64.add
      i64.store32 align=1
      local.get 83
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 516
      i32.add
      local.set 85
      local.get 85
      i64.load16_u align=1
      local.set 86
      local.get 0
      i32.const 516
      i32.add
      local.set 87
      local.get 87
      i64.load16_u align=1
      local.set 88
      i64.const 65534
      local.set 89
      local.get 87
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 90
      local.get 90
      i64.const 4294967295
      i64.and
      local.get 89
      i64.const 1
      i64.mul
      i64.add
      local.tee 91
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1242
        i32.const 76
        i32.const 15
        call 6
        unreachable
      end
      local.get 90
      i64.const -4294967296
      i64.and
      local.get 91
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 92
      local.get 0
      i32.const 66053
      i32.add
      local.set 93
      local.get 93
      i64.load32_u align=1
      local.set 94
      local.get 0
      i32.const 66053
      i32.add
      local.set 95
      local.get 95
      i64.load32_u align=1
      local.set 96
      i64.const 65535
      local.set 97
      local.get 95
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 98
      local.get 98
      i64.const 4294967295
      i64.and
      local.get 97
      i64.const 1
      i64.mul
      i64.add
      local.tee 99
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1318
        i32.const 76
        i32.const 15
        call 6
        unreachable
      end
      local.get 98
      i64.const -4294967296
      i64.and
      local.get 99
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 100
      call 0
      local.set 101
      local.get 101
      local.get 86
      i32.const 0
      call 1
      local.get 101
      i32.const 1394
      i32.const 1
      call 4
      local.get 101
      local.get 92
      i32.const 1
      call 1
      local.get 101
      i32.const 1395
      i32.const 1
      call 4
      local.get 101
      local.get 94
      i32.const 0
      call 1
      local.get 101
      i32.const 1396
      i32.const 1
      call 4
      local.get 101
      local.get 100
      i32.const 1
      call 1
      local.get 101
      call 5
      local.get 0
      i32.const 258
      i32.add
      local.set 102
      local.get 102
      i64.load16_u align=1
      local.set 103
      local.get 103
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1397
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 103
      i64.const 1
      i64.sub
      local.set 103
      local.get 102
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 104
      local.get 104
      i64.const 4294967295
      i64.and
      local.get 103
      i64.const 1
      i64.mul
      i64.add
      local.tee 105
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1473
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 104
      i64.const -4294967296
      i64.and
      local.get 105
      i64.or
      local.set 106
      local.get 106
      i32.wrap_i64
      i64.load8_u
      local.set 107
      local.get 102
      local.get 103
      i64.store16 align=1
      local.get 107
      local.set 108
      local.get 0
      i32.const 258
      i32.add
      local.set 109
      local.get 109
      i64.load16_u align=1
      local.set 110
      local.get 0
      i32.const 66053
      i32.add
      local.set 111
      local.get 111
      i64.load32_u align=1
      local.set 112
      local.get 112
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1549
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 112
      i64.const 1
      i64.sub
      local.set 112
      local.get 111
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 113
      local.get 113
      i64.const 4294967295
      i64.and
      local.get 112
      i64.const 1
      i64.mul
      i64.add
      local.tee 114
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1625
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 113
      i64.const -4294967296
      i64.and
      local.get 114
      i64.or
      local.set 115
      local.get 115
      i32.wrap_i64
      i64.load8_u
      local.set 116
      local.get 111
      local.get 112
      i64.store32 align=1
      local.get 116
      local.set 117
      local.get 0
      i32.const 66053
      i32.add
      local.set 118
      local.get 118
      i64.load32_u align=1
      local.set 119
      call 0
      local.set 120
      local.get 120
      local.get 108
      i32.const 1
      call 1
      local.get 120
      i32.const 1701
      i32.const 1
      call 4
      local.get 120
      local.get 110
      i32.const 0
      call 1
      local.get 120
      i32.const 1702
      i32.const 1
      call 4
      local.get 120
      local.get 117
      i32.const 1
      call 1
      local.get 120
      i32.const 1703
      i32.const 1
      call 4
      local.get 120
      local.get 119
      i32.const 0
      call 1
      local.get 120
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goosedistinct=zero=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose,,,")
)
