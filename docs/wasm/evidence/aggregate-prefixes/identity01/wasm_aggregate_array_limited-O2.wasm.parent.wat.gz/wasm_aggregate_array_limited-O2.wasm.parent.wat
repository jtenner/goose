(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 9 65536)
  (global (;0;) (mut i32) i32.const 526784)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 524300
      i32.const 82
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 524382
        i32.const 82
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i64 i32 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32)
    i32.const 528423
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      i64.const 2
      i64.store8
      local.get 3
      i64.const 1
      i64.store offset=1 align=1
      local.get 3
      i64.const 2
      i64.store offset=9 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 4
      local.get 4
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 524464
        i32.const 82
        i32.const 4
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 5
      i64.const 0
      local.set 6
      block ;; label = @2
        loop ;; label = @3
          local.get 6
          local.get 5
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 5
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 7
          local.get 7
          i64.const 4294967295
          i64.and
          local.get 6
          i64.const 8
          i64.mul
          i64.add
          local.tee 8
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 524546
            i32.const 82
            i32.const 5
            call 6
            unreachable
          end
          local.get 7
          i64.const -4294967296
          i64.and
          local.get 8
          i64.or
          i32.wrap_i64
          local.set 1
          local.get 6
          local.set 2
          block ;; label = @4
            local.get 1
            local.tee 9
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 524628
              i32.const 82
              i32.const 5
              call 6
              unreachable
            end
            local.get 9
            local.get 9
            i64.load align=1
            local.get 2
            i64.const 3
            i64.add
            i64.add
            i64.store align=1
          end
          local.get 6
          i64.const 1
          i64.add
          local.set 6
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i64.load8_u
      local.set 11
      i64.const 0
      local.set 12
      local.get 10
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 524710
        i32.const 82
        i32.const 5
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.set 15
      local.get 15
      i32.wrap_i64
      i64.load align=1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 524792
        i32.const 82
        i32.const 5
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 16
      local.get 16
      i64.load8_u
      local.set 17
      i64.const 1
      local.set 18
      local.get 16
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 524874
        i32.const 82
        i32.const 5
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load align=1
      i64.const 6
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 524956
        i32.const 82
        i32.const 5
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 22
      i32.const 25
      local.set 23
      local.get 22
      i64.extend_i32_u
      local.set 24
      local.get 0
      i32.const 25
      i32.add
      i64.extend_i32_u
      local.set 25
      local.get 25
      i32.wrap_i64
      local.get 24
      i32.wrap_i64
      local.get 23
      memory.copy
      local.get 0
      i32.const 25
      i32.add
      local.set 26
      local.get 26
      i64.load8_u
      local.set 27
      i64.const 1
      local.set 28
      local.get 28
      local.get 27
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 525038
        i32.const 82
        i32.const 6
        call 6
        unreachable
      end
      local.get 26
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      local.get 28
      i64.const 8
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 525120
        i32.const 82
        i32.const 6
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      local.set 31
      local.get 31
      i32.wrap_i64
      local.get 31
      i32.wrap_i64
      i64.load align=1
      i64.const 10
      i64.add
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 32
      local.get 32
      i64.load8_u
      local.set 33
      i64.const 1
      local.set 34
      local.get 32
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 35
      local.get 35
      i64.const 4294967295
      i64.and
      local.get 34
      i64.const 8
      i64.mul
      i64.add
      local.tee 36
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 525202
        i32.const 82
        i32.const 6
        call 6
        unreachable
      end
      local.get 35
      i64.const -4294967296
      i64.and
      local.get 36
      i64.or
      local.set 37
      local.get 37
      i32.wrap_i64
      i64.load align=1
      i64.const 6
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 525284
        i32.const 82
        i32.const 6
        call 6
        unreachable
      end
      local.get 0
      i32.const 25
      i32.add
      local.set 38
      local.get 38
      i64.load8_u
      local.set 39
      i64.const 1
      local.set 40
      local.get 38
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 41
      local.get 41
      i64.const 4294967295
      i64.and
      local.get 40
      i64.const 8
      i64.mul
      i64.add
      local.tee 42
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 525366
        i32.const 82
        i32.const 6
        call 6
        unreachable
      end
      local.get 41
      i64.const -4294967296
      i64.and
      local.get 42
      i64.or
      local.set 43
      local.get 43
      i32.wrap_i64
      i64.load align=1
      i64.const 16
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 525448
        i32.const 82
        i32.const 6
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 44
      local.get 44
      i64.load8_u
      local.set 45
      i64.const 0
      local.set 45
      local.get 44
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 46
      local.get 46
      i64.const 4294967295
      i64.and
      local.get 45
      i64.const 8
      i64.mul
      i64.add
      local.tee 47
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 525530
        i32.const 82
        i32.const 7
        call 6
        unreachable
      end
      local.get 46
      i64.const -4294967296
      i64.and
      local.get 47
      i64.or
      local.set 48
      local.get 44
      local.get 45
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      local.set 49
      local.get 49
      i64.load8_u
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 525612
        i32.const 82
        i32.const 7
        call 6
        unreachable
      end
      local.get 0
      i32.const 25
      i32.add
      local.set 50
      local.get 50
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 525694
        i32.const 82
        i32.const 7
        call 6
        unreachable
      end
      local.get 0
      i32.const 50
      i32.add
      local.set 51
      local.get 51
      i64.const 1
      i64.store8
      local.get 51
      i64.const 7
      i64.store offset=1 align=1
      local.get 0
      i32.const 2091
      i32.add
      local.set 52
      local.get 52
      i64.const 1
      i64.store16 align=1
      local.get 52
      i64.const 8
      i64.store offset=2 align=1
      local.get 0
      i32.const 4141
      i32.add
      local.set 53
      local.get 53
      i64.const 1
      i64.store16 align=1
      local.get 53
      i64.const 10
      i64.store offset=2 align=1
      local.get 0
      i32.const 50
      i32.add
      local.set 54
      local.get 54
      i64.load8_u
      local.set 55
      i64.const 0
      local.set 56
      local.get 54
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 57
      local.get 57
      i64.const 4294967295
      i64.and
      local.get 56
      i64.const 8
      i64.mul
      i64.add
      local.tee 58
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 525776
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 57
      i64.const -4294967296
      i64.and
      local.get 58
      i64.or
      local.set 59
      local.get 59
      i32.wrap_i64
      i64.load align=1
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 525858
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 0
      i32.const 2091
      i32.add
      local.set 60
      local.get 60
      i64.load16_u align=1
      local.set 61
      i64.const 0
      local.set 62
      local.get 60
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 63
      local.get 63
      i64.const 4294967295
      i64.and
      local.get 62
      i64.const 8
      i64.mul
      i64.add
      local.tee 64
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 525940
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 63
      i64.const -4294967296
      i64.and
      local.get 64
      i64.or
      local.set 65
      local.get 65
      i32.wrap_i64
      i64.load align=1
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 526022
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 0
      i32.const 4141
      i32.add
      local.set 66
      local.get 66
      i64.load16_u align=1
      local.set 67
      i64.const 0
      local.set 68
      local.get 66
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 69
      local.get 69
      i64.const 4294967295
      i64.and
      local.get 68
      i64.const 8
      i64.mul
      i64.add
      local.tee 70
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 526104
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 69
      i64.const -4294967296
      i64.and
      local.get 70
      i64.or
      local.set 71
      local.get 71
      i32.wrap_i64
      i64.load align=1
      i64.const 10
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 526186
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      i32.const 8
      local.set 72
      local.get 72
      i64.load32_u align=1
      local.set 73
      i64.const 0
      local.set 74
      local.get 74
      local.get 73
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 526268
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 72
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 75
      local.get 75
      i64.const 4294967295
      i64.and
      local.get 74
      i64.const 8
      i64.mul
      i64.add
      local.tee 76
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 526350
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 75
      i64.const -4294967296
      i64.and
      local.get 76
      i64.or
      local.set 77
      local.get 77
      i32.wrap_i64
      i64.load align=1
      i64.const 9
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 526432
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      i32.const 8
      local.set 78
      local.get 78
      i64.load32_u align=1
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 526514
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 0
      i32.const 25
      i32.add
      local.set 79
      local.get 79
      i64.load8_u
      local.set 80
      i64.const 0
      local.set 81
      local.get 79
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 82
      local.get 82
      i64.const 4294967295
      i64.and
      local.get 81
      i64.const 8
      i64.mul
      i64.add
      local.tee 83
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 526596
        i32.const 82
        i32.const 10
        call 6
        unreachable
      end
      local.get 82
      i64.const -4294967296
      i64.and
      local.get 83
      i64.or
      local.set 84
      local.get 84
      i32.wrap_i64
      i64.load align=1
      local.set 85
      local.get 0
      i32.const 25
      i32.add
      local.set 86
      local.get 86
      i64.load8_u
      local.set 87
      i64.const 1
      local.set 88
      local.get 86
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 89
      local.get 89
      i64.const 4294967295
      i64.and
      local.get 88
      i64.const 8
      i64.mul
      i64.add
      local.tee 90
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 526678
        i32.const 82
        i32.const 10
        call 6
        unreachable
      end
      local.get 89
      i64.const -4294967296
      i64.and
      local.get 90
      i64.or
      local.set 91
      local.get 91
      i32.wrap_i64
      i64.load align=1
      local.set 92
      call 0
      local.set 93
      local.get 93
      i32.const 526760
      i32.const 8
      call 4
      local.get 93
      local.get 85
      i32.const 0
      call 1
      local.get 93
      i32.const 526768
      i32.const 1
      call 4
      local.get 93
      local.get 92
      i32.const 0
      call 1
      local.get 93
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32 i32)
    i32.const 8
    local.set 1
    local.get 1
    i64.const 1
    i64.store32 align=1
    local.get 1
    i64.const 9
    i64.store offset=4 align=1
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 524300) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_limited.gooselimited=,")
)
