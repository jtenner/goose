(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 2448)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 81
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 89
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i32 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32)
    i32.const 128
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      i64.const 7
      i64.store8
      local.get 3
      i64.const 1
      i64.store offset=1 align=1
      local.get 3
      i32.const 9
      i32.add
      i32.const 0
      i32.add
      i64.const 2
      i64.store8
      local.get 3
      i32.const 9
      i32.add
      i32.const 1
      i32.add
      i64.const 3
      i64.store8
      local.get 3
      i64.const 4
      i64.store offset=11 align=1
      local.get 3
      i32.const 19
      i32.add
      i32.const 0
      i32.add
      i64.const 5
      i64.store8
      local.get 3
      i32.const 19
      i32.add
      i32.const 1
      i32.add
      i64.const 6
      i64.store8
      local.get 3
      i64.const 1
      i64.store8 offset=21
      local.get 3
      i64.const 8
      i64.store offset=22 align=1
      local.get 3
      i32.const 30
      i32.add
      i32.const 0
      i32.add
      i64.const 9
      i64.store8
      local.get 3
      i32.const 30
      i32.add
      i32.const 1
      i32.add
      i64.const 10
      i64.store8
      local.get 3
      i32.const 32
      i32.add
      i32.const 0
      i32.const 20
      memory.fill
      local.get 3
      i64.const 65000
      i64.store16 offset=52 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 4
      local.get 4
      i32.const 1
      i32.add
      call $value.1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 170
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 5
      local.get 5
      i32.const 21
      i32.add
      local.set 6
      local.get 6
      i64.load8_u
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 251
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 7
      local.get 7
      i32.const 21
      i32.add
      local.set 8
      local.get 8
      i64.load8_u
      local.set 9
      i64.const 0
      local.set 10
      local.get 8
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 11
      local.get 11
      i64.const 4294967295
      i64.and
      local.get 10
      i64.const 10
      i64.mul
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 332
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 11
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 413
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 14
      i32.wrap_i64
      local.set 15
      i64.const 2
      local.set 16
      i64.const 1
      local.set 17
      local.get 15
      i64.extend_i32_u
      local.set 18
      local.get 18
      i64.const 4294967295
      i64.and
      local.get 17
      i64.const 1
      i64.mul
      i64.add
      local.tee 19
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 494
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 18
      i64.const -4294967296
      i64.and
      local.get 19
      i64.or
      i32.wrap_i64
      i64.load8_u
      i64.const 10
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 575
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 20
      local.get 20
      i32.const 1
      i32.add
      local.set 21
      i32.const 20
      local.set 22
      local.get 21
      i64.extend_i32_u
      local.set 23
      local.get 0
      i32.const 54
      i32.add
      i64.extend_i32_u
      local.set 24
      local.get 24
      i32.wrap_i64
      local.get 23
      i32.wrap_i64
      local.get 22
      memory.copy
      local.get 0
      i32.const 54
      i32.add
      local.set 25
      i64.const 2
      local.set 26
      i64.const 1
      local.set 27
      local.get 25
      i64.extend_i32_u
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      local.get 27
      i64.const 10
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 656
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      local.set 30
      local.get 30
      i32.wrap_i64
      i64.const 99
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 31
      local.get 31
      i32.const 1
      i32.add
      local.set 32
      i64.const 2
      local.set 33
      i64.const 1
      local.set 34
      local.get 32
      i64.extend_i32_u
      local.set 35
      local.get 35
      i64.const 4294967295
      i64.and
      local.get 34
      i64.const 10
      i64.mul
      i64.add
      local.tee 36
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 737
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 35
      i64.const -4294967296
      i64.and
      local.get 36
      i64.or
      local.set 37
      local.get 37
      i32.wrap_i64
      i64.load align=1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 818
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 0
      i32.const 74
      i32.add
      local.set 38
      local.get 0
      i32.const 0
      i32.add
      local.set 39
      local.get 38
      i64.extend_i32_u
      local.set 40
      local.get 39
      i64.extend_i32_u
      local.set 41
      i32.const 54
      local.set 42
      local.get 40
      i32.wrap_i64
      local.get 41
      i32.wrap_i64
      local.get 42
      memory.copy
      local.get 0
      i32.const 74
      i32.add
      local.set 43
      local.get 43
      i32.const 1
      i32.add
      local.set 44
      i64.const 2
      local.set 45
      i64.const 0
      local.set 46
      local.get 44
      i64.extend_i32_u
      local.set 47
      local.get 47
      i64.const 4294967295
      i64.and
      local.get 46
      i64.const 10
      i64.mul
      i64.add
      local.tee 48
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 899
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 47
      i64.const -4294967296
      i64.and
      local.get 48
      i64.or
      local.set 49
      local.get 49
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 980
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 14
      i32.wrap_i64
      local.set 50
      i64.const 2
      local.set 51
      i64.const 0
      local.set 52
      local.get 50
      i64.extend_i32_u
      local.set 53
      local.get 53
      i64.const 4294967295
      i64.and
      local.get 52
      i64.const 1
      i64.mul
      i64.add
      local.tee 54
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1061
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 53
      i64.const -4294967296
      i64.and
      local.get 54
      i64.or
      local.set 55
      i64.const 55
      local.set 56
      local.get 55
      local.get 56
      local.set 57
      i32.wrap_i64
      local.get 57
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      local.set 58
      local.get 58
      i32.const 1
      i32.add
      local.set 59
      i64.const 2
      local.set 60
      i64.const 0
      local.set 61
      local.get 59
      i64.extend_i32_u
      local.set 62
      local.get 62
      i64.const 4294967295
      i64.and
      local.get 61
      i64.const 10
      i64.mul
      i64.add
      local.tee 63
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1142
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 62
      i64.const -4294967296
      i64.and
      local.get 63
      i64.or
      local.set 64
      local.get 64
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1223
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 14
      i32.wrap_i64
      local.set 65
      i64.const 2
      local.set 66
      i64.const 0
      local.set 67
      local.get 65
      i64.extend_i32_u
      local.set 68
      local.get 68
      i64.const 4294967295
      i64.and
      local.get 67
      i64.const 1
      i64.mul
      i64.add
      local.tee 69
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1304
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 68
      i64.const -4294967296
      i64.and
      local.get 69
      i64.or
      i32.wrap_i64
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1385
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 70
      local.get 70
      i32.const 1
      i32.add
      local.set 1
      i64.const 0
      local.set 72
      block ;; label = @2
        loop ;; label = @3
          local.get 1
          local.tee 73
          i32.eqz
          if ;; label = @4
            i32.const 4
            i32.const 1466
            i32.const 81
            i32.const 9
            call 6
            unreachable
          end
          local.get 73
          local.set 74
          local.get 74
          local.set 71
          local.get 72
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 71
          i64.extend_i32_u
          local.set 75
          local.get 75
          i64.const 4294967295
          i64.and
          local.get 72
          i64.const 10
          i64.mul
          i64.add
          local.tee 76
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1547
            i32.const 81
            i32.const 9
            call 6
            unreachable
          end
          local.get 75
          i64.const -4294967296
          i64.and
          local.get 76
          i64.or
          i32.wrap_i64
          local.set 2
          block ;; label = @4
            local.get 2
            local.tee 77
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 1628
              i32.const 81
              i32.const 9
              call 6
              unreachable
            end
            local.get 77
            local.get 77
            i64.load align=1
            i64.const 3
            i64.add
            i64.store align=1
          end
          local.get 72
          i64.const 1
          i64.add
          local.set 72
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 78
      local.get 78
      i32.const 1
      i32.add
      local.set 79
      i64.const 2
      local.set 80
      i64.const 0
      local.set 81
      local.get 79
      i64.extend_i32_u
      local.set 82
      local.get 82
      i64.const 4294967295
      i64.and
      local.get 81
      i64.const 10
      i64.mul
      i64.add
      local.tee 83
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1709
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 82
      i64.const -4294967296
      i64.and
      local.get 83
      i64.or
      local.set 84
      local.get 84
      i32.wrap_i64
      i64.load align=1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1790
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 85
      local.get 85
      i32.const 1
      i32.add
      local.set 86
      i64.const 2
      local.set 87
      i64.const 1
      local.set 88
      local.get 86
      i64.extend_i32_u
      local.set 89
      local.get 89
      i64.const 4294967295
      i64.and
      local.get 88
      i64.const 10
      i64.mul
      i64.add
      local.tee 90
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1871
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 89
      i64.const -4294967296
      i64.and
      local.get 90
      i64.or
      local.set 91
      local.get 91
      i32.wrap_i64
      i64.load align=1
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1952
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 92
      local.get 92
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2033
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 93
      local.get 93
      i64.load16_u offset=52 align=1
      i64.const 65000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2114
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 94
      local.get 94
      i32.const 1
      i32.add
      call $value.1
      local.set 95
      local.get 0
      i32.const 54
      i32.add
      local.set 96
      i64.const 2
      local.set 97
      i64.const 1
      local.set 98
      local.get 96
      i64.extend_i32_u
      local.set 99
      local.get 99
      i64.const 4294967295
      i64.and
      local.get 98
      i64.const 10
      i64.mul
      i64.add
      local.tee 100
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2195
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 99
      i64.const -4294967296
      i64.and
      local.get 100
      i64.or
      local.set 101
      local.get 101
      i32.wrap_i64
      i64.load align=1
      local.set 102
      call 0
      local.set 103
      local.get 103
      i32.const 2276
      i32.const 7
      call 4
      local.get 103
      local.get 95
      i32.const 0
      call 1
      local.get 103
      i32.const 2283
      i32.const 1
      call 4
      local.get 103
      local.get 102
      i32.const 0
      call 1
      local.get 103
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $value.1 (;12;) (type 11) (param i32) (result i64)
    (local i32 i64 i32 i32 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2284
        i32.const 81
        i32.const 3
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 2
      local.set 5
      i64.const 1
      local.set 6
      local.get 4
      i64.extend_i32_u
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 10
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2365
        i32.const 81
        i32.const 3
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      i64.load align=1
      local.set 10
      local.get 10
      local.set 2
    end
    local.get 2
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goosefields=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_fields.goose")
)
