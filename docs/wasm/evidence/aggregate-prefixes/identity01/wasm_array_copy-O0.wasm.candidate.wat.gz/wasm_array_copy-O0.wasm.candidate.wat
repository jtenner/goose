(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (type (;13;) (func (param i64 i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (memory (;5;) 1 65536)
  (memory (;6;) 1 65536)
  (memory (;7;) 1 65536)
  (memory (;8;) 1 65536)
  (memory (;9;) 1 65536)
  (memory (;10;) 1 65536)
  (memory (;11;) 1 65536)
  (memory (;12;) 1 65536)
  (memory (;13;) 1 65536)
  (memory (;14;) 1 65536)
  (memory (;15;) 1 65536)
  (memory (;16;) 1 65536)
  (memory (;17;) 1 65536)
  (global (;0;) (mut i32) i32.const 5504)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (global (;5;) (mut i32) i32.const 1)
  (global (;6;) (mut i32) i32.const 1)
  (global (;7;) (mut i32) i32.const 1)
  (global (;8;) (mut i32) i32.const 1)
  (global (;9;) (mut i32) i32.const 1)
  (global (;10;) (mut i32) i32.const 1)
  (global (;11;) (mut i32) i32.const 1)
  (global (;12;) (mut i32) i32.const 1)
  (global (;13;) (mut i32) i32.const 1)
  (global (;14;) (mut i32) i32.const 1)
  (global (;15;) (mut i32) i32.const 1)
  (global (;16;) (mut i32) i32.const 1)
  (global (;17;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "data_memory_5" (memory 5))
  (export "data_memory_6" (memory 6))
  (export "data_memory_7" (memory 7))
  (export "data_memory_8" (memory 8))
  (export "data_memory_9" (memory 9))
  (export "data_memory_10" (memory 10))
  (export "data_memory_11" (memory 11))
  (export "data_memory_12" (memory 12))
  (export "data_memory_13" (memory 13))
  (export "data_memory_14" (memory 14))
  (export "data_memory_15" (memory 15))
  (export "data_memory_16" (memory 16))
  (export "data_memory_17" (memory 17))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 16
      i32.const 69
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 85
        i32.const 69
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 f64 i64 i32 i64 f64 f64 i64 i32 i64 f64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 f64 i32 i64 i32 i64 i32 i64 i64 i64 i64 f64 i32 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 218
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 8
      i64.load align=1
      call $copied.1
      local.set 11
      call 0
      local.set 12
      local.get 12
      i32.const 154
      i32.const 7
      call 4
      local.get 12
      local.get 11
      i32.const 0
      call 1
      local.get 12
      call 5
      i32.const 1
      local.set 13
      i32.const 28
      call $goose.reserve_memory.1
      local.set 14
      local.get 13
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 14
      i64.extend_i32_u
      i64.or
      local.set 15
      local.get 15
      local.set 1
      local.get 15
      i64.const 3
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 1 align=1
      i64.const 1
      local.set 17
      local.get 14
      i32.const 4
      i32.add
      local.get 17
      i64.store 1 align=1
      i64.const 2
      local.set 17
      local.get 14
      i32.const 12
      i32.add
      local.get 17
      i64.store 1 align=1
      i64.const 3
      local.set 17
      local.get 14
      i32.const 20
      i32.add
      local.get 17
      i64.store 1 align=1
      local.get 1
      local.set 18
      local.get 18
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 21
      local.get 21
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 161
        i32.const 69
        i32.const 12
        call 6
        unreachable
      end
      local.get 21
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 19
      local.get 18
      local.set 20
      i32.const 2
      local.set 23
      local.get 19
      call $goose.reserve_memory.2
      local.set 24
      local.get 23
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 24
      i64.extend_i32_u
      i64.or
      local.set 22
      local.get 22
      local.set 2
      local.get 22
      i32.wrap_i64
      local.get 20
      i32.wrap_i64
      local.get 19
      memory.copy 2 1
      local.get 2
      local.set 25
      local.get 25
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 26
      i64.const 0
      local.set 27
      local.get 27
      local.get 26
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 230
        i32.const 69
        i32.const 12
        call 6
        unreachable
      end
      local.get 25
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 27
      i64.const 8
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 299
        i32.const 69
        i32.const 12
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      local.set 30
      i64.const 90
      local.set 31
      local.get 30
      local.get 31
      local.set 32
      i32.wrap_i64
      local.get 32
      i64.store 2 align=1
      local.get 1
      local.set 33
      local.get 33
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 34
      i64.const 0
      local.set 35
      local.get 33
      local.set 36
      local.get 36
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 35
      i64.const 8
      i64.mul
      i64.add
      local.tee 37
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 368
        i32.const 69
        i32.const 13
        call 6
        unreachable
      end
      local.get 36
      i64.const -4294967296
      i64.and
      local.get 37
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 38
      local.get 2
      local.set 39
      local.get 39
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 40
      i64.const 0
      local.set 41
      local.get 39
      local.set 42
      local.get 42
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 41
      i64.const 8
      i64.mul
      i64.add
      local.tee 43
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 437
        i32.const 69
        i32.const 13
        call 6
        unreachable
      end
      local.get 42
      i64.const -4294967296
      i64.and
      local.get 43
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 44
      local.get 2
      local.set 45
      local.get 45
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 46
      call 0
      local.set 47
      local.get 47
      i32.const 506
      i32.const 9
      call 4
      local.get 47
      local.get 38
      i32.const 0
      call 1
      local.get 47
      i32.const 515
      i32.const 1
      call 4
      local.get 47
      local.get 44
      i32.const 0
      call 1
      local.get 47
      i32.const 516
      i32.const 1
      call 4
      local.get 47
      local.get 46
      i32.const 0
      call 1
      local.get 47
      call 5
      local.get 1
      local.set 48
      local.get 48
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 49
      i64.const 0
      local.set 50
      local.get 48
      local.set 51
      local.get 51
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 50
      i64.const 8
      i64.mul
      i64.add
      local.tee 52
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 517
        i32.const 69
        i32.const 14
        call 6
        unreachable
      end
      local.get 51
      i64.const -4294967296
      i64.and
      local.get 52
      i64.or
      local.get 2
      local.set 53
      local.get 53
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 54
      i64.const 0
      local.set 55
      local.get 53
      local.set 56
      local.get 56
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 55
      i64.const 8
      i64.mul
      i64.add
      local.tee 57
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 586
        i32.const 69
        i32.const 14
        call 6
        unreachable
      end
      local.get 56
      i64.const -4294967296
      i64.and
      local.get 57
      i64.or
      i64.ne
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 655
        i32.const 69
        i32.const 14
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 58
      local.get 58
      i32.const 0
      i32.add
      i64.const 4
      i64.store align=1
      local.get 58
      i32.const 8
      i32.add
      i64.const 5
      i64.store align=1
      local.get 58
      i32.const 16
      i32.add
      i64.const 6
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 59
      i32.const 24
      local.set 60
      local.get 59
      local.set 61
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 62
      local.get 62
      i32.wrap_i64
      local.get 61
      i32.wrap_i64
      local.get 60
      memory.copy
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 63
      i64.const 3
      local.set 64
      i64.const 1
      local.set 65
      local.get 63
      local.set 66
      local.get 66
      i64.const 4294967295
      i64.and
      local.get 65
      i64.const 8
      i64.mul
      i64.add
      local.tee 67
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 724
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 66
      i64.const -4294967296
      i64.and
      local.get 67
      i64.or
      local.set 68
      i64.const 20
      local.set 69
      local.get 68
      local.get 69
      local.set 70
      i32.wrap_i64
      local.get 70
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 71
      i64.const 3
      local.set 72
      i64.const 1
      local.set 73
      local.get 71
      local.set 74
      local.get 74
      i64.const 4294967295
      i64.and
      local.get 73
      i64.const 8
      i64.mul
      i64.add
      local.tee 75
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 793
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 74
      i64.const -4294967296
      i64.and
      local.get 75
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 76
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 77
      i64.const 3
      local.set 78
      i64.const 1
      local.set 79
      local.get 77
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      local.get 79
      i64.const 8
      i64.mul
      i64.add
      local.tee 81
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 862
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 81
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 82
      call 0
      local.set 83
      local.get 83
      i32.const 931
      i32.const 6
      call 4
      local.get 83
      local.get 76
      i32.const 0
      call 1
      local.get 83
      i32.const 937
      i32.const 1
      call 4
      local.get 83
      local.get 82
      i32.const 0
      call 1
      local.get 83
      call 5
      local.get 0
      i32.const 48
      i32.add
      local.set 84
      local.get 84
      i64.const 0
      i64.store8
      i64.const 10
      local.set 85
      local.get 84
      i64.load8_u
      local.set 86
      local.get 86
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 938
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 84
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 88
      local.get 88
      i64.const 4294967295
      i64.and
      local.get 86
      i64.const 8
      i64.mul
      i64.add
      local.tee 89
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1007
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 88
      i64.const -4294967296
      i64.and
      local.get 89
      i64.or
      local.tee 90
      local.get 85
      local.set 91
      i32.wrap_i64
      local.get 91
      i64.store align=1
      local.get 84
      local.get 86
      i64.const 1
      i64.add
      i64.store8
      i64.const 11
      local.set 92
      local.get 84
      i64.load8_u
      local.set 93
      local.get 93
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1076
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 84
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 95
      local.get 95
      i64.const 4294967295
      i64.and
      local.get 93
      i64.const 8
      i64.mul
      i64.add
      local.tee 96
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1145
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 95
      i64.const -4294967296
      i64.and
      local.get 96
      i64.or
      local.tee 97
      local.get 92
      local.set 98
      i32.wrap_i64
      local.get 98
      i64.store align=1
      local.get 84
      local.get 93
      i64.const 1
      i64.add
      i64.store8
      local.get 84
      i32.const 17
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      local.get 0
      i32.const 48
      i32.add
      i64.extend_i32_u
      local.set 99
      i32.const 33
      local.set 100
      local.get 99
      local.set 101
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 102
      local.get 102
      i32.wrap_i64
      local.get 101
      i32.wrap_i64
      local.get 100
      memory.copy
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 103
      i64.const 12
      local.set 104
      local.get 103
      i32.wrap_i64
      i64.load8_u
      local.set 105
      local.get 105
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1214
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 103
      local.set 107
      local.get 107
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 105
      i64.const 8
      i64.mul
      i64.add
      local.tee 108
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1283
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 107
      i64.const -4294967296
      i64.and
      local.get 108
      i64.or
      local.tee 109
      local.get 104
      local.set 110
      i32.wrap_i64
      local.get 110
      i64.store align=1
      local.get 103
      local.get 105
      i64.const 1
      i64.add
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store8
      local.get 109
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 48
      i32.add
      i64.extend_i32_u
      local.set 111
      local.get 111
      i32.wrap_i64
      i64.load8_u
      local.set 112
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 113
      local.get 113
      i32.wrap_i64
      i64.load8_u
      local.set 114
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 115
      local.get 115
      i32.wrap_i64
      i64.load8_u
      local.set 116
      i64.const 2
      local.set 117
      local.get 117
      local.get 116
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1352
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 115
      local.set 118
      local.get 118
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 117
      i64.const 8
      i64.mul
      i64.add
      local.tee 119
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1421
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 118
      i64.const -4294967296
      i64.and
      local.get 119
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 120
      call 0
      local.set 121
      local.get 121
      i32.const 1490
      i32.const 8
      call 4
      local.get 121
      local.get 112
      i32.const 0
      call 1
      local.get 121
      i32.const 1498
      i32.const 1
      call 4
      local.get 121
      local.get 114
      i32.const 0
      call 1
      local.get 121
      i32.const 1499
      i32.const 1
      call 4
      local.get 121
      local.get 120
      i32.const 0
      call 1
      local.get 121
      call 5
      i64.const 5
      local.set 122
      local.get 122
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 12
        i32.const 1500
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 122
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 1569
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      i32.const 3
      local.set 123
      local.get 122
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      call $goose.reserve_memory.3
      local.set 124
      local.get 123
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 124
      i64.extend_i32_u
      i64.or
      local.set 125
      local.get 125
      local.set 3
      local.get 125
      local.get 122
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 3 align=1
      local.get 125
      i64.const 0
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 3 offset=4 align=1
      local.get 3
      local.set 126
      i64.const 30
      local.set 127
      local.get 126
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 128
      local.get 128
      local.get 126
      i32.wrap_i64
      i64.load32_u 3 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1638
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 126
      local.set 130
      local.get 130
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 128
      i64.const 8
      i64.mul
      i64.add
      local.tee 131
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1707
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 130
      i64.const -4294967296
      i64.and
      local.get 131
      i64.or
      local.tee 132
      local.get 127
      local.set 133
      i32.wrap_i64
      local.get 133
      i64.store 3 align=1
      local.get 126
      local.get 128
      i64.const 1
      i64.add
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 3 offset=4 align=1
      local.get 132
      i32.wrap_i64
      i64.load 3 align=1
      drop
      local.get 3
      local.set 134
      i64.const 31
      local.set 135
      local.get 134
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 136
      local.get 136
      local.get 134
      i32.wrap_i64
      i64.load32_u 3 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1776
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 134
      local.set 138
      local.get 138
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 136
      i64.const 8
      i64.mul
      i64.add
      local.tee 139
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1845
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 138
      i64.const -4294967296
      i64.and
      local.get 139
      i64.or
      local.tee 140
      local.get 135
      local.set 141
      i32.wrap_i64
      local.get 141
      i64.store 3 align=1
      local.get 134
      local.get 136
      i64.const 1
      i64.add
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 3 offset=4 align=1
      local.get 140
      i32.wrap_i64
      i64.load 3 align=1
      drop
      local.get 3
      local.set 142
      local.get 142
      i32.wrap_i64
      i64.load32_u 3 align=1
      local.set 145
      local.get 145
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 1914
        i32.const 69
        i32.const 20
        call 6
        unreachable
      end
      local.get 145
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      local.set 143
      local.get 142
      local.set 144
      i32.const 4
      local.set 147
      local.get 143
      call $goose.reserve_memory.4
      local.set 148
      local.get 147
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 148
      i64.extend_i32_u
      i64.or
      local.set 146
      local.get 146
      local.set 4
      local.get 146
      i32.wrap_i64
      local.get 144
      i32.wrap_i64
      local.get 143
      memory.copy 4 3
      local.get 4
      local.set 149
      i64.const 32
      local.set 150
      local.get 149
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 151
      local.get 151
      local.get 149
      i32.wrap_i64
      i64.load32_u 4 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1983
        i32.const 69
        i32.const 20
        call 6
        unreachable
      end
      local.get 149
      local.set 153
      local.get 153
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 151
      i64.const 8
      i64.mul
      i64.add
      local.tee 154
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2052
        i32.const 69
        i32.const 20
        call 6
        unreachable
      end
      local.get 153
      i64.const -4294967296
      i64.and
      local.get 154
      i64.or
      local.tee 155
      local.get 150
      local.set 156
      i32.wrap_i64
      local.get 156
      i64.store 4 align=1
      local.get 149
      local.get 151
      i64.const 1
      i64.add
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 4 offset=4 align=1
      local.get 155
      i32.wrap_i64
      i64.load 4 align=1
      drop
      local.get 3
      local.set 157
      local.get 157
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 158
      local.get 4
      local.set 159
      local.get 159
      i32.wrap_i64
      i64.load32_u 4 align=1
      local.set 160
      local.get 4
      local.set 161
      local.get 161
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 162
      local.get 3
      call $copied_cap.2
      local.set 163
      call 0
      local.set 164
      local.get 164
      i32.const 2121
      i32.const 8
      call 4
      local.get 164
      local.get 158
      i32.const 0
      call 1
      local.get 164
      i32.const 2129
      i32.const 1
      call 4
      local.get 164
      local.get 160
      i32.const 0
      call 1
      local.get 164
      i32.const 2130
      i32.const 1
      call 4
      local.get 164
      local.get 162
      i32.const 0
      call 1
      local.get 164
      i32.const 2131
      i32.const 1
      call 4
      local.get 164
      local.get 163
      i32.const 0
      call 1
      local.get 164
      call 5
      i32.const 5
      local.set 165
      global.get 5
      local.set 166
      local.get 0
      i32.const 114
      i32.add
      local.set 167
      local.get 167
      local.get 165
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 166
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 167
      i64.const 0
      i64.store offset=8 align=1
      i64.const 40
      local.set 168
      local.get 167
      i64.load offset=8 align=1
      local.set 169
      i32.const 8
      call $goose.reserve_memory.5
      local.set 170
      local.get 167
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 170
      i64.extend_i32_u
      i64.or
      local.tee 171
      local.get 168
      local.set 172
      i32.wrap_i64
      local.get 172
      i64.store 5 align=1
      local.get 167
      local.get 169
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i64.const 41
      local.set 173
      local.get 167
      i64.load offset=8 align=1
      local.set 174
      i32.const 8
      call $goose.reserve_memory.5
      local.set 175
      local.get 167
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 175
      i64.extend_i32_u
      i64.or
      local.tee 176
      local.get 173
      local.set 177
      i32.wrap_i64
      local.get 177
      i64.store 5 align=1
      local.get 167
      local.get 174
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 114
      i32.add
      local.set 178
      local.get 178
      i64.load offset=8 align=1
      local.set 181
      local.get 181
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2132
        i32.const 69
        i32.const 22
        call 6
        unreachable
      end
      local.get 181
      i64.const 8
      i64.mul
      i32.wrap_i64
      local.set 179
      local.get 178
      i64.load align=1
      local.set 180
      i32.const 6
      local.set 183
      local.get 179
      call $goose.reserve_memory.6
      local.set 184
      local.get 183
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 184
      i64.extend_i32_u
      i64.or
      local.set 182
      local.get 0
      i32.const 130
      i32.add
      local.get 182
      i64.store align=1
      local.get 0
      i32.const 130
      i32.add
      local.get 181
      i64.store offset=8 align=1
      local.get 182
      i32.wrap_i64
      local.get 180
      i32.wrap_i64
      local.get 179
      memory.copy 6 5
      local.get 0
      i32.const 130
      i32.add
      local.set 185
      i64.const 42
      local.set 186
      local.get 185
      i64.load offset=8 align=1
      local.set 187
      i32.const 8
      call $goose.reserve_memory.6
      local.set 188
      local.get 185
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 188
      i64.extend_i32_u
      i64.or
      local.tee 189
      local.get 186
      local.set 190
      i32.wrap_i64
      local.get 190
      i64.store 6 align=1
      local.get 185
      local.get 187
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 189
      i32.wrap_i64
      i64.load 6 align=1
      drop
      local.get 0
      i32.const 114
      i32.add
      local.set 191
      local.get 191
      i64.load offset=8 align=1
      local.set 192
      local.get 0
      i32.const 130
      i32.add
      local.set 193
      local.get 193
      i64.load offset=8 align=1
      local.set 194
      local.get 0
      i32.const 130
      i32.add
      local.set 195
      local.get 195
      i64.load offset=8 align=1
      local.set 196
      i64.const 2
      local.set 197
      local.get 197
      local.get 196
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2201
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 195
      i64.load align=1
      local.set 198
      local.get 198
      i64.const 4294967295
      i64.and
      local.get 197
      i64.const 8
      i64.mul
      i64.add
      local.tee 199
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2270
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 198
      i64.const -4294967296
      i64.and
      local.get 199
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.set 200
      call 0
      local.set 201
      local.get 201
      i32.const 2339
      i32.const 5
      call 4
      local.get 201
      local.get 192
      i32.const 0
      call 1
      local.get 201
      i32.const 2344
      i32.const 1
      call 4
      local.get 201
      local.get 194
      i32.const 0
      call 1
      local.get 201
      i32.const 2345
      i32.const 1
      call 4
      local.get 201
      local.get 200
      i32.const 0
      call 1
      local.get 201
      call 5
      i32.const 7
      local.set 202
      global.get 7
      local.set 203
      local.get 0
      i32.const 146
      i32.add
      local.set 204
      local.get 204
      local.get 202
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 203
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 204
      i64.const 0
      i64.store offset=8 align=1
      f64.const -0x0p+0 (;=-0;)
      local.set 205
      local.get 204
      i64.load offset=8 align=1
      local.set 206
      i32.const 8
      call $goose.reserve_memory.7
      local.set 207
      local.get 204
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 207
      i64.extend_i32_u
      i64.or
      local.tee 208
      local.get 205
      local.set 209
      i32.wrap_i64
      local.get 209
      f64.store 7 align=1
      local.get 204
      local.get 206
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      f64.const 0x1.8p+0 (;=1.5;)
      local.set 210
      local.get 204
      i64.load offset=8 align=1
      local.set 211
      i32.const 8
      call $goose.reserve_memory.7
      local.set 212
      local.get 204
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 212
      i64.extend_i32_u
      i64.or
      local.tee 213
      local.get 210
      local.set 214
      i32.wrap_i64
      local.get 214
      f64.store 7 align=1
      local.get 204
      local.get 211
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 146
      i32.add
      local.set 215
      local.get 215
      i64.load offset=8 align=1
      local.set 218
      local.get 218
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2346
        i32.const 69
        i32.const 24
        call 6
        unreachable
      end
      local.get 218
      i64.const 8
      i64.mul
      i32.wrap_i64
      local.set 216
      local.get 215
      i64.load align=1
      local.set 217
      i32.const 8
      local.set 220
      local.get 216
      call $goose.reserve_memory.8
      local.set 221
      local.get 220
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 221
      i64.extend_i32_u
      i64.or
      local.set 219
      local.get 0
      i32.const 162
      i32.add
      local.get 219
      i64.store align=1
      local.get 0
      i32.const 162
      i32.add
      local.get 218
      i64.store offset=8 align=1
      local.get 219
      i32.wrap_i64
      local.get 217
      i32.wrap_i64
      local.get 216
      memory.copy 8 7
      local.get 0
      i32.const 162
      i32.add
      local.set 222
      local.get 222
      i64.load offset=8 align=1
      local.set 223
      local.get 223
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 2415
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 223
      i64.const 1
      i64.sub
      local.set 223
      local.get 222
      i64.load align=1
      local.set 224
      local.get 224
      i64.const 4294967295
      i64.and
      local.get 223
      i64.const 8
      i64.mul
      i64.add
      local.tee 225
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2484
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 224
      i64.const -4294967296
      i64.and
      local.get 225
      i64.or
      local.set 226
      local.get 226
      i32.wrap_i64
      f64.load 8 align=1
      local.set 227
      local.get 226
      i32.wrap_i64
      global.set 8
      local.get 222
      local.get 223
      i64.store offset=8 align=1
      local.get 227
      drop
      local.get 0
      i32.const 146
      i32.add
      local.set 228
      local.get 228
      i64.load offset=8 align=1
      local.set 229
      local.get 0
      i32.const 162
      i32.add
      local.set 230
      local.get 230
      i64.load offset=8 align=1
      local.set 231
      local.get 0
      i32.const 162
      i32.add
      local.set 232
      local.get 232
      i64.load offset=8 align=1
      local.set 233
      i64.const 0
      local.set 234
      local.get 234
      local.get 233
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2553
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 232
      i64.load align=1
      local.set 235
      local.get 235
      i64.const 4294967295
      i64.and
      local.get 234
      i64.const 8
      i64.mul
      i64.add
      local.tee 236
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2622
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 235
      i64.const -4294967296
      i64.and
      local.get 236
      i64.or
      i32.wrap_i64
      f64.load 8 align=1
      local.set 237
      call 0
      local.set 238
      local.get 238
      i32.const 2691
      i32.const 7
      call 4
      local.get 238
      local.get 229
      i32.const 0
      call 1
      local.get 238
      i32.const 2698
      i32.const 1
      call 4
      local.get 238
      local.get 231
      i32.const 0
      call 1
      local.get 238
      i32.const 2699
      i32.const 1
      call 4
      local.get 238
      local.get 237
      i32.const 64
      call 2
      local.get 238
      call 5
      i64.const 50
      local.set 239
      local.get 0
      i32.const 178
      i32.add
      local.get 239
      i64.store align=1
      i32.const 9
      local.set 240
      i32.const 12
      call $goose.reserve_memory.9
      local.set 241
      local.get 240
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 241
      i64.extend_i32_u
      i64.or
      local.set 242
      local.get 242
      local.set 5
      local.get 242
      i64.const 1
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store32 9 align=1
      local.get 0
      i32.const 178
      i32.add
      i64.extend_i32_u
      local.set 243
      local.get 241
      i32.const 4
      i32.add
      local.get 243
      i64.store 9 align=1
      local.get 5
      local.set 244
      local.get 244
      i32.wrap_i64
      i64.load32_u 9 align=1
      local.set 247
      local.get 247
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2700
        i32.const 69
        i32.const 26
        call 6
        unreachable
      end
      local.get 247
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 245
      local.get 244
      local.set 246
      i32.const 10
      local.set 249
      local.get 245
      call $goose.reserve_memory.10
      local.set 250
      local.get 249
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 250
      i64.extend_i32_u
      i64.or
      local.set 248
      local.get 248
      local.set 6
      local.get 248
      i32.wrap_i64
      local.get 246
      i32.wrap_i64
      local.get 245
      memory.copy 10 9
      local.get 6
      local.set 251
      local.get 251
      i32.wrap_i64
      i64.load32_u 10 align=1
      local.set 252
      i64.const 0
      local.set 253
      local.get 253
      local.get 252
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2769
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 251
      local.set 254
      local.get 254
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 253
      i64.const 8
      i64.mul
      i64.add
      local.tee 255
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2838
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 254
      i64.const -4294967296
      i64.and
      local.get 255
      i64.or
      local.set 256
      local.get 256
      i32.wrap_i64
      i64.load 10 align=1
      local.tee 257
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2907
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 257
      local.set 256
      local.get 256
      call $goose.memory_op.41
      i64.const 3
      i64.add
      local.set 258
      local.get 256
      local.get 258
      call $goose.memory_op.55
      local.get 5
      local.set 259
      local.get 259
      i32.wrap_i64
      i64.load32_u 9 align=1
      local.set 260
      i64.const 0
      local.set 261
      local.get 259
      local.set 262
      local.get 262
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 261
      i64.const 8
      i64.mul
      i64.add
      local.tee 263
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2976
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 262
      i64.const -4294967296
      i64.and
      local.get 263
      i64.or
      i32.wrap_i64
      i64.load 9 align=1
      local.get 6
      local.set 264
      local.get 264
      i32.wrap_i64
      i64.load32_u 10 align=1
      local.set 265
      i64.const 0
      local.set 266
      local.get 264
      local.set 267
      local.get 267
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 266
      i64.const 8
      i64.mul
      i64.add
      local.tee 268
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3045
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 267
      i64.const -4294967296
      i64.and
      local.get 268
      i64.or
      i32.wrap_i64
      i64.load 10 align=1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3114
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 178
      i32.add
      i64.load align=1
      local.set 269
      local.get 5
      local.set 270
      local.get 270
      i32.wrap_i64
      i64.load32_u 9 align=1
      local.set 271
      i64.const 0
      local.set 272
      local.get 270
      local.set 273
      local.get 273
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 272
      i64.const 8
      i64.mul
      i64.add
      local.tee 274
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3183
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 273
      i64.const -4294967296
      i64.and
      local.get 274
      i64.or
      i32.wrap_i64
      i64.load 9 align=1
      local.tee 275
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3252
        i32.const 69
        i32.const 26
        call 6
        unreachable
      end
      local.get 275
      call $goose.memory_op.41
      local.set 276
      call 0
      local.set 277
      local.get 277
      i32.const 3321
      i32.const 5
      call 4
      local.get 277
      local.get 269
      i32.const 0
      call 1
      local.get 277
      i32.const 3326
      i32.const 1
      call 4
      local.get 277
      local.get 276
      i32.const 0
      call 1
      local.get 277
      call 5
      local.get 1
      call $echo.3
      local.tee 278
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3327
        i32.const 69
        i32.const 9
        call 6
        unreachable
      end
      local.get 278
      local.set 279
      local.get 279
      call $goose.memory_op.53
      local.set 282
      local.get 282
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 3396
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 282
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 280
      local.get 279
      local.set 281
      i32.const 11
      local.set 284
      local.get 280
      call $goose.reserve_memory.11
      local.set 285
      local.get 284
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 285
      i64.extend_i32_u
      i64.or
      local.set 283
      local.get 283
      local.set 7
      local.get 283
      local.get 281
      local.get 280
      call $goose.copy_memory
      local.get 7
      local.set 286
      local.get 286
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 287
      i64.const 2
      local.set 288
      local.get 288
      local.get 287
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3465
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 286
      local.set 289
      local.get 289
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 288
      i64.const 8
      i64.mul
      i64.add
      local.tee 290
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3534
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 289
      i64.const -4294967296
      i64.and
      local.get 290
      i64.or
      local.set 291
      i64.const 70
      local.set 292
      local.get 291
      local.get 292
      local.set 293
      i32.wrap_i64
      local.get 293
      i64.store 11 align=1
      local.get 1
      local.set 294
      local.get 294
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 295
      i64.const 2
      local.set 296
      local.get 294
      local.set 297
      local.get 297
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 296
      i64.const 8
      i64.mul
      i64.add
      local.tee 298
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3603
        i32.const 69
        i32.const 29
        call 6
        unreachable
      end
      local.get 297
      i64.const -4294967296
      i64.and
      local.get 298
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 299
      local.get 7
      local.set 300
      local.get 300
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 301
      i64.const 2
      local.set 302
      local.get 300
      local.set 303
      local.get 303
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 302
      i64.const 8
      i64.mul
      i64.add
      local.tee 304
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3672
        i32.const 69
        i32.const 29
        call 6
        unreachable
      end
      local.get 303
      i64.const -4294967296
      i64.and
      local.get 304
      i64.or
      i32.wrap_i64
      i64.load 11 align=1
      local.set 305
      call 0
      local.set 306
      local.get 306
      i32.const 3741
      i32.const 9
      call 4
      local.get 306
      local.get 299
      i32.const 0
      call 1
      local.get 306
      i32.const 3750
      i32.const 1
      call 4
      local.get 306
      local.get 305
      i32.const 0
      call 1
      local.get 306
      call 5
      i32.const 12
      local.set 307
      i32.const 8
      call $goose.reserve_memory.12
      local.set 308
      local.get 307
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 308
      i64.extend_i32_u
      i64.or
      local.set 309
      local.get 309
      local.set 8
      local.get 309
      i64.const 0
      local.set 16
      i32.wrap_i64
      local.get 16
      i64.store 12 align=1
      local.get 8
      local.set 310
      local.get 310
      i32.wrap_i64
      i64.load 12 align=1
      local.set 313
      local.get 313
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 3751
        i32.const 69
        i32.const 30
        call 6
        unreachable
      end
      local.get 313
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      local.set 311
      local.get 310
      local.set 312
      i32.const 13
      local.set 315
      local.get 311
      call $goose.reserve_memory.13
      local.set 316
      local.get 315
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 316
      i64.extend_i32_u
      i64.or
      local.set 314
      local.get 314
      local.set 9
      local.get 314
      i32.wrap_i64
      local.get 312
      i32.wrap_i64
      local.get 311
      memory.copy 13 12
      local.get 9
      local.set 317
      local.get 317
      i32.wrap_i64
      i64.load 13 align=1
      local.set 318
      call 0
      local.set 319
      local.get 319
      i32.const 3820
      i32.const 6
      call 4
      local.get 319
      local.get 318
      i32.const 0
      call 1
      local.get 319
      call 5
      i32.const 14
      local.set 320
      global.get 14
      local.set 321
      local.get 0
      i32.const 186
      i32.add
      local.set 322
      local.get 322
      local.get 320
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 321
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 322
      i64.const 0
      i64.store offset=8 align=1
      i64.const 0
      local.set 323
      i64.const 70000
      local.set 324
      block ;; label = @2
        loop ;; label = @3
          local.get 323
          local.get 324
          i64.ge_s
          br_if 1 (;@2;)
          local.get 323
          local.set 10
          block ;; label = @4
            local.get 0
            i32.const 186
            i32.add
            local.set 325
            i64.const 120
            local.set 326
            local.get 325
            i64.load offset=8 align=1
            local.set 327
            i32.const 1
            call $goose.reserve_memory.14
            local.set 328
            local.get 325
            i64.load align=1
            i64.const -4294967296
            i64.and
            local.get 328
            i64.extend_i32_u
            i64.or
            local.tee 329
            local.get 326
            local.set 330
            i32.wrap_i64
            local.get 330
            i64.store8 14
            local.get 325
            local.get 327
            i64.const 1
            i64.add
            i64.store offset=8 align=1
            local.get 329
            i32.wrap_i64
            i64.load8_u 14
            drop
          end
          local.get 323
          i64.const 1
          i64.add
          local.set 323
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 186
      i32.add
      local.set 331
      local.get 331
      i64.load offset=8 align=1
      local.set 334
      local.get 334
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 3826
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 334
      i64.const 1
      i64.mul
      i32.wrap_i64
      local.set 332
      local.get 331
      i64.load align=1
      local.set 333
      i32.const 15
      local.set 336
      local.get 332
      call $goose.reserve_memory.15
      local.set 337
      local.get 336
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 337
      i64.extend_i32_u
      i64.or
      local.set 335
      local.get 0
      i32.const 202
      i32.add
      local.get 335
      i64.store align=1
      local.get 0
      i32.const 202
      i32.add
      local.get 334
      i64.store offset=8 align=1
      local.get 335
      i32.wrap_i64
      local.get 333
      i32.wrap_i64
      local.get 332
      memory.copy 15 14
      local.get 0
      i32.const 202
      i32.add
      local.set 338
      local.get 338
      i64.load offset=8 align=1
      local.set 339
      i64.const 0
      local.set 340
      local.get 340
      local.get 339
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3895
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 338
      i64.load align=1
      local.set 341
      local.get 341
      i64.const 4294967295
      i64.and
      local.get 340
      i64.const 1
      i64.mul
      i64.add
      local.tee 342
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3964
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 341
      i64.const -4294967296
      i64.and
      local.get 342
      i64.or
      local.set 343
      i64.const 121
      local.set 344
      local.get 343
      local.get 344
      local.set 345
      i32.wrap_i64
      local.get 345
      i64.store8 15
      local.get 0
      i32.const 186
      i32.add
      local.set 346
      local.get 346
      i64.load offset=8 align=1
      local.set 347
      local.get 0
      i32.const 186
      i32.add
      local.set 348
      local.get 348
      i64.load offset=8 align=1
      local.set 349
      i64.const 0
      local.set 350
      local.get 348
      i64.load align=1
      local.set 351
      local.get 351
      i64.const 4294967295
      i64.and
      local.get 350
      i64.const 1
      i64.mul
      i64.add
      local.tee 352
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4033
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 351
      i64.const -4294967296
      i64.and
      local.get 352
      i64.or
      i32.wrap_i64
      i64.load8_u 14
      local.set 353
      local.get 0
      i32.const 202
      i32.add
      local.set 354
      local.get 354
      i64.load offset=8 align=1
      local.set 355
      local.get 0
      i32.const 202
      i32.add
      local.set 356
      local.get 356
      i64.load offset=8 align=1
      local.set 357
      i64.const 0
      local.set 358
      local.get 356
      i64.load align=1
      local.set 359
      local.get 359
      i64.const 4294967295
      i64.and
      local.get 358
      i64.const 1
      i64.mul
      i64.add
      local.tee 360
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4102
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 359
      i64.const -4294967296
      i64.and
      local.get 360
      i64.or
      i32.wrap_i64
      i64.load8_u 15
      local.set 361
      local.get 0
      i32.const 202
      i32.add
      local.set 362
      local.get 362
      i64.load offset=8 align=1
      local.set 363
      i64.const 69999
      local.set 364
      local.get 364
      local.get 363
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4171
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 362
      i64.load align=1
      local.set 365
      local.get 365
      i64.const 4294967295
      i64.and
      local.get 364
      i64.const 1
      i64.mul
      i64.add
      local.tee 366
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4240
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 365
      i64.const -4294967296
      i64.and
      local.get 366
      i64.or
      i32.wrap_i64
      i64.load8_u 15
      local.set 367
      call 0
      local.set 368
      local.get 368
      i32.const 4309
      i32.const 6
      call 4
      local.get 368
      local.get 347
      i32.const 0
      call 1
      local.get 368
      i32.const 4315
      i32.const 1
      call 4
      local.get 368
      local.get 353
      i32.const 1
      call 1
      local.get 368
      i32.const 4316
      i32.const 1
      call 4
      local.get 368
      local.get 355
      i32.const 0
      call 1
      local.get 368
      i32.const 4317
      i32.const 1
      call 4
      local.get 368
      local.get 361
      i32.const 1
      call 1
      local.get 368
      i32.const 4318
      i32.const 1
      call 4
      local.get 368
      local.get 367
      i32.const 1
      call 1
      local.get 368
      call 5
      local.get 1
      call $copied.4
      local.set 369
      local.get 1
      local.set 370
      local.get 370
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 371
      i64.const 0
      local.set 372
      local.get 370
      local.set 373
      local.get 373
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 372
      i64.const 8
      i64.mul
      i64.add
      local.tee 374
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4319
        i32.const 69
        i32.const 34
        call 6
        unreachable
      end
      local.get 373
      i64.const -4294967296
      i64.and
      local.get 374
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 375
      i32.const 8
      i64.load align=1
      local.set 376
      local.get 376
      i32.wrap_i64
      i64.load32_u 17 align=1
      local.set 377
      i64.const 0
      local.set 378
      local.get 378
      local.get 377
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4388
        i32.const 69
        i32.const 34
        call 6
        unreachable
      end
      local.get 376
      local.set 379
      local.get 379
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 378
      i64.const 8
      i64.mul
      i64.add
      local.tee 380
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4457
        i32.const 69
        i32.const 34
        call 6
        unreachable
      end
      local.get 379
      i64.const -4294967296
      i64.and
      local.get 380
      i64.or
      i32.wrap_i64
      i64.load 17 align=1
      local.set 381
      call 0
      local.set 382
      local.get 382
      i32.const 4526
      i32.const 6
      call 4
      local.get 382
      local.get 369
      i32.const 0
      call 1
      local.get 382
      i32.const 4532
      i32.const 1
      call 4
      local.get 382
      local.get 375
      i32.const 0
      call 1
      local.get 382
      i32.const 4533
      i32.const 1
      call 4
      local.get 382
      local.get 381
      i32.const 0
      call 1
      local.get 382
      call 5
      local.get 337
      global.set 15
      local.get 321
      global.set 14
      local.get 316
      global.set 13
      local.get 308
      global.set 12
      local.get 285
      global.set 11
      local.get 250
      global.set 10
      local.get 241
      global.set 9
      local.get 221
      global.set 8
      local.get 203
      global.set 7
      local.get 184
      global.set 6
      local.get 166
      global.set 5
      local.get 148
      global.set 4
      local.get 124
      global.set 3
      local.get 24
      global.set 2
      local.get 14
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $copied.1 (;12;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4534
        i32.const 69
        i32.const 2
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      call $goose.memory_op.53
      local.set 8
      local.get 8
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 4603
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 8
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 6
      local.get 5
      local.set 7
      i32.const 1
      local.set 10
      local.get 6
      call $goose.reserve_memory.1
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 2
      local.get 9
      local.get 7
      local.get 6
      call $goose.copy_memory
      local.get 2
      local.set 12
      local.get 12
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 13
      i64.const 0
      local.set 14
      local.get 14
      local.get 13
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4672
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 12
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4741
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 100
      i64.add
      local.set 18
      local.get 17
      local.get 18
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store 1 align=1
      local.get 2
      local.set 20
      local.get 20
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.get 2
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 22
      i64.const 0
      local.set 23
      local.get 21
      local.set 24
      local.get 24
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 23
      i64.const 8
      i64.mul
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4810
        i32.const 69
        i32.const 4
        call 6
        unreachable
      end
      local.get 24
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.add
      local.set 3
      local.get 11
      global.set 1
      br 0 (;@1;)
      local.get 11
      global.set 1
    end
    local.get 3
  )
  (func $copied_cap.2 (;13;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4879
        i32.const 69
        i32.const 6
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      call $goose.memory_op.53
      local.set 8
      local.get 8
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 4948
        i32.const 69
        i32.const 7
        call 6
        unreachable
      end
      local.get 8
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      local.set 6
      local.get 5
      local.set 7
      i32.const 5
      local.set 10
      local.get 6
      call $goose.reserve_memory.5
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 2
      local.get 9
      local.get 7
      local.get 6
      call $goose.copy_memory
      local.get 2
      local.set 12
      i64.const 9
      local.set 13
      local.get 12
      i32.wrap_i64
      i64.load32_u 5 offset=4 align=1
      local.set 14
      local.get 14
      local.get 12
      i32.wrap_i64
      i64.load32_u 5 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 5017
        i32.const 69
        i32.const 7
        call 6
        unreachable
      end
      local.get 12
      local.set 16
      local.get 16
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 17
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5086
        i32.const 69
        i32.const 7
        call 6
        unreachable
      end
      local.get 16
      i64.const -4294967296
      i64.and
      local.get 17
      i64.or
      local.tee 18
      local.get 13
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store 5 align=1
      local.get 12
      local.get 14
      i64.const 1
      i64.add
      local.set 20
      i32.wrap_i64
      local.get 20
      i64.store32 5 offset=4 align=1
      local.get 18
      i32.wrap_i64
      i64.load 5 align=1
      drop
      local.get 2
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load32_u 5 align=1
      local.get 2
      local.set 22
      local.get 22
      i32.wrap_i64
      i64.load32_u 5 offset=4 align=1
      i64.add
      local.set 3
      local.get 11
      global.set 5
      br 0 (;@1;)
      local.get 11
      global.set 5
    end
    local.get 3
  )
  (func $echo.3 (;14;) (type 11) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $copied.4 (;15;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5155
        i32.const 69
        i32.const 2
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      call $goose.memory_op.53
      local.set 8
      local.get 8
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 5224
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 8
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 6
      local.get 5
      local.set 7
      i32.const 16
      local.set 10
      local.get 6
      call $goose.reserve_memory.16
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 2
      local.get 9
      local.get 7
      local.get 6
      call $goose.copy_memory
      local.get 2
      local.set 12
      local.get 12
      i32.wrap_i64
      i64.load32_u 16 align=1
      local.set 13
      i64.const 0
      local.set 14
      local.get 14
      local.get 13
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 5293
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 12
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5362
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load 16 align=1
      i64.const 100
      i64.add
      local.set 18
      local.get 17
      local.get 18
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store 16 align=1
      local.get 2
      local.set 20
      local.get 20
      i32.wrap_i64
      i64.load32_u 16 align=1
      local.get 2
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load32_u 16 align=1
      local.set 22
      i64.const 0
      local.set 23
      local.get 21
      local.set 24
      local.get 24
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 23
      i64.const 8
      i64.mul
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5431
        i32.const 69
        i32.const 4
        call 6
        unreachable
      end
      local.get 24
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      i32.wrap_i64
      i64.load 16 align=1
      i64.add
      local.set 3
      local.get 11
      global.set 16
      br 0 (;@1;)
      local.get 11
      global.set 16
    end
    local.get 3
  )
  (func $goose.init (;16;) (type 10)
    (local i32 i32 i32 i64 i64 i64 i64)
    i32.const 17
    local.set 1
    i32.const 20
    call $goose.reserve_memory.17
    local.set 2
    local.get 1
    i64.extend_i32_u
    i64.const 32
    i64.shl
    local.get 2
    i64.extend_i32_u
    i64.or
    local.set 3
    local.get 3
    local.set 4
    i32.const 8
    local.get 4
    i64.store align=1
    local.get 3
    i64.const 2
    local.set 5
    i32.wrap_i64
    local.get 5
    i64.store32 17 align=1
    i64.const 7
    local.set 6
    local.get 2
    i32.const 4
    i32.add
    local.get 6
    i64.store 17 align=1
    i64.const 8
    local.set 6
    local.get 2
    i32.const 12
    i32.add
    local.get 6
    i64.store 17 align=1
  )
  (func $goose.start (;17;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;21;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.reserve_memory.5 (;22;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 5
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 5
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 5
      i32.sub
      memory.grow 5
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 5
    local.get 1
  )
  (func $goose.reserve_memory.6 (;23;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 6
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 6
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 6
      i32.sub
      memory.grow 6
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 6
    local.get 1
  )
  (func $goose.reserve_memory.7 (;24;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 7
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 7
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 7
      i32.sub
      memory.grow 7
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 7
    local.get 1
  )
  (func $goose.reserve_memory.8 (;25;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 8
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 8
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 8
      i32.sub
      memory.grow 8
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 8
    local.get 1
  )
  (func $goose.reserve_memory.9 (;26;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 9
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 9
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 9
      i32.sub
      memory.grow 9
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 9
    local.get 1
  )
  (func $goose.reserve_memory.10 (;27;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 10
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 10
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 10
      i32.sub
      memory.grow 10
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 10
    local.get 1
  )
  (func $goose.memory_op.41 (;28;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          i64.load align=1
                                          br 18 (;@1;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        i64.load 1 align=1
                                        br 17 (;@1;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      i64.load 2 align=1
                                      br 16 (;@1;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load 3 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load 4 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load 5 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load 6 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load 7 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load 8 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load 9 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load 10 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load 11 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load 12 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load 13 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load 14 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 15 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 16 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 17 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;29;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i64.store align=1
                                          br 18 (;@1;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i64.store 1 align=1
                                        br 17 (;@1;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i64.store 2 align=1
                                      br 16 (;@1;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i64.store 3 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i64.store 4 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i64.store 5 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i64.store 6 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i64.store 7 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i64.store 8 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i64.store 9 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store 10 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store 11 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store 12 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store 13 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store 14 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 15 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 16 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 17 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;30;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          i64.load32_u align=1
                                          br 18 (;@1;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        i64.load32_u 1 align=1
                                        br 17 (;@1;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      i64.load32_u 2 align=1
                                      br 16 (;@1;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load32_u 3 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load32_u 4 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load32_u 5 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load32_u 6 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load32_u 7 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load32_u 8 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load32_u 9 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load32_u 10 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load32_u 11 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load32_u 12 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load32_u 13 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u 14 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 15 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 16 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 17 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.11 (;31;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 11
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 11
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 11
      i32.sub
      memory.grow 11
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 11
    local.get 1
  )
  (func $goose.copy_memory (;32;) (type 13) (param i64 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            block ;; label = @37
                                                                              block ;; label = @38
                                                                                block ;; label = @39
                                                                                  local.get 1
                                                                                  i64.const 32
                                                                                  i64.shr_u
                                                                                  i32.wrap_i64
                                                                                  br_table 0 (;@39;) 1 (;@38;) 2 (;@37;) 3 (;@36;) 4 (;@35;) 5 (;@34;) 6 (;@33;) 7 (;@32;) 8 (;@31;) 9 (;@30;) 10 (;@29;) 11 (;@28;) 12 (;@27;) 13 (;@26;) 14 (;@25;) 15 (;@24;) 16 (;@23;) 17 (;@22;) 18 (;@21;)
                                                                                end
                                                                                local.get 0
                                                                                i32.wrap_i64
                                                                                local.get 1
                                                                                i32.wrap_i64
                                                                                local.get 2
                                                                                memory.copy
                                                                                br 18 (;@20;)
                                                                              end
                                                                              local.get 0
                                                                              i32.wrap_i64
                                                                              local.get 1
                                                                              i32.wrap_i64
                                                                              local.get 2
                                                                              memory.copy 0 1
                                                                              br 17 (;@20;)
                                                                            end
                                                                            local.get 0
                                                                            i32.wrap_i64
                                                                            local.get 1
                                                                            i32.wrap_i64
                                                                            local.get 2
                                                                            memory.copy 0 2
                                                                            br 16 (;@20;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 0 3
                                                                          br 15 (;@20;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 0 4
                                                                        br 14 (;@20;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 0 5
                                                                      br 13 (;@20;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 0 6
                                                                    br 12 (;@20;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 0 7
                                                                  br 11 (;@20;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 0 8
                                                                br 10 (;@20;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 0 9
                                                              br 9 (;@20;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 0 10
                                                            br 8 (;@20;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 0 11
                                                          br 7 (;@20;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 0 12
                                                        br 6 (;@20;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 0 13
                                                      br 5 (;@20;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 0 14
                                                    br 4 (;@20;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 0 15
                                                  br 3 (;@20;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 0 16
                                                br 2 (;@20;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 0 17
                                              br 1 (;@20;)
                                            end
                                            i32.const 7
                                            i32.const 0
                                            i32.const 0
                                            i32.const 0
                                            call 6
                                            unreachable
                                          end
                                          br 18 (;@1;)
                                        end
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            block ;; label = @37
                                                                              block ;; label = @38
                                                                                local.get 1
                                                                                i64.const 32
                                                                                i64.shr_u
                                                                                i32.wrap_i64
                                                                                br_table 0 (;@38;) 1 (;@37;) 2 (;@36;) 3 (;@35;) 4 (;@34;) 5 (;@33;) 6 (;@32;) 7 (;@31;) 8 (;@30;) 9 (;@29;) 10 (;@28;) 11 (;@27;) 12 (;@26;) 13 (;@25;) 14 (;@24;) 15 (;@23;) 16 (;@22;) 17 (;@21;) 18 (;@20;)
                                                                              end
                                                                              local.get 0
                                                                              i32.wrap_i64
                                                                              local.get 1
                                                                              i32.wrap_i64
                                                                              local.get 2
                                                                              memory.copy 1 0
                                                                              br 18 (;@19;)
                                                                            end
                                                                            local.get 0
                                                                            i32.wrap_i64
                                                                            local.get 1
                                                                            i32.wrap_i64
                                                                            local.get 2
                                                                            memory.copy 1 1
                                                                            br 17 (;@19;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 1 2
                                                                          br 16 (;@19;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 1 3
                                                                        br 15 (;@19;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 1 4
                                                                      br 14 (;@19;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 1 5
                                                                    br 13 (;@19;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 1 6
                                                                  br 12 (;@19;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 1 7
                                                                br 11 (;@19;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 1 8
                                                              br 10 (;@19;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 1 9
                                                            br 9 (;@19;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 1 10
                                                          br 8 (;@19;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 1 11
                                                        br 7 (;@19;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 1 12
                                                      br 6 (;@19;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 1 13
                                                    br 5 (;@19;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 1 14
                                                  br 4 (;@19;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 1 15
                                                br 3 (;@19;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 1 16
                                              br 2 (;@19;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 1 17
                                            br 1 (;@19;)
                                          end
                                          i32.const 7
                                          i32.const 0
                                          i32.const 0
                                          i32.const 0
                                          call 6
                                          unreachable
                                        end
                                        br 17 (;@1;)
                                      end
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            block ;; label = @37
                                                                              local.get 1
                                                                              i64.const 32
                                                                              i64.shr_u
                                                                              i32.wrap_i64
                                                                              br_table 0 (;@37;) 1 (;@36;) 2 (;@35;) 3 (;@34;) 4 (;@33;) 5 (;@32;) 6 (;@31;) 7 (;@30;) 8 (;@29;) 9 (;@28;) 10 (;@27;) 11 (;@26;) 12 (;@25;) 13 (;@24;) 14 (;@23;) 15 (;@22;) 16 (;@21;) 17 (;@20;) 18 (;@19;)
                                                                            end
                                                                            local.get 0
                                                                            i32.wrap_i64
                                                                            local.get 1
                                                                            i32.wrap_i64
                                                                            local.get 2
                                                                            memory.copy 2 0
                                                                            br 18 (;@18;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 2 1
                                                                          br 17 (;@18;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 2 2
                                                                        br 16 (;@18;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 2 3
                                                                      br 15 (;@18;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 2 4
                                                                    br 14 (;@18;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 2 5
                                                                  br 13 (;@18;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 2 6
                                                                br 12 (;@18;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 2 7
                                                              br 11 (;@18;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 2 8
                                                            br 10 (;@18;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 2 9
                                                          br 9 (;@18;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 2 10
                                                        br 8 (;@18;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 2 11
                                                      br 7 (;@18;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 2 12
                                                    br 6 (;@18;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 2 13
                                                  br 5 (;@18;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 2 14
                                                br 4 (;@18;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 2 15
                                              br 3 (;@18;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 2 16
                                            br 2 (;@18;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 2 17
                                          br 1 (;@18;)
                                        end
                                        i32.const 7
                                        i32.const 0
                                        i32.const 0
                                        i32.const 0
                                        call 6
                                        unreachable
                                      end
                                      br 16 (;@1;)
                                    end
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            local.get 1
                                                                            i64.const 32
                                                                            i64.shr_u
                                                                            i32.wrap_i64
                                                                            br_table 0 (;@36;) 1 (;@35;) 2 (;@34;) 3 (;@33;) 4 (;@32;) 5 (;@31;) 6 (;@30;) 7 (;@29;) 8 (;@28;) 9 (;@27;) 10 (;@26;) 11 (;@25;) 12 (;@24;) 13 (;@23;) 14 (;@22;) 15 (;@21;) 16 (;@20;) 17 (;@19;) 18 (;@18;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 3 0
                                                                          br 18 (;@17;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 3 1
                                                                        br 17 (;@17;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 3 2
                                                                      br 16 (;@17;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 3 3
                                                                    br 15 (;@17;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 3 4
                                                                  br 14 (;@17;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 3 5
                                                                br 13 (;@17;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 3 6
                                                              br 12 (;@17;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 3 7
                                                            br 11 (;@17;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 3 8
                                                          br 10 (;@17;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 3 9
                                                        br 9 (;@17;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 3 10
                                                      br 8 (;@17;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 3 11
                                                    br 7 (;@17;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 3 12
                                                  br 6 (;@17;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 3 13
                                                br 5 (;@17;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 3 14
                                              br 4 (;@17;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 3 15
                                            br 3 (;@17;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 3 16
                                          br 2 (;@17;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 3 17
                                        br 1 (;@17;)
                                      end
                                      i32.const 7
                                      i32.const 0
                                      i32.const 0
                                      i32.const 0
                                      call 6
                                      unreachable
                                    end
                                    br 15 (;@1;)
                                  end
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          local.get 1
                                                                          i64.const 32
                                                                          i64.shr_u
                                                                          i32.wrap_i64
                                                                          br_table 0 (;@35;) 1 (;@34;) 2 (;@33;) 3 (;@32;) 4 (;@31;) 5 (;@30;) 6 (;@29;) 7 (;@28;) 8 (;@27;) 9 (;@26;) 10 (;@25;) 11 (;@24;) 12 (;@23;) 13 (;@22;) 14 (;@21;) 15 (;@20;) 16 (;@19;) 17 (;@18;) 18 (;@17;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 4 0
                                                                        br 18 (;@16;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 4 1
                                                                      br 17 (;@16;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 4 2
                                                                    br 16 (;@16;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 4 3
                                                                  br 15 (;@16;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 4 4
                                                                br 14 (;@16;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 4 5
                                                              br 13 (;@16;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 4 6
                                                            br 12 (;@16;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 4 7
                                                          br 11 (;@16;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 4 8
                                                        br 10 (;@16;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 4 9
                                                      br 9 (;@16;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 4 10
                                                    br 8 (;@16;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 4 11
                                                  br 7 (;@16;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 4 12
                                                br 6 (;@16;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 4 13
                                              br 5 (;@16;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 4 14
                                            br 4 (;@16;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 4 15
                                          br 3 (;@16;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 4 16
                                        br 2 (;@16;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 4 17
                                      br 1 (;@16;)
                                    end
                                    i32.const 7
                                    i32.const 0
                                    i32.const 0
                                    i32.const 0
                                    call 6
                                    unreachable
                                  end
                                  br 14 (;@1;)
                                end
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        local.get 1
                                                                        i64.const 32
                                                                        i64.shr_u
                                                                        i32.wrap_i64
                                                                        br_table 0 (;@34;) 1 (;@33;) 2 (;@32;) 3 (;@31;) 4 (;@30;) 5 (;@29;) 6 (;@28;) 7 (;@27;) 8 (;@26;) 9 (;@25;) 10 (;@24;) 11 (;@23;) 12 (;@22;) 13 (;@21;) 14 (;@20;) 15 (;@19;) 16 (;@18;) 17 (;@17;) 18 (;@16;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 5 0
                                                                      br 18 (;@15;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 5 1
                                                                    br 17 (;@15;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 5 2
                                                                  br 16 (;@15;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 5 3
                                                                br 15 (;@15;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 5 4
                                                              br 14 (;@15;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 5 5
                                                            br 13 (;@15;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 5 6
                                                          br 12 (;@15;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 5 7
                                                        br 11 (;@15;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 5 8
                                                      br 10 (;@15;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 5 9
                                                    br 9 (;@15;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 5 10
                                                  br 8 (;@15;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 5 11
                                                br 7 (;@15;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 5 12
                                              br 6 (;@15;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 5 13
                                            br 5 (;@15;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 5 14
                                          br 4 (;@15;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 5 15
                                        br 3 (;@15;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 5 16
                                      br 2 (;@15;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 5 17
                                    br 1 (;@15;)
                                  end
                                  i32.const 7
                                  i32.const 0
                                  i32.const 0
                                  i32.const 0
                                  call 6
                                  unreachable
                                end
                                br 13 (;@1;)
                              end
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      local.get 1
                                                                      i64.const 32
                                                                      i64.shr_u
                                                                      i32.wrap_i64
                                                                      br_table 0 (;@33;) 1 (;@32;) 2 (;@31;) 3 (;@30;) 4 (;@29;) 5 (;@28;) 6 (;@27;) 7 (;@26;) 8 (;@25;) 9 (;@24;) 10 (;@23;) 11 (;@22;) 12 (;@21;) 13 (;@20;) 14 (;@19;) 15 (;@18;) 16 (;@17;) 17 (;@16;) 18 (;@15;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 6 0
                                                                    br 18 (;@14;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 6 1
                                                                  br 17 (;@14;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 6 2
                                                                br 16 (;@14;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 6 3
                                                              br 15 (;@14;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 6 4
                                                            br 14 (;@14;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 6 5
                                                          br 13 (;@14;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 6 6
                                                        br 12 (;@14;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 6 7
                                                      br 11 (;@14;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 6 8
                                                    br 10 (;@14;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 6 9
                                                  br 9 (;@14;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 6 10
                                                br 8 (;@14;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 6 11
                                              br 7 (;@14;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 6 12
                                            br 6 (;@14;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 6 13
                                          br 5 (;@14;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 6 14
                                        br 4 (;@14;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 6 15
                                      br 3 (;@14;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 6 16
                                    br 2 (;@14;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 6 17
                                  br 1 (;@14;)
                                end
                                i32.const 7
                                i32.const 0
                                i32.const 0
                                i32.const 0
                                call 6
                                unreachable
                              end
                              br 12 (;@1;)
                            end
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    local.get 1
                                                                    i64.const 32
                                                                    i64.shr_u
                                                                    i32.wrap_i64
                                                                    br_table 0 (;@32;) 1 (;@31;) 2 (;@30;) 3 (;@29;) 4 (;@28;) 5 (;@27;) 6 (;@26;) 7 (;@25;) 8 (;@24;) 9 (;@23;) 10 (;@22;) 11 (;@21;) 12 (;@20;) 13 (;@19;) 14 (;@18;) 15 (;@17;) 16 (;@16;) 17 (;@15;) 18 (;@14;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 7 0
                                                                  br 18 (;@13;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 7 1
                                                                br 17 (;@13;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 7 2
                                                              br 16 (;@13;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 7 3
                                                            br 15 (;@13;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 7 4
                                                          br 14 (;@13;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 7 5
                                                        br 13 (;@13;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 7 6
                                                      br 12 (;@13;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 7 7
                                                    br 11 (;@13;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 7 8
                                                  br 10 (;@13;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 7 9
                                                br 9 (;@13;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 7 10
                                              br 8 (;@13;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 7 11
                                            br 7 (;@13;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 7 12
                                          br 6 (;@13;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 7 13
                                        br 5 (;@13;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 7 14
                                      br 4 (;@13;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 7 15
                                    br 3 (;@13;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 7 16
                                  br 2 (;@13;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 7 17
                                br 1 (;@13;)
                              end
                              i32.const 7
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            br 11 (;@1;)
                          end
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  local.get 1
                                                                  i64.const 32
                                                                  i64.shr_u
                                                                  i32.wrap_i64
                                                                  br_table 0 (;@31;) 1 (;@30;) 2 (;@29;) 3 (;@28;) 4 (;@27;) 5 (;@26;) 6 (;@25;) 7 (;@24;) 8 (;@23;) 9 (;@22;) 10 (;@21;) 11 (;@20;) 12 (;@19;) 13 (;@18;) 14 (;@17;) 15 (;@16;) 16 (;@15;) 17 (;@14;) 18 (;@13;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 8 0
                                                                br 18 (;@12;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 8 1
                                                              br 17 (;@12;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 8 2
                                                            br 16 (;@12;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 8 3
                                                          br 15 (;@12;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 8 4
                                                        br 14 (;@12;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 8 5
                                                      br 13 (;@12;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 8 6
                                                    br 12 (;@12;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 8 7
                                                  br 11 (;@12;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 8 8
                                                br 10 (;@12;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 8 9
                                              br 9 (;@12;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 8 10
                                            br 8 (;@12;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 8 11
                                          br 7 (;@12;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 8 12
                                        br 6 (;@12;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 8 13
                                      br 5 (;@12;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 8 14
                                    br 4 (;@12;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 8 15
                                  br 3 (;@12;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 8 16
                                br 2 (;@12;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 8 17
                              br 1 (;@12;)
                            end
                            i32.const 7
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          br 10 (;@1;)
                        end
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                local.get 1
                                                                i64.const 32
                                                                i64.shr_u
                                                                i32.wrap_i64
                                                                br_table 0 (;@30;) 1 (;@29;) 2 (;@28;) 3 (;@27;) 4 (;@26;) 5 (;@25;) 6 (;@24;) 7 (;@23;) 8 (;@22;) 9 (;@21;) 10 (;@20;) 11 (;@19;) 12 (;@18;) 13 (;@17;) 14 (;@16;) 15 (;@15;) 16 (;@14;) 17 (;@13;) 18 (;@12;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 9 0
                                                              br 18 (;@11;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 9 1
                                                            br 17 (;@11;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 9 2
                                                          br 16 (;@11;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 9 3
                                                        br 15 (;@11;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 9 4
                                                      br 14 (;@11;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 9 5
                                                    br 13 (;@11;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 9 6
                                                  br 12 (;@11;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 9 7
                                                br 11 (;@11;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 9 8
                                              br 10 (;@11;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 9 9
                                            br 9 (;@11;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 9 10
                                          br 8 (;@11;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 9 11
                                        br 7 (;@11;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 9 12
                                      br 6 (;@11;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 9 13
                                    br 5 (;@11;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 9 14
                                  br 4 (;@11;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 9 15
                                br 3 (;@11;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 9 16
                              br 2 (;@11;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 9 17
                            br 1 (;@11;)
                          end
                          i32.const 7
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        br 9 (;@1;)
                      end
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              local.get 1
                                                              i64.const 32
                                                              i64.shr_u
                                                              i32.wrap_i64
                                                              br_table 0 (;@29;) 1 (;@28;) 2 (;@27;) 3 (;@26;) 4 (;@25;) 5 (;@24;) 6 (;@23;) 7 (;@22;) 8 (;@21;) 9 (;@20;) 10 (;@19;) 11 (;@18;) 12 (;@17;) 13 (;@16;) 14 (;@15;) 15 (;@14;) 16 (;@13;) 17 (;@12;) 18 (;@11;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 10 0
                                                            br 18 (;@10;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 10 1
                                                          br 17 (;@10;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 10 2
                                                        br 16 (;@10;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 10 3
                                                      br 15 (;@10;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 10 4
                                                    br 14 (;@10;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 10 5
                                                  br 13 (;@10;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 10 6
                                                br 12 (;@10;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 10 7
                                              br 11 (;@10;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 10 8
                                            br 10 (;@10;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 10 9
                                          br 9 (;@10;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 10 10
                                        br 8 (;@10;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 10 11
                                      br 7 (;@10;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 10 12
                                    br 6 (;@10;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 10 13
                                  br 5 (;@10;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 10 14
                                br 4 (;@10;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 10 15
                              br 3 (;@10;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 10 16
                            br 2 (;@10;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 10 17
                          br 1 (;@10;)
                        end
                        i32.const 7
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      br 8 (;@1;)
                    end
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            local.get 1
                                                            i64.const 32
                                                            i64.shr_u
                                                            i32.wrap_i64
                                                            br_table 0 (;@28;) 1 (;@27;) 2 (;@26;) 3 (;@25;) 4 (;@24;) 5 (;@23;) 6 (;@22;) 7 (;@21;) 8 (;@20;) 9 (;@19;) 10 (;@18;) 11 (;@17;) 12 (;@16;) 13 (;@15;) 14 (;@14;) 15 (;@13;) 16 (;@12;) 17 (;@11;) 18 (;@10;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 11 0
                                                          br 18 (;@9;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 11 1
                                                        br 17 (;@9;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 11 2
                                                      br 16 (;@9;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 11 3
                                                    br 15 (;@9;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 11 4
                                                  br 14 (;@9;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 11 5
                                                br 13 (;@9;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 11 6
                                              br 12 (;@9;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 11 7
                                            br 11 (;@9;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 11 8
                                          br 10 (;@9;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 11 9
                                        br 9 (;@9;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 11 10
                                      br 8 (;@9;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 11 11
                                    br 7 (;@9;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 11 12
                                  br 6 (;@9;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 11 13
                                br 5 (;@9;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 11 14
                              br 4 (;@9;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 11 15
                            br 3 (;@9;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 11 16
                          br 2 (;@9;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 11 17
                        br 1 (;@9;)
                      end
                      i32.const 7
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    br 7 (;@1;)
                  end
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          local.get 1
                                                          i64.const 32
                                                          i64.shr_u
                                                          i32.wrap_i64
                                                          br_table 0 (;@27;) 1 (;@26;) 2 (;@25;) 3 (;@24;) 4 (;@23;) 5 (;@22;) 6 (;@21;) 7 (;@20;) 8 (;@19;) 9 (;@18;) 10 (;@17;) 11 (;@16;) 12 (;@15;) 13 (;@14;) 14 (;@13;) 15 (;@12;) 16 (;@11;) 17 (;@10;) 18 (;@9;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 12 0
                                                        br 18 (;@8;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 12 1
                                                      br 17 (;@8;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 12 2
                                                    br 16 (;@8;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 12 3
                                                  br 15 (;@8;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 12 4
                                                br 14 (;@8;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 12 5
                                              br 13 (;@8;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 12 6
                                            br 12 (;@8;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 12 7
                                          br 11 (;@8;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 12 8
                                        br 10 (;@8;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 12 9
                                      br 9 (;@8;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 12 10
                                    br 8 (;@8;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 12 11
                                  br 7 (;@8;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 12 12
                                br 6 (;@8;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 12 13
                              br 5 (;@8;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 12 14
                            br 4 (;@8;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 12 15
                          br 3 (;@8;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 12 16
                        br 2 (;@8;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 12 17
                      br 1 (;@8;)
                    end
                    i32.const 7
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  br 6 (;@1;)
                end
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        local.get 1
                                                        i64.const 32
                                                        i64.shr_u
                                                        i32.wrap_i64
                                                        br_table 0 (;@26;) 1 (;@25;) 2 (;@24;) 3 (;@23;) 4 (;@22;) 5 (;@21;) 6 (;@20;) 7 (;@19;) 8 (;@18;) 9 (;@17;) 10 (;@16;) 11 (;@15;) 12 (;@14;) 13 (;@13;) 14 (;@12;) 15 (;@11;) 16 (;@10;) 17 (;@9;) 18 (;@8;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 13 0
                                                      br 18 (;@7;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 13 1
                                                    br 17 (;@7;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 13 2
                                                  br 16 (;@7;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 13 3
                                                br 15 (;@7;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 13 4
                                              br 14 (;@7;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 13 5
                                            br 13 (;@7;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 13 6
                                          br 12 (;@7;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 13 7
                                        br 11 (;@7;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 13 8
                                      br 10 (;@7;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 13 9
                                    br 9 (;@7;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 13 10
                                  br 8 (;@7;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 13 11
                                br 7 (;@7;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 13 12
                              br 6 (;@7;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 13 13
                            br 5 (;@7;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 13 14
                          br 4 (;@7;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 13 15
                        br 3 (;@7;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 13 16
                      br 2 (;@7;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 13 17
                    br 1 (;@7;)
                  end
                  i32.const 7
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                br 5 (;@1;)
              end
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      local.get 1
                                                      i64.const 32
                                                      i64.shr_u
                                                      i32.wrap_i64
                                                      br_table 0 (;@25;) 1 (;@24;) 2 (;@23;) 3 (;@22;) 4 (;@21;) 5 (;@20;) 6 (;@19;) 7 (;@18;) 8 (;@17;) 9 (;@16;) 10 (;@15;) 11 (;@14;) 12 (;@13;) 13 (;@12;) 14 (;@11;) 15 (;@10;) 16 (;@9;) 17 (;@8;) 18 (;@7;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 14 0
                                                    br 18 (;@6;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 14 1
                                                  br 17 (;@6;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 14 2
                                                br 16 (;@6;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 14 3
                                              br 15 (;@6;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 14 4
                                            br 14 (;@6;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 14 5
                                          br 13 (;@6;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 14 6
                                        br 12 (;@6;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 14 7
                                      br 11 (;@6;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 14 8
                                    br 10 (;@6;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 14 9
                                  br 9 (;@6;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 14 10
                                br 8 (;@6;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 14 11
                              br 7 (;@6;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 14 12
                            br 6 (;@6;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 14 13
                          br 5 (;@6;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 14 14
                        br 4 (;@6;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 14 15
                      br 3 (;@6;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 14 16
                    br 2 (;@6;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 14 17
                  br 1 (;@6;)
                end
                i32.const 7
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              br 4 (;@1;)
            end
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    local.get 1
                                                    i64.const 32
                                                    i64.shr_u
                                                    i32.wrap_i64
                                                    br_table 0 (;@24;) 1 (;@23;) 2 (;@22;) 3 (;@21;) 4 (;@20;) 5 (;@19;) 6 (;@18;) 7 (;@17;) 8 (;@16;) 9 (;@15;) 10 (;@14;) 11 (;@13;) 12 (;@12;) 13 (;@11;) 14 (;@10;) 15 (;@9;) 16 (;@8;) 17 (;@7;) 18 (;@6;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 15 0
                                                  br 18 (;@5;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 15 1
                                                br 17 (;@5;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 15 2
                                              br 16 (;@5;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 15 3
                                            br 15 (;@5;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 15 4
                                          br 14 (;@5;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 15 5
                                        br 13 (;@5;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 15 6
                                      br 12 (;@5;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 15 7
                                    br 11 (;@5;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 15 8
                                  br 10 (;@5;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 15 9
                                br 9 (;@5;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 15 10
                              br 8 (;@5;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 15 11
                            br 7 (;@5;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 15 12
                          br 6 (;@5;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 15 13
                        br 5 (;@5;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 15 14
                      br 4 (;@5;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 15 15
                    br 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 15 16
                  br 2 (;@5;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 15 17
                br 1 (;@5;)
              end
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            br 3 (;@1;)
          end
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  local.get 1
                                                  i64.const 32
                                                  i64.shr_u
                                                  i32.wrap_i64
                                                  br_table 0 (;@23;) 1 (;@22;) 2 (;@21;) 3 (;@20;) 4 (;@19;) 5 (;@18;) 6 (;@17;) 7 (;@16;) 8 (;@15;) 9 (;@14;) 10 (;@13;) 11 (;@12;) 12 (;@11;) 13 (;@10;) 14 (;@9;) 15 (;@8;) 16 (;@7;) 17 (;@6;) 18 (;@5;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 16 0
                                                br 18 (;@4;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 16 1
                                              br 17 (;@4;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 16 2
                                            br 16 (;@4;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 16 3
                                          br 15 (;@4;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 16 4
                                        br 14 (;@4;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 16 5
                                      br 13 (;@4;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 16 6
                                    br 12 (;@4;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 16 7
                                  br 11 (;@4;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 16 8
                                br 10 (;@4;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 16 9
                              br 9 (;@4;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 16 10
                            br 8 (;@4;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 16 11
                          br 7 (;@4;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 16 12
                        br 6 (;@4;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 16 13
                      br 5 (;@4;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 16 14
                    br 4 (;@4;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 16 15
                  br 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 16 16
                br 2 (;@4;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 16 17
              br 1 (;@4;)
            end
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          br 2 (;@1;)
        end
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                local.get 1
                                                i64.const 32
                                                i64.shr_u
                                                i32.wrap_i64
                                                br_table 0 (;@22;) 1 (;@21;) 2 (;@20;) 3 (;@19;) 4 (;@18;) 5 (;@17;) 6 (;@16;) 7 (;@15;) 8 (;@14;) 9 (;@13;) 10 (;@12;) 11 (;@11;) 12 (;@10;) 13 (;@9;) 14 (;@8;) 15 (;@7;) 16 (;@6;) 17 (;@5;) 18 (;@4;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 17 0
                                              br 18 (;@3;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 17 1
                                            br 17 (;@3;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 17 2
                                          br 16 (;@3;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 17 3
                                        br 15 (;@3;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 17 4
                                      br 14 (;@3;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 17 5
                                    br 13 (;@3;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 17 6
                                  br 12 (;@3;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 17 7
                                br 11 (;@3;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 17 8
                              br 10 (;@3;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 17 9
                            br 9 (;@3;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 17 10
                          br 8 (;@3;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 17 11
                        br 7 (;@3;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 17 12
                      br 6 (;@3;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 17 13
                    br 5 (;@3;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 17 14
                  br 4 (;@3;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 17 15
                br 3 (;@3;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 17 16
              br 2 (;@3;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 17 17
            br 1 (;@3;)
          end
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.12 (;33;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 12
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 12
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 12
      i32.sub
      memory.grow 12
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 12
    local.get 1
  )
  (func $goose.reserve_memory.13 (;34;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 13
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 13
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 13
      i32.sub
      memory.grow 13
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 13
    local.get 1
  )
  (func $goose.reserve_memory.14 (;35;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 14
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 14
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 14
      i32.sub
      memory.grow 14
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 14
    local.get 1
  )
  (func $goose.reserve_memory.15 (;36;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 15
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 15
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 15
      i32.sub
      memory.grow 15
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 15
    local.get 1
  )
  (func $goose.reserve_memory.16 (;37;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 16
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 16
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 16
      i32.sub
      memory.grow 16
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 16
    local.get 1
  )
  (func $goose.reserve_memory.17 (;38;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 17
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 17
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 17
      i32.sub
      memory.grow 17
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 17
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosebefore=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosevariable=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosefixed=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooselimited=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseruntime=,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosegrow=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseshrink=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooserefs=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseborrowed=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseempty=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooselarge=,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseafter=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose")
)
