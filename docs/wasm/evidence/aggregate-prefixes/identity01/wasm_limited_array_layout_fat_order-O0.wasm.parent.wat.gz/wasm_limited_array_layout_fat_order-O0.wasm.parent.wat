(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i64) (result i64)))
  (type (;12;) (func (param i64) (result i64)))
  (type (;13;) (func (param i64 i64 i32)))
  (type (;14;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 4032)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 15
      i32.const 89
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 104
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32)
    i32.const 8
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 3
      i32.const 518
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i64.const 1
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store32 1 align=1
      local.get 5
      i64.const 0
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=4 align=1
      i64.const 1
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load16_u 1 offset=4 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 193
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 282
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 371
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=4 align=1
      i64.const 2
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load16_u 1 offset=4 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 460
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 549
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 638
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=4 align=1
      i64.const 9
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load16_u 1 offset=4 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 727
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 816
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 905
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=4 align=1
      i32.const 2
      local.set 13
      i32.const 518
      call $goose.reserve_memory.2
      local.set 14
      local.get 13
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 14
      i64.extend_i32_u
      i64.or
      local.set 15
      local.get 15
      local.set 2
      local.get 15
      i64.const 1
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store32 2 align=1
      local.get 15
      i64.const 0
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 2 offset=4 align=1
      i64.const 3
      local.set 7
      local.get 15
      i32.wrap_i64
      i64.load16_u 2 offset=4 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 994
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1083
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1172
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 2 align=1
      local.get 15
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 2 offset=4 align=1
      i64.const 4
      local.set 7
      local.get 15
      i32.wrap_i64
      i64.load16_u 2 offset=4 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1261
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1350
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1439
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 2 align=1
      local.get 15
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 2 offset=4 align=1
      i64.const 8
      local.set 7
      local.get 15
      i32.wrap_i64
      i64.load16_u 2 offset=4 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1528
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1617
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1706
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store16 2 align=1
      local.get 15
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 2 offset=4 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 16
      local.get 16
      local.get 1
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 18
      i64.const 0
      local.set 19
      local.get 17
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 19
      i64.const 514
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1795
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 22
      local.get 22
      i64.load align=1
      local.tee 23
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1884
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.get 2
      local.set 24
      local.get 24
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 25
      i64.const 0
      local.set 26
      local.get 24
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 26
      i64.const 514
      i64.mul
      i64.add
      local.tee 28
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1973
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 28
      i64.or
      call $get.1
      local.tee 29
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2062
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 29
      call $goose.memory_op.49
      local.set 30
      local.get 30
      i64.const 2
      i64.mul
      i32.wrap_i64
      local.set 31
      local.get 23
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2151
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 23
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.get 29
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2240
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.get 31
      call $goose.copy_memory
      local.get 23
      local.get 30
      call $goose.memory_op.61
      local.get 1
      local.set 32
      local.get 32
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 33
      i64.const 0
      local.set 34
      local.get 34
      local.get 33
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2329
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 32
      local.set 35
      local.get 35
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 34
      i64.const 514
      i64.mul
      i64.add
      local.tee 36
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2418
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 35
      i64.const -4294967296
      i64.and
      local.get 36
      i64.or
      local.set 37
      local.get 37
      local.set 38
      local.get 38
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 2
      i64.eq
      if (result i32) ;; label = @2
        local.get 1
        local.set 39
        local.get 39
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 40
        i64.const 0
        local.set 41
        local.get 39
        local.set 42
        local.get 42
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 41
        i64.const 514
        i64.mul
        i64.add
        local.tee 43
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2507
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 42
        i64.const -4294967296
        i64.and
        local.get 43
        i64.or
        local.set 44
        local.get 44
        local.set 45
        local.get 45
        i32.wrap_i64
        i64.load16_u 1 align=1
        local.set 46
        i64.const 0
        local.set 47
        local.get 47
        local.get 46
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 2596
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 45
        local.set 48
        local.get 48
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 47
        i64.const 2
        i64.mul
        i64.add
        local.tee 49
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2685
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 48
        i64.const -4294967296
        i64.and
        local.get 49
        i64.or
        i32.wrap_i64
        i64.load16_u 1 align=1
        i64.const 77
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 2
        local.set 50
        local.get 50
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 51
        i64.const 0
        local.set 52
        local.get 52
        local.get 51
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 2774
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 50
        local.set 53
        local.get 53
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 52
        i64.const 514
        i64.mul
        i64.add
        local.tee 54
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2863
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 53
        i64.const -4294967296
        i64.and
        local.get 54
        i64.or
        local.set 55
        local.get 55
        local.set 56
        local.get 56
        i32.wrap_i64
        i64.load16_u 2 align=1
        i64.const 3
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 2
        local.set 57
        local.get 57
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 58
        i64.const 0
        local.set 59
        local.get 59
        local.get 58
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 2952
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 57
        local.set 60
        local.get 60
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 59
        i64.const 514
        i64.mul
        i64.add
        local.tee 61
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3041
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 60
        i64.const -4294967296
        i64.and
        local.get 61
        i64.or
        local.set 62
        local.get 62
        local.set 63
        local.get 63
        i32.wrap_i64
        i64.load16_u 2 align=1
        local.set 64
        i64.const 0
        local.set 65
        local.get 65
        local.get 64
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 3130
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 63
        local.set 66
        local.get 66
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 65
        i64.const 2
        i64.mul
        i64.add
        local.tee 67
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3219
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 66
        i64.const -4294967296
        i64.and
        local.get 67
        i64.or
        i32.wrap_i64
        i64.load16_u 2 align=1
        i64.const 3
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 0
        i32.const 0
        i32.add
        local.set 68
        local.get 68
        i64.load align=1
        local.get 2
        local.set 69
        local.get 69
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 70
        i64.const 0
        local.set 71
        local.get 71
        local.get 70
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 3308
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 69
        local.set 72
        local.get 72
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 71
        i64.const 514
        i64.mul
        i64.add
        local.tee 73
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3397
          i32.const 89
          i32.const 1
          call 6
          unreachable
        end
        local.get 72
        i64.const -4294967296
        i64.and
        local.get 73
        i64.or
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3486
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      call 0
      local.set 74
      local.get 74
      i32.const 3575
      i32.const 9
      call 4
      local.get 74
      call 5
      local.get 14
      global.set 2
      local.get 4
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $get.1 (;12;) (type 11) (param i64 i64) (result i64)
    (local i32 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3584
        i32.const 89
        i32.const 1
        call 6
        unreachable
      end
      local.get 4
      local.get 1
      call $goose.memory_op.55
      i32.const 8
      i64.extend_i32_u
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $goose.init (;13;) (type 10)
    (local i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64)
    i32.const 8
    local.set 1
    local.get 1
    i64.const 0
    i64.store8
    i64.const 77
    local.set 2
    local.get 1
    i64.load8_u
    local.set 3
    local.get 3
    i64.const 3
    i64.ge_u
    if ;; label = @1
      i32.const 10
      i32.const 3673
      i32.const 89
      i32.const 1
      call 6
      unreachable
    end
    local.get 1
    i32.const 1
    i32.add
    i64.extend_i32_u
    local.set 5
    local.get 5
    i64.const 4294967295
    i64.and
    local.get 3
    i64.const 2
    i64.mul
    i64.add
    local.tee 6
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 11
      i32.const 3762
      i32.const 89
      i32.const 1
      call 6
      unreachable
    end
    local.get 5
    i64.const -4294967296
    i64.and
    local.get 6
    i64.or
    local.tee 7
    local.get 2
    local.set 8
    i32.wrap_i64
    local.get 8
    i64.store16 align=1
    local.get 1
    local.get 3
    i64.const 1
    i64.add
    i64.store8
    i64.const 88
    local.set 9
    local.get 1
    i64.load8_u
    local.set 10
    local.get 10
    i64.const 3
    i64.ge_u
    if ;; label = @1
      i32.const 10
      i32.const 3851
      i32.const 89
      i32.const 1
      call 6
      unreachable
    end
    local.get 1
    i32.const 1
    i32.add
    i64.extend_i32_u
    local.set 12
    local.get 12
    i64.const 4294967295
    i64.and
    local.get 10
    i64.const 2
    i64.mul
    i64.add
    local.tee 13
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 11
      i32.const 3940
      i32.const 89
      i32.const 1
      call 6
      unreachable
    end
    local.get 12
    i64.const -4294967296
    i64.and
    local.get 13
    i64.or
    local.tee 14
    local.get 9
    local.set 15
    i32.wrap_i64
    local.get 15
    i64.store16 align=1
    local.get 1
    local.get 10
    i64.const 1
    i64.add
    i64.store8
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.49 (;17;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_memory (;18;) (type 13) (param i64 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      local.get 1
                      i64.const 32
                      i64.shr_u
                      i32.wrap_i64
                      br_table 0 (;@9;) 1 (;@8;) 2 (;@7;) 3 (;@6;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy
                    br 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 0 1
                  br 2 (;@5;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 0 2
                br 1 (;@5;)
              end
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            br 3 (;@1;)
          end
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    local.get 1
                    i64.const 32
                    i64.shr_u
                    i32.wrap_i64
                    br_table 0 (;@8;) 1 (;@7;) 2 (;@6;) 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 1 0
                  br 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 1 1
                br 2 (;@4;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 1 2
              br 1 (;@4;)
            end
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          br 2 (;@1;)
        end
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 1
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 2 0
                br 3 (;@3;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 2 1
              br 2 (;@3;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 2 2
            br 1 (;@3;)
          end
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.61 (;19;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store16 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store16 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store16 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;20;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 15) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goosefat_order/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_fat_order.goose")
)
