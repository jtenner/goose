(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32) (result i64)))
  (type (;12;) (func (param i64 i32) (result i64)))
  (type (;13;) (func (param i32 i32) (result i32)))
  (type (;14;) (func (param i64 i64)))
  (type (;15;) (func (param i64 i32 i32)))
  (type (;16;) (func (param i64) (result i64)))
  (type (;17;) (func (param i64 i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (global (;0;) (mut i32) i32.const 8064)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 16
      i32.const 81
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 97
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i32.const 0
      call $exercise.1
      i64.const 16
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 178
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 259
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      i32.const 1
      local.set 2
      i32.const 12
      call $goose.reserve_memory.1
      local.set 3
      local.get 2
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 3
      i64.extend_i32_u
      i64.or
      local.set 4
      local.get 4
      local.set 1
      local.get 4
      i64.const 1
      local.set 5
      i32.wrap_i64
      local.get 5
      i64.store32 1 align=1
      i64.const 91
      local.set 6
      local.get 3
      i32.const 4
      i32.add
      local.get 6
      i64.store 1 align=1
      i32.const 1
      call $exercise.1
      i64.const 16
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 340
        i32.const 81
        i32.const 22
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 421
        i32.const 81
        i32.const 22
        call 6
        unreachable
      end
      local.get 1
      local.set 7
      local.get 7
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 8
      i64.const 0
      local.set 9
      local.get 7
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 9
      i64.const 8
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 502
        i32.const 81
        i32.const 22
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 91
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 583
        i32.const 81
        i32.const 22
        call 6
        unreachable
      end
      i32.const 1
      call $exercise.1
      i64.const 16
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 664
        i32.const 81
        i32.const 23
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 12
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 745
        i32.const 81
        i32.const 23
        call 6
        unreachable
      end
      call 0
      local.set 12
      local.get 12
      i32.const 826
      i32.const 15
      call 4
      local.get 12
      call 5
      local.get 3
      global.set 1
    end
  )
  (func $exercise.1 (;12;) (type 11) (param i32) (result i64)
    (local i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      i32.const 1
      i32.add
      local.set 5
      local.get 5
      i32.const 64
      call $goose.reserve_data
      local.set 6
      local.get 5
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 6
      i64.extend_i32_u
      i64.or
      local.set 7
      local.get 7
      local.set 2
      local.get 7
      i64.const 2
      call $goose.memory_op.62
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 841
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i64.const 1
      call $goose.memory_op.60
      local.get 7
      i64.const 5
      i64.add
      i64.const 2
      call $goose.memory_op.60
      i64.const 7
      local.get 0
      i32.const 1
      i32.add
      call $tick.2
      i64.const 65535
      i64.and
      local.set 10
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 922
        i32.const 81
        i32.const 5
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i64.const 1
      i64.add
      local.set 9
      i64.const 0
      local.set 11
      block ;; label = @2
        loop ;; label = @3
          local.get 11
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 9
          local.get 11
          i64.const 2
          i64.mul
          i64.add
          local.get 10
          call $goose.memory_op.61
          local.get 11
          i64.const 1
          i64.add
          local.set 11
          br 0 (;@3;)
        end
      end
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 12
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1006
        i32.const 81
        i32.const 5
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i32.const 1003
      i32.const 3
      call $goose.copy_from_frame
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 15
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1087
        i32.const 81
        i32.const 3
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i32.const 0
      i32.const 8
      call $goose.fill_memory
      local.get 7
      i64.const 23
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 11
      local.get 0
      i32.const 1
      i32.add
      call $tick.2
      local.set 10
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 32
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1168
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i64.const 60000
      call $goose.memory_op.61
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 34
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1249
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i64.const 2
      call $goose.memory_op.60
      local.get 7
      i64.const 35
      i64.add
      i64.const 3
      call $goose.memory_op.60
      i64.const 9
      local.get 0
      i32.const 1
      i32.add
      call $tick.2
      i64.const 65535
      i64.and
      local.set 10
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 35
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1330
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i64.const 1
      i64.add
      local.set 9
      i64.const 0
      local.set 11
      block ;; label = @2
        loop ;; label = @3
          local.get 11
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 9
          local.get 11
          i64.const 2
          i64.mul
          i64.add
          local.get 10
          call $goose.memory_op.61
          local.get 11
          i64.const 1
          i64.add
          local.set 11
          br 0 (;@3;)
        end
      end
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 42
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1414
        i32.const 81
        i32.const 6
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i32.const 1411
      i32.const 3
      call $goose.copy_from_frame
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 45
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1495
        i32.const 81
        i32.const 3
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i32.const 0
      i32.const 8
      call $goose.fill_memory
      local.get 7
      i64.const 53
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 13
      local.get 0
      i32.const 1
      i32.add
      call $tick.2
      local.set 10
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 62
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1576
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i64.const 65000
      call $goose.memory_op.61
      local.get 2
      local.set 12
      local.get 12
      call $goose.memory_op.53
      local.set 13
      i64.const 0
      local.set 14
      local.get 12
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 14
      i64.const 30
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1657
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      call $goose.memory_op.49
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1738
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 2
      local.set 18
      local.get 18
      call $goose.memory_op.53
      local.set 19
      i64.const 1
      local.set 20
      local.get 18
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 20
      i64.const 30
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1819
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      local.set 23
      local.get 23
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1900
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 2
      local.set 24
      local.get 24
      call $goose.memory_op.53
      local.set 25
      i64.const 0
      local.set 26
      local.get 24
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 26
      i64.const 30
      i64.mul
      i64.add
      local.tee 28
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1981
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 28
      i64.or
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2062
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 30
      local.get 30
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2143
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 2
      local.set 31
      local.get 31
      call $goose.memory_op.53
      local.set 32
      i64.const 0
      local.set 33
      local.get 31
      local.set 34
      local.get 34
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 33
      i64.const 30
      i64.mul
      i64.add
      local.tee 35
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2224
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 34
      i64.const -4294967296
      i64.and
      local.get 35
      i64.or
      local.set 36
      local.get 36
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2305
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 36
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 37
      local.get 37
      call $goose.memory_op.49
      local.set 38
      i64.const 1
      local.set 39
      local.get 39
      local.get 38
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2386
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 37
      local.set 40
      local.get 40
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 39
      i64.const 2
      i64.mul
      i64.add
      local.tee 41
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2467
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 40
      i64.const -4294967296
      i64.and
      local.get 41
      i64.or
      call $goose.memory_op.51
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2548
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 2
      local.set 42
      local.get 42
      call $goose.memory_op.53
      local.set 43
      i64.const 1
      local.set 44
      local.get 42
      local.set 45
      local.get 45
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 44
      i64.const 30
      i64.mul
      i64.add
      local.tee 46
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2629
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 45
      i64.const -4294967296
      i64.and
      local.get 46
      i64.or
      local.set 47
      local.get 47
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2710
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 47
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 48
      local.get 48
      call $goose.memory_op.49
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2791
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 2
      local.set 49
      local.get 49
      call $goose.memory_op.53
      local.set 50
      i64.const 1
      local.set 51
      local.get 49
      local.set 52
      local.get 52
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 51
      i64.const 30
      i64.mul
      i64.add
      local.tee 53
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2872
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 52
      i64.const -4294967296
      i64.and
      local.get 53
      i64.or
      local.set 54
      local.get 54
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2953
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 54
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 55
      local.get 55
      call $goose.memory_op.49
      local.set 56
      i64.const 2
      local.set 57
      local.get 57
      local.get 56
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3034
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 55
      local.set 58
      local.get 58
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 57
      i64.const 2
      i64.mul
      i64.add
      local.tee 59
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3115
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 58
      i64.const -4294967296
      i64.and
      local.get 59
      i64.or
      call $goose.memory_op.51
      i64.const 9
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3196
        i32.const 81
        i32.const 9
        call 6
        unreachable
      end
      local.get 2
      local.set 60
      local.get 60
      call $goose.memory_op.53
      local.set 61
      i64.const 0
      local.set 62
      local.get 60
      local.set 63
      local.get 63
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 62
      i64.const 30
      i64.mul
      i64.add
      local.tee 64
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3277
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 63
      i64.const -4294967296
      i64.and
      local.get 64
      i64.or
      local.set 65
      local.get 65
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3358
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 65
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 66
      i64.const 3
      local.set 67
      i64.const 0
      local.set 68
      local.get 66
      local.set 69
      local.get 69
      i64.const 4294967295
      i64.and
      local.get 68
      i64.const 1
      i64.mul
      i64.add
      local.tee 70
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3439
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 69
      i64.const -4294967296
      i64.and
      local.get 70
      i64.or
      call $goose.memory_op.49
      i64.const 97
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3520
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 2
      local.set 71
      local.get 71
      call $goose.memory_op.53
      local.set 72
      i64.const 1
      local.set 73
      local.get 71
      local.set 74
      local.get 74
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 73
      i64.const 30
      i64.mul
      i64.add
      local.tee 75
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3601
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 74
      i64.const -4294967296
      i64.and
      local.get 75
      i64.or
      local.set 76
      local.get 76
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3682
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 76
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 77
      i64.const 3
      local.set 78
      i64.const 2
      local.set 79
      local.get 77
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      local.get 79
      i64.const 1
      i64.mul
      i64.add
      local.tee 81
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3763
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 81
      i64.or
      call $goose.memory_op.49
      i64.const 122
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3844
        i32.const 81
        i32.const 10
        call 6
        unreachable
      end
      local.get 2
      local.set 82
      local.get 82
      call $goose.memory_op.53
      local.set 83
      i64.const 0
      local.set 84
      local.get 82
      local.set 85
      local.get 85
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 84
      i64.const 30
      i64.mul
      i64.add
      local.tee 86
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3925
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 85
      i64.const -4294967296
      i64.and
      local.get 86
      i64.or
      local.set 87
      local.get 87
      i64.const 4294967295
      i64.and
      i64.const 11
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4006
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 87
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 88
      i64.const 2
      local.set 89
      i64.const 0
      local.set 90
      local.get 88
      local.set 91
      local.get 91
      i64.const 4294967295
      i64.and
      local.get 90
      i64.const 4
      i64.mul
      i64.add
      local.tee 92
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4087
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 91
      i64.const -4294967296
      i64.and
      local.get 92
      i64.or
      call $goose.memory_op.53
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4168
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 2
      local.set 93
      local.get 93
      call $goose.memory_op.53
      local.set 94
      i64.const 1
      local.set 95
      local.get 93
      local.set 96
      local.get 96
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 95
      i64.const 30
      i64.mul
      i64.add
      local.tee 97
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4249
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 96
      i64.const -4294967296
      i64.and
      local.get 97
      i64.or
      local.set 98
      local.get 98
      i64.const 4294967295
      i64.and
      i64.const 11
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4330
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 98
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 99
      i64.const 2
      local.set 100
      i64.const 1
      local.set 101
      local.get 99
      local.set 102
      local.get 102
      i64.const 4294967295
      i64.and
      local.get 101
      i64.const 4
      i64.mul
      i64.add
      local.tee 103
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4411
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 102
      i64.const -4294967296
      i64.and
      local.get 103
      i64.or
      call $goose.memory_op.53
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4492
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 2
      local.set 104
      local.get 104
      call $goose.memory_op.53
      local.set 105
      i64.const 0
      local.set 106
      local.get 104
      local.set 107
      local.get 107
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 106
      i64.const 30
      i64.mul
      i64.add
      local.tee 108
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4573
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 107
      i64.const -4294967296
      i64.and
      local.get 108
      i64.or
      local.set 109
      local.get 109
      i64.const 4294967295
      i64.and
      i64.const 19
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4654
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 109
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 110
      local.get 110
      call $goose.memory_op.49
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4735
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 2
      local.set 111
      local.get 111
      call $goose.memory_op.53
      local.set 112
      i64.const 1
      local.set 113
      local.get 111
      local.set 114
      local.get 114
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 113
      i64.const 30
      i64.mul
      i64.add
      local.tee 115
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4816
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 114
      i64.const -4294967296
      i64.and
      local.get 115
      i64.or
      local.set 116
      local.get 116
      i64.const 4294967295
      i64.and
      i64.const 19
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4897
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 116
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 117
      local.get 117
      call $goose.memory_op.49
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4978
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 2
      local.set 118
      local.get 118
      call $goose.memory_op.53
      local.set 119
      i64.const 0
      local.set 120
      local.get 118
      local.set 121
      local.get 121
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 120
      i64.const 30
      i64.mul
      i64.add
      local.tee 122
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5059
        i32.const 81
        i32.const 13
        call 6
        unreachable
      end
      local.get 121
      i64.const -4294967296
      i64.and
      local.get 122
      i64.or
      local.set 123
      local.get 123
      i64.const 4294967295
      i64.and
      i64.const 11
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5140
        i32.const 81
        i32.const 13
        call 6
        unreachable
      end
      local.get 123
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 124
      i64.const 2
      local.set 125
      i64.const 0
      local.set 126
      local.get 124
      local.set 127
      local.get 127
      i64.const 4294967295
      i64.and
      local.get 126
      i64.const 4
      i64.mul
      i64.add
      local.tee 128
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5221
        i32.const 81
        i32.const 13
        call 6
        unreachable
      end
      local.get 127
      i64.const -4294967296
      i64.and
      local.get 128
      i64.or
      local.set 129
      i64.const 12345
      local.set 130
      local.get 129
      local.get 130
      call $goose.memory_op.62
      local.get 2
      local.set 131
      local.get 131
      call $goose.memory_op.53
      local.set 132
      i64.const 1
      local.set 133
      local.get 131
      local.set 134
      local.get 134
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 133
      i64.const 30
      i64.mul
      i64.add
      local.tee 135
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5302
        i32.const 81
        i32.const 13
        call 6
        unreachable
      end
      local.get 134
      i64.const -4294967296
      i64.and
      local.get 135
      i64.or
      local.set 136
      local.get 136
      i64.const 4294967295
      i64.and
      i64.const 11
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5383
        i32.const 81
        i32.const 13
        call 6
        unreachable
      end
      local.get 136
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 137
      i64.const 2
      local.set 138
      i64.const 1
      local.set 139
      local.get 137
      local.set 140
      local.get 140
      i64.const 4294967295
      i64.and
      local.get 139
      i64.const 4
      i64.mul
      i64.add
      local.tee 141
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5464
        i32.const 81
        i32.const 13
        call 6
        unreachable
      end
      local.get 140
      i64.const -4294967296
      i64.and
      local.get 141
      i64.or
      local.set 142
      i64.const 54321
      local.set 143
      local.get 142
      local.get 143
      call $goose.memory_op.62
      local.get 2
      local.set 144
      local.get 144
      call $goose.memory_op.53
      local.set 145
      local.get 145
      i64.const 143165576
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 5545
        i32.const 81
        i32.const 14
        call 6
        unreachable
      end
      local.get 145
      i64.const 30
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 146
      local.get 0
      i32.const 2
      i32.add
      local.set 147
      local.get 147
      local.get 146
      call $goose.reserve_data
      local.set 148
      local.get 147
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 148
      i64.extend_i32_u
      i64.or
      local.set 149
      local.get 149
      local.set 3
      local.get 149
      local.get 144
      local.get 146
      call $goose.copy_memory
      local.get 3
      local.set 150
      local.get 150
      call $goose.memory_op.53
      local.set 151
      i64.const 0
      local.set 152
      local.get 152
      local.get 151
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 5626
        i32.const 81
        i32.const 14
        call 6
        unreachable
      end
      local.get 150
      local.set 153
      local.get 153
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 152
      i64.const 30
      i64.mul
      i64.add
      local.tee 154
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5707
        i32.const 81
        i32.const 14
        call 6
        unreachable
      end
      local.get 153
      i64.const -4294967296
      i64.and
      local.get 154
      i64.or
      local.set 155
      local.get 155
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5788
        i32.const 81
        i32.const 14
        call 6
        unreachable
      end
      local.get 155
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 156
      local.get 156
      call $goose.memory_op.49
      local.set 157
      i64.const 0
      local.set 158
      local.get 158
      local.get 157
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 5869
        i32.const 81
        i32.const 14
        call 6
        unreachable
      end
      local.get 156
      local.set 159
      local.get 159
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 158
      i64.const 2
      i64.mul
      i64.add
      local.tee 160
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5950
        i32.const 81
        i32.const 14
        call 6
        unreachable
      end
      local.get 159
      i64.const -4294967296
      i64.and
      local.get 160
      i64.or
      local.set 161
      i64.const 99
      local.set 162
      local.get 161
      local.get 162
      call $goose.memory_op.61
      local.get 2
      local.set 163
      local.get 163
      call $goose.memory_op.53
      local.set 164
      i64.const 0
      local.set 165
      local.get 163
      local.set 166
      local.get 166
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 165
      i64.const 30
      i64.mul
      i64.add
      local.tee 167
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6031
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 166
      i64.const -4294967296
      i64.and
      local.get 167
      i64.or
      local.set 168
      local.get 168
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6112
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 168
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 169
      local.get 169
      call $goose.memory_op.49
      local.set 170
      i64.const 0
      local.set 171
      local.get 171
      local.get 170
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 6193
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 169
      local.set 172
      local.get 172
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 171
      i64.const 2
      i64.mul
      i64.add
      local.tee 173
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6274
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 172
      i64.const -4294967296
      i64.and
      local.get 173
      i64.or
      call $goose.memory_op.51
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6355
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 3
      local.set 174
      local.get 174
      call $goose.memory_op.53
      local.set 175
      i64.const 0
      local.set 176
      local.get 174
      local.set 177
      local.get 177
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 176
      i64.const 30
      i64.mul
      i64.add
      local.tee 178
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6436
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 177
      i64.const -4294967296
      i64.and
      local.get 178
      i64.or
      local.set 179
      local.get 179
      i64.const 4294967295
      i64.and
      i64.const 11
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6517
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 179
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 180
      i64.const 2
      local.set 181
      i64.const 0
      local.set 182
      local.get 180
      local.set 183
      local.get 183
      i64.const 4294967295
      i64.and
      local.get 182
      i64.const 4
      i64.mul
      i64.add
      local.tee 184
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6598
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 183
      i64.const -4294967296
      i64.and
      local.get 184
      i64.or
      call $goose.memory_op.53
      i64.const 12345
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6679
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 3
      local.set 185
      local.get 185
      call $goose.memory_op.53
      local.set 186
      i64.const 0
      local.set 187
      local.get 185
      local.set 188
      local.get 188
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 187
      i64.const 30
      i64.mul
      i64.add
      local.tee 189
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6760
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 188
      i64.const -4294967296
      i64.and
      local.get 189
      i64.or
      local.set 190
      local.get 190
      i64.const 4294967295
      i64.and
      i64.const 28
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6841
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 190
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      call $goose.memory_op.51
      i64.const 60000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6922
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 3
      local.set 191
      local.get 191
      call $goose.memory_op.53
      local.set 192
      i64.const 1
      local.set 193
      local.get 193
      local.get 192
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 7003
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 191
      local.set 194
      local.get 194
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 193
      i64.const 30
      i64.mul
      i64.add
      local.tee 195
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7084
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 194
      i64.const -4294967296
      i64.and
      local.get 195
      i64.or
      local.set 196
      local.get 196
      i64.const 4294967295
      i64.and
      i64.const 28
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7165
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 196
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      call $goose.memory_op.51
      i64.const 65000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7246
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 2
      local.set 197
      local.get 197
      call $goose.memory_op.53
      local.set 198
      i64.const 0
      local.set 199
      local.get 197
      local.set 200
      local.get 200
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 199
      i64.const 30
      i64.mul
      i64.add
      local.tee 201
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7327
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 200
      i64.const -4294967296
      i64.and
      local.get 201
      i64.or
      local.set 202
      local.get 202
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7408
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 202
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 203
      local.get 203
      call $goose.memory_op.49
      local.set 204
      i64.const 1
      local.set 205
      local.get 205
      local.get 204
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 7489
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 203
      local.set 206
      local.get 206
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 205
      i64.const 2
      i64.mul
      i64.add
      local.tee 207
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7570
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 206
      i64.const -4294967296
      i64.and
      local.get 207
      i64.or
      call $goose.memory_op.51
      local.get 2
      local.set 208
      local.get 208
      call $goose.memory_op.53
      local.set 209
      i64.const 1
      local.set 210
      local.get 208
      local.set 211
      local.get 211
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 210
      i64.const 30
      i64.mul
      i64.add
      local.tee 212
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7651
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 211
      i64.const -4294967296
      i64.and
      local.get 212
      i64.or
      local.set 213
      local.get 213
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7732
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 213
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 214
      local.get 214
      call $goose.memory_op.49
      local.set 215
      i64.const 2
      local.set 216
      local.get 216
      local.get 215
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 7813
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 214
      local.set 217
      local.get 217
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 216
      i64.const 2
      i64.mul
      i64.add
      local.tee 218
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7894
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 217
      i64.const -4294967296
      i64.and
      local.get 218
      i64.or
      call $goose.memory_op.51
      i64.add
      i64.const 65535
      i64.and
      local.set 4
      local.get 147
      local.get 148
      call $goose.restore_data
      local.get 5
      local.get 6
      call $goose.restore_data
      br 0 (;@1;)
      local.get 147
      local.get 148
      call $goose.restore_data
      local.get 5
      local.get 6
      call $goose.restore_data
    end
    local.get 4
  )
  (func $tick.2 (;13;) (type 12) (param i64 i32) (result i64)
    (local i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 8
      i64.load align=1
      i64.const 1
      i64.add
      local.set 5
      i32.const 8
      local.get 5
      i64.store align=1
      local.get 1
      i32.const 1
      i32.add
      local.set 6
      local.get 6
      i32.const 12
      call $goose.reserve_data
      local.set 7
      local.get 6
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 7
      i64.extend_i32_u
      i64.or
      local.set 8
      local.get 8
      local.set 3
      local.get 8
      i64.const 1
      call $goose.memory_op.62
      local.get 0
      local.set 9
      local.get 8
      i64.const 4
      i64.add
      local.get 9
      call $goose.memory_op.55
      local.get 3
      local.set 10
      local.get 10
      call $goose.memory_op.53
      local.set 11
      i64.const 0
      local.set 12
      local.get 10
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7975
        i32.const 81
        i32.const 2
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      call $goose.memory_op.41
      local.set 4
      local.get 6
      local.get 7
      call $goose.restore_data
      br 0 (;@1;)
      local.get 6
      local.get 7
      call $goose.restore_data
    end
    local.get 4
  )
  (func $goose.init (;14;) (type 10)
    (local i32 i64)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
  )
  (func $goose.start (;15;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_data (;17;) (type 13) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            call $goose.reserve_memory.1
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.2
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.memory_op.62 (;20;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store32 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store32 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store32 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store32 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;21;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store8
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.61 (;22;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store16 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store16 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store16 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store16 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_from_frame (;23;) (type 15) (param i64 i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              local.get 2
              memory.copy
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            local.get 2
            memory.copy 1 0
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          local.get 2
          memory.copy 2 0
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        local.get 2
        memory.copy 3 0
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.fill_memory (;24;) (type 15) (param i64 i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              local.get 2
              memory.fill
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            local.get 2
            memory.fill 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          local.get 2
          memory.fill 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        local.get 2
        memory.fill 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;25;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;26;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.51 (;27;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load16_u align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load16_u 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load16_u 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load16_u 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_memory (;28;) (type 17) (param i64 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          local.get 1
                          i64.const 32
                          i64.shr_u
                          i32.wrap_i64
                          br_table 0 (;@11;) 1 (;@10;) 2 (;@9;) 3 (;@8;) 4 (;@7;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy
                        br 4 (;@6;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 0 1
                      br 3 (;@6;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 0 2
                    br 2 (;@6;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 0 3
                  br 1 (;@6;)
                end
                i32.const 7
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              br 4 (;@1;)
            end
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 1
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 1 0
                      br 4 (;@5;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 1 1
                    br 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 1 2
                  br 2 (;@5;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 1 3
                br 1 (;@5;)
              end
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            br 3 (;@1;)
          end
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      local.get 1
                      i64.const 32
                      i64.shr_u
                      i32.wrap_i64
                      br_table 0 (;@9;) 1 (;@8;) 2 (;@7;) 3 (;@6;) 4 (;@5;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 2 0
                    br 4 (;@4;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 2 1
                  br 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 2 2
                br 2 (;@4;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 2 3
              br 1 (;@4;)
            end
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          br 2 (;@1;)
        end
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    local.get 1
                    i64.const 32
                    i64.shr_u
                    i32.wrap_i64
                    br_table 0 (;@8;) 1 (;@7;) 2 (;@6;) 3 (;@5;) 4 (;@4;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 3 0
                  br 4 (;@3;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 3 1
                br 3 (;@3;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 3 2
              br 2 (;@3;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 3 3
            br 1 (;@3;)
          end
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;29;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            i32.eqz
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            i64.extend_i32_u
            memory.size 1
            i64.extend_i32_u
            i64.const 16
            i64.shl
            i64.gt_u
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            global.set 1
            br 3 (;@1;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 2
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 2
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 3
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;30;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;31;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goosedata-effects=ok/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.gooseabc/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goosexyz/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_effects.goose")
)
