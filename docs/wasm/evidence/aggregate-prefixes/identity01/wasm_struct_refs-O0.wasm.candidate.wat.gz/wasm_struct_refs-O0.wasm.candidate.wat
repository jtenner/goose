(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (type (;13;) (func (param i64) (result i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (memory (;5;) 1 65536)
  (memory (;6;) 1 65536)
  (memory (;7;) 1 65536)
  (global (;0;) (mut i32) i32.const 5232)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (global (;5;) (mut i32) i32.const 1)
  (global (;6;) (mut i32) i32.const 1)
  (global (;7;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "data_memory_5" (memory 5))
  (export "data_memory_6" (memory 6))
  (export "data_memory_7" (memory 7))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 70
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 78
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i32)
    i32.const 122
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i64.const 1
      i64.store8
      local.get 10
      i64.const 10
      i64.store offset=1 align=1
      local.get 0
      i32.const 9
      i32.add
      local.set 11
      local.get 11
      i64.const 2
      i64.store8
      local.get 11
      i64.const 20
      i64.store offset=1 align=1
      local.get 0
      i32.const 18
      i32.add
      local.set 12
      local.get 12
      i32.const 0
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 12
      i32.const 8
      i32.add
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 34
      i32.add
      local.set 13
      local.get 13
      i64.const 0
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 14
      local.get 13
      i64.load8_u
      local.set 15
      local.get 15
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 148
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 13
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 17
      local.get 17
      i64.const 4294967295
      i64.and
      local.get 15
      i64.const 8
      i64.mul
      i64.add
      local.tee 18
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 218
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 17
      i64.const -4294967296
      i64.and
      local.get 18
      i64.or
      local.tee 19
      local.get 14
      local.set 20
      i32.wrap_i64
      local.get 20
      i64.store align=1
      local.get 13
      local.get 15
      i64.const 1
      i64.add
      i64.store8
      local.get 13
      i32.const 9
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 21
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 22
      local.get 21
      i32.wrap_i64
      i64.load8_u
      local.set 23
      local.get 23
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 288
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 21
      local.set 25
      local.get 25
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 23
      i64.const 8
      i64.mul
      i64.add
      local.tee 26
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 358
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 25
      i64.const -4294967296
      i64.and
      local.get 26
      i64.or
      local.tee 27
      local.get 22
      local.set 28
      i32.wrap_i64
      local.get 28
      i64.store align=1
      local.get 21
      local.get 23
      i64.const 1
      i64.add
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store8
      local.get 27
      i32.wrap_i64
      i64.load align=1
      drop
      i32.const 1
      local.set 30
      i32.const 20
      call $goose.reserve_memory.1
      local.set 31
      local.get 30
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 31
      i64.extend_i32_u
      i64.or
      local.set 32
      local.get 32
      local.set 1
      local.get 32
      i64.const 2
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 1 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 33
      local.get 31
      i32.const 4
      i32.add
      local.get 33
      i64.store 1 align=1
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 33
      local.get 31
      i32.const 12
      i32.add
      local.get 33
      i64.store 1 align=1
      i32.const 2
      local.set 34
      i32.const 17
      call $goose.reserve_memory.2
      local.set 35
      local.get 34
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 35
      i64.extend_i32_u
      i64.or
      local.set 36
      local.get 36
      local.set 2
      local.get 36
      i32.wrap_i64
      i64.const 2
      i64.store8 2
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 37
      local.get 35
      i32.const 1
      i32.add
      local.get 37
      i64.store 2 align=1
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 37
      local.get 35
      i32.const 9
      i32.add
      local.get 37
      i64.store 2 align=1
      i64.const 3
      local.set 38
      local.get 38
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 12
        i32.const 428
        i32.const 70
        i32.const 7
        call 6
        unreachable
      end
      local.get 38
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 498
        i32.const 70
        i32.const 7
        call 6
        unreachable
      end
      i32.const 3
      local.set 39
      local.get 38
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      call $goose.reserve_memory.3
      local.set 40
      local.get 39
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 40
      i64.extend_i32_u
      i64.or
      local.set 41
      local.get 41
      local.set 3
      local.get 41
      local.get 38
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 3 align=1
      local.get 41
      i64.const 0
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 3 offset=4 align=1
      local.get 3
      local.set 42
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 43
      local.get 42
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 44
      local.get 44
      local.get 42
      i32.wrap_i64
      i64.load32_u 3 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 568
        i32.const 70
        i32.const 7
        call 6
        unreachable
      end
      local.get 42
      local.set 46
      local.get 46
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 44
      i64.const 8
      i64.mul
      i64.add
      local.tee 47
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 638
        i32.const 70
        i32.const 7
        call 6
        unreachable
      end
      local.get 46
      i64.const -4294967296
      i64.and
      local.get 47
      i64.or
      local.tee 48
      local.get 43
      local.set 49
      i32.wrap_i64
      local.get 49
      i64.store 3 align=1
      local.get 42
      local.get 44
      i64.const 1
      i64.add
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 3 offset=4 align=1
      local.get 48
      i32.wrap_i64
      i64.load 3 align=1
      drop
      local.get 3
      local.set 50
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 51
      local.get 50
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 52
      local.get 52
      local.get 50
      i32.wrap_i64
      i64.load32_u 3 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 708
        i32.const 70
        i32.const 7
        call 6
        unreachable
      end
      local.get 50
      local.set 54
      local.get 54
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 52
      i64.const 8
      i64.mul
      i64.add
      local.tee 55
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 778
        i32.const 70
        i32.const 7
        call 6
        unreachable
      end
      local.get 54
      i64.const -4294967296
      i64.and
      local.get 55
      i64.or
      local.tee 56
      local.get 51
      local.set 57
      i32.wrap_i64
      local.get 57
      i64.store 3 align=1
      local.get 50
      local.get 52
      i64.const 1
      i64.add
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 3 offset=4 align=1
      local.get 56
      i32.wrap_i64
      i64.load 3 align=1
      drop
      i32.const 4
      local.set 58
      global.get 4
      local.set 59
      local.get 0
      i32.const 59
      i32.add
      local.set 60
      local.get 60
      local.get 58
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 59
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 60
      i64.const 0
      i64.store offset=8 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 61
      local.get 60
      i64.load offset=8 align=1
      local.set 62
      i32.const 8
      call $goose.reserve_memory.4
      local.set 63
      local.get 60
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 63
      i64.extend_i32_u
      i64.or
      local.tee 64
      local.get 61
      local.set 65
      i32.wrap_i64
      local.get 65
      i64.store 4 align=1
      local.get 60
      local.get 62
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 59
      i32.add
      local.set 66
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 67
      local.get 66
      i64.load offset=8 align=1
      local.set 68
      i32.const 8
      call $goose.reserve_memory.4
      local.set 69
      local.get 66
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 69
      i64.extend_i32_u
      i64.or
      local.tee 70
      local.get 67
      local.set 71
      i32.wrap_i64
      local.get 71
      i64.store 4 align=1
      local.get 66
      local.get 68
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 70
      i32.wrap_i64
      i64.load 4 align=1
      drop
      local.get 0
      i32.const 18
      i32.add
      i64.extend_i32_u
      local.set 72
      i64.const 2
      local.set 73
      i64.const 0
      local.set 74
      local.get 72
      local.set 75
      local.get 75
      i64.const 4294967295
      i64.and
      local.get 74
      i64.const 8
      i64.mul
      i64.add
      local.tee 76
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 848
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 75
      i64.const -4294967296
      i64.and
      local.get 76
      i64.or
      local.set 77
      local.get 77
      i32.wrap_i64
      i64.load align=1
      local.tee 78
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 918
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 78
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 988
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 78
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.get 78
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1058
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 78
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      i64.const 1
      i64.add
      call $goose.memory_op.55
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 80
      local.get 80
      i32.wrap_i64
      i64.load8_u
      local.set 81
      i64.const 1
      local.set 82
      local.get 80
      local.set 83
      local.get 83
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 82
      i64.const 8
      i64.mul
      i64.add
      local.tee 84
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1128
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 83
      i64.const -4294967296
      i64.and
      local.get 84
      i64.or
      local.set 85
      local.get 85
      i32.wrap_i64
      i64.load align=1
      local.tee 86
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1198
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 86
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1268
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 86
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.get 86
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1338
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 86
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      i64.const 2
      i64.add
      call $goose.memory_op.55
      local.get 1
      local.set 87
      local.get 87
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 88
      i64.const 0
      local.set 89
      local.get 87
      local.set 90
      local.get 90
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 89
      i64.const 8
      i64.mul
      i64.add
      local.tee 91
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1408
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 90
      i64.const -4294967296
      i64.and
      local.get 91
      i64.or
      local.set 92
      local.get 92
      i32.wrap_i64
      i64.load 1 align=1
      local.tee 93
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1478
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 93
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1548
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.get 93
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1618
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      i64.const 3
      i64.add
      call $goose.memory_op.55
      local.get 2
      local.set 94
      local.get 94
      call $goose.read_array_prefix
      local.set 97
      local.set 95
      i64.const 1
      local.set 96
      local.get 94
      local.set 98
      local.get 98
      i64.const 4294967295
      i64.and
      local.get 97
      i64.extend_i32_u
      i64.add
      local.get 96
      i64.const 8
      i64.mul
      i64.add
      local.tee 99
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1688
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 98
      i64.const -4294967296
      i64.and
      local.get 99
      i64.or
      local.set 100
      local.get 100
      i32.wrap_i64
      i64.load 2 align=1
      local.tee 101
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1758
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      local.get 101
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1828
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 101
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.get 101
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1898
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 101
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      i64.const 4
      i64.add
      call $goose.memory_op.55
      local.get 3
      local.set 102
      local.get 102
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 103
      i64.const 0
      local.set 104
      local.get 102
      local.set 105
      local.get 105
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 104
      i64.const 8
      i64.mul
      i64.add
      local.tee 106
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1968
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      local.get 105
      i64.const -4294967296
      i64.and
      local.get 106
      i64.or
      local.set 107
      local.get 107
      i32.wrap_i64
      i64.load 3 align=1
      local.tee 108
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2038
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      local.get 108
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2108
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.get 108
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2178
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      i64.const 5
      i64.add
      call $goose.memory_op.55
      local.get 0
      i32.const 59
      i32.add
      local.set 109
      local.get 109
      i64.load offset=8 align=1
      local.set 110
      i64.const 1
      local.set 111
      local.get 109
      i64.load align=1
      local.set 112
      local.get 112
      i64.const 4294967295
      i64.and
      local.get 111
      i64.const 8
      i64.mul
      i64.add
      local.tee 113
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2248
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      local.get 112
      i64.const -4294967296
      i64.and
      local.get 113
      i64.or
      local.set 114
      local.get 114
      i32.wrap_i64
      i64.load 4 align=1
      local.tee 115
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2318
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      local.get 115
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2388
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 115
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.get 115
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2458
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 115
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      i64.const 6
      i64.add
      call $goose.memory_op.55
      local.get 0
      i32.const 59
      i32.add
      local.set 116
      i64.const 0
      local.set 117
      block ;; label = @2
        loop ;; label = @3
          local.get 117
          local.get 116
          i64.load offset=8 align=1
          i64.ge_u
          br_if 1 (;@2;)
          local.get 116
          i64.load align=1
          local.set 118
          local.get 118
          i64.const 4294967295
          i64.and
          local.get 117
          i64.const 8
          i64.mul
          i64.add
          local.tee 119
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 2528
            i32.const 70
            i32.const 11
            call 6
            unreachable
          end
          local.get 118
          i64.const -4294967296
          i64.and
          local.get 119
          i64.or
          i32.wrap_i64
          i64.load 4 align=1
          local.set 4
          block ;; label = @4
            local.get 4
            local.tee 120
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2598
              i32.const 70
              i32.const 11
              call 6
              unreachable
            end
            local.get 120
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.tee 79
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2668
              i32.const 70
              i32.const 0
              call 6
              unreachable
            end
            local.get 120
            i64.const -4294967296
            i64.and
            local.get 79
            i64.or
            local.get 120
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.tee 79
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2738
              i32.const 70
              i32.const 0
              call 6
              unreachable
            end
            local.get 120
            i64.const -4294967296
            i64.and
            local.get 79
            i64.or
            call $goose.memory_op.41
            i64.const 10
            i64.add
            call $goose.memory_op.55
          end
          local.get 117
          i64.const 1
          i64.add
          local.set 117
          br 0 (;@3;)
        end
      end
      local.get 1
      local.set 121
      local.get 121
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 124
      local.get 124
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2808
        i32.const 70
        i32.const 12
        call 6
        unreachable
      end
      local.get 124
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 122
      local.get 121
      local.set 123
      i32.const 5
      local.set 126
      local.get 122
      call $goose.reserve_memory.5
      local.set 127
      local.get 126
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 127
      i64.extend_i32_u
      i64.or
      local.set 125
      local.get 125
      local.set 5
      local.get 125
      i32.wrap_i64
      local.get 123
      i32.wrap_i64
      local.get 122
      memory.copy 5 1
      local.get 5
      local.set 128
      local.get 128
      i32.wrap_i64
      i64.load32_u 5 align=1
      local.set 129
      local.get 1
      local.set 130
      i32.const 0
      local.set 131
      local.get 129
      local.get 130
      i32.wrap_i64
      i64.load32_u 1 align=1
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 131
        i64.const 0
        local.set 132
        block ;; label = @3
          loop ;; label = @4
            local.get 132
            local.get 129
            i64.ge_u
            br_if 1 (;@3;)
            local.get 128
            local.set 133
            local.get 133
            i64.const 4294967295
            i64.and
            i64.const 4
            i64.add
            local.get 132
            i64.const 8
            i64.mul
            i64.add
            local.tee 134
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2878
              i32.const 70
              i32.const 12
              call 6
              unreachable
            end
            local.get 133
            i64.const -4294967296
            i64.and
            local.get 134
            i64.or
            i32.wrap_i64
            i64.load 5 align=1
            local.get 130
            local.set 135
            local.get 135
            i64.const 4294967295
            i64.and
            i64.const 4
            i64.add
            local.get 132
            i64.const 8
            i64.mul
            i64.add
            local.tee 136
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2948
              i32.const 70
              i32.const 12
              call 6
              unreachable
            end
            local.get 135
            i64.const -4294967296
            i64.and
            local.get 136
            i64.or
            i32.wrap_i64
            i64.load 1 align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 131
              br 2 (;@3;)
            end
            local.get 132
            i64.const 1
            i64.add
            local.set 132
            br 0 (;@4;)
          end
        end
      end
      local.get 131
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3018
        i32.const 70
        i32.const 12
        call 6
        unreachable
      end
      local.get 5
      local.set 137
      local.get 137
      i32.wrap_i64
      i64.load32_u 5 align=1
      local.set 138
      i64.const 0
      local.set 139
      local.get 139
      local.get 138
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3088
        i32.const 70
        i32.const 13
        call 6
        unreachable
      end
      local.get 137
      local.set 140
      local.get 140
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 139
      i64.const 8
      i64.mul
      i64.add
      local.tee 141
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3158
        i32.const 70
        i32.const 13
        call 6
        unreachable
      end
      local.get 140
      i64.const -4294967296
      i64.and
      local.get 141
      i64.or
      local.set 142
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 143
      local.get 142
      local.get 143
      local.set 144
      i32.wrap_i64
      local.get 144
      i64.store 5 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 145
      local.get 145
      i64.load offset=1 align=1
      local.set 146
      local.get 0
      i32.const 9
      i32.add
      local.set 147
      local.get 147
      i64.load offset=1 align=1
      local.set 148
      local.get 1
      local.set 149
      local.get 149
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 150
      i64.const 0
      local.set 151
      local.get 149
      local.set 152
      local.get 152
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 151
      i64.const 8
      i64.mul
      i64.add
      local.tee 153
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3228
        i32.const 70
        i32.const 13
        call 6
        unreachable
      end
      local.get 152
      i64.const -4294967296
      i64.and
      local.get 153
      i64.or
      local.set 154
      local.get 154
      i32.wrap_i64
      i64.load 1 align=1
      local.tee 155
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3298
        i32.const 70
        i32.const 13
        call 6
        unreachable
      end
      local.get 155
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3368
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 155
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      local.set 156
      local.get 5
      local.set 157
      local.get 157
      i32.wrap_i64
      i64.load32_u 5 align=1
      local.set 158
      i64.const 0
      local.set 159
      local.get 157
      local.set 160
      local.get 160
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 159
      i64.const 8
      i64.mul
      i64.add
      local.tee 161
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3438
        i32.const 70
        i32.const 13
        call 6
        unreachable
      end
      local.get 160
      i64.const -4294967296
      i64.and
      local.get 161
      i64.or
      local.set 162
      local.get 162
      i32.wrap_i64
      i64.load 5 align=1
      local.tee 163
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3508
        i32.const 70
        i32.const 13
        call 6
        unreachable
      end
      local.get 163
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3578
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
      local.get 163
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      call $goose.memory_op.41
      local.set 164
      call 0
      local.set 165
      local.get 165
      i32.const 3648
      i32.const 5
      call 4
      local.get 165
      local.get 146
      i32.const 0
      call 1
      local.get 165
      i32.const 3653
      i32.const 1
      call 4
      local.get 165
      local.get 148
      i32.const 0
      call 1
      local.get 165
      i32.const 3654
      i32.const 1
      call 4
      local.get 165
      local.get 156
      i32.const 0
      call 1
      local.get 165
      i32.const 3655
      i32.const 1
      call 4
      local.get 165
      local.get 164
      i32.const 0
      call 1
      local.get 165
      call 5
      i32.const 6
      local.set 166
      i32.const 12
      call $goose.reserve_memory.6
      local.set 167
      local.get 166
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 167
      i64.extend_i32_u
      i64.or
      local.set 168
      local.get 168
      local.set 6
      local.get 168
      i64.const 1
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 6 align=1
      i64.const 100
      local.set 169
      local.get 167
      i32.const 4
      i32.add
      local.get 169
      i64.store 6 align=1
      i32.const 7
      local.set 170
      i32.const 12
      call $goose.reserve_memory.7
      local.set 171
      local.get 170
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 171
      i64.extend_i32_u
      i64.or
      local.set 172
      local.get 172
      local.set 7
      local.get 172
      i64.const 1
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store32 7 align=1
      i64.const 200
      local.set 173
      local.get 171
      i32.const 4
      i32.add
      local.get 173
      i64.store 7 align=1
      local.get 0
      i32.const 75
      i32.add
      local.set 174
      local.get 174
      i64.const 3
      i64.store8
      local.get 174
      local.get 6
      local.set 175
      local.get 175
      i32.wrap_i64
      i64.load32_u 6 align=1
      local.set 176
      i64.const 0
      local.set 177
      local.get 175
      local.set 178
      local.get 178
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 177
      i64.const 8
      i64.mul
      i64.add
      local.tee 179
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3656
        i32.const 70
        i32.const 15
        call 6
        unreachable
      end
      local.get 178
      i64.const -4294967296
      i64.and
      local.get 179
      i64.or
      i64.store offset=1 align=1
      local.get 174
      i64.const 60000
      i64.store16 offset=9 align=1
      local.get 174
      local.get 7
      i64.store offset=11 align=1
      local.get 0
      i32.const 75
      i32.add
      local.set 180
      local.get 180
      i64.load offset=11 align=1
      local.set 8
      local.get 8
      i64.const 0
      i64.ne
      if ;; label = @2
        local.get 0
        i32.const 75
        i32.add
        local.set 181
        local.get 181
        i64.load offset=1 align=1
        local.tee 182
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 3726
          i32.const 70
          i32.const 2
          call 6
          unreachable
        end
        local.get 182
        call $goose.memory_op.41
        local.set 183
        local.get 8
        local.tee 184
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 3796
          i32.const 70
          i32.const 16
          call 6
          unreachable
        end
        local.get 184
        local.set 185
        local.get 185
        call $goose.memory_op.53
        local.set 186
        local.get 8
        local.tee 187
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 3866
          i32.const 70
          i32.const 16
          call 6
          unreachable
        end
        local.get 187
        local.set 188
        local.get 188
        call $goose.memory_op.53
        local.set 189
        i64.const 0
        local.set 190
        local.get 190
        local.get 189
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 3936
          i32.const 70
          i32.const 16
          call 6
          unreachable
        end
        local.get 188
        local.set 191
        local.get 191
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 190
        i64.const 8
        i64.mul
        i64.add
        local.tee 192
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4006
          i32.const 70
          i32.const 16
          call 6
          unreachable
        end
        local.get 191
        i64.const -4294967296
        i64.and
        local.get 192
        i64.or
        call $goose.memory_op.41
        local.set 193
        call 0
        local.set 194
        local.get 194
        i32.const 4076
        i32.const 5
        call 4
        local.get 194
        local.get 183
        i32.const 0
        call 1
        local.get 194
        i32.const 4081
        i32.const 1
        call 4
        local.get 194
        local.get 186
        i32.const 0
        call 1
        local.get 194
        i32.const 4082
        i32.const 1
        call 4
        local.get 194
        local.get 193
        i32.const 0
        call 1
        local.get 194
        call 5
      end
      local.get 0
      i32.const 75
      i32.add
      local.set 195
      local.get 195
      local.get 7
      local.set 196
      local.get 196
      i32.wrap_i64
      i64.load32_u 7 align=1
      local.set 197
      i64.const 0
      local.set 198
      local.get 196
      local.set 199
      local.get 199
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 198
      i64.const 8
      i64.mul
      i64.add
      local.tee 200
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4083
        i32.const 70
        i32.const 17
        call 6
        unreachable
      end
      local.get 199
      i64.const -4294967296
      i64.and
      local.get 200
      i64.or
      i64.store offset=1 align=1
      local.get 0
      i32.const 75
      i32.add
      local.set 201
      local.get 201
      i64.load offset=1 align=1
      local.tee 202
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4153
        i32.const 70
        i32.const 17
        call 6
        unreachable
      end
      local.get 202
      local.get 202
      call $goose.memory_op.41
      i64.const 7
      i64.add
      call $goose.memory_op.55
      local.get 0
      i32.const 94
      i32.add
      local.set 203
      local.get 0
      i32.const 75
      i32.add
      local.set 204
      local.get 203
      i64.extend_i32_u
      local.set 205
      local.get 204
      i64.extend_i32_u
      local.set 206
      i32.const 19
      local.set 207
      local.get 205
      i32.wrap_i64
      local.get 206
      i32.wrap_i64
      local.get 207
      memory.copy
      local.get 0
      i32.const 94
      i32.add
      local.set 208
      local.get 208
      i64.load offset=1 align=1
      local.tee 209
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4223
        i32.const 70
        i32.const 18
        call 6
        unreachable
      end
      local.get 209
      local.get 209
      call $goose.memory_op.41
      i64.const 8
      i64.add
      call $goose.memory_op.55
      local.get 6
      local.set 210
      local.get 210
      i32.wrap_i64
      i64.load32_u 6 align=1
      local.set 211
      i64.const 0
      local.set 212
      local.get 210
      local.set 213
      local.get 213
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 212
      i64.const 8
      i64.mul
      i64.add
      local.tee 214
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4293
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 213
      i64.const -4294967296
      i64.and
      local.get 214
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.set 215
      local.get 7
      local.set 216
      local.get 216
      i32.wrap_i64
      i64.load32_u 7 align=1
      local.set 217
      i64.const 0
      local.set 218
      local.get 216
      local.set 219
      local.get 219
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 218
      i64.const 8
      i64.mul
      i64.add
      local.tee 220
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4363
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 219
      i64.const -4294967296
      i64.and
      local.get 220
      i64.or
      i32.wrap_i64
      i64.load 7 align=1
      local.set 221
      local.get 0
      i32.const 94
      i32.add
      local.set 222
      local.get 222
      i64.load offset=1 align=1
      local.get 0
      i32.const 75
      i32.add
      local.set 223
      local.get 223
      i64.load offset=1 align=1
      i64.eq
      local.set 224
      local.get 0
      i32.const 75
      i32.add
      local.set 225
      local.get 225
      i64.load8_u
      local.set 226
      local.get 0
      i32.const 75
      i32.add
      local.set 227
      local.get 227
      i64.load16_u offset=9 align=1
      local.set 228
      call 0
      local.set 229
      local.get 229
      i32.const 4433
      i32.const 9
      call 4
      local.get 229
      local.get 215
      i32.const 0
      call 1
      local.get 229
      i32.const 4442
      i32.const 1
      call 4
      local.get 229
      local.get 221
      i32.const 0
      call 1
      local.get 229
      i32.const 4443
      i32.const 1
      call 4
      local.get 229
      local.get 224
      call 3
      local.get 229
      i32.const 4444
      i32.const 1
      call 4
      local.get 229
      local.get 226
      i32.const 1
      call 1
      local.get 229
      i32.const 4445
      i32.const 1
      call 4
      local.get 229
      local.get 228
      i32.const 1
      call 1
      local.get 229
      call 5
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 230
      local.get 230
      i32.wrap_i64
      i64.load8_u
      local.set 231
      i64.const 0
      local.set 231
      local.get 230
      local.set 232
      local.get 232
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 231
      i64.const 8
      i64.mul
      i64.add
      local.tee 233
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4446
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 232
      i64.const -4294967296
      i64.and
      local.get 233
      i64.or
      local.set 234
      local.get 230
      local.get 231
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store8
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 235
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 236
      local.get 235
      i32.wrap_i64
      i64.load8_u
      local.set 237
      local.get 237
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 4516
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 235
      local.set 239
      local.get 239
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 237
      i64.const 8
      i64.mul
      i64.add
      local.tee 240
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4586
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 239
      i64.const -4294967296
      i64.and
      local.get 240
      i64.or
      local.tee 241
      local.get 236
      local.set 242
      i32.wrap_i64
      local.get 242
      i64.store align=1
      local.get 235
      local.get 237
      i64.const 1
      i64.add
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store8
      local.get 241
      i32.wrap_i64
      i64.load align=1
      local.set 9
      local.get 9
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4656
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 0
      i32.const 113
      i32.add
      local.set 243
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 244
      local.get 244
      i32.wrap_i64
      i64.load8_u
      local.set 245
      local.get 245
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 4726
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 245
      i64.const 1
      i64.sub
      local.set 245
      local.get 244
      local.set 246
      local.get 246
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 245
      i64.const 8
      i64.mul
      i64.add
      local.tee 247
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4796
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 246
      i64.const -4294967296
      i64.and
      local.get 247
      i64.or
      local.set 248
      local.get 248
      i32.wrap_i64
      i64.load align=1
      local.set 249
      local.get 244
      local.get 245
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store8
      local.get 249
      local.tee 250
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4866
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 243
      i64.extend_i32_u
      local.set 251
      local.get 250
      local.set 252
      i32.const 9
      local.set 253
      local.get 251
      i32.wrap_i64
      local.get 252
      local.get 253
      call $goose.copy_to_frame
      local.get 0
      i32.const 113
      i32.add
      local.set 254
      local.get 254
      local.get 254
      i64.load offset=1 align=1
      i64.const 1
      i64.add
      i64.store offset=1 align=1
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 255
      local.get 0
      i32.const 9
      i32.add
      i64.extend_i32_u
      local.set 256
      local.get 255
      i32.wrap_i64
      i64.load8_u
      local.set 257
      local.get 257
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 4936
        i32.const 70
        i32.const 22
        call 6
        unreachable
      end
      local.get 255
      local.set 259
      local.get 259
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 257
      i64.const 8
      i64.mul
      i64.add
      local.tee 260
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5006
        i32.const 70
        i32.const 22
        call 6
        unreachable
      end
      local.get 259
      i64.const -4294967296
      i64.and
      local.get 260
      i64.or
      local.tee 261
      local.get 256
      local.set 262
      i32.wrap_i64
      local.get 262
      i64.store align=1
      local.get 255
      local.get 257
      i64.const 1
      i64.add
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store8
      local.get 261
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 263
      local.get 263
      i32.wrap_i64
      i64.load8_u
      local.set 264
      local.get 264
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 5076
        i32.const 70
        i32.const 22
        call 6
        unreachable
      end
      local.get 264
      i64.const 1
      i64.sub
      local.set 264
      local.get 263
      local.set 265
      local.get 265
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 264
      i64.const 8
      i64.mul
      i64.add
      local.tee 266
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5146
        i32.const 70
        i32.const 22
        call 6
        unreachable
      end
      local.get 265
      i64.const -4294967296
      i64.and
      local.get 266
      i64.or
      local.set 267
      local.get 267
      i32.wrap_i64
      i64.load align=1
      local.set 268
      local.get 263
      local.get 264
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store8
      local.get 268
      drop
      local.get 0
      i32.const 0
      i32.add
      local.set 269
      local.get 269
      i64.load offset=1 align=1
      local.set 270
      local.get 0
      i32.const 113
      i32.add
      local.set 271
      local.get 271
      i64.load offset=1 align=1
      local.set 272
      local.get 0
      i32.const 34
      i32.add
      i64.extend_i32_u
      local.set 273
      local.get 273
      i32.wrap_i64
      i64.load8_u
      local.set 274
      call 0
      local.set 275
      local.get 275
      i32.const 5216
      i32.const 9
      call 4
      local.get 275
      local.get 270
      i32.const 0
      call 1
      local.get 275
      i32.const 5225
      i32.const 1
      call 4
      local.get 275
      local.get 272
      i32.const 0
      call 1
      local.get 275
      i32.const 5226
      i32.const 1
      call 4
      local.get 275
      local.get 274
      i32.const 0
      call 1
      local.get 275
      call 5
      local.get 171
      global.set 7
      local.get 167
      global.set 6
      local.get 127
      global.set 5
      local.get 59
      global.set 4
      local.get 40
      global.set 3
      local.get 35
      global.set 2
      local.get 31
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.memory_op.41 (;18;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load 1 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load 2 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load 3 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load 4 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 5 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 6 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 7 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;19;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store 1 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store 2 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store 3 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store 4 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 5 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 6 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 7 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.read_array_prefix (;20;) (type 13) (param i64) (result i64 i32)
    (local i64 i32 i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load8_u
                      local.tee 3
                      i64.const 128
                      i64.lt_u
                      if ;; label = @10
                        local.get 3
                        local.set 1
                        i32.const 1
                        local.set 2
                      else
                        local.get 3
                        i64.const 127
                        i64.and
                        local.set 1
                        i32.const 1
                        local.set 2
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 0
                            i64.const 4294967295
                            i64.and
                            local.get 2
                            i64.extend_i32_u
                            i64.add
                            local.tee 4
                            i64.const 4294967295
                            i64.gt_u
                            if ;; label = @13
                              i32.const 11
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            local.get 4
                            i32.wrap_i64
                            i64.load8_u
                            local.set 3
                            local.get 2
                            i32.const 9
                            i32.eq
                            local.get 3
                            i64.const 1
                            i64.gt_u
                            i32.and
                            local.get 3
                            i64.eqz
                            i32.or
                            if ;; label = @13
                              i32.const 13
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            local.get 1
                            local.get 3
                            i64.const 127
                            i64.and
                            local.get 2
                            i32.const 7
                            i32.mul
                            i64.extend_i32_u
                            i64.shl
                            i64.or
                            local.set 1
                            local.get 2
                            i32.const 1
                            i32.add
                            local.set 2
                            local.get 3
                            i64.const 128
                            i64.and
                            i64.eqz
                            br_if 1 (;@11;)
                            br 0 (;@12;)
                          end
                        end
                      end
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load8_u 1
                    local.tee 3
                    i64.const 128
                    i64.lt_u
                    if ;; label = @9
                      local.get 3
                      local.set 1
                      i32.const 1
                      local.set 2
                    else
                      local.get 3
                      i64.const 127
                      i64.and
                      local.set 1
                      i32.const 1
                      local.set 2
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 0
                          i64.const 4294967295
                          i64.and
                          local.get 2
                          i64.extend_i32_u
                          i64.add
                          local.tee 4
                          i64.const 4294967295
                          i64.gt_u
                          if ;; label = @12
                            i32.const 11
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          local.get 4
                          i32.wrap_i64
                          i64.load8_u 1
                          local.set 3
                          local.get 2
                          i32.const 9
                          i32.eq
                          local.get 3
                          i64.const 1
                          i64.gt_u
                          i32.and
                          local.get 3
                          i64.eqz
                          i32.or
                          if ;; label = @12
                            i32.const 13
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          local.get 1
                          local.get 3
                          i64.const 127
                          i64.and
                          local.get 2
                          i32.const 7
                          i32.mul
                          i64.extend_i32_u
                          i64.shl
                          i64.or
                          local.set 1
                          local.get 2
                          i32.const 1
                          i32.add
                          local.set 2
                          local.get 3
                          i64.const 128
                          i64.and
                          i64.eqz
                          br_if 1 (;@10;)
                          br 0 (;@11;)
                        end
                      end
                    end
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load8_u 2
                  local.tee 3
                  i64.const 128
                  i64.lt_u
                  if ;; label = @8
                    local.get 3
                    local.set 1
                    i32.const 1
                    local.set 2
                  else
                    local.get 3
                    i64.const 127
                    i64.and
                    local.set 1
                    i32.const 1
                    local.set 2
                    block ;; label = @9
                      loop ;; label = @10
                        local.get 0
                        i64.const 4294967295
                        i64.and
                        local.get 2
                        i64.extend_i32_u
                        i64.add
                        local.tee 4
                        i64.const 4294967295
                        i64.gt_u
                        if ;; label = @11
                          i32.const 11
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        local.get 4
                        i32.wrap_i64
                        i64.load8_u 2
                        local.set 3
                        local.get 2
                        i32.const 9
                        i32.eq
                        local.get 3
                        i64.const 1
                        i64.gt_u
                        i32.and
                        local.get 3
                        i64.eqz
                        i32.or
                        if ;; label = @11
                          i32.const 13
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        local.get 1
                        local.get 3
                        i64.const 127
                        i64.and
                        local.get 2
                        i32.const 7
                        i32.mul
                        i64.extend_i32_u
                        i64.shl
                        i64.or
                        local.set 1
                        local.get 2
                        i32.const 1
                        i32.add
                        local.set 2
                        local.get 3
                        i64.const 128
                        i64.and
                        i64.eqz
                        br_if 1 (;@9;)
                        br 0 (;@10;)
                      end
                    end
                  end
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load8_u 3
                local.tee 3
                i64.const 128
                i64.lt_u
                if ;; label = @7
                  local.get 3
                  local.set 1
                  i32.const 1
                  local.set 2
                else
                  local.get 3
                  i64.const 127
                  i64.and
                  local.set 1
                  i32.const 1
                  local.set 2
                  block ;; label = @8
                    loop ;; label = @9
                      local.get 0
                      i64.const 4294967295
                      i64.and
                      local.get 2
                      i64.extend_i32_u
                      i64.add
                      local.tee 4
                      i64.const 4294967295
                      i64.gt_u
                      if ;; label = @10
                        i32.const 11
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      local.get 4
                      i32.wrap_i64
                      i64.load8_u 3
                      local.set 3
                      local.get 2
                      i32.const 9
                      i32.eq
                      local.get 3
                      i64.const 1
                      i64.gt_u
                      i32.and
                      local.get 3
                      i64.eqz
                      i32.or
                      if ;; label = @10
                        i32.const 13
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      local.get 1
                      local.get 3
                      i64.const 127
                      i64.and
                      local.get 2
                      i32.const 7
                      i32.mul
                      i64.extend_i32_u
                      i64.shl
                      i64.or
                      local.set 1
                      local.get 2
                      i32.const 1
                      i32.add
                      local.set 2
                      local.get 3
                      i64.const 128
                      i64.and
                      i64.eqz
                      br_if 1 (;@8;)
                      br 0 (;@9;)
                    end
                  end
                end
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u 4
              local.tee 3
              i64.const 128
              i64.lt_u
              if ;; label = @6
                local.get 3
                local.set 1
                i32.const 1
                local.set 2
              else
                local.get 3
                i64.const 127
                i64.and
                local.set 1
                i32.const 1
                local.set 2
                block ;; label = @7
                  loop ;; label = @8
                    local.get 0
                    i64.const 4294967295
                    i64.and
                    local.get 2
                    i64.extend_i32_u
                    i64.add
                    local.tee 4
                    i64.const 4294967295
                    i64.gt_u
                    if ;; label = @9
                      i32.const 11
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 4
                    i32.wrap_i64
                    i64.load8_u 4
                    local.set 3
                    local.get 2
                    i32.const 9
                    i32.eq
                    local.get 3
                    i64.const 1
                    i64.gt_u
                    i32.and
                    local.get 3
                    i64.eqz
                    i32.or
                    if ;; label = @9
                      i32.const 13
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 1
                    local.get 3
                    i64.const 127
                    i64.and
                    local.get 2
                    i32.const 7
                    i32.mul
                    i64.extend_i32_u
                    i64.shl
                    i64.or
                    local.set 1
                    local.get 2
                    i32.const 1
                    i32.add
                    local.set 2
                    local.get 3
                    i64.const 128
                    i64.and
                    i64.eqz
                    br_if 1 (;@7;)
                    br 0 (;@8;)
                  end
                end
              end
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 5
            local.tee 3
            i64.const 128
            i64.lt_u
            if ;; label = @5
              local.get 3
              local.set 1
              i32.const 1
              local.set 2
            else
              local.get 3
              i64.const 127
              i64.and
              local.set 1
              i32.const 1
              local.set 2
              block ;; label = @6
                loop ;; label = @7
                  local.get 0
                  i64.const 4294967295
                  i64.and
                  local.get 2
                  i64.extend_i32_u
                  i64.add
                  local.tee 4
                  i64.const 4294967295
                  i64.gt_u
                  if ;; label = @8
                    i32.const 11
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 4
                  i32.wrap_i64
                  i64.load8_u 5
                  local.set 3
                  local.get 2
                  i32.const 9
                  i32.eq
                  local.get 3
                  i64.const 1
                  i64.gt_u
                  i32.and
                  local.get 3
                  i64.eqz
                  i32.or
                  if ;; label = @8
                    i32.const 13
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 1
                  local.get 3
                  i64.const 127
                  i64.and
                  local.get 2
                  i32.const 7
                  i32.mul
                  i64.extend_i32_u
                  i64.shl
                  i64.or
                  local.set 1
                  local.get 2
                  i32.const 1
                  i32.add
                  local.set 2
                  local.get 3
                  i64.const 128
                  i64.and
                  i64.eqz
                  br_if 1 (;@6;)
                  br 0 (;@7;)
                end
              end
            end
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 6
          local.tee 3
          i64.const 128
          i64.lt_u
          if ;; label = @4
            local.get 3
            local.set 1
            i32.const 1
            local.set 2
          else
            local.get 3
            i64.const 127
            i64.and
            local.set 1
            i32.const 1
            local.set 2
            block ;; label = @5
              loop ;; label = @6
                local.get 0
                i64.const 4294967295
                i64.and
                local.get 2
                i64.extend_i32_u
                i64.add
                local.tee 4
                i64.const 4294967295
                i64.gt_u
                if ;; label = @7
                  i32.const 11
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 4
                i32.wrap_i64
                i64.load8_u 6
                local.set 3
                local.get 2
                i32.const 9
                i32.eq
                local.get 3
                i64.const 1
                i64.gt_u
                i32.and
                local.get 3
                i64.eqz
                i32.or
                if ;; label = @7
                  i32.const 13
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 1
                local.get 3
                i64.const 127
                i64.and
                local.get 2
                i32.const 7
                i32.mul
                i64.extend_i32_u
                i64.shl
                i64.or
                local.set 1
                local.get 2
                i32.const 1
                i32.add
                local.set 2
                local.get 3
                i64.const 128
                i64.and
                i64.eqz
                br_if 1 (;@5;)
                br 0 (;@6;)
              end
            end
          end
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 7
        local.tee 3
        i64.const 128
        i64.lt_u
        if ;; label = @3
          local.get 3
          local.set 1
          i32.const 1
          local.set 2
        else
          local.get 3
          i64.const 127
          i64.and
          local.set 1
          i32.const 1
          local.set 2
          block ;; label = @4
            loop ;; label = @5
              local.get 0
              i64.const 4294967295
              i64.and
              local.get 2
              i64.extend_i32_u
              i64.add
              local.tee 4
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 4
              i32.wrap_i64
              i64.load8_u 7
              local.set 3
              local.get 2
              i32.const 9
              i32.eq
              local.get 3
              i64.const 1
              i64.gt_u
              i32.and
              local.get 3
              i64.eqz
              i32.or
              if ;; label = @6
                i32.const 13
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 1
              local.get 3
              i64.const 127
              i64.and
              local.get 2
              i32.const 7
              i32.mul
              i64.extend_i32_u
              i64.shl
              i64.or
              local.set 1
              local.get 2
              i32.const 1
              i32.add
              local.set 2
              local.get 3
              i64.const 128
              i64.and
              i64.eqz
              br_if 1 (;@4;)
              br 0 (;@5;)
            end
          end
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 1
    local.get 2
  )
  (func $goose.reserve_memory.5 (;21;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 5
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 5
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 5
      i32.sub
      memory.grow 5
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 5
    local.get 1
  )
  (func $goose.reserve_memory.6 (;22;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 6
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 6
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 6
      i32.sub
      memory.grow 6
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 6
    local.get 1
  )
  (func $goose.reserve_memory.7 (;23;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 7
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 7
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 7
      i32.sub
      memory.grow 7
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 7
    local.get 1
  )
  (func $goose.memory_op.53 (;24;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load32_u align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load32_u 1 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load32_u 2 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load32_u 3 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u 4 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 5 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 6 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 7 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_to_frame (;25;) (type 1) (param i32 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 1
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy
                      br 8 (;@1;)
                    end
                    local.get 0
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 0 1
                    br 7 (;@1;)
                  end
                  local.get 0
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 0 2
                  br 6 (;@1;)
                end
                local.get 0
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 0 3
                br 5 (;@1;)
              end
              local.get 0
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 0 4
              br 4 (;@1;)
            end
            local.get 0
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 0 5
            br 3 (;@1;)
          end
          local.get 0
          local.get 1
          i32.wrap_i64
          local.get 2
          memory.copy 0 6
          br 2 (;@1;)
        end
        local.get 0
        local.get 1
        i32.wrap_i64
        local.get 2
        memory.copy 0 7
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.gooserefs=,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goosedata=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.gooseidentity=,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_refs.goosereturned=,,")
)
