(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (type (;12;) (func (param i64) (result i64)))
  (type (;13;) (func (param i32) (result i64)))
  (type (;14;) (func (param i64 i64)))
  (type (;15;) (func (param i32 i32) (result i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (global (;0;) (mut i32) i32.const 2144)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 69
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 77
        i32.const 69
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i32 i64 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i64 i32 i64 i32 i32)
    i32.const 25
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 7
      i32.const 7
      call $goose.reserve_memory.1
      local.set 8
      local.get 7
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 8
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 1
      local.get 9
      i64.const 3
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store32 1 align=1
      i64.const 97
      local.set 11
      local.get 8
      i32.const 4
      i32.add
      local.get 11
      i64.store8 1
      i64.const 98
      local.set 11
      local.get 8
      i32.const 5
      i32.add
      local.get 11
      i64.store8 1
      i64.const 99
      local.set 11
      local.get 8
      i32.const 6
      i32.add
      local.get 11
      i64.store8 1
      local.get 1
      local.set 12
      local.get 12
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 13
      i64.const 0
      local.set 14
      local.get 12
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 14
      i64.const 1
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 146
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 17
      i32.wrap_i64
      local.get 13
      i32.wrap_i64
      call 10
      local.set 18
      local.get 1
      call $change.1
      local.set 19
      local.get 1
      local.set 20
      local.get 20
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 21
      i64.const 0
      local.set 22
      local.get 20
      local.set 23
      local.get 23
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 22
      i64.const 1
      i64.mul
      i64.add
      local.tee 24
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 215
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 23
      i64.const -4294967296
      i64.and
      local.get 24
      i64.or
      local.set 25
      local.get 25
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 25
      i32.wrap_i64
      local.get 21
      i32.wrap_i64
      call 10
      local.set 26
      call 0
      local.set 27
      local.get 27
      i32.const 284
      i32.const 8
      call 4
      local.get 27
      local.get 18
      call 11
      local.get 27
      i32.const 292
      i32.const 1
      call 4
      local.get 27
      local.get 19
      i32.const 0
      call 1
      local.get 27
      i32.const 293
      i32.const 1
      call 4
      local.get 27
      local.get 26
      call 11
      local.get 27
      call 5
      i32.const 1
      call $early.2
      local.set 28
      call 0
      local.set 29
      local.get 29
      i32.const 294
      i32.const 11
      call 4
      local.get 29
      local.get 28
      i32.const 0
      call 1
      local.get 29
      call 5
      i32.const 0
      call $early.2
      local.set 30
      call 0
      local.set 31
      local.get 31
      i32.const 305
      i32.const 13
      call 4
      local.get 31
      local.get 30
      i32.const 0
      call 1
      local.get 31
      call 5
      i32.const 1
      call $inline_early.3
      local.set 32
      call 0
      local.set 33
      local.get 33
      i32.const 318
      i32.const 13
      call 4
      local.get 33
      local.get 32
      i32.const 0
      call 1
      local.get 33
      call 5
      i32.const 0
      call $inline_early.3
      local.set 34
      call 0
      local.set 35
      local.get 35
      i32.const 331
      i32.const 20
      call 4
      local.get 35
      local.get 34
      i32.const 0
      call 1
      local.get 35
      call 5
      i64.const 0
      local.set 2
      local.get 2
      local.set 36
      i32.const 0
      local.set 37
      local.get 37
      local.get 36
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 37
      else
        local.get 36
        local.set 38
      end
      local.get 37
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 351
        i32.const 4
        call 10
      else
        local.get 38
        call $goose.memory_op.53
        local.set 39
        i64.const 0
        local.set 40
        local.get 38
        local.set 41
        local.get 41
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 40
        i64.const 1
        i64.mul
        i64.add
        local.tee 42
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 355
          i32.const 69
          i32.const 22
          call 6
          unreachable
        end
        local.get 41
        i64.const -4294967296
        i64.and
        local.get 42
        i64.or
        local.set 43
        local.get 43
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 43
        i32.wrap_i64
        local.get 39
        i32.wrap_i64
        call 10
      end
      local.set 44
      call 0
      local.set 45
      local.get 45
      i32.const 424
      i32.const 9
      call 4
      local.get 45
      local.get 44
      call 11
      local.get 45
      call 5
      local.get 1
      local.set 2
      local.get 2
      local.tee 46
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 433
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 46
      local.set 47
      local.get 47
      call $goose.memory_op.53
      local.set 48
      i64.const 0
      local.set 49
      local.get 47
      local.set 50
      local.get 50
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 49
      i64.const 1
      i64.mul
      i64.add
      local.tee 51
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 502
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 50
      i64.const -4294967296
      i64.and
      local.get 51
      i64.or
      local.set 52
      local.get 52
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 52
      i32.wrap_i64
      local.get 48
      i32.wrap_i64
      call 10
      local.set 53
      call 0
      local.set 54
      local.get 54
      i32.const 571
      i32.const 9
      call 4
      local.get 54
      local.get 53
      call 11
      local.get 54
      call 5
      i64.const 0
      local.set 2
      local.get 2
      local.set 55
      i32.const 0
      local.set 56
      local.get 56
      local.get 55
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 56
      else
        local.get 55
        local.set 57
      end
      local.get 56
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 580
        i32.const 4
        call 10
      else
        local.get 57
        call $goose.memory_op.53
        local.set 58
        i64.const 0
        local.set 59
        local.get 57
        local.set 60
        local.get 60
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 59
        i64.const 1
        i64.mul
        i64.add
        local.tee 61
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 584
          i32.const 69
          i32.const 23
          call 6
          unreachable
        end
        local.get 60
        i64.const -4294967296
        i64.and
        local.get 61
        i64.or
        local.set 62
        local.get 62
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 62
        i32.wrap_i64
        local.get 58
        i32.wrap_i64
        call 10
      end
      local.set 63
      call 0
      local.set 64
      local.get 64
      i32.const 653
      i32.const 9
      call 4
      local.get 64
      local.get 63
      call 11
      local.get 64
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 65
      local.get 65
      i32.const 0
      i32.add
      i64.const 65
      i64.store8
      local.get 65
      i32.const 1
      i32.add
      i64.const 0
      i64.store8
      local.get 65
      i32.const 2
      i32.add
      i64.const 66
      i64.store8
      i64.const 0
      local.set 3
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 66
      i64.const 3
      local.set 67
      i64.const 0
      local.set 68
      local.get 66
      local.set 69
      local.get 69
      i64.const 4294967295
      i64.and
      local.get 68
      i64.const 1
      i64.mul
      i64.add
      local.tee 70
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 662
        i32.const 69
        i32.const 26
        call 6
        unreachable
      end
      local.get 69
      i64.const -4294967296
      i64.and
      local.get 70
      i64.or
      local.set 71
      local.get 71
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 71
      i32.wrap_i64
      local.get 67
      i32.wrap_i64
      call 10
      local.set 72
      local.get 3
      local.set 73
      i32.const 0
      local.set 74
      local.get 74
      local.get 73
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 74
      else
        local.get 73
        local.set 75
      end
      local.get 74
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 731
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 76
        i64.const 0
        local.set 77
        local.get 75
        local.set 78
        local.get 78
        i64.const 4294967295
        i64.and
        local.get 77
        i64.const 1
        i64.mul
        i64.add
        local.tee 79
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 735
          i32.const 69
          i32.const 26
          call 6
          unreachable
        end
        local.get 78
        i64.const -4294967296
        i64.and
        local.get 79
        i64.or
        local.set 80
        local.get 80
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 80
        i32.wrap_i64
        local.get 76
        i32.wrap_i64
        call 10
      end
      local.set 81
      call 0
      local.set 82
      local.get 82
      i32.const 804
      i32.const 6
      call 4
      local.get 82
      local.get 72
      call 11
      local.get 82
      i32.const 810
      i32.const 1
      call 4
      local.get 82
      local.get 81
      call 11
      local.get 82
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 3
      local.get 3
      local.tee 83
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 811
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 83
      local.set 84
      i64.const 3
      local.set 85
      i64.const 0
      local.set 86
      local.get 84
      local.set 87
      local.get 87
      i64.const 4294967295
      i64.and
      local.get 86
      i64.const 1
      i64.mul
      i64.add
      local.tee 88
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 880
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 87
      i64.const -4294967296
      i64.and
      local.get 88
      i64.or
      local.set 89
      local.get 89
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 89
      i32.wrap_i64
      local.get 85
      i32.wrap_i64
      call 10
      local.set 90
      call 0
      local.set 91
      local.get 91
      i32.const 949
      i32.const 6
      call 4
      local.get 91
      local.get 90
      call 11
      local.get 91
      call 5
      i64.const 0
      local.set 3
      local.get 3
      local.set 92
      i32.const 0
      local.set 93
      local.get 93
      local.get 92
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 93
      else
        local.get 92
        local.set 94
      end
      local.get 93
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 955
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 95
        i64.const 0
        local.set 96
        local.get 94
        local.set 97
        local.get 97
        i64.const 4294967295
        i64.and
        local.get 96
        i64.const 1
        i64.mul
        i64.add
        local.tee 98
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 959
          i32.const 69
          i32.const 27
          call 6
          unreachable
        end
        local.get 97
        i64.const -4294967296
        i64.and
        local.get 98
        i64.or
        local.set 99
        local.get 99
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 99
        i32.wrap_i64
        local.get 95
        i32.wrap_i64
        call 10
      end
      local.set 100
      call 0
      local.set 101
      local.get 101
      i32.const 1028
      i32.const 6
      call 4
      local.get 101
      local.get 100
      call 11
      local.get 101
      call 5
      local.get 0
      i32.const 3
      i32.add
      local.set 102
      local.get 102
      i64.const 0
      i64.store8
      i64.const 100
      local.set 103
      local.get 102
      i64.load8_u
      local.set 104
      local.get 104
      i64.const 5
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1034
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 102
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 106
      local.get 106
      i64.const 4294967295
      i64.and
      local.get 104
      i64.const 1
      i64.mul
      i64.add
      local.tee 107
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1103
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 106
      i64.const -4294967296
      i64.and
      local.get 107
      i64.or
      local.tee 108
      local.get 103
      local.set 109
      i32.wrap_i64
      local.get 109
      i64.store8
      local.get 102
      local.get 104
      i64.const 1
      i64.add
      i64.store8
      i64.const 101
      local.set 110
      local.get 102
      i64.load8_u
      local.set 111
      local.get 111
      i64.const 5
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1172
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 102
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 113
      local.get 113
      i64.const 4294967295
      i64.and
      local.get 111
      i64.const 1
      i64.mul
      i64.add
      local.tee 114
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1241
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 113
      i64.const -4294967296
      i64.and
      local.get 114
      i64.or
      local.tee 115
      local.get 110
      local.set 116
      i32.wrap_i64
      local.get 116
      i64.store8
      local.get 102
      local.get 111
      i64.const 1
      i64.add
      i64.store8
      local.get 102
      i32.const 3
      i32.add
      i32.const 0
      i32.const 3
      memory.fill
      i32.const 2
      local.set 117
      global.get 2
      local.set 118
      local.get 0
      i32.const 9
      i32.add
      local.set 119
      local.get 119
      local.get 117
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 118
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 119
      i64.const 0
      i64.store offset=8 align=1
      i64.const 71
      local.set 120
      local.get 119
      i64.load offset=8 align=1
      local.set 121
      i32.const 1
      call $goose.reserve_memory.2
      local.set 122
      local.get 119
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 122
      i64.extend_i32_u
      i64.or
      local.tee 123
      local.get 120
      local.set 124
      i32.wrap_i64
      local.get 124
      i64.store8 2
      local.get 119
      local.get 121
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 125
      local.get 125
      i32.wrap_i64
      i64.load8_u
      local.set 126
      i64.const 0
      local.set 127
      local.get 125
      local.set 128
      local.get 128
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 127
      i64.const 1
      i64.mul
      i64.add
      local.tee 129
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1310
        i32.const 69
        i32.const 30
        call 6
        unreachable
      end
      local.get 128
      i64.const -4294967296
      i64.and
      local.get 129
      i64.or
      local.set 130
      local.get 130
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 130
      i32.wrap_i64
      local.get 126
      i32.wrap_i64
      call 10
      local.set 131
      call 0
      local.set 132
      local.get 132
      i32.const 1379
      i32.const 8
      call 4
      local.get 132
      local.get 131
      call 11
      local.get 132
      call 5
      local.get 0
      i32.const 9
      i32.add
      local.set 133
      local.get 133
      i64.load offset=8 align=1
      local.set 134
      i64.const 0
      local.set 135
      local.get 133
      i64.load align=1
      local.set 136
      local.get 136
      i64.const 4294967295
      i64.and
      local.get 135
      i64.const 1
      i64.mul
      i64.add
      local.tee 137
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1387
        i32.const 69
        i32.const 31
        call 6
        unreachable
      end
      local.get 136
      i64.const -4294967296
      i64.and
      local.get 137
      i64.or
      local.set 138
      local.get 138
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 138
      i32.wrap_i64
      local.get 134
      i32.wrap_i64
      call 10
      local.set 139
      local.get 0
      i32.const 9
      i32.add
      call $grow.4
      local.set 140
      local.get 0
      i32.const 9
      i32.add
      local.set 141
      local.get 141
      i64.load offset=8 align=1
      local.set 142
      call 0
      local.set 143
      local.get 143
      i32.const 1456
      i32.const 7
      call 4
      local.get 143
      local.get 139
      call 11
      local.get 143
      i32.const 1463
      i32.const 1
      call 4
      local.get 143
      local.get 140
      i32.const 0
      call 1
      local.get 143
      i32.const 1464
      i32.const 1
      call 4
      local.get 143
      local.get 142
      i32.const 0
      call 1
      local.get 143
      call 5
      i32.const 3
      local.set 144
      i32.const 4
      call $goose.reserve_memory.3
      local.set 145
      local.get 144
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 145
      i64.extend_i32_u
      i64.or
      local.set 146
      local.get 146
      local.set 4
      local.get 146
      i64.const 0
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store32 3 align=1
      local.get 4
      local.set 147
      local.get 147
      i32.wrap_i64
      i64.load32_u 3 align=1
      local.set 148
      i64.const 0
      local.set 149
      local.get 147
      local.set 150
      local.get 150
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 149
      i64.const 1
      i64.mul
      i64.add
      local.tee 151
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1465
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 150
      i64.const -4294967296
      i64.and
      local.get 151
      i64.or
      local.set 152
      local.get 152
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 152
      i32.wrap_i64
      local.get 148
      i32.wrap_i64
      call 10
      local.set 153
      call 0
      local.set 154
      local.get 154
      i32.const 1534
      i32.const 6
      call 4
      local.get 154
      local.get 153
      call 11
      local.get 154
      i32.const 1540
      i32.const 1
      call 4
      local.get 154
      call 5
      i64.const 0
      local.set 155
      i64.const 3
      local.set 156
      block ;; label = @2
        loop ;; label = @3
          local.get 155
          local.get 156
          i64.ge_s
          br_if 1 (;@2;)
          local.get 155
          local.set 5
          block ;; label = @4
            i32.const 4
            local.set 157
            i32.const 6
            call $goose.reserve_memory.4
            local.set 158
            local.get 157
            i64.extend_i32_u
            i64.const 32
            i64.shl
            local.get 158
            i64.extend_i32_u
            i64.or
            local.set 159
            local.get 159
            local.set 6
            local.get 159
            i64.const 2
            local.set 10
            i32.wrap_i64
            local.get 10
            i64.store32 4 align=1
            i64.const 80
            local.set 160
            local.get 158
            i32.const 4
            i32.add
            local.get 160
            i64.store8 4
            i64.const 81
            local.set 160
            local.get 158
            i32.const 5
            i32.add
            local.get 160
            i64.store8 4
            local.get 6
            local.set 161
            local.get 161
            i32.wrap_i64
            i64.load32_u 4 align=1
            local.set 162
            i64.const 0
            local.set 163
            local.get 161
            local.set 164
            local.get 164
            i64.const 4294967295
            i64.and
            i64.const 4
            i64.add
            local.get 163
            i64.const 1
            i64.mul
            i64.add
            local.tee 165
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1541
              i32.const 69
              i32.const 36
              call 6
              unreachable
            end
            local.get 164
            i64.const -4294967296
            i64.and
            local.get 165
            i64.or
            local.set 166
            local.get 166
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            local.get 166
            i32.wrap_i64
            local.get 162
            i32.wrap_i64
            call 10
            local.set 167
            local.get 5
            i64.const 0
            i64.eq
            if (result i64) ;; label = @5
              local.get 167
              call 12
              local.get 5
              local.set 168
              call 0
              local.set 169
              local.get 169
              i32.const 1610
              i32.const 10
              call 4
              local.get 169
              local.get 168
              i32.const 0
              call 1
              local.get 169
              call 5
              local.get 158
              global.set 4
              br 1 (;@4;)
            else
              local.get 5
              i64.const 1
              i64.eq
              if (result i64) ;; label = @6
                local.get 167
                call 12
                local.get 5
                local.set 170
                call 0
                local.set 171
                local.get 171
                i32.const 1620
                i32.const 10
                call 4
                local.get 171
                local.get 170
                i32.const 0
                call 1
                local.get 171
                call 5
                local.get 158
                global.set 4
                br 4 (;@2;)
              else
                i64.const 4
              end
            end
            local.set 172
            call 0
            local.set 173
            local.get 173
            i32.const 1630
            i32.const 12
            call 4
            local.get 173
            local.get 167
            call 11
            local.get 173
            local.get 172
            i32.const 0
            call 1
            local.get 173
            call 5
            local.get 5
            local.set 174
            call 0
            local.set 175
            local.get 175
            i32.const 1642
            i32.const 10
            call 4
            local.get 175
            local.get 174
            i32.const 0
            call 1
            local.get 175
            call 5
            local.get 158
            global.set 4
          end
          local.get 155
          i64.const 1
          i64.add
          local.set 155
          br 0 (;@3;)
        end
      end
      call 0
      local.set 176
      local.get 176
      i32.const 1652
      i32.const 10
      call 4
      local.get 176
      call 5
      local.get 145
      global.set 3
      local.get 118
      global.set 2
      local.get 8
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $change.1 (;15;) (type 12) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      local.get 0
      local.tee 3
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1662
        i32.const 69
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      local.get 4
      call $goose.memory_op.53
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 6
      i64.const 1
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1731
        i32.const 69
        i32.const 1
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      i64.const 88
      local.set 10
      local.get 9
      local.get 10
      call $goose.memory_op.60
      call 0
      local.set 11
      local.get 11
      i32.const 1800
      i32.const 6
      call 4
      local.get 11
      call 5
      i64.const 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $early.2 (;16;) (type 13) (param i32) (result i64)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i32)
    block ;; label = @1
      i32.const 2
      local.set 4
      i32.const 6
      call $goose.reserve_memory.2
      local.set 5
      local.get 4
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 5
      i64.extend_i32_u
      i64.or
      local.set 6
      local.get 6
      local.set 2
      local.get 6
      i64.const 2
      local.set 7
      i32.wrap_i64
      local.get 7
      i64.store32 2 align=1
      i64.const 65
      local.set 8
      local.get 5
      i32.const 4
      i32.add
      local.get 8
      i64.store8 2
      i64.const 66
      local.set 8
      local.get 5
      i32.const 5
      i32.add
      local.get 8
      i64.store8 2
      local.get 2
      local.set 9
      local.get 9
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 10
      i64.const 0
      local.set 11
      local.get 9
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 11
      i64.const 1
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1806
        i32.const 69
        i32.const 5
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      local.set 14
      local.get 14
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 14
      i32.wrap_i64
      local.get 10
      i32.wrap_i64
      call 10
      local.set 15
      local.get 0
      if (result i64) ;; label = @2
        i64.const 7
        local.set 3
        local.get 15
        call 12
        call 0
        local.set 16
        local.get 16
        i32.const 1875
        i32.const 10
        call 4
        local.get 16
        call 5
        local.get 5
        global.set 2
        br 1 (;@1;)
      else
        i64.const 8
      end
      local.set 17
      call 0
      local.set 18
      local.get 18
      i32.const 1885
      i32.const 7
      call 4
      local.get 18
      local.get 15
      call 11
      local.get 18
      local.get 17
      i32.const 0
      call 1
      local.get 18
      call 5
      i64.const 9
      local.set 3
      call 0
      local.set 19
      local.get 19
      i32.const 1892
      i32.const 10
      call 4
      local.get 19
      call 5
      local.get 5
      global.set 2
      br 0 (;@1;)
      call 0
      local.set 20
      local.get 20
      i32.const 1902
      i32.const 10
      call 4
      local.get 20
      call 5
      local.get 5
      global.set 2
    end
    local.get 3
  )
  (func $inline_early.3 (;17;) (type 13) (param i32) (result i64)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32)
    block ;; label = @1
      i32.const 2
      local.set 4
      i32.const 6
      call $goose.reserve_memory.2
      local.set 5
      local.get 4
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 5
      i64.extend_i32_u
      i64.or
      local.set 6
      local.get 6
      local.set 2
      local.get 6
      i64.const 2
      local.set 7
      i32.wrap_i64
      local.get 7
      i64.store32 2 align=1
      i64.const 67
      local.set 8
      local.get 5
      i32.const 4
      i32.add
      local.get 8
      i64.store8 2
      i64.const 68
      local.set 8
      local.get 5
      i32.const 5
      i32.add
      local.get 8
      i64.store8 2
      local.get 2
      local.set 9
      local.get 9
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 10
      i64.const 0
      local.set 11
      local.get 9
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 11
      i64.const 1
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1912
        i32.const 69
        i32.const 10
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      local.set 14
      local.get 14
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 14
      i32.wrap_i64
      local.get 10
      i32.wrap_i64
      call 10
      local.set 15
      local.get 0
      if (result i64) ;; label = @2
        i64.const 10
        local.set 3
        local.get 15
        call 12
        local.get 5
        global.set 2
        br 1 (;@1;)
      else
        i64.const 11
      end
      local.set 16
      call 0
      local.set 17
      local.get 17
      i32.const 1981
      i32.const 14
      call 4
      local.get 17
      local.get 15
      call 11
      local.get 17
      local.get 16
      i32.const 0
      call 1
      local.get 17
      call 5
      i64.const 12
      local.set 3
      local.get 5
      global.set 2
      br 0 (;@1;)
      local.get 5
      global.set 2
    end
    local.get 3
  )
  (func $grow.4 (;18;) (type 13) (param i32) (result i64)
    (local i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i32 i32)
    block ;; label = @1
      i64.const 0
      local.set 4
      i64.const 70000
      local.set 5
      block ;; label = @2
        loop ;; label = @3
          local.get 4
          local.get 5
          i64.ge_s
          br_if 1 (;@2;)
          local.get 4
          local.set 2
          block ;; label = @4
            local.get 0
            local.tee 6
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 1995
              i32.const 69
              i32.const 13
              call 6
              unreachable
            end
            local.get 6
            local.set 7
            i64.const 120
            local.set 8
            local.get 7
            i64.load offset=8 align=1
            local.set 9
            local.get 7
            i64.load align=1
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 1
            call $goose.reserve_data
            local.set 10
            local.get 7
            i64.load align=1
            i64.const -4294967296
            i64.and
            local.get 10
            i64.extend_i32_u
            i64.or
            local.tee 11
            local.get 8
            call $goose.memory_op.60
            local.get 7
            local.get 9
            i64.const 1
            i64.add
            i64.store offset=8 align=1
            local.get 11
            call $goose.memory_op.49
            drop
          end
          local.get 4
          i64.const 1
          i64.add
          local.set 4
          br 0 (;@3;)
        end
      end
      local.get 0
      local.tee 12
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2064
        i32.const 69
        i32.const 13
        call 6
        unreachable
      end
      local.get 12
      local.set 13
      local.get 13
      i64.load offset=8 align=1
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $goose.init (;19;) (type 11)
    (local i32)
  )
  (func $goose.start (;20;) (type 11)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;21;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.53 (;22;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 0
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;) 4 (;@3;) 5 (;@2;)
                end
                local.get 0
                i32.wrap_i64
                i64.load32_u align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u 1 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 2 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 3 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 4 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;23;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;24;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;25;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.memory_op.60 (;26;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 0
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;) 4 (;@3;) 5 (;@2;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store8
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store8 1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8 2
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 3
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 4
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_data (;27;) (type 15) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i32.const 1
                i32.sub
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 1
              call $goose.reserve_memory.1
              br 4 (;@1;)
            end
            local.get 1
            call $goose.reserve_memory.2
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.3
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.4
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;28;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 0
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;) 4 (;@3;) 5 (;@2;)
                end
                local.get 0
                i32.wrap_i64
                i64.load8_u
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u 1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 2
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 3
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 4
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosecapture=||after-exit=after-normal=after-inline=after-inline-normal=null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseoptional=null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosenull/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosefixed=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosefixed=null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosefixed=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooselimited=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosegrowth=||/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseempty=!/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseloop-exit=loop-exit=unused-loop=loop-exit=done-bytes/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosenested/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosedefer-exitunused=defer-exitdefer-exit/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseunused-inline=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose")
)
