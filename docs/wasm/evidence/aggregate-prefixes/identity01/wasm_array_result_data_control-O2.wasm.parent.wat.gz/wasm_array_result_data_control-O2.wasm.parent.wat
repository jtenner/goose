(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 7520)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 84
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 92
        i32.const 84
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i32.const 1
      local.set 7
      i32.const 40
      call $goose.reserve_memory.1
      local.set 8
      local.get 7
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 8
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 1
      local.get 9
      i64.const 3
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store32 1 align=1
      local.get 9
      i32.wrap_i64
      i64.const 90
      i64.store8 1 offset=4
      i32.const 2
      local.set 11
      i32.const 6
      call $goose.reserve_memory.2
      local.set 12
      local.get 11
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 12
      i64.extend_i32_u
      i64.or
      local.set 13
      local.get 13
      local.set 2
      local.get 13
      i64.const 1
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store32 2 align=1
      i64.const 4660
      local.set 14
      local.get 12
      i32.const 4
      i32.add
      local.get 14
      i64.store16 2 align=1
      local.get 9
      i64.const 0
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store8 1 offset=5
      local.get 2
      local.set 20
      local.get 20
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 21
      i64.const 0
      local.set 22
      local.get 20
      local.set 23
      local.get 23
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 22
      i64.const 2
      i64.mul
      i64.add
      local.tee 24
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 176
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 23
      i64.const -4294967296
      i64.and
      local.get 24
      i64.or
      i32.wrap_i64
      i64.load16_u 2 align=1
      local.set 15
      local.get 9
      i32.wrap_i64
      i64.load8_u 1 offset=5
      local.set 16
      local.get 16
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 260
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 9
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 344
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 18
      local.get 18
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 16
      i64.const 2
      i64.mul
      i64.add
      local.tee 19
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 428
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 18
      i64.const -4294967296
      i64.and
      local.get 19
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      local.get 15
      i64.store16 1 align=1
      local.get 9
      local.get 16
      i64.const 1
      i64.add
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store8 1 offset=5
      i64.const 22136
      local.set 15
      local.get 9
      i32.wrap_i64
      i64.load8_u 1 offset=5
      local.set 16
      local.get 16
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 512
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 9
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 596
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 18
      local.get 18
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 16
      i64.const 2
      i64.mul
      i64.add
      local.tee 19
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 680
        i32.const 84
        i32.const 4
        call 6
        unreachable
      end
      local.get 18
      i64.const -4294967296
      i64.and
      local.get 19
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      local.get 15
      i64.store16 1 align=1
      local.get 9
      local.get 16
      i64.const 1
      i64.add
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store8 1 offset=5
      local.get 12
      global.set 2
      local.get 9
      i32.wrap_i64
      call 0
      local.set 26
      local.get 26
      i32.const 764
      i32.const 4
      call 4
      local.get 26
      call 5
      i64.const 13124
      local.set 27
      local.get 27
      i64.store16 1 offset=14 align=1
      local.get 9
      i32.wrap_i64
      i64.const 91
      i64.store8 1 offset=16
      i32.const 1
      call $choice.1
      if ;; label = @2
        i32.const 2
        local.set 28
        i32.const 6
        call $goose.reserve_memory.2
        local.set 29
        local.get 28
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 29
        i64.extend_i32_u
        i64.or
        local.set 30
        local.get 30
        local.set 3
        local.get 30
        i64.const 1
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store32 2 align=1
        i64.const 7
        local.set 31
        local.get 29
        i32.const 4
        i32.add
        local.get 31
        i64.store16 2 align=1
        local.get 9
        i64.const 0
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=17
        local.get 3
        local.set 32
        local.get 32
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 33
        i64.const 0
        local.set 34
        local.get 32
        local.set 35
        local.get 35
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 34
        i64.const 2
        i64.mul
        i64.add
        local.tee 36
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 768
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 35
        i64.const -4294967296
        i64.and
        local.get 36
        i64.or
        i32.wrap_i64
        i64.load16_u 2 align=1
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=17
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 852
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 17
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 936
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1020
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=17
        i64.const 8
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=17
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 1104
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 17
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1188
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1272
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=17
        local.get 29
        global.set 2
      else
        i32.const 2
        local.set 37
        i32.const 6
        call $goose.reserve_memory.2
        local.set 38
        local.get 37
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 38
        i64.extend_i32_u
        i64.or
        local.set 39
        local.get 39
        local.set 4
        local.get 39
        i64.const 1
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store32 2 align=1
        i64.const 99
        local.set 40
        local.get 38
        i32.const 4
        i32.add
        local.get 40
        i64.store16 2 align=1
        local.get 9
        i64.const 0
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=17
        local.get 4
        local.set 41
        local.get 41
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 42
        i64.const 0
        local.set 43
        local.get 41
        local.set 44
        local.get 44
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 43
        i64.const 2
        i64.mul
        i64.add
        local.tee 45
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1356
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 44
        i64.const -4294967296
        i64.and
        local.get 45
        i64.or
        i32.wrap_i64
        i64.load16_u 2 align=1
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=17
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 1440
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 17
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1524
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1608
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=17
        i64.const 100
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=17
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 1692
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 17
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1776
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1860
          i32.const 84
          i32.const 5
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=17
        local.get 38
        global.set 2
      end
      local.get 9
      i32.wrap_i64
      call 0
      local.set 46
      local.get 46
      i32.const 1944
      i32.const 4
      call 4
      local.get 46
      call 5
      i64.const 21862
      local.set 47
      local.get 47
      i64.store16 1 offset=26 align=1
      local.get 9
      i32.wrap_i64
      i64.const 92
      i64.store8 1 offset=28
      i32.const 0
      call $choice.1
      if ;; label = @2
        i32.const 2
        local.set 48
        i32.const 6
        call $goose.reserve_memory.2
        local.set 49
        local.get 48
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 49
        i64.extend_i32_u
        i64.or
        local.set 50
        local.get 50
        local.set 5
        local.get 50
        i64.const 1
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store32 2 align=1
        i64.const 99
        local.set 51
        local.get 49
        i32.const 4
        i32.add
        local.get 51
        i64.store16 2 align=1
        local.get 9
        i64.const 0
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=29
        local.get 5
        local.set 52
        local.get 52
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 53
        i64.const 0
        local.set 54
        local.get 52
        local.set 55
        local.get 55
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 54
        i64.const 2
        i64.mul
        i64.add
        local.tee 56
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1948
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 55
        i64.const -4294967296
        i64.and
        local.get 56
        i64.or
        i32.wrap_i64
        i64.load16_u 2 align=1
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=29
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 2032
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 29
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2116
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2200
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=29
        i64.const 100
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=29
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 2284
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 29
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2368
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2452
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=29
        local.get 49
        global.set 2
      else
        i32.const 2
        local.set 57
        i32.const 6
        call $goose.reserve_memory.2
        local.set 58
        local.get 57
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 58
        i64.extend_i32_u
        i64.or
        local.set 59
        local.get 59
        local.set 6
        local.get 59
        i64.const 1
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store32 2 align=1
        i64.const 11
        local.set 60
        local.get 58
        i32.const 4
        i32.add
        local.get 60
        i64.store16 2 align=1
        local.get 9
        i64.const 0
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=29
        local.get 6
        local.set 61
        local.get 61
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 62
        i64.const 0
        local.set 63
        local.get 61
        local.set 64
        local.get 64
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 63
        i64.const 2
        i64.mul
        i64.add
        local.tee 65
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2536
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 64
        i64.const -4294967296
        i64.and
        local.get 65
        i64.or
        i32.wrap_i64
        i64.load16_u 2 align=1
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=29
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 2620
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 29
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2704
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2788
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=29
        i64.const 12
        local.set 15
        local.get 9
        i32.wrap_i64
        i64.load8_u 1 offset=29
        local.set 16
        local.get 16
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 2872
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const 4294967295
        i64.and
        i64.const 29
        i64.add
        local.tee 25
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2956
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 9
        i64.const -4294967296
        i64.and
        local.get 25
        i64.or
        local.set 18
        local.get 18
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 16
        i64.const 2
        i64.mul
        i64.add
        local.tee 19
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3040
          i32.const 84
          i32.const 6
          call 6
          unreachable
        end
        local.get 18
        i64.const -4294967296
        i64.and
        local.get 19
        i64.or
        local.set 17
        local.get 17
        i32.wrap_i64
        local.get 15
        i64.store16 1 align=1
        local.get 9
        local.get 16
        i64.const 1
        i64.add
        local.set 10
        i32.wrap_i64
        local.get 10
        i64.store8 1 offset=29
        local.get 58
        global.set 2
      end
      local.get 9
      i32.wrap_i64
      call 0
      local.set 66
      local.get 66
      i32.const 3124
      i32.const 4
      call 4
      local.get 66
      call 5
      i64.const 30600
      local.set 67
      local.get 67
      i64.store16 1 offset=38 align=1
      local.get 1
      local.set 68
      local.get 68
      i32.wrap_i64
      i64.load32_u 1 align=1
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3128
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 1
      local.set 69
      local.get 69
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 70
      i64.const 0
      local.set 71
      local.get 69
      local.set 72
      local.get 72
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 71
      i64.const 12
      i64.mul
      i64.add
      local.tee 73
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3212
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 72
      i64.const -4294967296
      i64.and
      local.get 73
      i64.or
      local.set 74
      local.get 74
      i32.wrap_i64
      i64.load8_u 1
      i64.const 90
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3296
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 1
      local.set 75
      local.get 75
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 76
      i64.const 0
      local.set 77
      local.get 75
      local.set 78
      local.get 78
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 77
      i64.const 12
      i64.mul
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3380
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 78
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3464
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 81
      local.get 81
      i32.wrap_i64
      i64.load8_u 1
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3548
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 1
      local.set 82
      local.get 82
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 83
      i64.const 0
      local.set 84
      local.get 82
      local.set 85
      local.get 85
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 84
      i64.const 12
      i64.mul
      i64.add
      local.tee 86
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3632
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 85
      i64.const -4294967296
      i64.and
      local.get 86
      i64.or
      local.set 87
      local.get 87
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3716
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 87
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 88
      local.get 88
      i32.wrap_i64
      i64.load8_u 1
      local.set 89
      i64.const 0
      local.set 90
      local.get 90
      local.get 89
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3800
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 88
      local.set 91
      local.get 91
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 90
      i64.const 2
      i64.mul
      i64.add
      local.tee 92
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3884
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 91
      i64.const -4294967296
      i64.and
      local.get 92
      i64.or
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 4660
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3968
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 1
      local.set 93
      local.get 93
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 94
      i64.const 0
      local.set 95
      local.get 93
      local.set 96
      local.get 96
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 95
      i64.const 12
      i64.mul
      i64.add
      local.tee 97
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4052
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 96
      i64.const -4294967296
      i64.and
      local.get 97
      i64.or
      local.set 98
      local.get 98
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4136
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 98
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 99
      local.get 99
      i32.wrap_i64
      i64.load8_u 1
      local.set 100
      i64.const 1
      local.set 101
      local.get 101
      local.get 100
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4220
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 99
      local.set 102
      local.get 102
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 101
      i64.const 2
      i64.mul
      i64.add
      local.tee 103
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4304
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 102
      i64.const -4294967296
      i64.and
      local.get 103
      i64.or
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 22136
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4388
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 1
      local.set 104
      local.get 104
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 105
      i64.const 0
      local.set 106
      local.get 104
      local.set 107
      local.get 107
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 106
      i64.const 12
      i64.mul
      i64.add
      local.tee 108
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4472
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 107
      i64.const -4294967296
      i64.and
      local.get 108
      i64.or
      local.set 109
      local.get 109
      i32.wrap_i64
      i64.load16_u 1 offset=10 align=1
      i64.const 13124
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4556
        i32.const 84
        i32.const 7
        call 6
        unreachable
      end
      local.get 1
      local.set 110
      local.get 110
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 111
      i64.const 1
      local.set 112
      local.get 110
      local.set 113
      local.get 113
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 112
      i64.const 12
      i64.mul
      i64.add
      local.tee 114
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4640
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 113
      i64.const -4294967296
      i64.and
      local.get 114
      i64.or
      local.set 115
      local.get 115
      i32.wrap_i64
      i64.load8_u 1
      i64.const 91
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4724
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 1
      local.set 116
      local.get 116
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 117
      i64.const 1
      local.set 118
      local.get 116
      local.set 119
      local.get 119
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 118
      i64.const 12
      i64.mul
      i64.add
      local.tee 120
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4808
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 119
      i64.const -4294967296
      i64.and
      local.get 120
      i64.or
      local.set 121
      local.get 121
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4892
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 121
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 122
      local.get 122
      i32.wrap_i64
      i64.load8_u 1
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4976
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 1
      local.set 123
      local.get 123
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 124
      i64.const 1
      local.set 125
      local.get 123
      local.set 126
      local.get 126
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 125
      i64.const 12
      i64.mul
      i64.add
      local.tee 127
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5060
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 126
      i64.const -4294967296
      i64.and
      local.get 127
      i64.or
      local.set 128
      local.get 128
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5144
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 128
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 129
      local.get 129
      i32.wrap_i64
      i64.load8_u 1
      local.set 130
      i64.const 0
      local.set 131
      local.get 131
      local.get 130
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 5228
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 129
      local.set 132
      local.get 132
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 131
      i64.const 2
      i64.mul
      i64.add
      local.tee 133
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5312
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 132
      i64.const -4294967296
      i64.and
      local.get 133
      i64.or
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5396
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 1
      local.set 134
      local.get 134
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 135
      i64.const 1
      local.set 136
      local.get 134
      local.set 137
      local.get 137
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 136
      i64.const 12
      i64.mul
      i64.add
      local.tee 138
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5480
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 137
      i64.const -4294967296
      i64.and
      local.get 138
      i64.or
      local.set 139
      local.get 139
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5564
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 139
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 140
      local.get 140
      i32.wrap_i64
      i64.load8_u 1
      local.set 141
      i64.const 1
      local.set 142
      local.get 142
      local.get 141
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 5648
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 140
      local.set 143
      local.get 143
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 142
      i64.const 2
      i64.mul
      i64.add
      local.tee 144
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5732
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 143
      i64.const -4294967296
      i64.and
      local.get 144
      i64.or
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5816
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 1
      local.set 145
      local.get 145
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 146
      i64.const 1
      local.set 147
      local.get 145
      local.set 148
      local.get 148
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 147
      i64.const 12
      i64.mul
      i64.add
      local.tee 149
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5900
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 148
      i64.const -4294967296
      i64.and
      local.get 149
      i64.or
      local.set 150
      local.get 150
      i32.wrap_i64
      i64.load16_u 1 offset=10 align=1
      i64.const 21862
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5984
        i32.const 84
        i32.const 8
        call 6
        unreachable
      end
      local.get 1
      local.set 151
      local.get 151
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 152
      i64.const 2
      local.set 153
      local.get 151
      local.set 154
      local.get 154
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 153
      i64.const 12
      i64.mul
      i64.add
      local.tee 155
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6068
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 154
      i64.const -4294967296
      i64.and
      local.get 155
      i64.or
      local.set 156
      local.get 156
      i32.wrap_i64
      i64.load8_u 1
      i64.const 92
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6152
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 1
      local.set 157
      local.get 157
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 158
      i64.const 2
      local.set 159
      local.get 157
      local.set 160
      local.get 160
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 159
      i64.const 12
      i64.mul
      i64.add
      local.tee 161
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6236
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 160
      i64.const -4294967296
      i64.and
      local.get 161
      i64.or
      local.set 162
      local.get 162
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6320
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 162
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 163
      local.get 163
      i32.wrap_i64
      i64.load8_u 1
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6404
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 1
      local.set 164
      local.get 164
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 165
      i64.const 2
      local.set 166
      local.get 164
      local.set 167
      local.get 167
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 166
      i64.const 12
      i64.mul
      i64.add
      local.tee 168
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6488
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 167
      i64.const -4294967296
      i64.and
      local.get 168
      i64.or
      local.set 169
      local.get 169
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6572
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 169
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 170
      local.get 170
      i32.wrap_i64
      i64.load8_u 1
      local.set 171
      i64.const 0
      local.set 172
      local.get 172
      local.get 171
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 6656
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 170
      local.set 173
      local.get 173
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 172
      i64.const 2
      i64.mul
      i64.add
      local.tee 174
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6740
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 173
      i64.const -4294967296
      i64.and
      local.get 174
      i64.or
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 11
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6824
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 1
      local.set 175
      local.get 175
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 176
      i64.const 2
      local.set 177
      local.get 175
      local.set 178
      local.get 178
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 177
      i64.const 12
      i64.mul
      i64.add
      local.tee 179
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6908
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 178
      i64.const -4294967296
      i64.and
      local.get 179
      i64.or
      local.set 180
      local.get 180
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6992
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 180
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      local.set 181
      local.get 181
      i32.wrap_i64
      i64.load8_u 1
      local.set 182
      i64.const 1
      local.set 183
      local.get 183
      local.get 182
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 7076
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 181
      local.set 184
      local.get 184
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 183
      i64.const 2
      i64.mul
      i64.add
      local.tee 185
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7160
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 184
      i64.const -4294967296
      i64.and
      local.get 185
      i64.or
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 12
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7244
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 1
      local.set 186
      local.get 186
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 187
      i64.const 2
      local.set 188
      local.get 186
      local.set 189
      local.get 189
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 188
      i64.const 12
      i64.mul
      i64.add
      local.tee 190
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7328
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      local.get 189
      i64.const -4294967296
      i64.and
      local.get 190
      i64.or
      local.set 191
      local.get 191
      i32.wrap_i64
      i64.load16_u 1 offset=10 align=1
      i64.const 30600
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7412
        i32.const 84
        i32.const 9
        call 6
        unreachable
      end
      call 0
      local.set 192
      local.get 192
      i32.const 7496
      i32.const 12
      call 4
      local.get 192
      call 5
      local.get 8
      global.set 1
    end
  )
  (func $choice.1 (;12;) (type 9) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.gooserow0/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.gooserow1/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.gooserow2/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_result_data_control.goosedata_control")
)
