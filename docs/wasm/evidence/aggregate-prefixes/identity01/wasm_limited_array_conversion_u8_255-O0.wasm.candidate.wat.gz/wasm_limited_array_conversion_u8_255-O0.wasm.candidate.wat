(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (global (;0;) (mut i32) i32.const 736)
  (global (;1;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 90
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 98
        i32.const 90
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 258
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      i64.const 0
      i64.store16 align=1
      local.get 3
      i32.const 2
      i32.add
      i32.const 0
      i32.const 256
      memory.fill
      i64.const 0
      local.set 4
      i64.const 255
      local.set 5
      block ;; label = @2
        loop ;; label = @3
          local.get 4
          local.get 5
          i64.ge_s
          br_if 1 (;@2;)
          local.get 4
          local.set 1
          block ;; label = @4
            local.get 0
            i32.const 0
            i32.add
            i64.extend_i32_u
            local.set 6
            local.get 1
            i64.const 255
            i64.and
            local.set 7
            local.get 6
            i32.wrap_i64
            i64.load16_u align=1
            local.set 8
            local.get 8
            i64.const 256
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 188
              i32.const 90
              i32.const 1
              call 6
              unreachable
            end
            local.get 6
            local.set 10
            local.get 10
            i64.const 4294967295
            i64.and
            i64.const 2
            i64.add
            local.get 8
            i64.const 1
            i64.mul
            i64.add
            local.tee 11
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 278
              i32.const 90
              i32.const 1
              call 6
              unreachable
            end
            local.get 10
            i64.const -4294967296
            i64.and
            local.get 11
            i64.or
            local.tee 12
            local.get 7
            local.set 13
            i32.wrap_i64
            local.get 13
            i64.store8
            local.get 6
            local.get 8
            i64.const 1
            i64.add
            local.set 14
            i32.wrap_i64
            local.get 14
            i64.store16 align=1
            local.get 12
            i32.wrap_i64
            i64.load8_u
            drop
          end
          local.get 4
          i64.const 1
          i64.add
          local.set 4
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 15
      local.get 15
      i64.load16_u align=1
      local.set 16
      i32.const 1
      local.set 17
      local.get 16
      i64.const 255
      i64.gt_u
      if ;; label = @2
        i32.const 15
        i32.const 368
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 16
      i64.const 1
      i64.mul
      i32.wrap_i64
      local.set 18
      local.get 18
      i64.extend_i32_u
      local.get 17
      i64.extend_i32_u
      i64.add
      local.tee 19
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 458
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 19
      i32.wrap_i64
      local.set 20
      i32.const 1
      local.set 21
      local.get 20
      call $goose.reserve_memory.1
      local.set 22
      local.get 21
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 22
      i64.extend_i32_u
      i64.or
      local.set 23
      local.get 23
      local.set 2
      local.get 23
      local.get 16
      local.set 14
      i32.wrap_i64
      local.get 14
      i64.store8 1
      local.get 23
      local.get 17
      i64.extend_i32_u
      i64.add
      local.set 23
      local.get 23
      i32.wrap_i64
      local.get 15
      i32.const 2
      i32.add
      local.get 18
      memory.copy 1 0
      local.get 2
      local.set 24
      local.get 24
      i32.wrap_i64
      i64.load8_u 1
      i64.const 255
      i64.eq
      if (result i32) ;; label = @2
        local.get 2
        local.set 25
        local.get 25
        i32.wrap_i64
        i64.load8_u 1
        local.set 26
        i64.const 254
        local.set 27
        local.get 25
        local.set 28
        local.get 28
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 27
        i64.const 1
        i64.mul
        i64.add
        local.tee 29
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 548
          i32.const 90
          i32.const 1
          call 6
          unreachable
        end
        local.get 28
        i64.const -4294967296
        i64.and
        local.get 29
        i64.or
        i32.wrap_i64
        i64.load8_u 1
        i64.const 254
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 638
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      call 0
      local.set 30
      local.get 30
      i32.const 728
      i32.const 6
      call 4
      local.get 30
      call 5
      local.get 22
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_conversion_u8_255.gooseu8_255")
)
