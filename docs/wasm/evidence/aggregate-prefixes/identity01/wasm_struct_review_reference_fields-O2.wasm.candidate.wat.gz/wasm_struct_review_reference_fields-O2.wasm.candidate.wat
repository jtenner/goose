(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 5184)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 90
      i32.const 89
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 179
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32)
    i32.const 48
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      i32.const 42
      local.set 4
      local.get 3
      i64.extend_i32_u
      local.set 5
      local.get 4
      i64.extend_i32_u
      local.set 6
      i32.const 48
      local.set 7
      local.get 5
      i32.wrap_i64
      local.get 6
      i32.wrap_i64
      local.get 7
      memory.copy
      local.get 0
      i32.const 0
      i32.add
      local.set 8
      local.get 8
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 9
      i64.const 2
      local.set 10
      i64.const 0
      local.set 11
      local.get 9
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      local.get 11
      i64.const 8
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 268
        i32.const 89
        i32.const 8
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      local.set 14
      local.get 14
      i32.wrap_i64
      i64.load align=1
      local.tee 15
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 357
        i32.const 89
        i32.const 8
        call 6
        unreachable
      end
      local.get 15
      call $goose.memory_op.41
      local.tee 16
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 446
        i32.const 89
        i32.const 8
        call 6
        unreachable
      end
      local.get 16
      local.get 16
      call $goose.memory_op.41
      i64.const 1
      i64.add
      call $goose.memory_op.55
      i32.const 8
      i64.load align=1
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 18
      i64.const 0
      local.set 19
      local.get 19
      local.get 18
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 535
        i32.const 89
        i32.const 9
        call 6
        unreachable
      end
      local.get 17
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 19
      i64.const 8
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 624
        i32.const 89
        i32.const 9
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 11
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 713
        i32.const 89
        i32.const 9
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 22
      local.get 22
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 23
      i64.const 2
      local.set 24
      i64.const 0
      local.set 25
      local.get 23
      local.set 26
      local.get 26
      i64.const 4294967295
      i64.and
      local.get 25
      i64.const 8
      i64.mul
      i64.add
      local.tee 27
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 802
        i32.const 89
        i32.const 9
        call 6
        unreachable
      end
      local.get 26
      i64.const -4294967296
      i64.and
      local.get 27
      i64.or
      local.set 28
      i32.const 33
      i64.extend_i32_u
      local.set 29
      local.get 28
      local.get 29
      local.set 30
      i32.wrap_i64
      local.get 30
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 31
      local.get 31
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 32
      i64.const 2
      local.set 33
      i64.const 0
      local.set 34
      local.get 32
      local.set 35
      local.get 35
      i64.const 4294967295
      i64.and
      local.get 34
      i64.const 8
      i64.mul
      i64.add
      local.tee 36
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 891
        i32.const 89
        i32.const 10
        call 6
        unreachable
      end
      local.get 35
      i64.const -4294967296
      i64.and
      local.get 36
      i64.or
      i32.wrap_i64
      i64.load align=1
      i32.const 33
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 980
        i32.const 89
        i32.const 10
        call 6
        unreachable
      end
      i32.const 42
      local.set 37
      local.get 37
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 38
      i64.const 2
      local.set 39
      i64.const 0
      local.set 40
      local.get 38
      local.set 41
      local.get 41
      i64.const 4294967295
      i64.and
      local.get 40
      i64.const 8
      i64.mul
      i64.add
      local.tee 42
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1069
        i32.const 89
        i32.const 10
        call 6
        unreachable
      end
      local.get 41
      i64.const -4294967296
      i64.and
      local.get 42
      i64.or
      i32.wrap_i64
      i64.load align=1
      i32.const 24
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1158
        i32.const 89
        i32.const 10
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 43
      local.get 43
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 44
      i64.const 2
      local.set 45
      i64.const 0
      local.set 46
      local.get 44
      local.set 47
      local.get 47
      i64.const 4294967295
      i64.and
      local.get 46
      i64.const 8
      i64.mul
      i64.add
      local.tee 48
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1247
        i32.const 89
        i32.const 11
        call 6
        unreachable
      end
      local.get 47
      i64.const -4294967296
      i64.and
      local.get 48
      i64.or
      local.set 49
      local.get 49
      i32.wrap_i64
      i64.load align=1
      local.tee 50
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1336
        i32.const 89
        i32.const 11
        call 6
        unreachable
      end
      local.get 50
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 51
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1425
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
      local.get 50
      i64.const -4294967296
      i64.and
      local.get 51
      i64.or
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1514
        i32.const 89
        i32.const 11
        call 6
        unreachable
      end
      i32.const 42
      local.set 52
      local.get 52
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 53
      i64.const 2
      local.set 54
      i64.const 0
      local.set 55
      local.get 53
      local.set 56
      local.get 56
      i64.const 4294967295
      i64.and
      local.get 55
      i64.const 8
      i64.mul
      i64.add
      local.tee 57
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1603
        i32.const 89
        i32.const 11
        call 6
        unreachable
      end
      local.get 56
      i64.const -4294967296
      i64.and
      local.get 57
      i64.or
      local.set 58
      local.get 58
      i32.wrap_i64
      i64.load align=1
      local.tee 59
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1692
        i32.const 89
        i32.const 11
        call 6
        unreachable
      end
      local.get 59
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.tee 51
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1781
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
      local.get 59
      i64.const -4294967296
      i64.and
      local.get 51
      i64.or
      call $goose.memory_op.49
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1870
        i32.const 89
        i32.const 11
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 60
      local.get 60
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 61
      i32.const 24
      i64.extend_i32_u
      local.set 62
      local.get 61
      i32.wrap_i64
      i64.load8_u
      local.set 63
      local.get 63
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1959
        i32.const 89
        i32.const 12
        call 6
        unreachable
      end
      local.get 61
      local.set 65
      local.get 65
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 63
      i64.const 8
      i64.mul
      i64.add
      local.tee 66
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2048
        i32.const 89
        i32.const 12
        call 6
        unreachable
      end
      local.get 65
      i64.const -4294967296
      i64.and
      local.get 66
      i64.or
      local.tee 67
      local.get 62
      local.set 68
      i32.wrap_i64
      local.get 68
      i64.store align=1
      local.get 61
      local.get 63
      i64.const 1
      i64.add
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 67
      i32.wrap_i64
      i64.load align=1
      local.set 1
      local.get 1
      i32.const 24
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2137
        i32.const 89
        i32.const 12
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 70
      local.get 70
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 71
      local.get 71
      i32.wrap_i64
      i64.load8_u
      local.set 72
      local.get 72
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 2226
        i32.const 89
        i32.const 13
        call 6
        unreachable
      end
      local.get 72
      i64.const 1
      i64.sub
      local.set 72
      local.get 71
      local.set 73
      local.get 73
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 72
      i64.const 8
      i64.mul
      i64.add
      local.tee 74
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2315
        i32.const 89
        i32.const 13
        call 6
        unreachable
      end
      local.get 73
      i64.const -4294967296
      i64.and
      local.get 74
      i64.or
      local.set 75
      local.get 75
      i32.wrap_i64
      i64.load align=1
      local.set 76
      local.get 71
      local.get 72
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 76
      local.set 2
      local.get 2
      i32.const 24
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2404
        i32.const 89
        i32.const 13
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 77
      local.get 77
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 78
      local.get 78
      i32.wrap_i64
      i64.load8_u
      local.set 79
      i64.const 0
      local.set 79
      local.get 78
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 79
      i64.const 8
      i64.mul
      i64.add
      local.tee 81
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2493
        i32.const 89
        i32.const 14
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 81
      i64.or
      local.set 82
      local.get 78
      local.get 79
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      local.set 83
      local.get 83
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 84
      i32.const 33
      i64.extend_i32_u
      local.set 85
      local.get 84
      i32.wrap_i64
      i64.load8_u
      local.set 86
      local.get 86
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2582
        i32.const 89
        i32.const 14
        call 6
        unreachable
      end
      local.get 84
      local.set 88
      local.get 88
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 86
      i64.const 8
      i64.mul
      i64.add
      local.tee 89
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2671
        i32.const 89
        i32.const 14
        call 6
        unreachable
      end
      local.get 88
      i64.const -4294967296
      i64.and
      local.get 89
      i64.or
      local.tee 90
      local.get 85
      local.set 91
      i32.wrap_i64
      local.get 91
      i64.store align=1
      local.get 84
      local.get 86
      i64.const 1
      i64.add
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 90
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 0
      i32.add
      local.set 92
      local.get 92
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 93
      local.get 93
      i32.wrap_i64
      i64.load8_u
      local.set 94
      local.get 94
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 2760
        i32.const 89
        i32.const 14
        call 6
        unreachable
      end
      local.get 94
      i64.const 1
      i64.sub
      local.set 94
      local.get 93
      local.set 95
      local.get 95
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 94
      i64.const 8
      i64.mul
      i64.add
      local.tee 96
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2849
        i32.const 89
        i32.const 14
        call 6
        unreachable
      end
      local.get 95
      i64.const -4294967296
      i64.and
      local.get 96
      i64.or
      local.set 97
      local.get 97
      i32.wrap_i64
      i64.load align=1
      local.set 98
      local.get 93
      local.get 94
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 98
      drop
      local.get 0
      i32.const 0
      i32.add
      local.set 99
      local.get 99
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 100
      i32.const 24
      i64.extend_i32_u
      local.set 101
      local.get 100
      i32.wrap_i64
      i64.load8_u
      local.set 102
      local.get 102
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2938
        i32.const 89
        i32.const 15
        call 6
        unreachable
      end
      local.get 100
      local.set 104
      local.get 104
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 102
      i64.const 8
      i64.mul
      i64.add
      local.tee 105
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3027
        i32.const 89
        i32.const 15
        call 6
        unreachable
      end
      local.get 104
      i64.const -4294967296
      i64.and
      local.get 105
      i64.or
      local.tee 106
      local.get 101
      local.set 107
      i32.wrap_i64
      local.get 107
      i64.store align=1
      local.get 100
      local.get 102
      i64.const 1
      i64.add
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 106
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 0
      i32.add
      local.set 108
      local.get 108
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 109
      local.get 109
      i32.wrap_i64
      i64.load8_u
      local.set 110
      i64.const 0
      local.set 111
      local.get 109
      local.set 112
      local.get 112
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 111
      i64.const 8
      i64.mul
      i64.add
      local.tee 113
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3116
        i32.const 89
        i32.const 15
        call 6
        unreachable
      end
      local.get 112
      i64.const -4294967296
      i64.and
      local.get 113
      i64.or
      local.set 114
      local.get 114
      i32.wrap_i64
      i64.load align=1
      local.tee 115
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3205
        i32.const 89
        i32.const 15
        call 6
        unreachable
      end
      local.get 115
      call $goose.memory_op.41
      local.tee 116
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3294
        i32.const 89
        i32.const 15
        call 6
        unreachable
      end
      local.get 116
      local.get 116
      call $goose.memory_op.41
      i64.const 2
      i64.add
      call $goose.memory_op.55
      i32.const 8
      i64.load align=1
      local.set 117
      local.get 117
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 118
      i64.const 0
      local.set 119
      local.get 117
      local.set 120
      local.get 120
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 119
      i64.const 8
      i64.mul
      i64.add
      local.tee 121
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3383
        i32.const 89
        i32.const 16
        call 6
        unreachable
      end
      local.get 120
      i64.const -4294967296
      i64.and
      local.get 121
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 13
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3472
        i32.const 89
        i32.const 16
        call 6
        unreachable
      end
      i32.const 16
      i64.load align=1
      local.set 122
      local.get 122
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 123
      i64.const 0
      local.set 124
      local.get 124
      local.get 123
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3561
        i32.const 89
        i32.const 16
        call 6
        unreachable
      end
      local.get 122
      local.set 125
      local.get 125
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 124
      i64.const 8
      i64.mul
      i64.add
      local.tee 126
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3650
        i32.const 89
        i32.const 16
        call 6
        unreachable
      end
      local.get 125
      i64.const -4294967296
      i64.and
      local.get 126
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      i64.const 20
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3739
        i32.const 89
        i32.const 16
        call 6
        unreachable
      end
      i32.const 42
      local.set 127
      local.get 127
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 128
      local.get 128
      i32.wrap_i64
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3828
        i32.const 89
        i32.const 16
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 129
      local.get 129
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3917
        i32.const 89
        i32.const 17
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 130
      local.get 130
      i64.load16_u offset=1 align=1
      i64.const 60000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4006
        i32.const 89
        i32.const 17
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 131
      local.get 131
      i64.load16_u offset=44 align=1
      i64.const 65000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4095
        i32.const 89
        i32.const 17
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 132
      local.get 132
      i64.load16_u offset=46 align=1
      i64.const 50000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4184
        i32.const 89
        i32.const 17
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      local.set 133
      local.get 133
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 134
      i64.const 0
      local.set 135
      local.get 133
      local.set 136
      local.get 136
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 135
      i64.const 8
      i64.mul
      i64.add
      local.tee 137
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4273
        i32.const 89
        i32.const 18
        call 6
        unreachable
      end
      local.get 136
      i64.const -4294967296
      i64.and
      local.get 137
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 138
      i32.const 16
      i64.load align=1
      local.set 139
      local.get 139
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 140
      i64.const 0
      local.set 141
      local.get 139
      local.set 142
      local.get 142
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 141
      i64.const 8
      i64.mul
      i64.add
      local.tee 143
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4362
        i32.const 89
        i32.const 18
        call 6
        unreachable
      end
      local.get 142
      i64.const -4294967296
      i64.and
      local.get 143
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 144
      i32.const 42
      local.set 145
      local.get 145
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 146
      local.get 146
      i32.wrap_i64
      i64.load8_u
      local.set 147
      local.get 0
      i32.const 0
      i32.add
      local.set 148
      local.get 148
      i32.const 19
      i32.add
      i64.extend_i32_u
      local.set 149
      local.get 149
      i32.wrap_i64
      i64.load8_u
      local.set 150
      call 0
      local.set 151
      local.get 151
      i32.const 4451
      i32.const 11
      call 4
      local.get 151
      local.get 138
      i32.const 0
      call 1
      local.get 151
      i32.const 4462
      i32.const 1
      call 4
      local.get 151
      local.get 144
      i32.const 0
      call 1
      local.get 151
      i32.const 4463
      i32.const 1
      call 4
      local.get 151
      local.get 147
      i32.const 0
      call 1
      local.get 151
      i32.const 4464
      i32.const 1
      call 4
      local.get 151
      local.get 150
      i32.const 0
      call 1
      local.get 151
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64)
    i32.const 1
    local.set 1
    i32.const 12
    call $goose.reserve_memory.1
    local.set 2
    local.get 1
    i64.extend_i32_u
    i64.const 32
    i64.shl
    local.get 2
    i64.extend_i32_u
    i64.or
    local.set 3
    local.get 3
    local.set 4
    i32.const 8
    local.get 4
    i64.store align=1
    local.get 3
    i64.const 1
    local.set 5
    i32.wrap_i64
    local.get 5
    i64.store32 1 align=1
    i64.const 10
    local.set 6
    local.get 2
    i32.const 4
    i32.add
    local.get 6
    i64.store 1 align=1
    i32.const 2
    local.set 7
    i32.const 12
    call $goose.reserve_memory.2
    local.set 8
    local.get 7
    i64.extend_i32_u
    i64.const 32
    i64.shl
    local.get 8
    i64.extend_i32_u
    i64.or
    local.set 9
    local.get 9
    local.set 10
    i32.const 16
    local.get 10
    i64.store align=1
    local.get 9
    i64.const 1
    local.set 5
    i32.wrap_i64
    local.get 5
    i64.store32 2 align=1
    i64.const 20
    local.set 11
    local.get 8
    i32.const 4
    i32.add
    local.get 11
    i64.store 2 align=1
    i32.const 24
    local.set 12
    local.get 12
    i32.const 8
    i64.load align=1
    local.set 13
    local.get 13
    i32.wrap_i64
    i64.load32_u 1 align=1
    local.set 14
    i64.const 0
    local.set 15
    local.get 15
    local.get 14
    i64.ge_u
    if ;; label = @1
      i32.const 8
      i32.const 4465
      i32.const 89
      i32.const 5
      call 6
      unreachable
    end
    local.get 13
    local.set 16
    local.get 16
    i64.const 4294967295
    i64.and
    i64.const 4
    i64.add
    local.get 15
    i64.const 8
    i64.mul
    i64.add
    local.tee 17
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 11
      i32.const 4554
      i32.const 89
      i32.const 5
      call 6
      unreachable
    end
    local.get 16
    i64.const -4294967296
    i64.and
    local.get 17
    i64.or
    i64.store align=1
    local.get 12
    i64.const 1
    i64.store8 offset=8
    i32.const 33
    local.set 18
    local.get 18
    i32.const 16
    i64.load align=1
    local.set 19
    local.get 19
    i32.wrap_i64
    i64.load32_u 2 align=1
    local.set 20
    i64.const 0
    local.set 21
    local.get 21
    local.get 20
    i64.ge_u
    if ;; label = @1
      i32.const 8
      i32.const 4643
      i32.const 89
      i32.const 5
      call 6
      unreachable
    end
    local.get 19
    local.set 22
    local.get 22
    i64.const 4294967295
    i64.and
    i64.const 4
    i64.add
    local.get 21
    i64.const 8
    i64.mul
    i64.add
    local.tee 23
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 11
      i32.const 4732
      i32.const 89
      i32.const 5
      call 6
      unreachable
    end
    local.get 22
    i64.const -4294967296
    i64.and
    local.get 23
    i64.or
    i64.store align=1
    local.get 18
    i64.const 2
    i64.store8 offset=8
    i32.const 42
    local.set 24
    local.get 24
    i64.const 7
    i64.store8
    local.get 24
    i64.const 60000
    i64.store16 offset=1 align=1
    local.get 24
    i32.const 3
    i32.add
    i32.const 0
    i32.add
    i32.const 24
    i64.extend_i32_u
    i64.store align=1
    local.get 24
    i32.const 3
    i32.add
    i32.const 8
    i32.add
    i32.const 33
    i64.extend_i32_u
    i64.store align=1
    local.get 24
    i64.const 0
    i64.store8 offset=19
    i32.const 24
    i64.extend_i32_u
    local.set 25
    local.get 24
    i64.load8_u offset=19
    local.set 26
    local.get 26
    i64.const 3
    i64.ge_u
    if ;; label = @1
      i32.const 10
      i32.const 4821
      i32.const 89
      i32.const 6
      call 6
      unreachable
    end
    local.get 24
    i32.const 19
    i32.add
    i32.const 1
    i32.add
    i64.extend_i32_u
    local.set 28
    local.get 28
    i64.const 4294967295
    i64.and
    local.get 26
    i64.const 8
    i64.mul
    i64.add
    local.tee 29
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 11
      i32.const 4910
      i32.const 89
      i32.const 6
      call 6
      unreachable
    end
    local.get 28
    i64.const -4294967296
    i64.and
    local.get 29
    i64.or
    local.set 27
    local.get 27
    i32.wrap_i64
    local.get 25
    i64.store align=1
    local.get 24
    local.get 26
    i64.const 1
    i64.add
    i64.store8 offset=19
    i32.const 33
    i64.extend_i32_u
    local.set 25
    local.get 24
    i64.load8_u offset=19
    local.set 26
    local.get 26
    i64.const 3
    i64.ge_u
    if ;; label = @1
      i32.const 10
      i32.const 4999
      i32.const 89
      i32.const 6
      call 6
      unreachable
    end
    local.get 24
    i32.const 19
    i32.add
    i32.const 1
    i32.add
    i64.extend_i32_u
    local.set 28
    local.get 28
    i64.const 4294967295
    i64.and
    local.get 26
    i64.const 8
    i64.mul
    i64.add
    local.tee 29
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 11
      i32.const 5088
      i32.const 89
      i32.const 6
      call 6
      unreachable
    end
    local.get 28
    i64.const -4294967296
    i64.and
    local.get 29
    i64.or
    local.set 27
    local.get 27
    i32.wrap_i64
    local.get 25
    i64.store align=1
    local.get 24
    local.get 26
    i64.const 1
    i64.add
    i64.store8 offset=19
    local.get 24
    i32.const 36
    i32.add
    i32.const 0
    i32.const 8
    memory.fill
    local.get 24
    i64.const 65000
    i64.store16 offset=44 align=1
    local.get 24
    i64.const 50000
    i64.store16 offset=46 align=1
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.memory_op.41 (;14;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;15;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;16;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.1 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 90) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goosereferences=,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_struct_review_reference_fields.goose")
)
