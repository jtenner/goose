(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32 i32) (result i64)))
  (type (;12;) (func (param i32 i32) (result i32)))
  (type (;13;) (func (param i64 i64)))
  (type (;14;) (func (param i64) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (global (;0;) (mut i32) i32.const 3168)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 81
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 89
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32)
    i32.const 16
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      i32.const 0
      call $leave.1
      local.set 1
      call 0
      local.set 2
      local.get 2
      i32.const 170
      i32.const 6
      call 4
      local.get 2
      local.get 1
      i32.const 0
      call 1
      local.get 2
      call 5
      i32.const 1
      local.set 3
      global.get 1
      local.set 4
      local.get 0
      i32.const 0
      i32.add
      local.set 5
      local.get 5
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 5
      i64.const 0
      i64.store offset=8 align=1
      i64.const 90
      local.set 6
      local.get 5
      i64.load offset=8 align=1
      local.set 7
      i32.const 8
      call $goose.reserve_memory.1
      local.set 8
      local.get 5
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 8
      i64.extend_i32_u
      i64.or
      local.tee 9
      local.get 6
      local.set 10
      i32.wrap_i64
      local.get 10
      i64.store 1 align=1
      local.get 5
      local.get 7
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i32.const 0
      i32.const 1
      call $leave.1
      local.set 11
      call 0
      local.set 12
      local.get 12
      i32.const 176
      i32.const 7
      call 4
      local.get 12
      local.get 11
      i32.const 0
      call 1
      local.get 12
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 13
      local.get 13
      i64.load offset=8 align=1
      local.set 14
      i64.const 0
      local.set 15
      local.get 13
      i64.load align=1
      local.set 16
      local.get 16
      i64.const 4294967295
      i64.and
      local.get 15
      i64.const 8
      i64.mul
      i64.add
      local.tee 17
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 183
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 16
      i64.const -4294967296
      i64.and
      local.get 17
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 18
      call 0
      local.set 19
      local.get 19
      i32.const 264
      i32.const 5
      call 4
      local.get 19
      local.get 18
      i32.const 0
      call 1
      local.get 19
      call 5
      local.get 4
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $leave.1 (;12;) (type 11) (param i32 i32) (result i64)
    (local i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 67
    call $goose.reserve_frame
    local.set 2
    block ;; label = @1
      local.get 1
      i32.const 1
      i32.add
      local.set 5
      local.get 5
      call $goose.data_top
      local.set 6
      local.get 2
      i32.const 0
      i32.add
      local.set 7
      local.get 7
      local.get 5
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 6
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 7
      i64.const 0
      i64.store offset=8 align=1
      i64.const 10
      local.set 8
      local.get 7
      i64.load offset=8 align=1
      local.set 9
      local.get 7
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 10
      local.get 7
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 10
      i64.extend_i32_u
      i64.or
      local.tee 11
      local.get 8
      call $goose.memory_op.55
      local.get 7
      local.get 9
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 2
      i32.const 16
      i32.add
      local.set 12
      local.get 12
      i32.const 0
      i32.add
      i64.const 1
      i64.store align=1
      local.get 12
      i32.const 8
      i32.add
      i64.const 2
      i64.store align=1
      local.get 2
      i32.const 32
      i32.add
      local.set 13
      local.get 13
      i32.const 0
      i32.add
      i64.const 3
      i64.store align=1
      local.get 13
      i32.const 8
      i32.add
      i64.const 4
      i64.store align=1
      local.get 2
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 3
      local.get 1
      i32.const 2
      i32.add
      local.set 14
      local.get 14
      call $goose.data_top
      local.set 15
      local.get 2
      i32.const 51
      i32.add
      local.set 16
      local.get 16
      local.get 14
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 15
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 16
      i64.const 0
      i64.store offset=8 align=1
      i64.const 20
      local.set 17
      local.get 16
      i64.load offset=8 align=1
      local.set 18
      local.get 16
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 19
      local.get 16
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 19
      i64.extend_i32_u
      i64.or
      local.tee 20
      local.get 17
      call $goose.memory_op.55
      local.get 16
      local.get 18
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      if ;; label = @2
        local.get 3
        local.tee 21
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 269
          i32.const 81
          i32.const 4
          call 6
          unreachable
        end
        local.get 21
        local.set 22
        i64.const 2
        local.set 23
        i64.const 0
        local.set 24
        local.get 22
        local.set 25
        local.get 25
        i64.const 4294967295
        i64.and
        local.get 24
        i64.const 8
        i64.mul
        i64.add
        local.tee 26
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 350
          i32.const 81
          i32.const 13
          call 6
          unreachable
        end
        local.get 25
        i64.const -4294967296
        i64.and
        local.get 26
        i64.or
        call $goose.memory_op.41
        local.get 2
        i32.const 0
        i32.add
        local.set 27
        local.get 27
        i64.load offset=8 align=1
        local.set 28
        i64.const 0
        local.set 29
        local.get 27
        i64.load align=1
        local.set 30
        local.get 30
        i64.const 4294967295
        i64.and
        local.get 29
        i64.const 8
        i64.mul
        i64.add
        local.tee 31
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 431
          i32.const 81
          i32.const 13
          call 6
          unreachable
        end
        local.get 30
        i64.const -4294967296
        i64.and
        local.get 31
        i64.or
        call $goose.memory_op.41
        i64.add
        local.set 4
        local.get 3
        local.tee 32
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 512
          i32.const 81
          i32.const 4
          call 6
          unreachable
        end
        local.get 32
        local.set 33
        i64.const 2
        local.set 34
        i64.const 0
        local.set 35
        local.get 33
        local.set 36
        local.get 36
        i64.const 4294967295
        i64.and
        local.get 35
        i64.const 8
        i64.mul
        i64.add
        local.tee 37
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 593
          i32.const 81
          i32.const 12
          call 6
          unreachable
        end
        local.get 36
        i64.const -4294967296
        i64.and
        local.get 37
        i64.or
        call $goose.memory_op.41
        local.set 38
        local.get 2
        i32.const 51
        i32.add
        local.set 39
        local.get 39
        i64.load offset=8 align=1
        local.set 40
        i64.const 0
        local.set 41
        local.get 41
        local.get 40
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 674
          i32.const 81
          i32.const 12
          call 6
          unreachable
        end
        local.get 39
        i64.load align=1
        local.set 42
        local.get 42
        i64.const 4294967295
        i64.and
        local.get 41
        i64.const 8
        i64.mul
        i64.add
        local.tee 43
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 755
          i32.const 81
          i32.const 12
          call 6
          unreachable
        end
        local.get 42
        i64.const -4294967296
        i64.and
        local.get 43
        i64.or
        call $goose.memory_op.41
        local.set 44
        call 0
        local.set 45
        local.get 45
        i32.const 836
        i32.const 6
        call 4
        local.get 45
        local.get 38
        i32.const 0
        call 1
        local.get 45
        i32.const 842
        i32.const 1
        call 4
        local.get 45
        local.get 44
        i32.const 0
        call 1
        local.get 45
        call 5
        local.get 14
        local.get 15
        call $goose.restore_data
        local.get 2
        i32.const 32
        i32.add
        i64.extend_i32_u
        local.set 3
        local.get 3
        local.tee 46
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 843
          i32.const 81
          i32.const 4
          call 6
          unreachable
        end
        local.get 46
        local.set 47
        i64.const 2
        local.set 48
        i64.const 1
        local.set 49
        local.get 47
        local.set 50
        local.get 50
        i64.const 4294967295
        i64.and
        local.get 49
        i64.const 8
        i64.mul
        i64.add
        local.tee 51
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 924
          i32.const 81
          i32.const 7
          call 6
          unreachable
        end
        local.get 50
        i64.const -4294967296
        i64.and
        local.get 51
        i64.or
        call $goose.memory_op.41
        local.set 52
        local.get 2
        i32.const 0
        i32.add
        local.set 53
        local.get 53
        i64.load offset=8 align=1
        local.set 54
        i64.const 0
        local.set 55
        local.get 55
        local.get 54
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 1005
          i32.const 81
          i32.const 7
          call 6
          unreachable
        end
        local.get 53
        i64.load align=1
        local.set 56
        local.get 56
        i64.const 4294967295
        i64.and
        local.get 55
        i64.const 8
        i64.mul
        i64.add
        local.tee 57
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1086
          i32.const 81
          i32.const 7
          call 6
          unreachable
        end
        local.get 56
        i64.const -4294967296
        i64.and
        local.get 57
        i64.or
        call $goose.memory_op.41
        local.set 58
        call 0
        local.set 59
        local.get 59
        i32.const 1167
        i32.const 6
        call 4
        local.get 59
        local.get 52
        i32.const 0
        call 1
        local.get 59
        i32.const 1173
        i32.const 1
        call 4
        local.get 59
        local.get 58
        i32.const 0
        call 1
        local.get 59
        call 5
        local.get 2
        i32.const 48
        i32.add
        local.set 60
        local.get 60
        i64.const 0
        i64.store8
        i64.const 7
        local.set 61
        local.get 60
        i64.load8_u
        local.set 62
        local.get 62
        i64.const 2
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 1174
          i32.const 81
          i32.const 8
          call 6
          unreachable
        end
        local.get 60
        i32.const 1
        i32.add
        i64.extend_i32_u
        local.set 64
        local.get 64
        i64.const 4294967295
        i64.and
        local.get 62
        i64.const 1
        i64.mul
        i64.add
        local.tee 65
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1255
          i32.const 81
          i32.const 8
          call 6
          unreachable
        end
        local.get 64
        i64.const -4294967296
        i64.and
        local.get 65
        i64.or
        local.tee 66
        local.get 61
        local.set 67
        i32.wrap_i64
        local.get 67
        i64.store8
        local.get 60
        local.get 62
        i64.const 1
        i64.add
        i64.store8
        local.get 60
        i32.const 2
        i32.add
        i32.const 0
        i32.const 1
        memory.fill
        local.get 2
        i32.const 48
        i32.add
        i64.extend_i32_u
        local.set 68
        local.get 68
        i32.wrap_i64
        i64.load8_u
        local.set 69
        i64.const 0
        local.set 70
        local.get 68
        local.set 71
        local.get 71
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 70
        i64.const 1
        i64.mul
        i64.add
        local.tee 72
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1336
          i32.const 81
          i32.const 8
          call 6
          unreachable
        end
        local.get 71
        i64.const -4294967296
        i64.and
        local.get 72
        i64.or
        i32.wrap_i64
        i64.load8_u
        local.set 73
        call 0
        local.set 74
        local.get 74
        i32.const 1417
        i32.const 8
        call 4
        local.get 74
        local.get 73
        i32.const 1
        call 1
        local.get 74
        call 5
        local.get 5
        local.get 6
        call $goose.restore_data
        br 1 (;@1;)
      end
      local.get 3
      local.tee 75
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1425
        i32.const 81
        i32.const 4
        call 6
        unreachable
      end
      local.get 75
      local.set 76
      i64.const 2
      local.set 77
      i64.const 0
      local.set 78
      local.get 76
      local.set 79
      local.get 79
      i64.const 4294967295
      i64.and
      local.get 78
      i64.const 8
      i64.mul
      i64.add
      local.tee 80
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1506
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 79
      i64.const -4294967296
      i64.and
      local.get 80
      i64.or
      call $goose.memory_op.41
      local.set 81
      local.get 2
      i32.const 51
      i32.add
      local.set 82
      local.get 82
      i64.load offset=8 align=1
      local.set 83
      i64.const 0
      local.set 84
      local.get 84
      local.get 83
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1587
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 82
      i64.load align=1
      local.set 85
      local.get 85
      i64.const 4294967295
      i64.and
      local.get 84
      i64.const 8
      i64.mul
      i64.add
      local.tee 86
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1668
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 85
      i64.const -4294967296
      i64.and
      local.get 86
      i64.or
      call $goose.memory_op.41
      local.set 87
      call 0
      local.set 88
      local.get 88
      i32.const 1749
      i32.const 6
      call 4
      local.get 88
      local.get 81
      i32.const 0
      call 1
      local.get 88
      i32.const 1755
      i32.const 1
      call 4
      local.get 88
      local.get 87
      i32.const 0
      call 1
      local.get 88
      call 5
      local.get 14
      local.get 15
      call $goose.restore_data
      local.get 3
      local.tee 89
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1756
        i32.const 81
        i32.const 4
        call 6
        unreachable
      end
      local.get 89
      local.set 90
      i64.const 2
      local.set 91
      i64.const 1
      local.set 92
      local.get 90
      local.set 93
      local.get 93
      i64.const 4294967295
      i64.and
      local.get 92
      i64.const 8
      i64.mul
      i64.add
      local.tee 94
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1837
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 94
      i64.or
      call $goose.memory_op.41
      local.get 2
      i32.const 0
      i32.add
      local.set 95
      local.get 95
      i64.load offset=8 align=1
      local.set 96
      i64.const 0
      local.set 97
      local.get 95
      i64.load align=1
      local.set 98
      local.get 98
      i64.const 4294967295
      i64.and
      local.get 97
      i64.const 8
      i64.mul
      i64.add
      local.tee 99
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1918
        i32.const 81
        i32.const 15
        call 6
        unreachable
      end
      local.get 98
      i64.const -4294967296
      i64.and
      local.get 99
      i64.or
      call $goose.memory_op.41
      i64.add
      local.set 4
      local.get 2
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 3
      local.get 3
      local.tee 100
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1999
        i32.const 81
        i32.const 4
        call 6
        unreachable
      end
      local.get 100
      local.set 101
      i64.const 2
      local.set 102
      i64.const 1
      local.set 103
      local.get 101
      local.set 104
      local.get 104
      i64.const 4294967295
      i64.and
      local.get 103
      i64.const 8
      i64.mul
      i64.add
      local.tee 105
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2080
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 104
      i64.const -4294967296
      i64.and
      local.get 105
      i64.or
      call $goose.memory_op.41
      local.set 106
      local.get 2
      i32.const 0
      i32.add
      local.set 107
      local.get 107
      i64.load offset=8 align=1
      local.set 108
      i64.const 0
      local.set 109
      local.get 109
      local.get 108
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2161
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 107
      i64.load align=1
      local.set 110
      local.get 110
      i64.const 4294967295
      i64.and
      local.get 109
      i64.const 8
      i64.mul
      i64.add
      local.tee 111
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2242
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 110
      i64.const -4294967296
      i64.and
      local.get 111
      i64.or
      call $goose.memory_op.41
      local.set 112
      call 0
      local.set 113
      local.get 113
      i32.const 2323
      i32.const 6
      call 4
      local.get 113
      local.get 106
      i32.const 0
      call 1
      local.get 113
      i32.const 2329
      i32.const 1
      call 4
      local.get 113
      local.get 112
      i32.const 0
      call 1
      local.get 113
      call 5
      local.get 2
      i32.const 48
      i32.add
      local.set 114
      local.get 114
      i64.const 0
      i64.store8
      i64.const 7
      local.set 115
      local.get 114
      i64.load8_u
      local.set 116
      local.get 116
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2330
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 114
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 118
      local.get 118
      i64.const 4294967295
      i64.and
      local.get 116
      i64.const 1
      i64.mul
      i64.add
      local.tee 119
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2411
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 118
      i64.const -4294967296
      i64.and
      local.get 119
      i64.or
      local.tee 120
      local.get 115
      local.set 121
      i32.wrap_i64
      local.get 121
      i64.store8
      local.get 114
      local.get 116
      i64.const 1
      i64.add
      i64.store8
      local.get 114
      i32.const 2
      i32.add
      i32.const 0
      i32.const 1
      memory.fill
      local.get 2
      i32.const 48
      i32.add
      i64.extend_i32_u
      local.set 122
      local.get 122
      i32.wrap_i64
      i64.load8_u
      local.set 123
      i64.const 0
      local.set 124
      local.get 122
      local.set 125
      local.get 125
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 124
      i64.const 1
      i64.mul
      i64.add
      local.tee 126
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2492
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 125
      i64.const -4294967296
      i64.and
      local.get 126
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 127
      call 0
      local.set 128
      local.get 128
      i32.const 2573
      i32.const 8
      call 4
      local.get 128
      local.get 127
      i32.const 1
      call 1
      local.get 128
      call 5
      local.get 5
      local.get 6
      call $goose.restore_data
      br 0 (;@1;)
      local.get 2
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 3
      local.get 3
      local.tee 129
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2581
        i32.const 81
        i32.const 4
        call 6
        unreachable
      end
      local.get 129
      local.set 130
      i64.const 2
      local.set 131
      i64.const 1
      local.set 132
      local.get 130
      local.set 133
      local.get 133
      i64.const 4294967295
      i64.and
      local.get 132
      i64.const 8
      i64.mul
      i64.add
      local.tee 134
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2662
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 133
      i64.const -4294967296
      i64.and
      local.get 134
      i64.or
      call $goose.memory_op.41
      local.set 135
      local.get 2
      i32.const 0
      i32.add
      local.set 136
      local.get 136
      i64.load offset=8 align=1
      local.set 137
      i64.const 0
      local.set 138
      local.get 138
      local.get 137
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2743
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 136
      i64.load align=1
      local.set 139
      local.get 139
      i64.const 4294967295
      i64.and
      local.get 138
      i64.const 8
      i64.mul
      i64.add
      local.tee 140
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2824
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 139
      i64.const -4294967296
      i64.and
      local.get 140
      i64.or
      call $goose.memory_op.41
      local.set 141
      call 0
      local.set 142
      local.get 142
      i32.const 2905
      i32.const 6
      call 4
      local.get 142
      local.get 135
      i32.const 0
      call 1
      local.get 142
      i32.const 2911
      i32.const 1
      call 4
      local.get 142
      local.get 141
      i32.const 0
      call 1
      local.get 142
      call 5
      local.get 2
      i32.const 48
      i32.add
      local.set 143
      local.get 143
      i64.const 0
      i64.store8
      i64.const 7
      local.set 144
      local.get 143
      i64.load8_u
      local.set 145
      local.get 145
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2912
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 143
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 147
      local.get 147
      i64.const 4294967295
      i64.and
      local.get 145
      i64.const 1
      i64.mul
      i64.add
      local.tee 148
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2993
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 147
      i64.const -4294967296
      i64.and
      local.get 148
      i64.or
      local.tee 149
      local.get 144
      local.set 150
      i32.wrap_i64
      local.get 150
      i64.store8
      local.get 143
      local.get 145
      i64.const 1
      i64.add
      i64.store8
      local.get 143
      i32.const 2
      i32.add
      i32.const 0
      i32.const 1
      memory.fill
      local.get 2
      i32.const 48
      i32.add
      i64.extend_i32_u
      local.set 151
      local.get 151
      i32.wrap_i64
      i64.load8_u
      local.set 152
      i64.const 0
      local.set 153
      local.get 151
      local.set 154
      local.get 154
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 153
      i64.const 1
      i64.mul
      i64.add
      local.tee 155
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3074
        i32.const 81
        i32.const 8
        call 6
        unreachable
      end
      local.get 154
      i64.const -4294967296
      i64.and
      local.get 155
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 156
      call 0
      local.set 157
      local.get 157
      i32.const 3155
      i32.const 8
      call 4
      local.get 157
      local.get 156
      i32.const 1
      call 1
      local.get 157
      call 5
      local.get 5
      local.get 6
      call $goose.restore_data
    end
    local.get 2
    global.set 0
    local.get 4
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.data_top (;16;) (type 9) (param i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            global.get 1
            br 3 (;@1;)
          end
          global.get 2
          br 2 (;@1;)
        end
        global.get 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_data (;17;) (type 12) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            call $goose.reserve_memory.1
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.2
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.memory_op.55 (;20;) (type 13) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;21;) (type 14) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;22;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            i32.eqz
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            i64.extend_i32_u
            memory.size 1
            i64.extend_i32_u
            i64.const 16
            i64.shl
            i64.gt_u
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            global.set 1
            br 3 (;@1;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 2
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 2
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 3
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooseearly=normal=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooselive=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooseinner=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooseouter=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goosescratch=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooseinner=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooseouter=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goosescratch=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.gooseouter=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_deferred_rebind.goosescratch=")
)
