(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1104)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 78
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 86
        i32.const 78
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32)
    i32.const 58
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 2
      local.get 2
      i64.const 0
      i64.store8
      i64.const 1
      local.set 3
      local.get 2
      i64.load8_u
      local.set 4
      local.get 4
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 164
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 2
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 8
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 242
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.tee 8
      local.get 3
      local.set 9
      i32.wrap_i64
      local.get 9
      i64.store align=1
      local.get 2
      local.get 4
      i64.const 1
      i64.add
      i64.store8
      local.get 2
      i32.const 9
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      local.get 0
      i32.const 25
      i32.add
      local.set 10
      local.get 10
      i64.const 0
      i64.store8
      i64.const 10
      local.set 11
      local.get 10
      i64.load8_u
      local.set 12
      local.get 12
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 320
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 10
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 398
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.tee 16
      local.get 11
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store align=1
      local.get 10
      local.get 12
      i64.const 1
      i64.add
      i64.store8
      i64.const 20
      local.set 18
      local.get 10
      i64.load8_u
      local.set 19
      local.get 19
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 476
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 10
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      local.get 19
      i64.const 8
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 554
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      local.tee 23
      local.get 18
      local.set 24
      i32.wrap_i64
      local.get 24
      i64.store align=1
      local.get 10
      local.get 19
      i64.const 1
      i64.add
      i64.store8
      i64.const 30
      local.set 25
      local.get 10
      i64.load8_u
      local.set 26
      local.get 26
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 632
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 10
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      local.get 26
      i64.const 8
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 710
        i32.const 78
        i32.const 2
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      local.tee 30
      local.get 25
      local.set 31
      i32.wrap_i64
      local.get 31
      i64.store align=1
      local.get 10
      local.get 26
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 50
      i32.add
      local.set 32
      local.get 32
      i32.const 0
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 50
      i32.add
      local.set 33
      i64.const 0
      local.set 34
      i64.const 0
      local.set 36
      block ;; label = @2
        loop ;; label = @3
          local.get 33
          i64.extend_i32_u
          local.set 37
          local.get 37
          i64.const 4294967295
          i64.and
          local.get 34
          i64.const 8
          i64.mul
          i64.add
          local.tee 38
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 788
            i32.const 78
            i32.const 4
            call 6
            unreachable
          end
          local.get 37
          i64.const -4294967296
          i64.and
          local.get 38
          i64.or
          i32.wrap_i64
          i64.load align=1
          i32.wrap_i64
          local.tee 39
          i32.eqz
          if ;; label = @4
            i32.const 4
            i32.const 866
            i32.const 78
            i32.const 4
            call 6
            unreachable
          end
          local.get 39
          local.set 40
          local.get 40
          local.set 35
          local.get 36
          local.get 35
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 35
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 41
          local.get 41
          i64.const 4294967295
          i64.and
          local.get 36
          i64.const 8
          i64.mul
          i64.add
          local.tee 42
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 944
            i32.const 78
            i32.const 4
            call 6
            unreachable
          end
          local.get 41
          i64.const -4294967296
          i64.and
          local.get 42
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 1
          block ;; label = @4
            local.get 1
            local.set 43
            call 0
            local.set 44
            local.get 44
            local.get 43
            i32.const 0
            call 1
            local.get 44
            call 5
            local.get 0
            i32.const 50
            i32.add
            local.set 45
            i64.const 1
            local.set 46
            i64.const 0
            local.set 47
            local.get 45
            i64.extend_i32_u
            local.set 48
            local.get 48
            i64.const 4294967295
            i64.and
            local.get 47
            i64.const 8
            i64.mul
            i64.add
            local.tee 49
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1022
              i32.const 78
              i32.const 4
              call 6
              unreachable
            end
            local.get 48
            i64.const -4294967296
            i64.and
            local.get 49
            i64.or
            local.set 50
            local.get 0
            i32.const 25
            i32.add
            local.set 51
            local.get 50
            local.get 51
            local.set 52
            i32.wrap_i64
            local.get 52
            i64.extend_i32_u
            i64.store align=1
          end
          local.get 36
          i64.const 1
          i64.add
          local.set 36
          br 0 (;@3;)
        end
      end
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_limited_path.goose")
)
