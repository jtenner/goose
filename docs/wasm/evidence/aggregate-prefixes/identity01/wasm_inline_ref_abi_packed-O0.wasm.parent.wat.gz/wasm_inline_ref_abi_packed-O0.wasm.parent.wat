(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (type (;12;) (func (param i64) (result i64)))
  (type (;13;) (func (param i64 i64 i32) (result i64)))
  (type (;14;) (func (param i64 i32) (result i64)))
  (type (;15;) (func (param i64)))
  (type (;16;) (func (param i64 i64)))
  (type (;17;) (func (param i32 i32) (result i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (global (;0;) (mut i32) i32.const 6960)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 40
      i32.const 80
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 120
        i32.const 80
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 216
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i32.const 0
      i32.add
      i64.const 10
      i64.store align=1
      local.get 10
      i32.const 8
      i32.add
      i64.const 20
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 11
      local.get 11
      i32.const 0
      i32.add
      i64.const 30
      i64.store align=1
      local.get 11
      i32.const 8
      i32.add
      i64.const 40
      i64.store align=1
      local.get 0
      i32.const 32
      i32.add
      local.set 12
      local.get 12
      i64.const 0
      i64.store8
      i64.const 50
      local.set 13
      local.get 12
      i64.load8_u
      local.set 14
      local.get 14
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 200
        i32.const 80
        i32.const 17
        call 6
        unreachable
      end
      local.get 12
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 16
      local.get 16
      i64.const 4294967295
      i64.and
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 17
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 280
        i32.const 80
        i32.const 17
        call 6
        unreachable
      end
      local.get 16
      i64.const -4294967296
      i64.and
      local.get 17
      i64.or
      local.tee 18
      local.get 13
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store align=1
      local.get 12
      local.get 14
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 57
      i32.add
      local.set 20
      local.get 20
      i64.const 7
      i64.store8
      local.get 20
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 20
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      i64.store offset=9 align=1
      local.get 20
      i64.const 0
      i64.store offset=17 align=1
      local.get 20
      i64.const 4000000000
      i64.store32 offset=25 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 21
      local.get 21
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 360
        i32.const 80
        i32.const 19
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 22
      local.get 22
      i64.load32_u offset=25 align=1
      i64.const 4000000000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 440
        i32.const 80
        i32.const 19
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 23
      local.get 23
      i64.load offset=17 align=1
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 520
        i32.const 80
        i32.const 19
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 24
      local.get 24
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 25
      local.get 25
      i64.load offset=9 align=1
      local.tee 26
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 600
        i32.const 80
        i32.const 20
        call 6
        unreachable
      end
      local.get 26
      local.set 27
      i64.const 51
      local.set 28
      local.get 27
      call $goose.memory_op.49
      local.set 29
      local.get 29
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 680
        i32.const 80
        i32.const 20
        call 6
        unreachable
      end
      local.get 27
      local.set 31
      local.get 31
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 29
      i64.const 8
      i64.mul
      i64.add
      local.tee 32
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 760
        i32.const 80
        i32.const 20
        call 6
        unreachable
      end
      local.get 31
      i64.const -4294967296
      i64.and
      local.get 32
      i64.or
      local.tee 33
      local.get 28
      call $goose.memory_op.55
      local.get 27
      local.get 29
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 33
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 57
      i32.add
      local.set 34
      local.get 34
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=17 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 35
      local.get 35
      i64.load offset=1 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 840
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 36
      local.get 36
      i64.load offset=9 align=1
      local.tee 37
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 920
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 37
      local.set 38
      local.get 38
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1000
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 39
      local.get 39
      i64.load offset=9 align=1
      local.tee 40
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1080
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 40
      local.set 41
      local.get 41
      call $goose.memory_op.49
      local.set 42
      i64.const 1
      local.set 43
      local.get 41
      local.set 44
      local.get 44
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 43
      i64.const 8
      i64.mul
      i64.add
      local.tee 45
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1160
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 44
      i64.const -4294967296
      i64.and
      local.get 45
      i64.or
      call $goose.memory_op.41
      i64.const 51
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1240
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 46
      local.get 46
      i64.load offset=17 align=1
      local.set 1
      local.get 1
      i64.eqz
      i32.eqz
      if ;; label = @2
        local.get 1
        local.tee 47
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1320
          i32.const 80
          i32.const 22
          call 6
          unreachable
        end
        local.get 47
        local.set 48
        i64.const 2
        local.set 49
        i64.const 1
        local.set 50
        local.get 48
        local.set 51
        local.get 51
        i64.const 4294967295
        i64.and
        local.get 50
        i64.const 8
        i64.mul
        i64.add
        local.tee 52
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1400
          i32.const 80
          i32.const 22
          call 6
          unreachable
        end
        local.get 51
        i64.const -4294967296
        i64.and
        local.get 52
        i64.or
        call $goose.memory_op.41
        i64.const 20
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1480
          i32.const 80
          i32.const 22
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 86
      i32.add
      local.set 53
      local.get 0
      i32.const 57
      i32.add
      local.set 54
      local.get 53
      i64.extend_i32_u
      local.set 55
      local.get 54
      i64.extend_i32_u
      local.set 56
      i32.const 29
      local.set 57
      local.get 55
      i32.wrap_i64
      local.get 56
      i32.wrap_i64
      local.get 57
      memory.copy
      local.get 0
      i32.const 115
      i32.add
      local.set 58
      local.get 58
      local.get 0
      i32.const 57
      i32.add
      i32.const 29
      memory.copy
      local.get 58
      i32.const 29
      i32.add
      local.get 0
      i32.const 86
      i32.add
      i32.const 29
      memory.copy
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 59
      i64.const 2
      local.set 60
      i64.const 0
      local.set 61
      local.get 59
      local.set 62
      local.get 62
      i64.const 4294967295
      i64.and
      local.get 61
      i64.const 29
      i64.mul
      i64.add
      local.tee 63
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1560
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 62
      i64.const -4294967296
      i64.and
      local.get 63
      i64.or
      local.set 64
      local.get 64
      i32.wrap_i64
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 65
      i64.const 2
      local.set 66
      i64.const 0
      local.set 67
      local.get 65
      local.set 68
      local.get 68
      i64.const 4294967295
      i64.and
      local.get 67
      i64.const 29
      i64.mul
      i64.add
      local.tee 69
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1640
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 68
      i64.const -4294967296
      i64.and
      local.get 69
      i64.or
      local.set 70
      local.get 70
      i32.wrap_i64
      i64.load offset=1 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1720
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 71
      i64.const 2
      local.set 72
      i64.const 1
      local.set 73
      local.get 71
      local.set 74
      local.get 74
      i64.const 4294967295
      i64.and
      local.get 73
      i64.const 29
      i64.mul
      i64.add
      local.tee 75
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1800
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 74
      i64.const -4294967296
      i64.and
      local.get 75
      i64.or
      local.set 76
      local.get 76
      i32.wrap_i64
      i64.load offset=1 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1880
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 77
      i64.const 2
      local.set 78
      i64.const 0
      local.set 79
      local.get 77
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      local.get 79
      i64.const 29
      i64.mul
      i64.add
      local.tee 81
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1960
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 81
      i64.or
      local.set 82
      local.get 82
      i32.wrap_i64
      i64.load32_u offset=25 align=1
      i64.const 4000000000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2040
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 83
      i64.const 2
      local.set 84
      i64.const 1
      local.set 85
      local.get 83
      local.set 86
      local.get 86
      i64.const 4294967295
      i64.and
      local.get 85
      i64.const 29
      i64.mul
      i64.add
      local.tee 87
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2120
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 86
      i64.const -4294967296
      i64.and
      local.get 87
      i64.or
      local.set 88
      local.get 88
      i32.wrap_i64
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2200
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 0
      i32.const 173
      i32.add
      local.set 89
      local.get 89
      i32.const 0
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 89
      i32.const 8
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 89
      i32.const 16
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 173
      i32.add
      i64.extend_i32_u
      local.set 90
      i64.const 3
      local.set 91
      i64.const 1
      local.set 92
      local.get 90
      local.set 93
      local.get 93
      i64.const 4294967295
      i64.and
      local.get 92
      i64.const 8
      i64.mul
      i64.add
      local.tee 94
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2280
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 94
      i64.or
      local.set 95
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 96
      local.get 95
      local.get 96
      local.set 97
      i32.wrap_i64
      local.get 97
      i64.store align=1
      local.get 0
      i32.const 173
      i32.add
      i64.extend_i32_u
      local.set 98
      i64.const 3
      local.set 99
      i64.const 1
      local.set 100
      local.get 98
      local.set 101
      local.get 101
      i64.const 4294967295
      i64.and
      local.get 100
      i64.const 8
      i64.mul
      i64.add
      local.tee 102
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2360
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 101
      i64.const -4294967296
      i64.and
      local.get 102
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2440
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 173
      i32.add
      i64.extend_i32_u
      local.set 103
      i64.const 3
      local.set 104
      i64.const 2
      local.set 105
      local.get 103
      local.set 106
      local.get 106
      i64.const 4294967295
      i64.and
      local.get 105
      i64.const 8
      i64.mul
      i64.add
      local.tee 107
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2520
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 106
      i64.const -4294967296
      i64.and
      local.get 107
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2600
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      call $fixedref.1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      call $inlineref.2
      i32.const 0
      call $choose.3
      local.set 2
      local.get 2
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2680
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 2
      local.tee 108
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2760
        i32.const 80
        i32.const 28
        call 6
        unreachable
      end
      local.get 108
      local.set 109
      i64.const 2
      local.set 110
      i64.const 0
      local.set 111
      local.get 109
      local.set 112
      local.get 112
      i64.const 4294967295
      i64.and
      local.get 111
      i64.const 8
      i64.mul
      i64.add
      local.tee 113
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2840
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 112
      i64.const -4294967296
      i64.and
      local.get 113
      i64.or
      local.set 114
      local.get 114
      call $goose.memory_op.41
      i64.const 1
      i64.add
      local.set 115
      local.get 114
      local.get 115
      call $goose.memory_op.55
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 116
      i64.const 2
      local.set 117
      i64.const 0
      local.set 118
      local.get 116
      local.set 119
      local.get 119
      i64.const 4294967295
      i64.and
      local.get 118
      i64.const 8
      i64.mul
      i64.add
      local.tee 120
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2920
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 119
      i64.const -4294967296
      i64.and
      local.get 120
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 31
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3000
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i32.const 1
      call $optionalref.4
      local.set 3
      local.get 3
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3080
        i32.const 80
        i32.const 30
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i32.const 0
      call $optionalref.4
      local.set 3
      local.get 3
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3160
        i32.const 80
        i32.const 31
        call 6
        unreachable
      end
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      call $limitedref.5
      local.tee 121
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3240
        i32.const 80
        i32.const 6
        call 6
        unreachable
      end
      local.get 121
      local.set 122
      i64.const 52
      local.set 123
      local.get 122
      call $goose.memory_op.49
      local.set 124
      local.get 124
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 3320
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 122
      local.set 126
      local.get 126
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 124
      i64.const 8
      i64.mul
      i64.add
      local.tee 127
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3400
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 126
      i64.const -4294967296
      i64.and
      local.get 127
      i64.or
      local.tee 128
      local.get 123
      call $goose.memory_op.55
      local.get 122
      local.get 124
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 128
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 129
      local.get 129
      i32.wrap_i64
      i64.load8_u
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3480
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 130
      local.get 130
      i32.wrap_i64
      i64.load8_u
      local.set 131
      i64.const 2
      local.set 132
      local.get 130
      local.set 133
      local.get 133
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 132
      i64.const 8
      i64.mul
      i64.add
      local.tee 134
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3560
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 133
      i64.const -4294967296
      i64.and
      local.get 134
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 52
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3640
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      call $invoke.6
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 135
      i64.const 2
      local.set 136
      i64.const 1
      local.set 137
      local.get 135
      local.set 138
      local.get 138
      i64.const 4294967295
      i64.and
      local.get 137
      i64.const 8
      i64.mul
      i64.add
      local.tee 139
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3720
        i32.const 80
        i32.const 34
        call 6
        unreachable
      end
      local.get 138
      i64.const -4294967296
      i64.and
      local.get 139
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 43
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3800
        i32.const 80
        i32.const 34
        call 6
        unreachable
      end
      i32.const 24
      i64.load align=1
      local.tee 140
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3880
        i32.const 80
        i32.const 3
        call 6
        unreachable
      end
      local.get 140
      local.set 141
      i64.const 2
      local.set 142
      i64.const 0
      local.set 143
      local.get 141
      local.set 144
      local.get 144
      i64.const 4294967295
      i64.and
      local.get 143
      i64.const 8
      i64.mul
      i64.add
      local.tee 145
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3960
        i32.const 80
        i32.const 35
        call 6
        unreachable
      end
      local.get 144
      i64.const -4294967296
      i64.and
      local.get 145
      i64.or
      local.set 146
      local.get 146
      call $goose.memory_op.41
      i64.const 4
      i64.add
      local.set 147
      local.get 146
      local.get 147
      call $goose.memory_op.55
      i32.const 8
      i64.extend_i32_u
      local.set 148
      i32.const 32
      local.get 148
      i64.store align=1
      i32.const 32
      i64.load align=1
      i64.eqz
      i32.eqz
      if ;; label = @2
        i32.const 32
        i64.load align=1
        local.tee 149
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 4040
          i32.const 80
          i32.const 4
          call 6
          unreachable
        end
        local.get 149
        local.set 150
        i64.const 2
        local.set 151
        i64.const 0
        local.set 152
        local.get 150
        local.set 153
        local.get 153
        i64.const 4294967295
        i64.and
        local.get 152
        i64.const 8
        i64.mul
        i64.add
        local.tee 154
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4120
          i32.const 80
          i32.const 36
          call 6
          unreachable
        end
        local.get 153
        i64.const -4294967296
        i64.and
        local.get 154
        i64.or
        call $goose.memory_op.41
        i64.const 5
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 4200
          i32.const 80
          i32.const 36
          call 6
          unreachable
        end
      end
      i32.const 24
      i64.load align=1
      i32.const 8
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4280
        i32.const 80
        i32.const 37
        call 6
        unreachable
      end
      local.get 0
      i32.const 197
      i32.add
      local.set 155
      local.get 155
      i32.const 0
      i32.add
      i64.const 65
      i64.store8
      local.get 155
      i32.const 1
      i32.add
      i64.const 66
      i64.store8
      local.get 155
      i32.const 2
      i32.add
      i64.const 67
      i64.store8
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      local.set 156
      i64.const 3
      local.set 157
      i64.const 0
      local.set 158
      local.get 156
      local.set 159
      local.get 159
      i64.const 4294967295
      i64.and
      local.get 158
      i64.const 1
      i64.mul
      i64.add
      local.tee 160
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4360
        i32.const 80
        i32.const 39
        call 6
        unreachable
      end
      local.get 159
      i64.const -4294967296
      i64.and
      local.get 160
      i64.or
      local.set 161
      local.get 161
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 161
      i32.wrap_i64
      local.get 157
      i32.wrap_i64
      call 10
      local.set 162
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      call $change.7
      local.set 163
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      local.set 164
      i64.const 3
      local.set 165
      i64.const 0
      local.set 166
      local.get 164
      local.set 167
      local.get 167
      i64.const 4294967295
      i64.and
      local.get 166
      i64.const 1
      i64.mul
      i64.add
      local.tee 168
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4440
        i32.const 80
        i32.const 39
        call 6
        unreachable
      end
      local.get 167
      i64.const -4294967296
      i64.and
      local.get 168
      i64.or
      local.set 169
      local.get 169
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 169
      i32.wrap_i64
      local.get 165
      i32.wrap_i64
      call 10
      local.set 170
      call 0
      local.set 171
      local.get 171
      i32.const 4520
      i32.const 6
      call 4
      local.get 171
      local.get 162
      call 11
      local.get 171
      i32.const 4526
      i32.const 1
      call 4
      local.get 171
      local.get 163
      i32.const 0
      call 1
      local.get 171
      i32.const 4527
      i32.const 1
      call 4
      local.get 171
      local.get 170
      call 11
      local.get 171
      call 5
      i64.const 0
      local.set 4
      local.get 4
      local.set 172
      i32.const 0
      local.set 173
      local.get 173
      local.get 172
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 173
      else
        local.get 172
        local.set 174
      end
      local.get 173
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 4528
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 175
        i64.const 0
        local.set 176
        local.get 174
        local.set 177
        local.get 177
        i64.const 4294967295
        i64.and
        local.get 176
        i64.const 1
        i64.mul
        i64.add
        local.tee 178
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4532
          i32.const 80
          i32.const 40
          call 6
          unreachable
        end
        local.get 177
        i64.const -4294967296
        i64.and
        local.get 178
        i64.or
        local.set 179
        local.get 179
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 179
        i32.wrap_i64
        local.get 175
        i32.wrap_i64
        call 10
      end
      local.set 180
      call 0
      local.set 181
      local.get 181
      i32.const 4612
      i32.const 9
      call 4
      local.get 181
      local.get 180
      call 11
      local.get 181
      call 5
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      local.set 4
      local.get 4
      local.tee 182
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4621
        i32.const 80
        i32.const 41
        call 6
        unreachable
      end
      local.get 182
      local.set 183
      i64.const 3
      local.set 184
      i64.const 0
      local.set 185
      local.get 183
      local.set 186
      local.get 186
      i64.const 4294967295
      i64.and
      local.get 185
      i64.const 1
      i64.mul
      i64.add
      local.tee 187
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4701
        i32.const 80
        i32.const 41
        call 6
        unreachable
      end
      local.get 186
      i64.const -4294967296
      i64.and
      local.get 187
      i64.or
      local.set 188
      local.get 188
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 188
      i32.wrap_i64
      local.get 184
      i32.wrap_i64
      call 10
      local.set 189
      call 0
      local.set 190
      local.get 190
      i32.const 4781
      i32.const 6
      call 4
      local.get 190
      local.get 189
      call 11
      local.get 190
      call 5
      i32.const 1
      local.set 191
      i32.const 12
      call $goose.reserve_memory.1
      local.set 192
      local.get 191
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 192
      i64.extend_i32_u
      i64.or
      local.set 193
      local.get 193
      local.set 5
      local.get 193
      i64.const 1
      local.set 194
      i32.wrap_i64
      local.get 194
      i64.store32 1 align=1
      i64.const 99
      local.set 195
      local.get 192
      i32.const 4
      i32.add
      local.get 195
      i64.store 1 align=1
      i32.const 2
      local.set 196
      i32.const 20
      call $goose.reserve_memory.2
      local.set 197
      local.get 196
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 197
      i64.extend_i32_u
      i64.or
      local.set 198
      local.get 198
      local.set 6
      local.get 198
      i64.const 2
      local.set 194
      i32.wrap_i64
      local.get 194
      i64.store32 2 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 199
      local.get 197
      i32.const 4
      i32.add
      local.get 199
      i64.store 2 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 199
      local.get 197
      i32.const 12
      i32.add
      local.get 199
      i64.store 2 align=1
      local.get 6
      local.set 200
      local.get 200
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 201
      i64.const 0
      local.set 202
      local.get 200
      local.set 203
      local.get 203
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 202
      i64.const 8
      i64.mul
      i64.add
      local.tee 204
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4787
        i32.const 80
        i32.const 43
        call 6
        unreachable
      end
      local.get 203
      i64.const -4294967296
      i64.and
      local.get 204
      i64.or
      local.set 205
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 206
      local.get 205
      local.get 206
      local.set 207
      i32.wrap_i64
      local.get 207
      i64.store 2 align=1
      local.get 6
      local.set 208
      local.get 208
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 209
      i64.const 0
      local.set 210
      local.get 208
      local.set 211
      local.get 211
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 210
      i64.const 8
      i64.mul
      i64.add
      local.tee 212
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4867
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 211
      i64.const -4294967296
      i64.and
      local.get 212
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4947
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 6
      local.set 213
      local.get 213
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 214
      i64.const 1
      local.set 215
      local.get 213
      local.set 216
      local.get 216
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 215
      i64.const 8
      i64.mul
      i64.add
      local.tee 217
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5027
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 216
      i64.const -4294967296
      i64.and
      local.get 217
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.tee 218
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5107
        i32.const 80
        i32.const 43
        call 6
        unreachable
      end
      local.get 218
      local.set 219
      i64.const 2
      local.set 220
      i64.const 1
      local.set 221
      local.get 219
      local.set 222
      local.get 222
      i64.const 4294967295
      i64.and
      local.get 221
      i64.const 8
      i64.mul
      i64.add
      local.tee 223
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5187
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 222
      i64.const -4294967296
      i64.and
      local.get 223
      i64.or
      call $goose.memory_op.41
      i64.const 43
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5267
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      i32.const 3
      local.set 224
      global.get 3
      local.set 225
      local.get 0
      i32.const 200
      i32.add
      local.set 226
      local.get 226
      local.get 224
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 225
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 226
      i64.const 0
      i64.store offset=8 align=1
      i64.const 7
      local.set 227
      local.get 226
      i64.load offset=8 align=1
      local.set 228
      i32.const 8
      call $goose.reserve_memory.3
      local.set 229
      local.get 226
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 229
      i64.extend_i32_u
      i64.or
      local.tee 230
      local.get 227
      local.set 231
      i32.wrap_i64
      local.get 231
      i64.store 3 align=1
      local.get 226
      local.get 228
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 200
      i32.add
      local.set 7
      local.get 7
      local.tee 232
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5347
        i32.const 80
        i32.const 46
        call 6
        unreachable
      end
      local.get 232
      local.set 233
      i64.const 8
      local.set 234
      local.get 233
      i64.load offset=8 align=1
      local.set 235
      local.get 233
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 236
      local.get 233
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 236
      i64.extend_i32_u
      i64.or
      local.tee 237
      local.get 234
      call $goose.memory_op.55
      local.get 233
      local.get 235
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 237
      call $goose.memory_op.41
      drop
      local.get 7
      local.set 8
      local.get 8
      local.tee 238
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5427
        i32.const 80
        i32.const 47
        call 6
        unreachable
      end
      local.get 238
      local.set 239
      i64.const 9
      local.set 240
      local.get 239
      i64.load offset=8 align=1
      local.set 241
      local.get 239
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 242
      local.get 239
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 242
      i64.extend_i32_u
      i64.or
      local.tee 243
      local.get 240
      call $goose.memory_op.55
      local.get 239
      local.get 241
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 243
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 200
      i32.add
      call $headerref.8
      local.set 9
      local.get 9
      local.tee 244
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5507
        i32.const 80
        i32.const 48
        call 6
        unreachable
      end
      local.get 244
      local.set 245
      i64.const 10
      local.set 246
      local.get 245
      i64.load offset=8 align=1
      local.set 247
      local.get 245
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 248
      local.get 245
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 248
      i64.extend_i32_u
      i64.or
      local.tee 249
      local.get 246
      call $goose.memory_op.55
      local.get 245
      local.get 247
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 249
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 200
      i32.add
      local.set 250
      local.get 250
      i64.load offset=8 align=1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5587
        i32.const 80
        i32.const 49
        call 6
        unreachable
      end
      local.get 0
      i32.const 200
      i32.add
      local.set 251
      local.get 251
      i64.load offset=8 align=1
      local.set 252
      i64.const 3
      local.set 253
      local.get 251
      i64.load align=1
      local.set 254
      local.get 254
      i64.const 4294967295
      i64.and
      local.get 253
      i64.const 8
      i64.mul
      i64.add
      local.tee 255
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5667
        i32.const 80
        i32.const 49
        call 6
        unreachable
      end
      local.get 254
      i64.const -4294967296
      i64.and
      local.get 255
      i64.or
      i32.wrap_i64
      i64.load 3 align=1
      i64.const 10
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5747
        i32.const 80
        i32.const 49
        call 6
        unreachable
      end
      local.get 7
      i64.extend_i32_u
      local.get 0
      i32.const 200
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5827
        i32.const 80
        i32.const 50
        call 6
        unreachable
      end
      local.get 8
      i64.extend_i32_u
      local.get 0
      i32.const 200
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5907
        i32.const 80
        i32.const 50
        call 6
        unreachable
      end
      local.get 5
      local.set 256
      local.get 256
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 257
      i64.const 0
      local.set 258
      local.get 256
      local.set 259
      local.get 259
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 258
      i64.const 8
      i64.mul
      i64.add
      local.tee 260
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5987
        i32.const 80
        i32.const 51
        call 6
        unreachable
      end
      local.get 259
      i64.const -4294967296
      i64.and
      local.get 260
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 99
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6067
        i32.const 80
        i32.const 51
        call 6
        unreachable
      end
      call 0
      local.set 261
      local.get 261
      i32.const 6147
      i32.const 6
      call 4
      local.get 261
      call 5
      local.get 225
      global.set 3
      local.get 197
      global.set 2
      local.get 192
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $fixedref.1 (;15;) (type 12) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $inlineref.2 (;16;) (type 12) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $choose.3 (;17;) (type 13) (param i64 i64 i32) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 2
      if ;; label = @2
        local.get 0
        local.set 4
        br 1 (;@1;)
      end
      local.get 1
      local.set 4
      br 0 (;@1;)
    end
    local.get 4
  )
  (func $optionalref.4 (;18;) (type 14) (param i64 i32) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 1
      if ;; label = @2
        local.get 0
        local.set 3
        br 1 (;@1;)
      end
      i64.const 0
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $limitedref.5 (;19;) (type 12) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $invoke.6 (;20;) (type 15) (param i64)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.tee 3
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6153
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 2
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 8
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6233
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      call $goose.memory_op.41
      i64.const 31
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6313
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 2
      local.tee 9
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6393
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 9
      local.set 10
      i64.const 2
      local.set 11
      i64.const 1
      local.set 12
      local.get 10
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6473
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      call $goose.memory_op.41
      i64.const 40
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6553
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 2
      local.tee 15
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6633
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 15
      local.set 16
      i64.const 2
      local.set 17
      i64.const 1
      local.set 18
      local.get 16
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6713
        i32.const 80
        i32.const 33
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      local.set 21
      local.get 21
      call $goose.memory_op.41
      i64.const 3
      i64.add
      local.set 22
      local.get 21
      local.get 22
      call $goose.memory_op.55
    end
  )
  (func $change.7 (;21;) (type 12) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6793
        i32.const 80
        i32.const 13
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 3
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 1
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6873
        i32.const 80
        i32.const 13
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      i64.const 88
      local.set 10
      local.get 9
      local.get 10
      call $goose.memory_op.60
      i64.const 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $headerref.8 (;22;) (type 10) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;23;) (type 11)
    (local i32 i32 i64 i64)
    i32.const 8
    local.set 1
    local.get 1
    i32.const 0
    i32.add
    i64.const 1
    i64.store align=1
    local.get 1
    i32.const 8
    i32.add
    i64.const 2
    i64.store align=1
    i32.const 8
    i64.extend_i32_u
    local.set 2
    i32.const 24
    local.get 2
    i64.store align=1
    i64.const 0
    local.set 3
    i32.const 32
    local.get 3
    i64.store align=1
  )
  (func $goose.start (;24;) (type 11)
    call $goose.init
    call $main.0
  )
  (func $goose.memory_op.49 (;25;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;26;) (type 16) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;27;) (type 16) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store8
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;28;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.1 (;29;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;30;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;31;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_data (;32;) (type 17) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            call $goose.reserve_memory.1
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.2
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 24) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goosebytes=||null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goosebytes=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.gooseABI=ok/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose")
)
