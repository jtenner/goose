(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (type (;12;) (func (param i32) (result i64)))
  (type (;13;) (func (param i64) (result i64)))
  (type (;14;) (func (param i64 i64)))
  (type (;15;) (func (param i32 i32) (result i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (global (;0;) (mut i32) i32.const 2224)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 69
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 77
        i32.const 69
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i64 i32 i64 i32 i32)
    i32.const 25
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 12
      i32.const 7
      call $goose.reserve_memory.1
      local.set 13
      local.get 12
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 13
      i64.extend_i32_u
      i64.or
      local.set 14
      local.get 14
      local.set 1
      local.get 14
      i64.const 3
      local.set 15
      i32.wrap_i64
      local.get 15
      i64.store32 1 align=1
      i64.const 97
      local.set 16
      local.get 13
      i32.const 4
      i32.add
      local.get 16
      i64.store8 1
      i64.const 98
      local.set 16
      local.get 13
      i32.const 5
      i32.add
      local.get 16
      i64.store8 1
      i64.const 99
      local.set 16
      local.get 13
      i32.const 6
      i32.add
      local.get 16
      i64.store8 1
      local.get 1
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 18
      i64.const 0
      local.set 19
      local.get 17
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 19
      i64.const 1
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 146
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      local.set 22
      local.get 22
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 22
      i32.wrap_i64
      local.get 18
      i32.wrap_i64
      call 10
      local.set 23
      block ;; label = @2
        local.get 1
        local.set 2
        local.get 2
        local.tee 25
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 215
          i32.const 69
          i32.const 1
          call 6
          unreachable
        end
        local.get 25
        local.set 26
        local.get 26
        call $goose.memory_op.53
        local.set 27
        i64.const 0
        local.set 28
        local.get 26
        local.set 29
        local.get 29
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 28
        i64.const 1
        i64.mul
        i64.add
        local.tee 30
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 284
          i32.const 69
          i32.const 1
          call 6
          unreachable
        end
        local.get 29
        i64.const -4294967296
        i64.and
        local.get 30
        i64.or
        local.set 31
        i64.const 88
        local.set 32
        local.get 31
        local.get 32
        call $goose.memory_op.60
        call 0
        local.set 33
        local.get 33
        i32.const 353
        i32.const 6
        call 4
        local.get 33
        call 5
        i64.const 0
        local.set 24
        br 0 (;@2;)
      end
      local.get 24
      local.set 34
      local.get 1
      local.set 35
      local.get 35
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 36
      i64.const 0
      local.set 37
      local.get 35
      local.set 38
      local.get 38
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 37
      i64.const 1
      i64.mul
      i64.add
      local.tee 39
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 359
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 38
      i64.const -4294967296
      i64.and
      local.get 39
      i64.or
      local.set 40
      local.get 40
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 40
      i32.wrap_i64
      local.get 36
      i32.wrap_i64
      call 10
      local.set 41
      call 0
      local.set 42
      local.get 42
      i32.const 428
      i32.const 8
      call 4
      local.get 42
      local.get 23
      call 11
      local.get 42
      i32.const 436
      i32.const 1
      call 4
      local.get 42
      local.get 34
      i32.const 0
      call 1
      local.get 42
      i32.const 437
      i32.const 1
      call 4
      local.get 42
      local.get 41
      call 11
      local.get 42
      call 5
      i32.const 1
      call $early.2
      local.set 43
      call 0
      local.set 44
      local.get 44
      i32.const 438
      i32.const 11
      call 4
      local.get 44
      local.get 43
      i32.const 0
      call 1
      local.get 44
      call 5
      i32.const 0
      call $early.2
      local.set 45
      call 0
      local.set 46
      local.get 46
      i32.const 449
      i32.const 13
      call 4
      local.get 46
      local.get 45
      i32.const 0
      call 1
      local.get 46
      call 5
      block ;; label = @2
        i32.const 2
        local.set 48
        i32.const 6
        call $goose.reserve_memory.2
        local.set 49
        local.get 48
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 49
        i64.extend_i32_u
        i64.or
        local.set 50
        local.get 50
        local.set 3
        local.get 50
        i64.const 2
        local.set 15
        i32.wrap_i64
        local.get 15
        i64.store32 2 align=1
        i64.const 67
        local.set 51
        local.get 49
        i32.const 4
        i32.add
        local.get 51
        i64.store8 2
        i64.const 68
        local.set 51
        local.get 49
        i32.const 5
        i32.add
        local.get 51
        i64.store8 2
        local.get 3
        local.set 52
        local.get 52
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 53
        i64.const 0
        local.set 54
        local.get 52
        local.set 55
        local.get 55
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 54
        i64.const 1
        i64.mul
        i64.add
        local.tee 56
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 462
          i32.const 69
          i32.const 10
          call 6
          unreachable
        end
        local.get 55
        i64.const -4294967296
        i64.and
        local.get 56
        i64.or
        local.set 57
        local.get 57
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 57
        i32.wrap_i64
        local.get 53
        i32.wrap_i64
        call 10
        local.set 58
        i32.const 1
        if (result i64) ;; label = @3
          i64.const 10
          local.set 47
          local.get 58
          call 12
          local.get 49
          global.set 2
          br 1 (;@2;)
        else
          i64.const 11
        end
        local.set 59
        call 0
        local.set 60
        local.get 60
        i32.const 531
        i32.const 14
        call 4
        local.get 60
        local.get 58
        call 11
        local.get 60
        local.get 59
        i32.const 0
        call 1
        local.get 60
        call 5
        i64.const 12
        local.set 47
        local.get 49
        global.set 2
        br 0 (;@2;)
        local.get 49
        global.set 2
      end
      local.get 47
      local.set 61
      call 0
      local.set 62
      local.get 62
      i32.const 545
      i32.const 13
      call 4
      local.get 62
      local.get 61
      i32.const 0
      call 1
      local.get 62
      call 5
      block ;; label = @2
        i32.const 2
        local.set 64
        i32.const 6
        call $goose.reserve_memory.2
        local.set 65
        local.get 64
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 65
        i64.extend_i32_u
        i64.or
        local.set 66
        local.get 66
        local.set 4
        local.get 66
        i64.const 2
        local.set 15
        i32.wrap_i64
        local.get 15
        i64.store32 2 align=1
        i64.const 67
        local.set 67
        local.get 65
        i32.const 4
        i32.add
        local.get 67
        i64.store8 2
        i64.const 68
        local.set 67
        local.get 65
        i32.const 5
        i32.add
        local.get 67
        i64.store8 2
        local.get 4
        local.set 68
        local.get 68
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 69
        i64.const 0
        local.set 70
        local.get 68
        local.set 71
        local.get 71
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 70
        i64.const 1
        i64.mul
        i64.add
        local.tee 72
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 558
          i32.const 69
          i32.const 10
          call 6
          unreachable
        end
        local.get 71
        i64.const -4294967296
        i64.and
        local.get 72
        i64.or
        local.set 73
        local.get 73
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 73
        i32.wrap_i64
        local.get 69
        i32.wrap_i64
        call 10
        local.set 74
        i64.const 11
        local.set 75
        call 0
        local.set 76
        local.get 76
        i32.const 627
        i32.const 14
        call 4
        local.get 76
        local.get 74
        call 11
        local.get 76
        local.get 75
        i32.const 0
        call 1
        local.get 76
        call 5
        i64.const 12
        local.set 63
        local.get 65
        global.set 2
        br 0 (;@2;)
        local.get 65
        global.set 2
      end
      local.get 63
      local.set 77
      call 0
      local.set 78
      local.get 78
      i32.const 641
      i32.const 20
      call 4
      local.get 78
      local.get 77
      i32.const 0
      call 1
      local.get 78
      call 5
      i64.const 0
      local.set 5
      local.get 5
      local.set 79
      i32.const 0
      local.set 80
      local.get 80
      local.get 79
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 80
      else
        local.get 79
        local.set 81
      end
      local.get 80
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 661
        i32.const 4
        call 10
      else
        local.get 81
        call $goose.memory_op.53
        local.set 82
        i64.const 0
        local.set 83
        local.get 81
        local.set 84
        local.get 84
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 83
        i64.const 1
        i64.mul
        i64.add
        local.tee 85
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 665
          i32.const 69
          i32.const 22
          call 6
          unreachable
        end
        local.get 84
        i64.const -4294967296
        i64.and
        local.get 85
        i64.or
        local.set 86
        local.get 86
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 86
        i32.wrap_i64
        local.get 82
        i32.wrap_i64
        call 10
      end
      local.set 87
      call 0
      local.set 88
      local.get 88
      i32.const 734
      i32.const 9
      call 4
      local.get 88
      local.get 87
      call 11
      local.get 88
      call 5
      local.get 1
      local.set 5
      local.get 5
      local.tee 89
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 743
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 89
      local.set 90
      local.get 90
      call $goose.memory_op.53
      local.set 91
      i64.const 0
      local.set 92
      local.get 90
      local.set 93
      local.get 93
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 92
      i64.const 1
      i64.mul
      i64.add
      local.tee 94
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 812
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 94
      i64.or
      local.set 95
      local.get 95
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 95
      i32.wrap_i64
      local.get 91
      i32.wrap_i64
      call 10
      local.set 96
      call 0
      local.set 97
      local.get 97
      i32.const 881
      i32.const 9
      call 4
      local.get 97
      local.get 96
      call 11
      local.get 97
      call 5
      i64.const 0
      local.set 5
      local.get 5
      local.set 98
      i32.const 0
      local.set 99
      local.get 99
      local.get 98
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 99
      else
        local.get 98
        local.set 100
      end
      local.get 99
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 890
        i32.const 4
        call 10
      else
        local.get 100
        call $goose.memory_op.53
        local.set 101
        i64.const 0
        local.set 102
        local.get 100
        local.set 103
        local.get 103
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 102
        i64.const 1
        i64.mul
        i64.add
        local.tee 104
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 894
          i32.const 69
          i32.const 23
          call 6
          unreachable
        end
        local.get 103
        i64.const -4294967296
        i64.and
        local.get 104
        i64.or
        local.set 105
        local.get 105
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 105
        i32.wrap_i64
        local.get 101
        i32.wrap_i64
        call 10
      end
      local.set 106
      call 0
      local.set 107
      local.get 107
      i32.const 963
      i32.const 9
      call 4
      local.get 107
      local.get 106
      call 11
      local.get 107
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 108
      local.get 108
      i32.const 0
      i32.add
      i64.const 65
      i64.store8
      local.get 108
      i32.const 1
      i32.add
      i64.const 0
      i64.store8
      local.get 108
      i32.const 2
      i32.add
      i64.const 66
      i64.store8
      i64.const 0
      local.set 6
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 109
      i64.const 3
      local.set 110
      i64.const 0
      local.set 111
      local.get 109
      local.set 112
      local.get 112
      i64.const 4294967295
      i64.and
      local.get 111
      i64.const 1
      i64.mul
      i64.add
      local.tee 113
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 972
        i32.const 69
        i32.const 26
        call 6
        unreachable
      end
      local.get 112
      i64.const -4294967296
      i64.and
      local.get 113
      i64.or
      local.set 114
      local.get 114
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 114
      i32.wrap_i64
      local.get 110
      i32.wrap_i64
      call 10
      local.set 115
      local.get 6
      local.set 116
      i32.const 0
      local.set 117
      local.get 117
      local.get 116
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 117
      else
        local.get 116
        local.set 118
      end
      local.get 117
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 1041
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 119
        i64.const 0
        local.set 120
        local.get 118
        local.set 121
        local.get 121
        i64.const 4294967295
        i64.and
        local.get 120
        i64.const 1
        i64.mul
        i64.add
        local.tee 122
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1045
          i32.const 69
          i32.const 26
          call 6
          unreachable
        end
        local.get 121
        i64.const -4294967296
        i64.and
        local.get 122
        i64.or
        local.set 123
        local.get 123
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 123
        i32.wrap_i64
        local.get 119
        i32.wrap_i64
        call 10
      end
      local.set 124
      call 0
      local.set 125
      local.get 125
      i32.const 1114
      i32.const 6
      call 4
      local.get 125
      local.get 115
      call 11
      local.get 125
      i32.const 1120
      i32.const 1
      call 4
      local.get 125
      local.get 124
      call 11
      local.get 125
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      local.tee 126
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1121
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 126
      local.set 127
      i64.const 3
      local.set 128
      i64.const 0
      local.set 129
      local.get 127
      local.set 130
      local.get 130
      i64.const 4294967295
      i64.and
      local.get 129
      i64.const 1
      i64.mul
      i64.add
      local.tee 131
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1190
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 130
      i64.const -4294967296
      i64.and
      local.get 131
      i64.or
      local.set 132
      local.get 132
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 132
      i32.wrap_i64
      local.get 128
      i32.wrap_i64
      call 10
      local.set 133
      call 0
      local.set 134
      local.get 134
      i32.const 1259
      i32.const 6
      call 4
      local.get 134
      local.get 133
      call 11
      local.get 134
      call 5
      i64.const 0
      local.set 6
      local.get 6
      local.set 135
      i32.const 0
      local.set 136
      local.get 136
      local.get 135
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 136
      else
        local.get 135
        local.set 137
      end
      local.get 136
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 1265
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 138
        i64.const 0
        local.set 139
        local.get 137
        local.set 140
        local.get 140
        i64.const 4294967295
        i64.and
        local.get 139
        i64.const 1
        i64.mul
        i64.add
        local.tee 141
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1269
          i32.const 69
          i32.const 27
          call 6
          unreachable
        end
        local.get 140
        i64.const -4294967296
        i64.and
        local.get 141
        i64.or
        local.set 142
        local.get 142
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 142
        i32.wrap_i64
        local.get 138
        i32.wrap_i64
        call 10
      end
      local.set 143
      call 0
      local.set 144
      local.get 144
      i32.const 1338
      i32.const 6
      call 4
      local.get 144
      local.get 143
      call 11
      local.get 144
      call 5
      local.get 0
      i32.const 3
      i32.add
      local.set 145
      local.get 145
      i64.const 0
      i64.store8
      i64.const 100
      local.set 146
      local.get 145
      i64.load8_u
      local.set 147
      local.get 147
      i64.const 5
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1344
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 145
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 149
      local.get 149
      i64.const 4294967295
      i64.and
      local.get 147
      i64.const 1
      i64.mul
      i64.add
      local.tee 150
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1413
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 149
      i64.const -4294967296
      i64.and
      local.get 150
      i64.or
      local.tee 151
      local.get 146
      local.set 152
      i32.wrap_i64
      local.get 152
      i64.store8
      local.get 145
      local.get 147
      i64.const 1
      i64.add
      i64.store8
      i64.const 101
      local.set 153
      local.get 145
      i64.load8_u
      local.set 154
      local.get 154
      i64.const 5
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1482
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 145
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 156
      local.get 156
      i64.const 4294967295
      i64.and
      local.get 154
      i64.const 1
      i64.mul
      i64.add
      local.tee 157
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1551
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 156
      i64.const -4294967296
      i64.and
      local.get 157
      i64.or
      local.tee 158
      local.get 153
      local.set 159
      i32.wrap_i64
      local.get 159
      i64.store8
      local.get 145
      local.get 154
      i64.const 1
      i64.add
      i64.store8
      local.get 145
      i32.const 3
      i32.add
      i32.const 0
      i32.const 3
      memory.fill
      i32.const 2
      local.set 160
      global.get 2
      local.set 161
      local.get 0
      i32.const 9
      i32.add
      local.set 162
      local.get 162
      local.get 160
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 161
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 162
      i64.const 0
      i64.store offset=8 align=1
      i64.const 71
      local.set 163
      local.get 162
      i64.load offset=8 align=1
      local.set 164
      i32.const 1
      call $goose.reserve_memory.2
      local.set 165
      local.get 162
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 165
      i64.extend_i32_u
      i64.or
      local.tee 166
      local.get 163
      local.set 167
      i32.wrap_i64
      local.get 167
      i64.store8 2
      local.get 162
      local.get 164
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 168
      local.get 168
      i32.wrap_i64
      i64.load8_u
      local.set 169
      i64.const 0
      local.set 170
      local.get 168
      local.set 171
      local.get 171
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 170
      i64.const 1
      i64.mul
      i64.add
      local.tee 172
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1620
        i32.const 69
        i32.const 30
        call 6
        unreachable
      end
      local.get 171
      i64.const -4294967296
      i64.and
      local.get 172
      i64.or
      local.set 173
      local.get 173
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 173
      i32.wrap_i64
      local.get 169
      i32.wrap_i64
      call 10
      local.set 174
      call 0
      local.set 175
      local.get 175
      i32.const 1689
      i32.const 8
      call 4
      local.get 175
      local.get 174
      call 11
      local.get 175
      call 5
      local.get 0
      i32.const 9
      i32.add
      local.set 176
      local.get 176
      i64.load offset=8 align=1
      local.set 177
      i64.const 0
      local.set 178
      local.get 176
      i64.load align=1
      local.set 179
      local.get 179
      i64.const 4294967295
      i64.and
      local.get 178
      i64.const 1
      i64.mul
      i64.add
      local.tee 180
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1697
        i32.const 69
        i32.const 31
        call 6
        unreachable
      end
      local.get 179
      i64.const -4294967296
      i64.and
      local.get 180
      i64.or
      local.set 181
      local.get 181
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 181
      i32.wrap_i64
      local.get 177
      i32.wrap_i64
      call 10
      local.set 182
      block ;; label = @2
        local.get 0
        i32.const 9
        i32.add
        local.set 7
        i64.const 0
        local.set 184
        i64.const 70000
        local.set 185
        block ;; label = @3
          loop ;; label = @4
            local.get 184
            local.get 185
            i64.ge_s
            br_if 1 (;@3;)
            local.get 184
            local.set 8
            block ;; label = @5
              local.get 7
              local.tee 186
              i32.eqz
              if ;; label = @6
                i32.const 4
                i32.const 1766
                i32.const 69
                i32.const 13
                call 6
                unreachable
              end
              local.get 186
              local.set 187
              i64.const 120
              local.set 188
              local.get 187
              i64.load offset=8 align=1
              local.set 189
              local.get 187
              i64.load align=1
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              i32.const 1
              call $goose.reserve_data
              local.set 190
              local.get 187
              i64.load align=1
              i64.const -4294967296
              i64.and
              local.get 190
              i64.extend_i32_u
              i64.or
              local.tee 191
              local.get 188
              call $goose.memory_op.60
              local.get 187
              local.get 189
              i64.const 1
              i64.add
              i64.store offset=8 align=1
              local.get 191
              call $goose.memory_op.49
              drop
            end
            local.get 184
            i64.const 1
            i64.add
            local.set 184
            br 0 (;@4;)
          end
        end
        local.get 7
        local.tee 192
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1835
          i32.const 69
          i32.const 13
          call 6
          unreachable
        end
        local.get 192
        local.set 193
        local.get 193
        i64.load offset=8 align=1
        local.set 183
        br 0 (;@2;)
      end
      local.get 183
      local.set 194
      local.get 0
      i32.const 9
      i32.add
      local.set 195
      local.get 195
      i64.load offset=8 align=1
      local.set 196
      call 0
      local.set 197
      local.get 197
      i32.const 1904
      i32.const 7
      call 4
      local.get 197
      local.get 182
      call 11
      local.get 197
      i32.const 1911
      i32.const 1
      call 4
      local.get 197
      local.get 194
      i32.const 0
      call 1
      local.get 197
      i32.const 1912
      i32.const 1
      call 4
      local.get 197
      local.get 196
      i32.const 0
      call 1
      local.get 197
      call 5
      i32.const 3
      local.set 198
      i32.const 4
      call $goose.reserve_memory.3
      local.set 199
      local.get 198
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 199
      i64.extend_i32_u
      i64.or
      local.set 200
      local.get 200
      local.set 9
      local.get 200
      i64.const 0
      local.set 15
      i32.wrap_i64
      local.get 15
      i64.store32 3 align=1
      local.get 9
      local.set 201
      local.get 201
      i32.wrap_i64
      i64.load32_u 3 align=1
      local.set 202
      i64.const 0
      local.set 203
      local.get 201
      local.set 204
      local.get 204
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 203
      i64.const 1
      i64.mul
      i64.add
      local.tee 205
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1913
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 204
      i64.const -4294967296
      i64.and
      local.get 205
      i64.or
      local.set 206
      local.get 206
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 206
      i32.wrap_i64
      local.get 202
      i32.wrap_i64
      call 10
      local.set 207
      call 0
      local.set 208
      local.get 208
      i32.const 1982
      i32.const 6
      call 4
      local.get 208
      local.get 207
      call 11
      local.get 208
      i32.const 1988
      i32.const 1
      call 4
      local.get 208
      call 5
      i64.const 0
      local.set 209
      i64.const 3
      local.set 210
      block ;; label = @2
        loop ;; label = @3
          local.get 209
          local.get 210
          i64.ge_s
          br_if 1 (;@2;)
          local.get 209
          local.set 10
          block ;; label = @4
            i32.const 4
            local.set 211
            i32.const 6
            call $goose.reserve_memory.4
            local.set 212
            local.get 211
            i64.extend_i32_u
            i64.const 32
            i64.shl
            local.get 212
            i64.extend_i32_u
            i64.or
            local.set 213
            local.get 213
            local.set 11
            local.get 213
            i64.const 2
            local.set 15
            i32.wrap_i64
            local.get 15
            i64.store32 4 align=1
            i64.const 80
            local.set 214
            local.get 212
            i32.const 4
            i32.add
            local.get 214
            i64.store8 4
            i64.const 81
            local.set 214
            local.get 212
            i32.const 5
            i32.add
            local.get 214
            i64.store8 4
            local.get 11
            local.set 215
            local.get 215
            i32.wrap_i64
            i64.load32_u 4 align=1
            local.set 216
            i64.const 0
            local.set 217
            local.get 215
            local.set 218
            local.get 218
            i64.const 4294967295
            i64.and
            i64.const 4
            i64.add
            local.get 217
            i64.const 1
            i64.mul
            i64.add
            local.tee 219
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1989
              i32.const 69
              i32.const 36
              call 6
              unreachable
            end
            local.get 218
            i64.const -4294967296
            i64.and
            local.get 219
            i64.or
            local.set 220
            local.get 220
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            local.get 220
            i32.wrap_i64
            local.get 216
            i32.wrap_i64
            call 10
            local.set 221
            local.get 10
            i64.const 0
            i64.eq
            if (result i64) ;; label = @5
              local.get 221
              call 12
              local.get 10
              local.set 222
              call 0
              local.set 223
              local.get 223
              i32.const 2058
              i32.const 10
              call 4
              local.get 223
              local.get 222
              i32.const 0
              call 1
              local.get 223
              call 5
              local.get 212
              global.set 4
              br 1 (;@4;)
            else
              local.get 10
              i64.const 1
              i64.eq
              if (result i64) ;; label = @6
                local.get 221
                call 12
                local.get 10
                local.set 224
                call 0
                local.set 225
                local.get 225
                i32.const 2068
                i32.const 10
                call 4
                local.get 225
                local.get 224
                i32.const 0
                call 1
                local.get 225
                call 5
                local.get 212
                global.set 4
                br 4 (;@2;)
              else
                i64.const 4
              end
            end
            local.set 226
            call 0
            local.set 227
            local.get 227
            i32.const 2078
            i32.const 12
            call 4
            local.get 227
            local.get 221
            call 11
            local.get 227
            local.get 226
            i32.const 0
            call 1
            local.get 227
            call 5
            local.get 10
            local.set 228
            call 0
            local.set 229
            local.get 229
            i32.const 2090
            i32.const 10
            call 4
            local.get 229
            local.get 228
            i32.const 0
            call 1
            local.get 229
            call 5
            local.get 212
            global.set 4
          end
          local.get 209
          i64.const 1
          i64.add
          local.set 209
          br 0 (;@3;)
        end
      end
      call 0
      local.set 230
      local.get 230
      i32.const 2100
      i32.const 10
      call 4
      local.get 230
      call 5
      local.get 199
      global.set 3
      local.get 161
      global.set 2
      local.get 13
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $early.2 (;15;) (type 12) (param i32) (result i64)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i32)
    block ;; label = @1
      i32.const 2
      local.set 4
      i32.const 6
      call $goose.reserve_memory.2
      local.set 5
      local.get 4
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 5
      i64.extend_i32_u
      i64.or
      local.set 6
      local.get 6
      local.set 2
      local.get 6
      i64.const 2
      local.set 7
      i32.wrap_i64
      local.get 7
      i64.store32 2 align=1
      i64.const 65
      local.set 8
      local.get 5
      i32.const 4
      i32.add
      local.get 8
      i64.store8 2
      i64.const 66
      local.set 8
      local.get 5
      i32.const 5
      i32.add
      local.get 8
      i64.store8 2
      local.get 2
      local.set 9
      local.get 9
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 10
      i64.const 0
      local.set 11
      local.get 9
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 11
      i64.const 1
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2110
        i32.const 69
        i32.const 5
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      local.set 14
      local.get 14
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 14
      i32.wrap_i64
      local.get 10
      i32.wrap_i64
      call 10
      local.set 15
      local.get 0
      if (result i64) ;; label = @2
        i64.const 7
        local.set 3
        local.get 15
        call 12
        call 0
        local.set 16
        local.get 16
        i32.const 2179
        i32.const 10
        call 4
        local.get 16
        call 5
        local.get 5
        global.set 2
        br 1 (;@1;)
      else
        i64.const 8
      end
      local.set 17
      call 0
      local.set 18
      local.get 18
      i32.const 2189
      i32.const 7
      call 4
      local.get 18
      local.get 15
      call 11
      local.get 18
      local.get 17
      i32.const 0
      call 1
      local.get 18
      call 5
      i64.const 9
      local.set 3
      call 0
      local.set 19
      local.get 19
      i32.const 2196
      i32.const 10
      call 4
      local.get 19
      call 5
      local.get 5
      global.set 2
      br 0 (;@1;)
      call 0
      local.set 20
      local.get 20
      i32.const 2206
      i32.const 10
      call 4
      local.get 20
      call 5
      local.get 5
      global.set 2
    end
    local.get 3
  )
  (func $goose.init (;16;) (type 11)
    (local i32)
  )
  (func $goose.start (;17;) (type 11)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;18;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.53 (;19;) (type 13) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 0
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;) 4 (;@3;) 5 (;@2;)
                end
                local.get 0
                i32.wrap_i64
                i64.load32_u align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u 1 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 2 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 3 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 4 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;20;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 0
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;) 4 (;@3;) 5 (;@2;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store8
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store8 1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8 2
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 3
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 4
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;21;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_data (;22;) (type 15) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i32.const 1
                i32.sub
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 1
              call $goose.reserve_memory.1
              br 4 (;@1;)
            end
            local.get 1
            call $goose.reserve_memory.2
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.3
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.4
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.3 (;23;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;24;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.memory_op.49 (;25;) (type 13) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 0
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;) 4 (;@3;) 5 (;@2;)
                end
                local.get 0
                i32.wrap_i64
                i64.load8_u
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u 1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 2
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 3
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 4
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosenested/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosecapture=||after-exit=after-normal=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseunused-inline=after-inline=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseunused-inline=after-inline-normal=null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseoptional=null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosenull/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosefixed=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosefixed=null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosefixed=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooselimited=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosegrowth=||/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseempty=!/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.gooseloop-exit=loop-exit=unused-loop=loop-exit=done-bytes/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_byte_print.goosedefer-exitunused=defer-exitdefer-exit")
)
