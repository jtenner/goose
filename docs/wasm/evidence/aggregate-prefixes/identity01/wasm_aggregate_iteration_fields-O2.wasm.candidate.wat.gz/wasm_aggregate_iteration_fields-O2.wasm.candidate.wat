(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1904)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 16
      i32.const 85
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 101
        i32.const 85
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i32 i32 i32 i64 i32)
    i32.const 1552
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 5
        i32.const 8
        local.get 5
        i64.store align=1
        i64.const 7
        local.set 4
        br 0 (;@2;)
      end
      local.get 4
      i64.store align=1
      local.get 3
      i64.const 0
      i64.store16 offset=8 align=1
      i64.const 1
      local.set 6
      local.get 3
      i64.load16_u offset=8 align=1
      local.set 7
      local.get 7
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 186
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 3
      i32.const 8
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 9
      local.get 9
      i64.const 4294967295
      i64.and
      local.get 7
      i64.const 1
      i64.mul
      i64.add
      local.tee 10
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 271
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 10
      i64.or
      local.set 8
      local.get 8
      i32.wrap_i64
      local.get 6
      i64.store8
      local.get 3
      local.get 7
      i64.const 1
      i64.add
      i64.store16 offset=8 align=1
      i64.const 2
      local.set 6
      local.get 3
      i64.load16_u offset=8 align=1
      local.set 7
      local.get 7
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 356
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 3
      i32.const 8
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 9
      local.get 9
      i64.const 4294967295
      i64.and
      local.get 7
      i64.const 1
      i64.mul
      i64.add
      local.tee 10
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 441
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 10
      i64.or
      local.set 8
      local.get 8
      i32.wrap_i64
      local.get 6
      i64.store8
      local.get 3
      local.get 7
      i64.const 1
      i64.add
      i64.store16 offset=8 align=1
      local.get 3
      i32.const 12
      i32.add
      i32.const 0
      i32.const 298
      memory.fill
      local.get 3
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 12
        i32.const 8
        local.get 12
        i64.store align=1
        i64.const 7
        local.set 11
        br 0 (;@2;)
      end
      local.get 11
      i64.store offset=310 align=1
      local.get 3
      i64.const 0
      i64.store16 offset=318 align=1
      i64.const 3
      local.set 6
      local.get 3
      i64.load16_u offset=318 align=1
      local.set 7
      local.get 7
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 526
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 3
      i32.const 318
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 9
      local.get 9
      i64.const 4294967295
      i64.and
      local.get 7
      i64.const 1
      i64.mul
      i64.add
      local.tee 10
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 611
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 10
      i64.or
      local.set 8
      local.get 8
      i32.wrap_i64
      local.get 6
      i64.store8
      local.get 3
      local.get 7
      i64.const 1
      i64.add
      i64.store16 offset=318 align=1
      i64.const 4
      local.set 6
      local.get 3
      i64.load16_u offset=318 align=1
      local.set 7
      local.get 7
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 696
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 3
      i32.const 318
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 9
      local.get 9
      i64.const 4294967295
      i64.and
      local.get 7
      i64.const 1
      i64.mul
      i64.add
      local.tee 10
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 781
        i32.const 85
        i32.const 6
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 10
      i64.or
      local.set 8
      local.get 8
      i32.wrap_i64
      local.get 6
      i64.store8
      local.get 3
      local.get 7
      i64.const 1
      i64.add
      i64.store16 offset=318 align=1
      local.get 3
      i32.const 322
      i32.add
      i32.const 0
      i32.const 298
      memory.fill
      local.get 3
      i64.const 9
      i64.store8 offset=620
      i32.const 8
      i64.load align=1
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 866
        i32.const 85
        i32.const 7
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 13
      i64.const 0
      local.set 14
      block ;; label = @2
        loop ;; label = @3
          local.get 14
          i64.const 1
          i64.ge_u
          br_if 1 (;@2;)
          local.get 13
          i64.extend_i32_u
          local.set 15
          local.get 15
          i64.const 4294967295
          i64.and
          local.get 14
          i64.const 621
          i64.mul
          i64.add
          local.tee 16
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 951
            i32.const 85
            i32.const 8
            call 6
            unreachable
          end
          local.get 15
          i64.const -4294967296
          i64.and
          local.get 16
          i64.or
          local.set 17
          local.get 0
          i32.const 621
          i32.add
          local.set 18
          local.get 18
          i64.extend_i32_u
          local.set 19
          local.get 17
          local.set 20
          i32.const 621
          local.set 21
          local.get 19
          i32.wrap_i64
          local.get 20
          i32.wrap_i64
          local.get 21
          memory.copy
          block ;; label = @4
            local.get 0
            i32.const 0
            i32.add
            local.set 22
            i64.const 1
            local.set 23
            i64.const 0
            local.set 24
            local.get 22
            i64.extend_i32_u
            local.set 25
            local.get 25
            i64.const 4294967295
            i64.and
            local.get 24
            i64.const 621
            i64.mul
            i64.add
            local.tee 26
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1036
              i32.const 85
              i32.const 9
              call 6
              unreachable
            end
            local.get 25
            i64.const -4294967296
            i64.and
            local.get 26
            i64.or
            local.set 27
            local.get 27
            i32.wrap_i64
            local.set 28
            i64.const 2
            local.set 29
            i64.const 0
            local.set 30
            local.get 28
            i64.extend_i32_u
            local.set 31
            local.get 31
            i64.const 4294967295
            i64.and
            local.get 30
            i64.const 310
            i64.mul
            i64.add
            local.tee 32
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1121
              i32.const 85
              i32.const 9
              call 6
              unreachable
            end
            local.get 31
            i64.const -4294967296
            i64.and
            local.get 32
            i64.or
            local.set 33
            local.get 33
            i32.wrap_i64
            local.get 33
            i32.wrap_i64
            i64.load align=1
            i64.const 100
            i64.add
            i64.store align=1
            local.get 0
            i32.const 621
            i32.add
            local.set 34
            local.get 34
            local.set 35
            i64.const 2
            local.set 36
            i64.const 0
            local.set 37
            local.get 35
            i64.extend_i32_u
            local.set 38
            local.get 38
            i64.const 4294967295
            i64.and
            local.get 37
            i64.const 310
            i64.mul
            i64.add
            local.tee 39
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1206
              i32.const 85
              i32.const 9
              call 6
              unreachable
            end
            local.get 38
            i64.const -4294967296
            i64.and
            local.get 39
            i64.or
            local.set 40
            local.get 40
            i32.wrap_i64
            i64.load align=1
            i64.const 7
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 1291
              i32.const 85
              i32.const 9
              call 6
              unreachable
            end
            local.get 0
            i32.const 621
            i32.add
            local.set 41
            local.get 41
            local.set 1
            i64.const 0
            local.set 2
            local.get 1
            local.tee 42
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 1376
              i32.const 85
              i32.const 10
              call 6
              unreachable
            end
            local.get 42
            local.set 43
            i64.const 0
            local.set 44
            block ;; label = @5
              loop ;; label = @6
                local.get 44
                i64.const 2
                i64.ge_u
                br_if 1 (;@5;)
                local.get 43
                i64.extend_i32_u
                local.set 45
                local.get 45
                i64.const 4294967295
                i64.and
                local.get 44
                i64.const 310
                i64.mul
                i64.add
                local.tee 46
                i64.const 4294967295
                i64.gt_u
                if ;; label = @7
                  i32.const 11
                  i32.const 1461
                  i32.const 85
                  i32.const 11
                  call 6
                  unreachable
                end
                local.get 45
                i64.const -4294967296
                i64.and
                local.get 46
                i64.or
                local.set 47
                local.get 0
                i32.const 1242
                i32.add
                local.set 48
                local.get 48
                i64.extend_i32_u
                local.set 49
                local.get 47
                local.set 50
                i32.const 310
                local.set 51
                local.get 49
                i32.wrap_i64
                local.get 50
                i32.wrap_i64
                local.get 51
                memory.copy
                block ;; label = @7
                  local.get 2
                  local.get 0
                  i32.const 1242
                  i32.add
                  local.set 52
                  local.get 52
                  i64.load align=1
                  i64.add
                  local.set 2
                  local.get 0
                  i32.const 1242
                  i32.add
                  local.set 53
                  local.get 53
                  i32.const 8
                  i32.add
                  local.set 54
                  local.get 54
                  i64.load16_u align=1
                  i64.const 2
                  i64.eq
                  i32.eqz
                  if ;; label = @8
                    i32.const 1
                    i32.const 1546
                    i32.const 85
                    i32.const 11
                    call 6
                    unreachable
                  end
                end
                local.get 44
                i64.const 1
                i64.add
                local.set 44
                br 0 (;@6;)
              end
            end
            local.get 2
            i64.const 14
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 1631
              i32.const 85
              i32.const 12
              call 6
              unreachable
            end
            local.get 0
            i32.const 621
            i32.add
            local.set 55
            local.get 55
            i64.load8_u offset=620
            i64.const 9
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 1716
              i32.const 85
              i32.const 12
              call 6
              unreachable
            end
          end
          local.get 14
          i64.const 1
          i64.add
          local.set 14
          br 0 (;@3;)
        end
      end
      i32.const 8
      i64.load align=1
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1801
        i32.const 85
        i32.const 14
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      local.set 56
      call 0
      local.set 57
      local.get 57
      i32.const 1886
      i32.const 7
      call 4
      local.get 57
      local.get 56
      i32.const 0
      call 1
      local.get 57
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32 i64)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_iteration_fields.goosefields=")
)
