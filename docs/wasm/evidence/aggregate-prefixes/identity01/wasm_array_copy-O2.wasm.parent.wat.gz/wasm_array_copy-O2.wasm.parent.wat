(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (type (;13;) (func (param i64 i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (memory (;5;) 1 65536)
  (memory (;6;) 1 65536)
  (memory (;7;) 1 65536)
  (memory (;8;) 1 65536)
  (memory (;9;) 1 65536)
  (memory (;10;) 1 65536)
  (memory (;11;) 1 65536)
  (memory (;12;) 1 65536)
  (memory (;13;) 1 65536)
  (memory (;14;) 1 65536)
  (memory (;15;) 1 65536)
  (memory (;16;) 1 65536)
  (memory (;17;) 1 65536)
  (global (;0;) (mut i32) i32.const 5504)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (global (;5;) (mut i32) i32.const 1)
  (global (;6;) (mut i32) i32.const 1)
  (global (;7;) (mut i32) i32.const 1)
  (global (;8;) (mut i32) i32.const 1)
  (global (;9;) (mut i32) i32.const 1)
  (global (;10;) (mut i32) i32.const 1)
  (global (;11;) (mut i32) i32.const 1)
  (global (;12;) (mut i32) i32.const 1)
  (global (;13;) (mut i32) i32.const 1)
  (global (;14;) (mut i32) i32.const 1)
  (global (;15;) (mut i32) i32.const 1)
  (global (;16;) (mut i32) i32.const 1)
  (global (;17;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "data_memory_5" (memory 5))
  (export "data_memory_6" (memory 6))
  (export "data_memory_7" (memory 7))
  (export "data_memory_8" (memory 8))
  (export "data_memory_9" (memory 9))
  (export "data_memory_10" (memory 10))
  (export "data_memory_11" (memory 11))
  (export "data_memory_12" (memory 12))
  (export "data_memory_13" (memory 13))
  (export "data_memory_14" (memory 14))
  (export "data_memory_15" (memory 15))
  (export "data_memory_16" (memory 16))
  (export "data_memory_17" (memory 17))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 16
      i32.const 69
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 85
        i32.const 69
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 f64 i64 i32 i64 f64 f64 i64 i32 i64 f64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 f64 i32 i64 i32 i64 i32 i64 i64 i64 i64 f64 i32 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 218
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 8
      i64.load align=1
      call $copied.1
      local.set 12
      call 0
      local.set 13
      local.get 13
      i32.const 154
      i32.const 7
      call 4
      local.get 13
      local.get 12
      i32.const 0
      call 1
      local.get 13
      call 5
      i32.const 1
      local.set 14
      i32.const 28
      call $goose.reserve_memory.1
      local.set 15
      local.get 14
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 15
      i64.extend_i32_u
      i64.or
      local.set 16
      local.get 16
      local.set 1
      local.get 16
      i64.const 3
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 1 align=1
      i64.const 1
      local.set 18
      local.get 15
      i32.const 4
      i32.add
      local.get 18
      i64.store 1 align=1
      i64.const 2
      local.set 18
      local.get 15
      i32.const 12
      i32.add
      local.get 18
      i64.store 1 align=1
      i64.const 3
      local.set 18
      local.get 15
      i32.const 20
      i32.add
      local.get 18
      i64.store 1 align=1
      local.get 1
      local.set 19
      local.get 19
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 22
      local.get 22
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 161
        i32.const 69
        i32.const 12
        call 6
        unreachable
      end
      local.get 22
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 20
      local.get 19
      local.set 21
      i32.const 2
      local.set 24
      local.get 20
      call $goose.reserve_memory.2
      local.set 25
      local.get 24
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 25
      i64.extend_i32_u
      i64.or
      local.set 23
      local.get 23
      local.set 2
      local.get 23
      i32.wrap_i64
      local.get 21
      i32.wrap_i64
      local.get 20
      memory.copy 2 1
      local.get 2
      local.set 26
      local.get 26
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 27
      i64.const 0
      local.set 28
      local.get 28
      local.get 27
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 230
        i32.const 69
        i32.const 12
        call 6
        unreachable
      end
      local.get 26
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 28
      i64.const 8
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 299
        i32.const 69
        i32.const 12
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      local.set 31
      i64.const 90
      local.set 32
      local.get 31
      local.get 32
      local.set 33
      i32.wrap_i64
      local.get 33
      i64.store 2 align=1
      local.get 1
      local.set 34
      local.get 34
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 35
      i64.const 0
      local.set 36
      local.get 34
      local.set 37
      local.get 37
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 36
      i64.const 8
      i64.mul
      i64.add
      local.tee 38
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 368
        i32.const 69
        i32.const 13
        call 6
        unreachable
      end
      local.get 37
      i64.const -4294967296
      i64.and
      local.get 38
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 39
      local.get 2
      local.set 40
      local.get 40
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 41
      i64.const 0
      local.set 42
      local.get 40
      local.set 43
      local.get 43
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 42
      i64.const 8
      i64.mul
      i64.add
      local.tee 44
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 437
        i32.const 69
        i32.const 13
        call 6
        unreachable
      end
      local.get 43
      i64.const -4294967296
      i64.and
      local.get 44
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 45
      local.get 2
      local.set 46
      local.get 46
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 47
      call 0
      local.set 48
      local.get 48
      i32.const 506
      i32.const 9
      call 4
      local.get 48
      local.get 39
      i32.const 0
      call 1
      local.get 48
      i32.const 515
      i32.const 1
      call 4
      local.get 48
      local.get 45
      i32.const 0
      call 1
      local.get 48
      i32.const 516
      i32.const 1
      call 4
      local.get 48
      local.get 47
      i32.const 0
      call 1
      local.get 48
      call 5
      local.get 1
      local.set 49
      local.get 49
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 50
      i64.const 0
      local.set 51
      local.get 49
      local.set 52
      local.get 52
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 51
      i64.const 8
      i64.mul
      i64.add
      local.tee 53
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 517
        i32.const 69
        i32.const 14
        call 6
        unreachable
      end
      local.get 52
      i64.const -4294967296
      i64.and
      local.get 53
      i64.or
      local.get 2
      local.set 54
      local.get 54
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 55
      i64.const 0
      local.set 56
      local.get 54
      local.set 57
      local.get 57
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 56
      i64.const 8
      i64.mul
      i64.add
      local.tee 58
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 586
        i32.const 69
        i32.const 14
        call 6
        unreachable
      end
      local.get 57
      i64.const -4294967296
      i64.and
      local.get 58
      i64.or
      i64.ne
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 655
        i32.const 69
        i32.const 14
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 59
      local.get 59
      i32.const 0
      i32.add
      i64.const 4
      i64.store align=1
      local.get 59
      i32.const 8
      i32.add
      i64.const 5
      i64.store align=1
      local.get 59
      i32.const 16
      i32.add
      i64.const 6
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 60
      i32.const 24
      local.set 61
      local.get 60
      local.set 62
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 63
      local.get 63
      i32.wrap_i64
      local.get 62
      i32.wrap_i64
      local.get 61
      memory.copy
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 64
      i64.const 3
      local.set 65
      i64.const 1
      local.set 66
      local.get 64
      local.set 67
      local.get 67
      i64.const 4294967295
      i64.and
      local.get 66
      i64.const 8
      i64.mul
      i64.add
      local.tee 68
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 724
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 67
      i64.const -4294967296
      i64.and
      local.get 68
      i64.or
      local.set 69
      i64.const 20
      local.set 70
      local.get 69
      local.get 70
      local.set 71
      i32.wrap_i64
      local.get 71
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 72
      i64.const 3
      local.set 73
      i64.const 1
      local.set 74
      local.get 72
      local.set 75
      local.get 75
      i64.const 4294967295
      i64.and
      local.get 74
      i64.const 8
      i64.mul
      i64.add
      local.tee 76
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 793
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 75
      i64.const -4294967296
      i64.and
      local.get 76
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 77
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 78
      i64.const 3
      local.set 79
      i64.const 1
      local.set 80
      local.get 78
      local.set 81
      local.get 81
      i64.const 4294967295
      i64.and
      local.get 80
      i64.const 8
      i64.mul
      i64.add
      local.tee 82
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 862
        i32.const 69
        i32.const 16
        call 6
        unreachable
      end
      local.get 81
      i64.const -4294967296
      i64.and
      local.get 82
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 83
      call 0
      local.set 84
      local.get 84
      i32.const 931
      i32.const 6
      call 4
      local.get 84
      local.get 77
      i32.const 0
      call 1
      local.get 84
      i32.const 937
      i32.const 1
      call 4
      local.get 84
      local.get 83
      i32.const 0
      call 1
      local.get 84
      call 5
      local.get 0
      i32.const 48
      i32.add
      local.set 85
      local.get 85
      i64.const 0
      i64.store8
      i64.const 10
      local.set 86
      local.get 85
      i64.load8_u
      local.set 87
      local.get 87
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 938
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 85
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 89
      local.get 89
      i64.const 4294967295
      i64.and
      local.get 87
      i64.const 8
      i64.mul
      i64.add
      local.tee 90
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1007
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 89
      i64.const -4294967296
      i64.and
      local.get 90
      i64.or
      local.tee 91
      local.get 86
      local.set 92
      i32.wrap_i64
      local.get 92
      i64.store align=1
      local.get 85
      local.get 87
      i64.const 1
      i64.add
      i64.store8
      i64.const 11
      local.set 93
      local.get 85
      i64.load8_u
      local.set 94
      local.get 94
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1076
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 85
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 96
      local.get 96
      i64.const 4294967295
      i64.and
      local.get 94
      i64.const 8
      i64.mul
      i64.add
      local.tee 97
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1145
        i32.const 69
        i32.const 17
        call 6
        unreachable
      end
      local.get 96
      i64.const -4294967296
      i64.and
      local.get 97
      i64.or
      local.tee 98
      local.get 93
      local.set 99
      i32.wrap_i64
      local.get 99
      i64.store align=1
      local.get 85
      local.get 94
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 48
      i32.add
      i64.extend_i32_u
      local.set 100
      i32.const 33
      local.set 101
      local.get 100
      local.set 102
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 103
      local.get 103
      i32.wrap_i64
      local.get 102
      i32.wrap_i64
      local.get 101
      memory.copy
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 104
      i64.const 12
      local.set 105
      local.get 104
      i32.wrap_i64
      i64.load8_u
      local.set 106
      local.get 106
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1214
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 104
      local.set 108
      local.get 108
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 106
      i64.const 8
      i64.mul
      i64.add
      local.tee 109
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1283
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 109
      i64.or
      local.tee 110
      local.get 105
      local.set 111
      i32.wrap_i64
      local.get 111
      i64.store align=1
      local.get 104
      local.get 106
      i64.const 1
      i64.add
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store8
      local.get 110
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 48
      i32.add
      i64.extend_i32_u
      local.set 112
      local.get 112
      i32.wrap_i64
      i64.load8_u
      local.set 113
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 114
      local.get 114
      i32.wrap_i64
      i64.load8_u
      local.set 115
      local.get 0
      i32.const 81
      i32.add
      i64.extend_i32_u
      local.set 116
      local.get 116
      i32.wrap_i64
      i64.load8_u
      local.set 117
      i64.const 2
      local.set 118
      local.get 118
      local.get 117
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1352
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 116
      local.set 119
      local.get 119
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 118
      i64.const 8
      i64.mul
      i64.add
      local.tee 120
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1421
        i32.const 69
        i32.const 18
        call 6
        unreachable
      end
      local.get 119
      i64.const -4294967296
      i64.and
      local.get 120
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 121
      call 0
      local.set 122
      local.get 122
      i32.const 1490
      i32.const 8
      call 4
      local.get 122
      local.get 113
      i32.const 0
      call 1
      local.get 122
      i32.const 1498
      i32.const 1
      call 4
      local.get 122
      local.get 115
      i32.const 0
      call 1
      local.get 122
      i32.const 1499
      i32.const 1
      call 4
      local.get 122
      local.get 121
      i32.const 0
      call 1
      local.get 122
      call 5
      i64.const 5
      local.set 123
      local.get 123
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 12
        i32.const 1500
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 123
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 1569
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      i32.const 3
      local.set 124
      local.get 123
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      call $goose.reserve_memory.3
      local.set 125
      local.get 124
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 125
      i64.extend_i32_u
      i64.or
      local.set 126
      local.get 126
      local.set 3
      local.get 126
      local.get 123
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 3 align=1
      local.get 126
      i64.const 0
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 3 offset=4 align=1
      local.get 3
      local.set 127
      i64.const 30
      local.set 128
      local.get 127
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 129
      local.get 129
      local.get 127
      i32.wrap_i64
      i64.load32_u 3 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1638
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 127
      local.set 131
      local.get 131
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 129
      i64.const 8
      i64.mul
      i64.add
      local.tee 132
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1707
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 131
      i64.const -4294967296
      i64.and
      local.get 132
      i64.or
      local.tee 133
      local.get 128
      local.set 134
      i32.wrap_i64
      local.get 134
      i64.store 3 align=1
      local.get 127
      local.get 129
      i64.const 1
      i64.add
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 3 offset=4 align=1
      local.get 133
      i32.wrap_i64
      i64.load 3 align=1
      drop
      local.get 3
      local.set 135
      i64.const 31
      local.set 136
      local.get 135
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 137
      local.get 137
      local.get 135
      i32.wrap_i64
      i64.load32_u 3 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1776
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 135
      local.set 139
      local.get 139
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 137
      i64.const 8
      i64.mul
      i64.add
      local.tee 140
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1845
        i32.const 69
        i32.const 19
        call 6
        unreachable
      end
      local.get 139
      i64.const -4294967296
      i64.and
      local.get 140
      i64.or
      local.tee 141
      local.get 136
      local.set 142
      i32.wrap_i64
      local.get 142
      i64.store 3 align=1
      local.get 135
      local.get 137
      i64.const 1
      i64.add
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 3 offset=4 align=1
      local.get 141
      i32.wrap_i64
      i64.load 3 align=1
      drop
      local.get 3
      local.set 143
      local.get 143
      i32.wrap_i64
      i64.load32_u 3 align=1
      local.set 146
      local.get 146
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 1914
        i32.const 69
        i32.const 20
        call 6
        unreachable
      end
      local.get 146
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      local.set 144
      local.get 143
      local.set 145
      i32.const 4
      local.set 148
      local.get 144
      call $goose.reserve_memory.4
      local.set 149
      local.get 148
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 149
      i64.extend_i32_u
      i64.or
      local.set 147
      local.get 147
      local.set 4
      local.get 147
      i32.wrap_i64
      local.get 145
      i32.wrap_i64
      local.get 144
      memory.copy 4 3
      local.get 4
      local.set 150
      i64.const 32
      local.set 151
      local.get 150
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 152
      local.get 152
      local.get 150
      i32.wrap_i64
      i64.load32_u 4 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1983
        i32.const 69
        i32.const 20
        call 6
        unreachable
      end
      local.get 150
      local.set 154
      local.get 154
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 152
      i64.const 8
      i64.mul
      i64.add
      local.tee 155
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2052
        i32.const 69
        i32.const 20
        call 6
        unreachable
      end
      local.get 154
      i64.const -4294967296
      i64.and
      local.get 155
      i64.or
      local.tee 156
      local.get 151
      local.set 157
      i32.wrap_i64
      local.get 157
      i64.store 4 align=1
      local.get 150
      local.get 152
      i64.const 1
      i64.add
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 4 offset=4 align=1
      local.get 156
      i32.wrap_i64
      i64.load 4 align=1
      drop
      local.get 3
      local.set 158
      local.get 158
      i32.wrap_i64
      i64.load32_u 3 offset=4 align=1
      local.set 159
      local.get 4
      local.set 160
      local.get 160
      i32.wrap_i64
      i64.load32_u 4 align=1
      local.set 161
      local.get 4
      local.set 162
      local.get 162
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 163
      local.get 3
      call $copied_cap.2
      local.set 164
      call 0
      local.set 165
      local.get 165
      i32.const 2121
      i32.const 8
      call 4
      local.get 165
      local.get 159
      i32.const 0
      call 1
      local.get 165
      i32.const 2129
      i32.const 1
      call 4
      local.get 165
      local.get 161
      i32.const 0
      call 1
      local.get 165
      i32.const 2130
      i32.const 1
      call 4
      local.get 165
      local.get 163
      i32.const 0
      call 1
      local.get 165
      i32.const 2131
      i32.const 1
      call 4
      local.get 165
      local.get 164
      i32.const 0
      call 1
      local.get 165
      call 5
      i32.const 5
      local.set 166
      global.get 5
      local.set 167
      local.get 0
      i32.const 114
      i32.add
      local.set 168
      local.get 168
      local.get 166
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 167
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 168
      i64.const 0
      i64.store offset=8 align=1
      i64.const 40
      local.set 169
      local.get 168
      i64.load offset=8 align=1
      local.set 170
      i32.const 8
      call $goose.reserve_memory.5
      local.set 171
      local.get 168
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 171
      i64.extend_i32_u
      i64.or
      local.tee 172
      local.get 169
      local.set 173
      i32.wrap_i64
      local.get 173
      i64.store 5 align=1
      local.get 168
      local.get 170
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i64.const 41
      local.set 174
      local.get 168
      i64.load offset=8 align=1
      local.set 175
      i32.const 8
      call $goose.reserve_memory.5
      local.set 176
      local.get 168
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 176
      i64.extend_i32_u
      i64.or
      local.tee 177
      local.get 174
      local.set 178
      i32.wrap_i64
      local.get 178
      i64.store 5 align=1
      local.get 168
      local.get 175
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 114
      i32.add
      local.set 179
      local.get 179
      i64.load offset=8 align=1
      local.set 182
      local.get 182
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2132
        i32.const 69
        i32.const 22
        call 6
        unreachable
      end
      local.get 182
      i64.const 8
      i64.mul
      i32.wrap_i64
      local.set 180
      local.get 179
      i64.load align=1
      local.set 181
      i32.const 6
      local.set 184
      local.get 180
      call $goose.reserve_memory.6
      local.set 185
      local.get 184
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 185
      i64.extend_i32_u
      i64.or
      local.set 183
      local.get 0
      i32.const 130
      i32.add
      local.get 183
      i64.store align=1
      local.get 0
      i32.const 130
      i32.add
      local.get 182
      i64.store offset=8 align=1
      local.get 183
      i32.wrap_i64
      local.get 181
      i32.wrap_i64
      local.get 180
      memory.copy 6 5
      local.get 0
      i32.const 130
      i32.add
      local.set 186
      i64.const 42
      local.set 187
      local.get 186
      i64.load offset=8 align=1
      local.set 188
      i32.const 8
      call $goose.reserve_memory.6
      local.set 189
      local.get 186
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 189
      i64.extend_i32_u
      i64.or
      local.tee 190
      local.get 187
      local.set 191
      i32.wrap_i64
      local.get 191
      i64.store 6 align=1
      local.get 186
      local.get 188
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 190
      i32.wrap_i64
      i64.load 6 align=1
      drop
      local.get 0
      i32.const 114
      i32.add
      local.set 192
      local.get 192
      i64.load offset=8 align=1
      local.set 193
      local.get 0
      i32.const 130
      i32.add
      local.set 194
      local.get 194
      i64.load offset=8 align=1
      local.set 195
      local.get 0
      i32.const 130
      i32.add
      local.set 196
      local.get 196
      i64.load offset=8 align=1
      local.set 197
      i64.const 2
      local.set 198
      local.get 198
      local.get 197
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2201
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 196
      i64.load align=1
      local.set 199
      local.get 199
      i64.const 4294967295
      i64.and
      local.get 198
      i64.const 8
      i64.mul
      i64.add
      local.tee 200
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2270
        i32.const 69
        i32.const 23
        call 6
        unreachable
      end
      local.get 199
      i64.const -4294967296
      i64.and
      local.get 200
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.set 201
      call 0
      local.set 202
      local.get 202
      i32.const 2339
      i32.const 5
      call 4
      local.get 202
      local.get 193
      i32.const 0
      call 1
      local.get 202
      i32.const 2344
      i32.const 1
      call 4
      local.get 202
      local.get 195
      i32.const 0
      call 1
      local.get 202
      i32.const 2345
      i32.const 1
      call 4
      local.get 202
      local.get 201
      i32.const 0
      call 1
      local.get 202
      call 5
      i32.const 7
      local.set 203
      global.get 7
      local.set 204
      local.get 0
      i32.const 146
      i32.add
      local.set 205
      local.get 205
      local.get 203
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 204
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 205
      i64.const 0
      i64.store offset=8 align=1
      f64.const -0x0p+0 (;=-0;)
      local.set 206
      local.get 205
      i64.load offset=8 align=1
      local.set 207
      i32.const 8
      call $goose.reserve_memory.7
      local.set 208
      local.get 205
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 208
      i64.extend_i32_u
      i64.or
      local.tee 209
      local.get 206
      local.set 210
      i32.wrap_i64
      local.get 210
      f64.store 7 align=1
      local.get 205
      local.get 207
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      f64.const 0x1.8p+0 (;=1.5;)
      local.set 211
      local.get 205
      i64.load offset=8 align=1
      local.set 212
      i32.const 8
      call $goose.reserve_memory.7
      local.set 213
      local.get 205
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 213
      i64.extend_i32_u
      i64.or
      local.tee 214
      local.get 211
      local.set 215
      i32.wrap_i64
      local.get 215
      f64.store 7 align=1
      local.get 205
      local.get 212
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 146
      i32.add
      local.set 216
      local.get 216
      i64.load offset=8 align=1
      local.set 219
      local.get 219
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2346
        i32.const 69
        i32.const 24
        call 6
        unreachable
      end
      local.get 219
      i64.const 8
      i64.mul
      i32.wrap_i64
      local.set 217
      local.get 216
      i64.load align=1
      local.set 218
      i32.const 8
      local.set 221
      local.get 217
      call $goose.reserve_memory.8
      local.set 222
      local.get 221
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 222
      i64.extend_i32_u
      i64.or
      local.set 220
      local.get 0
      i32.const 162
      i32.add
      local.get 220
      i64.store align=1
      local.get 0
      i32.const 162
      i32.add
      local.get 219
      i64.store offset=8 align=1
      local.get 220
      i32.wrap_i64
      local.get 218
      i32.wrap_i64
      local.get 217
      memory.copy 8 7
      local.get 0
      i32.const 162
      i32.add
      local.set 223
      local.get 223
      i64.load offset=8 align=1
      local.set 224
      local.get 224
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 2415
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 224
      i64.const 1
      i64.sub
      local.set 224
      local.get 223
      i64.load align=1
      local.set 225
      local.get 225
      i64.const 4294967295
      i64.and
      local.get 224
      i64.const 8
      i64.mul
      i64.add
      local.tee 226
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2484
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 225
      i64.const -4294967296
      i64.and
      local.get 226
      i64.or
      local.set 227
      local.get 227
      i32.wrap_i64
      f64.load 8 align=1
      local.set 228
      local.get 227
      i32.wrap_i64
      global.set 8
      local.get 223
      local.get 224
      i64.store offset=8 align=1
      local.get 228
      drop
      local.get 0
      i32.const 146
      i32.add
      local.set 229
      local.get 229
      i64.load offset=8 align=1
      local.set 230
      local.get 0
      i32.const 162
      i32.add
      local.set 231
      local.get 231
      i64.load offset=8 align=1
      local.set 232
      local.get 0
      i32.const 162
      i32.add
      local.set 233
      local.get 233
      i64.load offset=8 align=1
      local.set 234
      i64.const 0
      local.set 235
      local.get 235
      local.get 234
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2553
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 233
      i64.load align=1
      local.set 236
      local.get 236
      i64.const 4294967295
      i64.and
      local.get 235
      i64.const 8
      i64.mul
      i64.add
      local.tee 237
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2622
        i32.const 69
        i32.const 25
        call 6
        unreachable
      end
      local.get 236
      i64.const -4294967296
      i64.and
      local.get 237
      i64.or
      i32.wrap_i64
      f64.load 8 align=1
      local.set 238
      call 0
      local.set 239
      local.get 239
      i32.const 2691
      i32.const 7
      call 4
      local.get 239
      local.get 230
      i32.const 0
      call 1
      local.get 239
      i32.const 2698
      i32.const 1
      call 4
      local.get 239
      local.get 232
      i32.const 0
      call 1
      local.get 239
      i32.const 2699
      i32.const 1
      call 4
      local.get 239
      local.get 238
      i32.const 64
      call 2
      local.get 239
      call 5
      i64.const 50
      local.set 240
      local.get 0
      i32.const 178
      i32.add
      local.get 240
      i64.store align=1
      i32.const 9
      local.set 241
      i32.const 12
      call $goose.reserve_memory.9
      local.set 242
      local.get 241
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 242
      i64.extend_i32_u
      i64.or
      local.set 243
      local.get 243
      local.set 5
      local.get 243
      i64.const 1
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store32 9 align=1
      local.get 0
      i32.const 178
      i32.add
      i64.extend_i32_u
      local.set 244
      local.get 242
      i32.const 4
      i32.add
      local.get 244
      i64.store 9 align=1
      local.get 5
      local.set 245
      local.get 245
      i32.wrap_i64
      i64.load32_u 9 align=1
      local.set 248
      local.get 248
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2700
        i32.const 69
        i32.const 26
        call 6
        unreachable
      end
      local.get 248
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 246
      local.get 245
      local.set 247
      i32.const 10
      local.set 250
      local.get 246
      call $goose.reserve_memory.10
      local.set 251
      local.get 250
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 251
      i64.extend_i32_u
      i64.or
      local.set 249
      local.get 249
      local.set 6
      local.get 249
      i32.wrap_i64
      local.get 247
      i32.wrap_i64
      local.get 246
      memory.copy 10 9
      local.get 6
      local.set 252
      local.get 252
      i32.wrap_i64
      i64.load32_u 10 align=1
      local.set 253
      i64.const 0
      local.set 254
      local.get 254
      local.get 253
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2769
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 252
      local.set 255
      local.get 255
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 254
      i64.const 8
      i64.mul
      i64.add
      local.tee 256
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2838
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 255
      i64.const -4294967296
      i64.and
      local.get 256
      i64.or
      local.set 257
      local.get 257
      i32.wrap_i64
      i64.load 10 align=1
      local.tee 258
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2907
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 258
      local.set 257
      local.get 257
      call $goose.memory_op.41
      i64.const 3
      i64.add
      local.set 259
      local.get 257
      local.get 259
      call $goose.memory_op.55
      local.get 5
      local.set 260
      local.get 260
      i32.wrap_i64
      i64.load32_u 9 align=1
      local.set 261
      i64.const 0
      local.set 262
      local.get 260
      local.set 263
      local.get 263
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 262
      i64.const 8
      i64.mul
      i64.add
      local.tee 264
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2976
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 263
      i64.const -4294967296
      i64.and
      local.get 264
      i64.or
      i32.wrap_i64
      i64.load 9 align=1
      local.get 6
      local.set 265
      local.get 265
      i32.wrap_i64
      i64.load32_u 10 align=1
      local.set 266
      i64.const 0
      local.set 267
      local.get 265
      local.set 268
      local.get 268
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 267
      i64.const 8
      i64.mul
      i64.add
      local.tee 269
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3045
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 268
      i64.const -4294967296
      i64.and
      local.get 269
      i64.or
      i32.wrap_i64
      i64.load 10 align=1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3114
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 178
      i32.add
      i64.load align=1
      local.set 270
      local.get 5
      local.set 271
      local.get 271
      i32.wrap_i64
      i64.load32_u 9 align=1
      local.set 272
      i64.const 0
      local.set 273
      local.get 271
      local.set 274
      local.get 274
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 273
      i64.const 8
      i64.mul
      i64.add
      local.tee 275
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3183
        i32.const 69
        i32.const 27
        call 6
        unreachable
      end
      local.get 274
      i64.const -4294967296
      i64.and
      local.get 275
      i64.or
      i32.wrap_i64
      i64.load 9 align=1
      local.tee 276
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3252
        i32.const 69
        i32.const 26
        call 6
        unreachable
      end
      local.get 276
      call $goose.memory_op.41
      local.set 277
      call 0
      local.set 278
      local.get 278
      i32.const 3321
      i32.const 5
      call 4
      local.get 278
      local.get 270
      i32.const 0
      call 1
      local.get 278
      i32.const 3326
      i32.const 1
      call 4
      local.get 278
      local.get 277
      i32.const 0
      call 1
      local.get 278
      call 5
      block ;; label = @2
        local.get 1
        local.set 8
        local.get 8
        local.set 279
        br 0 (;@2;)
      end
      local.get 279
      local.tee 280
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3327
        i32.const 69
        i32.const 9
        call 6
        unreachable
      end
      local.get 280
      local.set 281
      local.get 281
      call $goose.memory_op.53
      local.set 284
      local.get 284
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 3396
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 284
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 282
      local.get 281
      local.set 283
      i32.const 11
      local.set 286
      local.get 282
      call $goose.reserve_memory.11
      local.set 287
      local.get 286
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 287
      i64.extend_i32_u
      i64.or
      local.set 285
      local.get 285
      local.set 7
      local.get 285
      local.get 283
      local.get 282
      call $goose.copy_memory
      local.get 7
      local.set 288
      local.get 288
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 289
      i64.const 2
      local.set 290
      local.get 290
      local.get 289
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3465
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 288
      local.set 291
      local.get 291
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 290
      i64.const 8
      i64.mul
      i64.add
      local.tee 292
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3534
        i32.const 69
        i32.const 28
        call 6
        unreachable
      end
      local.get 291
      i64.const -4294967296
      i64.and
      local.get 292
      i64.or
      local.set 293
      i64.const 70
      local.set 294
      local.get 293
      local.get 294
      local.set 295
      i32.wrap_i64
      local.get 295
      i64.store 11 align=1
      local.get 1
      local.set 296
      local.get 296
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 297
      i64.const 2
      local.set 298
      local.get 296
      local.set 299
      local.get 299
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 298
      i64.const 8
      i64.mul
      i64.add
      local.tee 300
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3603
        i32.const 69
        i32.const 29
        call 6
        unreachable
      end
      local.get 299
      i64.const -4294967296
      i64.and
      local.get 300
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 301
      local.get 7
      local.set 302
      local.get 302
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 303
      i64.const 2
      local.set 304
      local.get 302
      local.set 305
      local.get 305
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 304
      i64.const 8
      i64.mul
      i64.add
      local.tee 306
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3672
        i32.const 69
        i32.const 29
        call 6
        unreachable
      end
      local.get 305
      i64.const -4294967296
      i64.and
      local.get 306
      i64.or
      i32.wrap_i64
      i64.load 11 align=1
      local.set 307
      call 0
      local.set 308
      local.get 308
      i32.const 3741
      i32.const 9
      call 4
      local.get 308
      local.get 301
      i32.const 0
      call 1
      local.get 308
      i32.const 3750
      i32.const 1
      call 4
      local.get 308
      local.get 307
      i32.const 0
      call 1
      local.get 308
      call 5
      i32.const 12
      local.set 309
      i32.const 8
      call $goose.reserve_memory.12
      local.set 310
      local.get 309
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 310
      i64.extend_i32_u
      i64.or
      local.set 311
      local.get 311
      local.set 9
      local.get 311
      i64.const 0
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store 12 align=1
      local.get 9
      local.set 312
      local.get 312
      i32.wrap_i64
      i64.load 12 align=1
      local.set 315
      local.get 315
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 3751
        i32.const 69
        i32.const 30
        call 6
        unreachable
      end
      local.get 315
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      local.set 313
      local.get 312
      local.set 314
      i32.const 13
      local.set 317
      local.get 313
      call $goose.reserve_memory.13
      local.set 318
      local.get 317
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 318
      i64.extend_i32_u
      i64.or
      local.set 316
      local.get 316
      local.set 10
      local.get 316
      i32.wrap_i64
      local.get 314
      i32.wrap_i64
      local.get 313
      memory.copy 13 12
      local.get 10
      local.set 319
      local.get 319
      i32.wrap_i64
      i64.load 13 align=1
      local.set 320
      call 0
      local.set 321
      local.get 321
      i32.const 3820
      i32.const 6
      call 4
      local.get 321
      local.get 320
      i32.const 0
      call 1
      local.get 321
      call 5
      i32.const 14
      local.set 322
      global.get 14
      local.set 323
      local.get 0
      i32.const 186
      i32.add
      local.set 324
      local.get 324
      local.get 322
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 323
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 324
      i64.const 0
      i64.store offset=8 align=1
      i64.const 0
      local.set 325
      i64.const 70000
      local.set 326
      block ;; label = @2
        loop ;; label = @3
          local.get 325
          local.get 326
          i64.ge_s
          br_if 1 (;@2;)
          local.get 325
          local.set 11
          block ;; label = @4
            local.get 0
            i32.const 186
            i32.add
            local.set 327
            i64.const 120
            local.set 328
            local.get 327
            i64.load offset=8 align=1
            local.set 329
            i32.const 1
            call $goose.reserve_memory.14
            local.set 330
            local.get 327
            i64.load align=1
            i64.const -4294967296
            i64.and
            local.get 330
            i64.extend_i32_u
            i64.or
            local.tee 331
            local.get 328
            local.set 332
            i32.wrap_i64
            local.get 332
            i64.store8 14
            local.get 327
            local.get 329
            i64.const 1
            i64.add
            i64.store offset=8 align=1
            local.get 331
            i32.wrap_i64
            i64.load8_u 14
            drop
          end
          local.get 325
          i64.const 1
          i64.add
          local.set 325
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 186
      i32.add
      local.set 333
      local.get 333
      i64.load offset=8 align=1
      local.set 336
      local.get 336
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 3826
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 336
      i64.const 1
      i64.mul
      i32.wrap_i64
      local.set 334
      local.get 333
      i64.load align=1
      local.set 335
      i32.const 15
      local.set 338
      local.get 334
      call $goose.reserve_memory.15
      local.set 339
      local.get 338
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 339
      i64.extend_i32_u
      i64.or
      local.set 337
      local.get 0
      i32.const 202
      i32.add
      local.get 337
      i64.store align=1
      local.get 0
      i32.const 202
      i32.add
      local.get 336
      i64.store offset=8 align=1
      local.get 337
      i32.wrap_i64
      local.get 335
      i32.wrap_i64
      local.get 334
      memory.copy 15 14
      local.get 0
      i32.const 202
      i32.add
      local.set 340
      local.get 340
      i64.load offset=8 align=1
      local.set 341
      i64.const 0
      local.set 342
      local.get 342
      local.get 341
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3895
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 340
      i64.load align=1
      local.set 343
      local.get 343
      i64.const 4294967295
      i64.and
      local.get 342
      i64.const 1
      i64.mul
      i64.add
      local.tee 344
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3964
        i32.const 69
        i32.const 32
        call 6
        unreachable
      end
      local.get 343
      i64.const -4294967296
      i64.and
      local.get 344
      i64.or
      local.set 345
      i64.const 121
      local.set 346
      local.get 345
      local.get 346
      local.set 347
      i32.wrap_i64
      local.get 347
      i64.store8 15
      local.get 0
      i32.const 186
      i32.add
      local.set 348
      local.get 348
      i64.load offset=8 align=1
      local.set 349
      local.get 0
      i32.const 186
      i32.add
      local.set 350
      local.get 350
      i64.load offset=8 align=1
      local.set 351
      i64.const 0
      local.set 352
      local.get 350
      i64.load align=1
      local.set 353
      local.get 353
      i64.const 4294967295
      i64.and
      local.get 352
      i64.const 1
      i64.mul
      i64.add
      local.tee 354
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4033
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 353
      i64.const -4294967296
      i64.and
      local.get 354
      i64.or
      i32.wrap_i64
      i64.load8_u 14
      local.set 355
      local.get 0
      i32.const 202
      i32.add
      local.set 356
      local.get 356
      i64.load offset=8 align=1
      local.set 357
      local.get 0
      i32.const 202
      i32.add
      local.set 358
      local.get 358
      i64.load offset=8 align=1
      local.set 359
      i64.const 0
      local.set 360
      local.get 358
      i64.load align=1
      local.set 361
      local.get 361
      i64.const 4294967295
      i64.and
      local.get 360
      i64.const 1
      i64.mul
      i64.add
      local.tee 362
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4102
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 361
      i64.const -4294967296
      i64.and
      local.get 362
      i64.or
      i32.wrap_i64
      i64.load8_u 15
      local.set 363
      local.get 0
      i32.const 202
      i32.add
      local.set 364
      local.get 364
      i64.load offset=8 align=1
      local.set 365
      i64.const 69999
      local.set 366
      local.get 366
      local.get 365
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4171
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 364
      i64.load align=1
      local.set 367
      local.get 367
      i64.const 4294967295
      i64.and
      local.get 366
      i64.const 1
      i64.mul
      i64.add
      local.tee 368
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4240
        i32.const 69
        i32.const 33
        call 6
        unreachable
      end
      local.get 367
      i64.const -4294967296
      i64.and
      local.get 368
      i64.or
      i32.wrap_i64
      i64.load8_u 15
      local.set 369
      call 0
      local.set 370
      local.get 370
      i32.const 4309
      i32.const 6
      call 4
      local.get 370
      local.get 349
      i32.const 0
      call 1
      local.get 370
      i32.const 4315
      i32.const 1
      call 4
      local.get 370
      local.get 355
      i32.const 1
      call 1
      local.get 370
      i32.const 4316
      i32.const 1
      call 4
      local.get 370
      local.get 357
      i32.const 0
      call 1
      local.get 370
      i32.const 4317
      i32.const 1
      call 4
      local.get 370
      local.get 363
      i32.const 1
      call 1
      local.get 370
      i32.const 4318
      i32.const 1
      call 4
      local.get 370
      local.get 369
      i32.const 1
      call 1
      local.get 370
      call 5
      local.get 1
      call $copied.4
      local.set 371
      local.get 1
      local.set 372
      local.get 372
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 373
      i64.const 0
      local.set 374
      local.get 372
      local.set 375
      local.get 375
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 374
      i64.const 8
      i64.mul
      i64.add
      local.tee 376
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4319
        i32.const 69
        i32.const 34
        call 6
        unreachable
      end
      local.get 375
      i64.const -4294967296
      i64.and
      local.get 376
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 377
      i32.const 8
      i64.load align=1
      local.set 378
      local.get 378
      i32.wrap_i64
      i64.load32_u 17 align=1
      local.set 379
      i64.const 0
      local.set 380
      local.get 380
      local.get 379
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4388
        i32.const 69
        i32.const 34
        call 6
        unreachable
      end
      local.get 378
      local.set 381
      local.get 381
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 380
      i64.const 8
      i64.mul
      i64.add
      local.tee 382
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4457
        i32.const 69
        i32.const 34
        call 6
        unreachable
      end
      local.get 381
      i64.const -4294967296
      i64.and
      local.get 382
      i64.or
      i32.wrap_i64
      i64.load 17 align=1
      local.set 383
      call 0
      local.set 384
      local.get 384
      i32.const 4526
      i32.const 6
      call 4
      local.get 384
      local.get 371
      i32.const 0
      call 1
      local.get 384
      i32.const 4532
      i32.const 1
      call 4
      local.get 384
      local.get 377
      i32.const 0
      call 1
      local.get 384
      i32.const 4533
      i32.const 1
      call 4
      local.get 384
      local.get 383
      i32.const 0
      call 1
      local.get 384
      call 5
      local.get 339
      global.set 15
      local.get 323
      global.set 14
      local.get 318
      global.set 13
      local.get 310
      global.set 12
      local.get 287
      global.set 11
      local.get 251
      global.set 10
      local.get 242
      global.set 9
      local.get 222
      global.set 8
      local.get 204
      global.set 7
      local.get 185
      global.set 6
      local.get 167
      global.set 5
      local.get 149
      global.set 4
      local.get 125
      global.set 3
      local.get 25
      global.set 2
      local.get 15
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $copied.1 (;12;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4534
        i32.const 69
        i32.const 2
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      call $goose.memory_op.53
      local.set 8
      local.get 8
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 4603
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 8
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 6
      local.get 5
      local.set 7
      i32.const 1
      local.set 10
      local.get 6
      call $goose.reserve_memory.1
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 2
      local.get 9
      local.get 7
      local.get 6
      call $goose.copy_memory
      local.get 2
      local.set 12
      local.get 12
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 13
      i64.const 0
      local.set 14
      local.get 14
      local.get 13
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 4672
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 12
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4741
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 100
      i64.add
      local.set 18
      local.get 17
      local.get 18
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store 1 align=1
      local.get 2
      local.set 20
      local.get 20
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.get 2
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 22
      i64.const 0
      local.set 23
      local.get 21
      local.set 24
      local.get 24
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 23
      i64.const 8
      i64.mul
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4810
        i32.const 69
        i32.const 4
        call 6
        unreachable
      end
      local.get 24
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.add
      local.set 3
      local.get 11
      global.set 1
      br 0 (;@1;)
      local.get 11
      global.set 1
    end
    local.get 3
  )
  (func $copied_cap.2 (;13;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4879
        i32.const 69
        i32.const 6
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      call $goose.memory_op.53
      local.set 8
      local.get 8
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 4948
        i32.const 69
        i32.const 7
        call 6
        unreachable
      end
      local.get 8
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      local.set 6
      local.get 5
      local.set 7
      i32.const 5
      local.set 10
      local.get 6
      call $goose.reserve_memory.5
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 2
      local.get 9
      local.get 7
      local.get 6
      call $goose.copy_memory
      local.get 2
      local.set 12
      i64.const 9
      local.set 13
      local.get 12
      i32.wrap_i64
      i64.load32_u 5 offset=4 align=1
      local.set 14
      local.get 14
      local.get 12
      i32.wrap_i64
      i64.load32_u 5 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 5017
        i32.const 69
        i32.const 7
        call 6
        unreachable
      end
      local.get 12
      local.set 16
      local.get 16
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 17
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5086
        i32.const 69
        i32.const 7
        call 6
        unreachable
      end
      local.get 16
      i64.const -4294967296
      i64.and
      local.get 17
      i64.or
      local.tee 18
      local.get 13
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store 5 align=1
      local.get 12
      local.get 14
      i64.const 1
      i64.add
      local.set 20
      i32.wrap_i64
      local.get 20
      i64.store32 5 offset=4 align=1
      local.get 18
      i32.wrap_i64
      i64.load 5 align=1
      drop
      local.get 2
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load32_u 5 align=1
      local.get 2
      local.set 22
      local.get 22
      i32.wrap_i64
      i64.load32_u 5 offset=4 align=1
      i64.add
      local.set 3
      local.get 11
      global.set 5
      br 0 (;@1;)
      local.get 11
      global.set 5
    end
    local.get 3
  )
  (func $copied.4 (;14;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5155
        i32.const 69
        i32.const 2
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      call $goose.memory_op.53
      local.set 8
      local.get 8
      i64.const 536870911
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 5224
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 8
      i64.const 8
      i64.mul
      i64.const 4
      i64.add
      i32.wrap_i64
      local.set 6
      local.get 5
      local.set 7
      i32.const 16
      local.set 10
      local.get 6
      call $goose.reserve_memory.16
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 9
      local.get 9
      local.set 2
      local.get 9
      local.get 7
      local.get 6
      call $goose.copy_memory
      local.get 2
      local.set 12
      local.get 12
      i32.wrap_i64
      i64.load32_u 16 align=1
      local.set 13
      i64.const 0
      local.set 14
      local.get 14
      local.get 13
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 5293
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 12
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 14
      i64.const 8
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5362
        i32.const 69
        i32.const 3
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load 16 align=1
      i64.const 100
      i64.add
      local.set 18
      local.get 17
      local.get 18
      local.set 19
      i32.wrap_i64
      local.get 19
      i64.store 16 align=1
      local.get 2
      local.set 20
      local.get 20
      i32.wrap_i64
      i64.load32_u 16 align=1
      local.get 2
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load32_u 16 align=1
      local.set 22
      i64.const 0
      local.set 23
      local.get 21
      local.set 24
      local.get 24
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 23
      i64.const 8
      i64.mul
      i64.add
      local.tee 25
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5431
        i32.const 69
        i32.const 4
        call 6
        unreachable
      end
      local.get 24
      i64.const -4294967296
      i64.and
      local.get 25
      i64.or
      i32.wrap_i64
      i64.load 16 align=1
      i64.add
      local.set 3
      local.get 11
      global.set 16
      br 0 (;@1;)
      local.get 11
      global.set 16
    end
    local.get 3
  )
  (func $goose.init (;15;) (type 10)
    (local i32 i32 i32 i64 i64 i64 i64)
    i32.const 17
    local.set 1
    i32.const 20
    call $goose.reserve_memory.17
    local.set 2
    local.get 1
    i64.extend_i32_u
    i64.const 32
    i64.shl
    local.get 2
    i64.extend_i32_u
    i64.or
    local.set 3
    local.get 3
    local.set 4
    i32.const 8
    local.get 4
    i64.store align=1
    local.get 3
    i64.const 2
    local.set 5
    i32.wrap_i64
    local.get 5
    i64.store32 17 align=1
    i64.const 7
    local.set 6
    local.get 2
    i32.const 4
    i32.add
    local.get 6
    i64.store 17 align=1
    i64.const 8
    local.set 6
    local.get 2
    i32.const 12
    i32.add
    local.get 6
    i64.store 17 align=1
  )
  (func $goose.start (;16;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.reserve_memory.5 (;21;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 5
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 5
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 5
      i32.sub
      memory.grow 5
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 5
    local.get 1
  )
  (func $goose.reserve_memory.6 (;22;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 6
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 6
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 6
      i32.sub
      memory.grow 6
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 6
    local.get 1
  )
  (func $goose.reserve_memory.7 (;23;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 7
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 7
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 7
      i32.sub
      memory.grow 7
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 7
    local.get 1
  )
  (func $goose.reserve_memory.8 (;24;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 8
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 8
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 8
      i32.sub
      memory.grow 8
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 8
    local.get 1
  )
  (func $goose.reserve_memory.9 (;25;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 9
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 9
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 9
      i32.sub
      memory.grow 9
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 9
    local.get 1
  )
  (func $goose.reserve_memory.10 (;26;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 10
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 10
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 10
      i32.sub
      memory.grow 10
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 10
    local.get 1
  )
  (func $goose.memory_op.41 (;27;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          i64.load align=1
                                          br 18 (;@1;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        i64.load 1 align=1
                                        br 17 (;@1;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      i64.load 2 align=1
                                      br 16 (;@1;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load 3 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load 4 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load 5 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load 6 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load 7 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load 8 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load 9 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load 10 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load 11 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load 12 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load 13 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load 14 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 15 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 16 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 17 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;28;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i64.store align=1
                                          br 18 (;@1;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i64.store 1 align=1
                                        br 17 (;@1;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i64.store 2 align=1
                                      br 16 (;@1;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i64.store 3 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i64.store 4 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i64.store 5 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i64.store 6 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i64.store 7 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i64.store 8 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i64.store 9 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store 10 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store 11 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store 12 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store 13 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store 14 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 15 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 16 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 17 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;29;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          i64.load32_u align=1
                                          br 18 (;@1;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        i64.load32_u 1 align=1
                                        br 17 (;@1;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      i64.load32_u 2 align=1
                                      br 16 (;@1;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load32_u 3 align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load32_u 4 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load32_u 5 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load32_u 6 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load32_u 7 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load32_u 8 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load32_u 9 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load32_u 10 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load32_u 11 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load32_u 12 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load32_u 13 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u 14 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 15 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 16 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 17 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.11 (;30;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 11
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 11
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 11
      i32.sub
      memory.grow 11
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 11
    local.get 1
  )
  (func $goose.copy_memory (;31;) (type 13) (param i64 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            local.get 0
                                            i64.const 32
                                            i64.shr_u
                                            i32.wrap_i64
                                            br_table 0 (;@20;) 1 (;@19;) 2 (;@18;) 3 (;@17;) 4 (;@16;) 5 (;@15;) 6 (;@14;) 7 (;@13;) 8 (;@12;) 9 (;@11;) 10 (;@10;) 11 (;@9;) 12 (;@8;) 13 (;@7;) 14 (;@6;) 15 (;@5;) 16 (;@4;) 17 (;@3;) 18 (;@2;)
                                          end
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            block ;; label = @37
                                                                              block ;; label = @38
                                                                                block ;; label = @39
                                                                                  local.get 1
                                                                                  i64.const 32
                                                                                  i64.shr_u
                                                                                  i32.wrap_i64
                                                                                  br_table 0 (;@39;) 1 (;@38;) 2 (;@37;) 3 (;@36;) 4 (;@35;) 5 (;@34;) 6 (;@33;) 7 (;@32;) 8 (;@31;) 9 (;@30;) 10 (;@29;) 11 (;@28;) 12 (;@27;) 13 (;@26;) 14 (;@25;) 15 (;@24;) 16 (;@23;) 17 (;@22;) 18 (;@21;)
                                                                                end
                                                                                local.get 0
                                                                                i32.wrap_i64
                                                                                local.get 1
                                                                                i32.wrap_i64
                                                                                local.get 2
                                                                                memory.copy
                                                                                br 18 (;@20;)
                                                                              end
                                                                              local.get 0
                                                                              i32.wrap_i64
                                                                              local.get 1
                                                                              i32.wrap_i64
                                                                              local.get 2
                                                                              memory.copy 0 1
                                                                              br 17 (;@20;)
                                                                            end
                                                                            local.get 0
                                                                            i32.wrap_i64
                                                                            local.get 1
                                                                            i32.wrap_i64
                                                                            local.get 2
                                                                            memory.copy 0 2
                                                                            br 16 (;@20;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 0 3
                                                                          br 15 (;@20;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 0 4
                                                                        br 14 (;@20;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 0 5
                                                                      br 13 (;@20;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 0 6
                                                                    br 12 (;@20;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 0 7
                                                                  br 11 (;@20;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 0 8
                                                                br 10 (;@20;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 0 9
                                                              br 9 (;@20;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 0 10
                                                            br 8 (;@20;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 0 11
                                                          br 7 (;@20;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 0 12
                                                        br 6 (;@20;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 0 13
                                                      br 5 (;@20;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 0 14
                                                    br 4 (;@20;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 0 15
                                                  br 3 (;@20;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 0 16
                                                br 2 (;@20;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 0 17
                                              br 1 (;@20;)
                                            end
                                            i32.const 7
                                            i32.const 0
                                            i32.const 0
                                            i32.const 0
                                            call 6
                                            unreachable
                                          end
                                          br 18 (;@1;)
                                        end
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            block ;; label = @37
                                                                              block ;; label = @38
                                                                                local.get 1
                                                                                i64.const 32
                                                                                i64.shr_u
                                                                                i32.wrap_i64
                                                                                br_table 0 (;@38;) 1 (;@37;) 2 (;@36;) 3 (;@35;) 4 (;@34;) 5 (;@33;) 6 (;@32;) 7 (;@31;) 8 (;@30;) 9 (;@29;) 10 (;@28;) 11 (;@27;) 12 (;@26;) 13 (;@25;) 14 (;@24;) 15 (;@23;) 16 (;@22;) 17 (;@21;) 18 (;@20;)
                                                                              end
                                                                              local.get 0
                                                                              i32.wrap_i64
                                                                              local.get 1
                                                                              i32.wrap_i64
                                                                              local.get 2
                                                                              memory.copy 1 0
                                                                              br 18 (;@19;)
                                                                            end
                                                                            local.get 0
                                                                            i32.wrap_i64
                                                                            local.get 1
                                                                            i32.wrap_i64
                                                                            local.get 2
                                                                            memory.copy 1 1
                                                                            br 17 (;@19;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 1 2
                                                                          br 16 (;@19;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 1 3
                                                                        br 15 (;@19;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 1 4
                                                                      br 14 (;@19;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 1 5
                                                                    br 13 (;@19;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 1 6
                                                                  br 12 (;@19;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 1 7
                                                                br 11 (;@19;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 1 8
                                                              br 10 (;@19;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 1 9
                                                            br 9 (;@19;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 1 10
                                                          br 8 (;@19;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 1 11
                                                        br 7 (;@19;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 1 12
                                                      br 6 (;@19;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 1 13
                                                    br 5 (;@19;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 1 14
                                                  br 4 (;@19;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 1 15
                                                br 3 (;@19;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 1 16
                                              br 2 (;@19;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 1 17
                                            br 1 (;@19;)
                                          end
                                          i32.const 7
                                          i32.const 0
                                          i32.const 0
                                          i32.const 0
                                          call 6
                                          unreachable
                                        end
                                        br 17 (;@1;)
                                      end
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            block ;; label = @37
                                                                              local.get 1
                                                                              i64.const 32
                                                                              i64.shr_u
                                                                              i32.wrap_i64
                                                                              br_table 0 (;@37;) 1 (;@36;) 2 (;@35;) 3 (;@34;) 4 (;@33;) 5 (;@32;) 6 (;@31;) 7 (;@30;) 8 (;@29;) 9 (;@28;) 10 (;@27;) 11 (;@26;) 12 (;@25;) 13 (;@24;) 14 (;@23;) 15 (;@22;) 16 (;@21;) 17 (;@20;) 18 (;@19;)
                                                                            end
                                                                            local.get 0
                                                                            i32.wrap_i64
                                                                            local.get 1
                                                                            i32.wrap_i64
                                                                            local.get 2
                                                                            memory.copy 2 0
                                                                            br 18 (;@18;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 2 1
                                                                          br 17 (;@18;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 2 2
                                                                        br 16 (;@18;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 2 3
                                                                      br 15 (;@18;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 2 4
                                                                    br 14 (;@18;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 2 5
                                                                  br 13 (;@18;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 2 6
                                                                br 12 (;@18;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 2 7
                                                              br 11 (;@18;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 2 8
                                                            br 10 (;@18;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 2 9
                                                          br 9 (;@18;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 2 10
                                                        br 8 (;@18;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 2 11
                                                      br 7 (;@18;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 2 12
                                                    br 6 (;@18;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 2 13
                                                  br 5 (;@18;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 2 14
                                                br 4 (;@18;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 2 15
                                              br 3 (;@18;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 2 16
                                            br 2 (;@18;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 2 17
                                          br 1 (;@18;)
                                        end
                                        i32.const 7
                                        i32.const 0
                                        i32.const 0
                                        i32.const 0
                                        call 6
                                        unreachable
                                      end
                                      br 16 (;@1;)
                                    end
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          block ;; label = @36
                                                                            local.get 1
                                                                            i64.const 32
                                                                            i64.shr_u
                                                                            i32.wrap_i64
                                                                            br_table 0 (;@36;) 1 (;@35;) 2 (;@34;) 3 (;@33;) 4 (;@32;) 5 (;@31;) 6 (;@30;) 7 (;@29;) 8 (;@28;) 9 (;@27;) 10 (;@26;) 11 (;@25;) 12 (;@24;) 13 (;@23;) 14 (;@22;) 15 (;@21;) 16 (;@20;) 17 (;@19;) 18 (;@18;)
                                                                          end
                                                                          local.get 0
                                                                          i32.wrap_i64
                                                                          local.get 1
                                                                          i32.wrap_i64
                                                                          local.get 2
                                                                          memory.copy 3 0
                                                                          br 18 (;@17;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 3 1
                                                                        br 17 (;@17;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 3 2
                                                                      br 16 (;@17;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 3 3
                                                                    br 15 (;@17;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 3 4
                                                                  br 14 (;@17;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 3 5
                                                                br 13 (;@17;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 3 6
                                                              br 12 (;@17;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 3 7
                                                            br 11 (;@17;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 3 8
                                                          br 10 (;@17;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 3 9
                                                        br 9 (;@17;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 3 10
                                                      br 8 (;@17;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 3 11
                                                    br 7 (;@17;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 3 12
                                                  br 6 (;@17;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 3 13
                                                br 5 (;@17;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 3 14
                                              br 4 (;@17;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 3 15
                                            br 3 (;@17;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 3 16
                                          br 2 (;@17;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 3 17
                                        br 1 (;@17;)
                                      end
                                      i32.const 7
                                      i32.const 0
                                      i32.const 0
                                      i32.const 0
                                      call 6
                                      unreachable
                                    end
                                    br 15 (;@1;)
                                  end
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        block ;; label = @35
                                                                          local.get 1
                                                                          i64.const 32
                                                                          i64.shr_u
                                                                          i32.wrap_i64
                                                                          br_table 0 (;@35;) 1 (;@34;) 2 (;@33;) 3 (;@32;) 4 (;@31;) 5 (;@30;) 6 (;@29;) 7 (;@28;) 8 (;@27;) 9 (;@26;) 10 (;@25;) 11 (;@24;) 12 (;@23;) 13 (;@22;) 14 (;@21;) 15 (;@20;) 16 (;@19;) 17 (;@18;) 18 (;@17;)
                                                                        end
                                                                        local.get 0
                                                                        i32.wrap_i64
                                                                        local.get 1
                                                                        i32.wrap_i64
                                                                        local.get 2
                                                                        memory.copy 4 0
                                                                        br 18 (;@16;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 4 1
                                                                      br 17 (;@16;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 4 2
                                                                    br 16 (;@16;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 4 3
                                                                  br 15 (;@16;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 4 4
                                                                br 14 (;@16;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 4 5
                                                              br 13 (;@16;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 4 6
                                                            br 12 (;@16;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 4 7
                                                          br 11 (;@16;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 4 8
                                                        br 10 (;@16;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 4 9
                                                      br 9 (;@16;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 4 10
                                                    br 8 (;@16;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 4 11
                                                  br 7 (;@16;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 4 12
                                                br 6 (;@16;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 4 13
                                              br 5 (;@16;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 4 14
                                            br 4 (;@16;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 4 15
                                          br 3 (;@16;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 4 16
                                        br 2 (;@16;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 4 17
                                      br 1 (;@16;)
                                    end
                                    i32.const 7
                                    i32.const 0
                                    i32.const 0
                                    i32.const 0
                                    call 6
                                    unreachable
                                  end
                                  br 14 (;@1;)
                                end
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      block ;; label = @34
                                                                        local.get 1
                                                                        i64.const 32
                                                                        i64.shr_u
                                                                        i32.wrap_i64
                                                                        br_table 0 (;@34;) 1 (;@33;) 2 (;@32;) 3 (;@31;) 4 (;@30;) 5 (;@29;) 6 (;@28;) 7 (;@27;) 8 (;@26;) 9 (;@25;) 10 (;@24;) 11 (;@23;) 12 (;@22;) 13 (;@21;) 14 (;@20;) 15 (;@19;) 16 (;@18;) 17 (;@17;) 18 (;@16;)
                                                                      end
                                                                      local.get 0
                                                                      i32.wrap_i64
                                                                      local.get 1
                                                                      i32.wrap_i64
                                                                      local.get 2
                                                                      memory.copy 5 0
                                                                      br 18 (;@15;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 5 1
                                                                    br 17 (;@15;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 5 2
                                                                  br 16 (;@15;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 5 3
                                                                br 15 (;@15;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 5 4
                                                              br 14 (;@15;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 5 5
                                                            br 13 (;@15;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 5 6
                                                          br 12 (;@15;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 5 7
                                                        br 11 (;@15;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 5 8
                                                      br 10 (;@15;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 5 9
                                                    br 9 (;@15;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 5 10
                                                  br 8 (;@15;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 5 11
                                                br 7 (;@15;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 5 12
                                              br 6 (;@15;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 5 13
                                            br 5 (;@15;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 5 14
                                          br 4 (;@15;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 5 15
                                        br 3 (;@15;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 5 16
                                      br 2 (;@15;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 5 17
                                    br 1 (;@15;)
                                  end
                                  i32.const 7
                                  i32.const 0
                                  i32.const 0
                                  i32.const 0
                                  call 6
                                  unreachable
                                end
                                br 13 (;@1;)
                              end
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    block ;; label = @33
                                                                      local.get 1
                                                                      i64.const 32
                                                                      i64.shr_u
                                                                      i32.wrap_i64
                                                                      br_table 0 (;@33;) 1 (;@32;) 2 (;@31;) 3 (;@30;) 4 (;@29;) 5 (;@28;) 6 (;@27;) 7 (;@26;) 8 (;@25;) 9 (;@24;) 10 (;@23;) 11 (;@22;) 12 (;@21;) 13 (;@20;) 14 (;@19;) 15 (;@18;) 16 (;@17;) 17 (;@16;) 18 (;@15;)
                                                                    end
                                                                    local.get 0
                                                                    i32.wrap_i64
                                                                    local.get 1
                                                                    i32.wrap_i64
                                                                    local.get 2
                                                                    memory.copy 6 0
                                                                    br 18 (;@14;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 6 1
                                                                  br 17 (;@14;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 6 2
                                                                br 16 (;@14;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 6 3
                                                              br 15 (;@14;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 6 4
                                                            br 14 (;@14;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 6 5
                                                          br 13 (;@14;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 6 6
                                                        br 12 (;@14;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 6 7
                                                      br 11 (;@14;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 6 8
                                                    br 10 (;@14;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 6 9
                                                  br 9 (;@14;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 6 10
                                                br 8 (;@14;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 6 11
                                              br 7 (;@14;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 6 12
                                            br 6 (;@14;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 6 13
                                          br 5 (;@14;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 6 14
                                        br 4 (;@14;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 6 15
                                      br 3 (;@14;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 6 16
                                    br 2 (;@14;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 6 17
                                  br 1 (;@14;)
                                end
                                i32.const 7
                                i32.const 0
                                i32.const 0
                                i32.const 0
                                call 6
                                unreachable
                              end
                              br 12 (;@1;)
                            end
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  block ;; label = @32
                                                                    local.get 1
                                                                    i64.const 32
                                                                    i64.shr_u
                                                                    i32.wrap_i64
                                                                    br_table 0 (;@32;) 1 (;@31;) 2 (;@30;) 3 (;@29;) 4 (;@28;) 5 (;@27;) 6 (;@26;) 7 (;@25;) 8 (;@24;) 9 (;@23;) 10 (;@22;) 11 (;@21;) 12 (;@20;) 13 (;@19;) 14 (;@18;) 15 (;@17;) 16 (;@16;) 17 (;@15;) 18 (;@14;)
                                                                  end
                                                                  local.get 0
                                                                  i32.wrap_i64
                                                                  local.get 1
                                                                  i32.wrap_i64
                                                                  local.get 2
                                                                  memory.copy 7 0
                                                                  br 18 (;@13;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 7 1
                                                                br 17 (;@13;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 7 2
                                                              br 16 (;@13;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 7 3
                                                            br 15 (;@13;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 7 4
                                                          br 14 (;@13;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 7 5
                                                        br 13 (;@13;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 7 6
                                                      br 12 (;@13;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 7 7
                                                    br 11 (;@13;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 7 8
                                                  br 10 (;@13;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 7 9
                                                br 9 (;@13;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 7 10
                                              br 8 (;@13;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 7 11
                                            br 7 (;@13;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 7 12
                                          br 6 (;@13;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 7 13
                                        br 5 (;@13;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 7 14
                                      br 4 (;@13;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 7 15
                                    br 3 (;@13;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 7 16
                                  br 2 (;@13;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 7 17
                                br 1 (;@13;)
                              end
                              i32.const 7
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            br 11 (;@1;)
                          end
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                block ;; label = @31
                                                                  local.get 1
                                                                  i64.const 32
                                                                  i64.shr_u
                                                                  i32.wrap_i64
                                                                  br_table 0 (;@31;) 1 (;@30;) 2 (;@29;) 3 (;@28;) 4 (;@27;) 5 (;@26;) 6 (;@25;) 7 (;@24;) 8 (;@23;) 9 (;@22;) 10 (;@21;) 11 (;@20;) 12 (;@19;) 13 (;@18;) 14 (;@17;) 15 (;@16;) 16 (;@15;) 17 (;@14;) 18 (;@13;)
                                                                end
                                                                local.get 0
                                                                i32.wrap_i64
                                                                local.get 1
                                                                i32.wrap_i64
                                                                local.get 2
                                                                memory.copy 8 0
                                                                br 18 (;@12;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 8 1
                                                              br 17 (;@12;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 8 2
                                                            br 16 (;@12;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 8 3
                                                          br 15 (;@12;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 8 4
                                                        br 14 (;@12;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 8 5
                                                      br 13 (;@12;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 8 6
                                                    br 12 (;@12;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 8 7
                                                  br 11 (;@12;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 8 8
                                                br 10 (;@12;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 8 9
                                              br 9 (;@12;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 8 10
                                            br 8 (;@12;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 8 11
                                          br 7 (;@12;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 8 12
                                        br 6 (;@12;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 8 13
                                      br 5 (;@12;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 8 14
                                    br 4 (;@12;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 8 15
                                  br 3 (;@12;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 8 16
                                br 2 (;@12;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 8 17
                              br 1 (;@12;)
                            end
                            i32.const 7
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          br 10 (;@1;)
                        end
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              block ;; label = @30
                                                                local.get 1
                                                                i64.const 32
                                                                i64.shr_u
                                                                i32.wrap_i64
                                                                br_table 0 (;@30;) 1 (;@29;) 2 (;@28;) 3 (;@27;) 4 (;@26;) 5 (;@25;) 6 (;@24;) 7 (;@23;) 8 (;@22;) 9 (;@21;) 10 (;@20;) 11 (;@19;) 12 (;@18;) 13 (;@17;) 14 (;@16;) 15 (;@15;) 16 (;@14;) 17 (;@13;) 18 (;@12;)
                                                              end
                                                              local.get 0
                                                              i32.wrap_i64
                                                              local.get 1
                                                              i32.wrap_i64
                                                              local.get 2
                                                              memory.copy 9 0
                                                              br 18 (;@11;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 9 1
                                                            br 17 (;@11;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 9 2
                                                          br 16 (;@11;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 9 3
                                                        br 15 (;@11;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 9 4
                                                      br 14 (;@11;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 9 5
                                                    br 13 (;@11;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 9 6
                                                  br 12 (;@11;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 9 7
                                                br 11 (;@11;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 9 8
                                              br 10 (;@11;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 9 9
                                            br 9 (;@11;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 9 10
                                          br 8 (;@11;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 9 11
                                        br 7 (;@11;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 9 12
                                      br 6 (;@11;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 9 13
                                    br 5 (;@11;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 9 14
                                  br 4 (;@11;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 9 15
                                br 3 (;@11;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 9 16
                              br 2 (;@11;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 9 17
                            br 1 (;@11;)
                          end
                          i32.const 7
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        br 9 (;@1;)
                      end
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            block ;; label = @29
                                                              local.get 1
                                                              i64.const 32
                                                              i64.shr_u
                                                              i32.wrap_i64
                                                              br_table 0 (;@29;) 1 (;@28;) 2 (;@27;) 3 (;@26;) 4 (;@25;) 5 (;@24;) 6 (;@23;) 7 (;@22;) 8 (;@21;) 9 (;@20;) 10 (;@19;) 11 (;@18;) 12 (;@17;) 13 (;@16;) 14 (;@15;) 15 (;@14;) 16 (;@13;) 17 (;@12;) 18 (;@11;)
                                                            end
                                                            local.get 0
                                                            i32.wrap_i64
                                                            local.get 1
                                                            i32.wrap_i64
                                                            local.get 2
                                                            memory.copy 10 0
                                                            br 18 (;@10;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 10 1
                                                          br 17 (;@10;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 10 2
                                                        br 16 (;@10;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 10 3
                                                      br 15 (;@10;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 10 4
                                                    br 14 (;@10;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 10 5
                                                  br 13 (;@10;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 10 6
                                                br 12 (;@10;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 10 7
                                              br 11 (;@10;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 10 8
                                            br 10 (;@10;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 10 9
                                          br 9 (;@10;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 10 10
                                        br 8 (;@10;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 10 11
                                      br 7 (;@10;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 10 12
                                    br 6 (;@10;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 10 13
                                  br 5 (;@10;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 10 14
                                br 4 (;@10;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 10 15
                              br 3 (;@10;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 10 16
                            br 2 (;@10;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 10 17
                          br 1 (;@10;)
                        end
                        i32.const 7
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      br 8 (;@1;)
                    end
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          block ;; label = @28
                                                            local.get 1
                                                            i64.const 32
                                                            i64.shr_u
                                                            i32.wrap_i64
                                                            br_table 0 (;@28;) 1 (;@27;) 2 (;@26;) 3 (;@25;) 4 (;@24;) 5 (;@23;) 6 (;@22;) 7 (;@21;) 8 (;@20;) 9 (;@19;) 10 (;@18;) 11 (;@17;) 12 (;@16;) 13 (;@15;) 14 (;@14;) 15 (;@13;) 16 (;@12;) 17 (;@11;) 18 (;@10;)
                                                          end
                                                          local.get 0
                                                          i32.wrap_i64
                                                          local.get 1
                                                          i32.wrap_i64
                                                          local.get 2
                                                          memory.copy 11 0
                                                          br 18 (;@9;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 11 1
                                                        br 17 (;@9;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 11 2
                                                      br 16 (;@9;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 11 3
                                                    br 15 (;@9;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 11 4
                                                  br 14 (;@9;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 11 5
                                                br 13 (;@9;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 11 6
                                              br 12 (;@9;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 11 7
                                            br 11 (;@9;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 11 8
                                          br 10 (;@9;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 11 9
                                        br 9 (;@9;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 11 10
                                      br 8 (;@9;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 11 11
                                    br 7 (;@9;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 11 12
                                  br 6 (;@9;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 11 13
                                br 5 (;@9;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 11 14
                              br 4 (;@9;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 11 15
                            br 3 (;@9;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 11 16
                          br 2 (;@9;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 11 17
                        br 1 (;@9;)
                      end
                      i32.const 7
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    br 7 (;@1;)
                  end
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        block ;; label = @27
                                                          local.get 1
                                                          i64.const 32
                                                          i64.shr_u
                                                          i32.wrap_i64
                                                          br_table 0 (;@27;) 1 (;@26;) 2 (;@25;) 3 (;@24;) 4 (;@23;) 5 (;@22;) 6 (;@21;) 7 (;@20;) 8 (;@19;) 9 (;@18;) 10 (;@17;) 11 (;@16;) 12 (;@15;) 13 (;@14;) 14 (;@13;) 15 (;@12;) 16 (;@11;) 17 (;@10;) 18 (;@9;)
                                                        end
                                                        local.get 0
                                                        i32.wrap_i64
                                                        local.get 1
                                                        i32.wrap_i64
                                                        local.get 2
                                                        memory.copy 12 0
                                                        br 18 (;@8;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 12 1
                                                      br 17 (;@8;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 12 2
                                                    br 16 (;@8;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 12 3
                                                  br 15 (;@8;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 12 4
                                                br 14 (;@8;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 12 5
                                              br 13 (;@8;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 12 6
                                            br 12 (;@8;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 12 7
                                          br 11 (;@8;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 12 8
                                        br 10 (;@8;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 12 9
                                      br 9 (;@8;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 12 10
                                    br 8 (;@8;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 12 11
                                  br 7 (;@8;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 12 12
                                br 6 (;@8;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 12 13
                              br 5 (;@8;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 12 14
                            br 4 (;@8;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 12 15
                          br 3 (;@8;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 12 16
                        br 2 (;@8;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 12 17
                      br 1 (;@8;)
                    end
                    i32.const 7
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  br 6 (;@1;)
                end
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      block ;; label = @26
                                                        local.get 1
                                                        i64.const 32
                                                        i64.shr_u
                                                        i32.wrap_i64
                                                        br_table 0 (;@26;) 1 (;@25;) 2 (;@24;) 3 (;@23;) 4 (;@22;) 5 (;@21;) 6 (;@20;) 7 (;@19;) 8 (;@18;) 9 (;@17;) 10 (;@16;) 11 (;@15;) 12 (;@14;) 13 (;@13;) 14 (;@12;) 15 (;@11;) 16 (;@10;) 17 (;@9;) 18 (;@8;)
                                                      end
                                                      local.get 0
                                                      i32.wrap_i64
                                                      local.get 1
                                                      i32.wrap_i64
                                                      local.get 2
                                                      memory.copy 13 0
                                                      br 18 (;@7;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 13 1
                                                    br 17 (;@7;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 13 2
                                                  br 16 (;@7;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 13 3
                                                br 15 (;@7;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 13 4
                                              br 14 (;@7;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 13 5
                                            br 13 (;@7;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 13 6
                                          br 12 (;@7;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 13 7
                                        br 11 (;@7;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 13 8
                                      br 10 (;@7;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 13 9
                                    br 9 (;@7;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 13 10
                                  br 8 (;@7;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 13 11
                                br 7 (;@7;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 13 12
                              br 6 (;@7;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 13 13
                            br 5 (;@7;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 13 14
                          br 4 (;@7;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 13 15
                        br 3 (;@7;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 13 16
                      br 2 (;@7;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 13 17
                    br 1 (;@7;)
                  end
                  i32.const 7
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                br 5 (;@1;)
              end
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    block ;; label = @25
                                                      local.get 1
                                                      i64.const 32
                                                      i64.shr_u
                                                      i32.wrap_i64
                                                      br_table 0 (;@25;) 1 (;@24;) 2 (;@23;) 3 (;@22;) 4 (;@21;) 5 (;@20;) 6 (;@19;) 7 (;@18;) 8 (;@17;) 9 (;@16;) 10 (;@15;) 11 (;@14;) 12 (;@13;) 13 (;@12;) 14 (;@11;) 15 (;@10;) 16 (;@9;) 17 (;@8;) 18 (;@7;)
                                                    end
                                                    local.get 0
                                                    i32.wrap_i64
                                                    local.get 1
                                                    i32.wrap_i64
                                                    local.get 2
                                                    memory.copy 14 0
                                                    br 18 (;@6;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 14 1
                                                  br 17 (;@6;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 14 2
                                                br 16 (;@6;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 14 3
                                              br 15 (;@6;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 14 4
                                            br 14 (;@6;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 14 5
                                          br 13 (;@6;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 14 6
                                        br 12 (;@6;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 14 7
                                      br 11 (;@6;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 14 8
                                    br 10 (;@6;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 14 9
                                  br 9 (;@6;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 14 10
                                br 8 (;@6;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 14 11
                              br 7 (;@6;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 14 12
                            br 6 (;@6;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 14 13
                          br 5 (;@6;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 14 14
                        br 4 (;@6;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 14 15
                      br 3 (;@6;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 14 16
                    br 2 (;@6;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 14 17
                  br 1 (;@6;)
                end
                i32.const 7
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              br 4 (;@1;)
            end
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  block ;; label = @24
                                                    local.get 1
                                                    i64.const 32
                                                    i64.shr_u
                                                    i32.wrap_i64
                                                    br_table 0 (;@24;) 1 (;@23;) 2 (;@22;) 3 (;@21;) 4 (;@20;) 5 (;@19;) 6 (;@18;) 7 (;@17;) 8 (;@16;) 9 (;@15;) 10 (;@14;) 11 (;@13;) 12 (;@12;) 13 (;@11;) 14 (;@10;) 15 (;@9;) 16 (;@8;) 17 (;@7;) 18 (;@6;)
                                                  end
                                                  local.get 0
                                                  i32.wrap_i64
                                                  local.get 1
                                                  i32.wrap_i64
                                                  local.get 2
                                                  memory.copy 15 0
                                                  br 18 (;@5;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 15 1
                                                br 17 (;@5;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 15 2
                                              br 16 (;@5;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 15 3
                                            br 15 (;@5;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 15 4
                                          br 14 (;@5;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 15 5
                                        br 13 (;@5;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 15 6
                                      br 12 (;@5;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 15 7
                                    br 11 (;@5;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 15 8
                                  br 10 (;@5;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 15 9
                                br 9 (;@5;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 15 10
                              br 8 (;@5;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 15 11
                            br 7 (;@5;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 15 12
                          br 6 (;@5;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 15 13
                        br 5 (;@5;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 15 14
                      br 4 (;@5;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 15 15
                    br 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 15 16
                  br 2 (;@5;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 15 17
                br 1 (;@5;)
              end
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            br 3 (;@1;)
          end
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                block ;; label = @23
                                                  local.get 1
                                                  i64.const 32
                                                  i64.shr_u
                                                  i32.wrap_i64
                                                  br_table 0 (;@23;) 1 (;@22;) 2 (;@21;) 3 (;@20;) 4 (;@19;) 5 (;@18;) 6 (;@17;) 7 (;@16;) 8 (;@15;) 9 (;@14;) 10 (;@13;) 11 (;@12;) 12 (;@11;) 13 (;@10;) 14 (;@9;) 15 (;@8;) 16 (;@7;) 17 (;@6;) 18 (;@5;)
                                                end
                                                local.get 0
                                                i32.wrap_i64
                                                local.get 1
                                                i32.wrap_i64
                                                local.get 2
                                                memory.copy 16 0
                                                br 18 (;@4;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 16 1
                                              br 17 (;@4;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 16 2
                                            br 16 (;@4;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 16 3
                                          br 15 (;@4;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 16 4
                                        br 14 (;@4;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 16 5
                                      br 13 (;@4;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 16 6
                                    br 12 (;@4;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 16 7
                                  br 11 (;@4;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 16 8
                                br 10 (;@4;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 16 9
                              br 9 (;@4;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 16 10
                            br 8 (;@4;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 16 11
                          br 7 (;@4;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 16 12
                        br 6 (;@4;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 16 13
                      br 5 (;@4;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 16 14
                    br 4 (;@4;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 16 15
                  br 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 16 16
                br 2 (;@4;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 16 17
              br 1 (;@4;)
            end
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          br 2 (;@1;)
        end
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      block ;; label = @18
                                        block ;; label = @19
                                          block ;; label = @20
                                            block ;; label = @21
                                              block ;; label = @22
                                                local.get 1
                                                i64.const 32
                                                i64.shr_u
                                                i32.wrap_i64
                                                br_table 0 (;@22;) 1 (;@21;) 2 (;@20;) 3 (;@19;) 4 (;@18;) 5 (;@17;) 6 (;@16;) 7 (;@15;) 8 (;@14;) 9 (;@13;) 10 (;@12;) 11 (;@11;) 12 (;@10;) 13 (;@9;) 14 (;@8;) 15 (;@7;) 16 (;@6;) 17 (;@5;) 18 (;@4;)
                                              end
                                              local.get 0
                                              i32.wrap_i64
                                              local.get 1
                                              i32.wrap_i64
                                              local.get 2
                                              memory.copy 17 0
                                              br 18 (;@3;)
                                            end
                                            local.get 0
                                            i32.wrap_i64
                                            local.get 1
                                            i32.wrap_i64
                                            local.get 2
                                            memory.copy 17 1
                                            br 17 (;@3;)
                                          end
                                          local.get 0
                                          i32.wrap_i64
                                          local.get 1
                                          i32.wrap_i64
                                          local.get 2
                                          memory.copy 17 2
                                          br 16 (;@3;)
                                        end
                                        local.get 0
                                        i32.wrap_i64
                                        local.get 1
                                        i32.wrap_i64
                                        local.get 2
                                        memory.copy 17 3
                                        br 15 (;@3;)
                                      end
                                      local.get 0
                                      i32.wrap_i64
                                      local.get 1
                                      i32.wrap_i64
                                      local.get 2
                                      memory.copy 17 4
                                      br 14 (;@3;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i32.wrap_i64
                                    local.get 2
                                    memory.copy 17 5
                                    br 13 (;@3;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i32.wrap_i64
                                  local.get 2
                                  memory.copy 17 6
                                  br 12 (;@3;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i32.wrap_i64
                                local.get 2
                                memory.copy 17 7
                                br 11 (;@3;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i32.wrap_i64
                              local.get 2
                              memory.copy 17 8
                              br 10 (;@3;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i32.wrap_i64
                            local.get 2
                            memory.copy 17 9
                            br 9 (;@3;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i32.wrap_i64
                          local.get 2
                          memory.copy 17 10
                          br 8 (;@3;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i32.wrap_i64
                        local.get 2
                        memory.copy 17 11
                        br 7 (;@3;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy 17 12
                      br 6 (;@3;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 17 13
                    br 5 (;@3;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 17 14
                  br 4 (;@3;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 17 15
                br 3 (;@3;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 17 16
              br 2 (;@3;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 17 17
            br 1 (;@3;)
          end
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.12 (;32;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 12
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 12
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 12
      i32.sub
      memory.grow 12
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 12
    local.get 1
  )
  (func $goose.reserve_memory.13 (;33;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 13
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 13
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 13
      i32.sub
      memory.grow 13
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 13
    local.get 1
  )
  (func $goose.reserve_memory.14 (;34;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 14
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 14
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 14
      i32.sub
      memory.grow 14
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 14
    local.get 1
  )
  (func $goose.reserve_memory.15 (;35;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 15
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 15
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 15
      i32.sub
      memory.grow 15
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 15
    local.get 1
  )
  (func $goose.reserve_memory.16 (;36;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 16
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 16
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 16
      i32.sub
      memory.grow 16
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 16
    local.get 1
  )
  (func $goose.reserve_memory.17 (;37;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 17
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 17
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 17
      i32.sub
      memory.grow 17
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 17
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosebefore=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosevariable=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosefixed=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooselimited=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseruntime=,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goosegrow=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseshrink=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooserefs=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseborrowed=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseempty=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooselarge=,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.gooseafter=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy.goose")
)
