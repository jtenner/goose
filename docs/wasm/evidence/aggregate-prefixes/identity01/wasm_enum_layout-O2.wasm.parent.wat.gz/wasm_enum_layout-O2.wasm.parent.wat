(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 2464)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 70
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 78
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i32 i32 i32 i64 i64 i32 i32 i32 i32 i32 i64 i64 i32 i32 i64 i64 i32 i32 i64 i32 i64 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i64 i32 i64 i64 i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 i32 i32 i32 i64 i64 i64 i64)
    i32.const 6949
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 2
      local.get 2
      i64.const 0
      i64.store8
      local.get 2
      i64.const 7
      i64.store8 offset=1
      local.get 2
      i64.const 305419896
      i64.store32 offset=5 align=1
      local.get 2
      i64.const -3
      i64.store16 offset=12 align=1
      local.get 2
      i64.const 19
      i64.store offset=14 align=1
      local.get 2
      i64.const 0
      i64.store16 offset=22 align=1
      i64.const 4
      local.set 3
      local.get 2
      i64.load16_u offset=22 align=1
      local.set 4
      local.get 4
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 148
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 2
      i32.const 22
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 2
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 218
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 5
      local.get 5
      i32.wrap_i64
      local.get 3
      i64.store16 align=1
      local.get 2
      local.get 4
      i64.const 1
      i64.add
      i64.store16 offset=22 align=1
      i64.const 5
      local.set 3
      local.get 2
      i64.load16_u offset=22 align=1
      local.set 4
      local.get 4
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 288
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 2
      i32.const 22
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 2
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 358
        i32.const 70
        i32.const 5
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 5
      local.get 5
      i32.wrap_i64
      local.get 3
      i64.store16 align=1
      local.get 2
      local.get 4
      i64.const 1
      i64.add
      i64.store16 offset=22 align=1
      local.get 2
      i32.const 0
      i64.extend_i32_u
      i64.store offset=624 align=1
      local.get 0
      i32.const 632
      i32.add
      local.set 8
      local.get 0
      i32.const 0
      i32.add
      local.set 9
      local.get 8
      i64.extend_i32_u
      local.set 10
      local.get 9
      i64.extend_i32_u
      local.set 11
      i32.const 632
      local.set 12
      local.get 10
      i32.wrap_i64
      local.get 11
      i32.wrap_i64
      local.get 12
      memory.copy
      local.get 0
      i32.const 1264
      i32.add
      local.set 13
      local.get 13
      i64.const 0
      i64.store8
      local.get 13
      i64.const 7
      i64.store8 offset=1
      local.get 13
      i64.const 305419896
      i64.store32 offset=5 align=1
      local.get 13
      i64.const -3
      i64.store16 offset=12 align=1
      local.get 13
      i64.const 19
      i64.store offset=14 align=1
      local.get 13
      i64.const 0
      i64.store16 offset=22 align=1
      local.get 13
      i32.const 0
      i64.extend_i32_u
      i64.store offset=624 align=1
      local.get 0
      i32.const 1896
      i32.add
      local.set 14
      local.get 14
      i64.const 7
      i64.store8
      local.get 14
      i64.const 305419896
      i64.store32 offset=4 align=1
      local.get 14
      i64.const -3
      i64.store16 offset=11 align=1
      local.get 14
      i64.const 19
      i64.store offset=13 align=1
      local.get 14
      i64.const 0
      i64.store16 offset=21 align=1
      i64.const 8
      local.set 3
      local.get 14
      i64.load16_u offset=21 align=1
      local.set 4
      local.get 4
      i64.const 300
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 428
        i32.const 70
        i32.const 6
        call 6
        unreachable
      end
      local.get 14
      i32.const 21
      i32.add
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 2
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 498
        i32.const 70
        i32.const 6
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 5
      local.get 5
      i32.wrap_i64
      local.get 3
      i64.store16 align=1
      local.get 14
      local.get 4
      i64.const 1
      i64.add
      i64.store16 offset=21 align=1
      local.get 14
      i32.const 0
      i64.extend_i32_u
      i64.store offset=623 align=1
      local.get 0
      i32.const 2527
      i32.add
      local.set 15
      local.get 0
      i32.const 1896
      i32.add
      local.set 16
      local.get 15
      i64.extend_i32_u
      local.set 17
      local.get 16
      i64.extend_i32_u
      local.set 18
      i32.const 631
      local.set 19
      local.get 17
      i32.wrap_i64
      local.get 18
      i32.wrap_i64
      local.get 19
      memory.copy
      local.get 0
      i32.const 2527
      i32.add
      local.set 20
      local.get 20
      i64.const 77
      i64.store offset=13 align=1
      local.get 0
      i32.const 1896
      i32.add
      local.set 21
      local.get 21
      i64.load offset=13 align=1
      i64.const 19
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 568
        i32.const 70
        i32.const 6
        call 6
        unreachable
      end
      local.get 0
      i32.const 3158
      i32.add
      local.set 22
      local.get 22
      i64.const 9
      i64.store8
      local.get 0
      i32.const 632
      i32.add
      local.set 23
      local.get 22
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 24
      local.get 23
      i64.extend_i32_u
      local.set 25
      i32.const 632
      local.set 26
      local.get 24
      i32.wrap_i64
      local.get 25
      i32.wrap_i64
      local.get 26
      memory.copy
      local.get 0
      i32.const 1896
      i32.add
      local.set 27
      local.get 22
      i32.const 633
      i32.add
      i64.extend_i32_u
      local.set 28
      local.get 27
      i64.extend_i32_u
      local.set 29
      i32.const 631
      local.set 30
      local.get 28
      i32.wrap_i64
      local.get 29
      i32.wrap_i64
      local.get 30
      memory.copy
      local.get 22
      i64.const 65000
      i64.store16 offset=1264 align=1
      local.get 0
      i32.const 3158
      i32.add
      local.set 31
      local.get 31
      i64.load8_u offset=1
      local.set 32
      local.get 32
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 638
        i32.const 70
        i32.const 8
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 32
        i64.const 0
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 4424
          i32.add
          local.set 33
          local.get 33
          i64.extend_i32_u
          local.set 34
          local.get 31
          i32.const 2
          i32.add
          i64.extend_i32_u
          local.set 35
          i32.const 631
          local.set 36
          local.get 34
          i32.wrap_i64
          local.get 35
          i32.wrap_i64
          local.get 36
          memory.copy
          local.get 0
          i32.const 4424
          i32.add
          local.set 37
          local.get 37
          i64.load8_u
          i64.const 7
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 708
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 4424
          i32.add
          local.set 38
          local.get 38
          i64.load32_u offset=4 align=1
          i64.const 305419896
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 778
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 4424
          i32.add
          local.set 39
          local.get 39
          i64.load16_s offset=11 align=1
          i64.const -3
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 848
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 4424
          i32.add
          local.set 40
          local.get 40
          i64.load offset=13 align=1
          i64.const 19
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 918
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 4424
          i32.add
          local.set 41
          local.get 41
          i32.const 21
          i32.add
          local.set 42
          local.get 42
          i64.load16_u align=1
          i64.const 2
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 988
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 4424
          i32.add
          local.set 43
          local.get 43
          i32.const 21
          i32.add
          local.set 44
          local.get 44
          i64.load16_u align=1
          local.set 45
          i64.const 1
          local.set 46
          local.get 44
          i32.const 2
          i32.add
          i64.extend_i32_u
          local.set 47
          local.get 47
          i64.const 4294967295
          i64.and
          local.get 46
          i64.const 2
          i64.mul
          i64.add
          local.tee 48
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1058
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 47
          i64.const -4294967296
          i64.and
          local.get 48
          i64.or
          i32.wrap_i64
          i64.load16_u align=1
          i64.const 5
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1128
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 4424
          i32.add
          local.set 49
          local.get 49
          i64.load offset=623 align=1
          i32.wrap_i64
          local.set 1
          local.get 1
          i32.const 0
          i32.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1198
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 5055
          i32.add
          local.set 50
          local.get 0
          i32.const 4424
          i32.add
          local.set 51
          local.get 50
          i64.extend_i32_u
          local.set 52
          local.get 51
          i64.extend_i32_u
          local.set 53
          i32.const 631
          local.set 54
          local.get 52
          i32.wrap_i64
          local.get 53
          i32.wrap_i64
          local.get 54
          memory.copy
          local.get 0
          i32.const 5055
          i32.add
          local.set 55
          local.get 55
          i32.const 21
          i32.add
          local.set 56
          local.get 56
          i64.load16_u align=1
          local.set 57
          i64.const 0
          local.set 58
          local.get 58
          local.get 57
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 1268
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 56
          i32.const 2
          i32.add
          i64.extend_i32_u
          local.set 59
          local.get 59
          i64.const 4294967295
          i64.and
          local.get 58
          i64.const 2
          i64.mul
          i64.add
          local.tee 60
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1338
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 59
          i64.const -4294967296
          i64.and
          local.get 60
          i64.or
          local.set 61
          i64.const 99
          local.set 62
          local.get 61
          local.get 62
          local.set 63
          i32.wrap_i64
          local.get 63
          i64.store16 align=1
          local.get 0
          i32.const 4424
          i32.add
          local.set 64
          local.get 64
          i32.const 21
          i32.add
          local.set 65
          local.get 65
          i64.load16_u align=1
          local.set 66
          i64.const 0
          local.set 67
          local.get 65
          i32.const 2
          i32.add
          i64.extend_i32_u
          local.set 68
          local.get 68
          i64.const 4294967295
          i64.and
          local.get 67
          i64.const 2
          i64.mul
          i64.add
          local.tee 69
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1408
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          local.get 68
          i64.const -4294967296
          i64.and
          local.get 69
          i64.or
          i32.wrap_i64
          i64.load16_u align=1
          i64.const 4
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1478
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 32
        i64.const 1
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1548
            i32.const 70
            i32.const 8
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
      end
      local.get 0
      i32.const 1264
      i32.add
      local.set 70
      local.get 70
      i64.load8_u
      local.set 71
      local.get 71
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 1618
        i32.const 70
        i32.const 9
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 71
        i64.const 0
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 5686
          i32.add
          local.set 72
          local.get 72
          i64.extend_i32_u
          local.set 73
          local.get 70
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 74
          i32.const 631
          local.set 75
          local.get 73
          i32.wrap_i64
          local.get 74
          i32.wrap_i64
          local.get 75
          memory.copy
          local.get 0
          i32.const 5686
          i32.add
          local.set 76
          local.get 76
          i32.const 21
          i32.add
          local.set 77
          local.get 77
          i64.load16_u align=1
          i64.const 0
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1688
            i32.const 70
            i32.const 9
            call 6
            unreachable
          end
          local.get 0
          i32.const 5686
          i32.add
          local.set 78
          local.get 78
          i64.load8_u
          i64.const 7
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1758
            i32.const 70
            i32.const 9
            call 6
            unreachable
          end
          local.get 0
          i32.const 5686
          i32.add
          local.set 79
          local.get 79
          i64.load offset=13 align=1
          i64.const 19
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1828
            i32.const 70
            i32.const 9
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 71
        i64.const 1
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1898
            i32.const 70
            i32.const 9
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
      end
      local.get 0
      i32.const 6317
      i32.add
      local.set 80
      local.get 80
      i64.const 1
      i64.store8
      local.get 0
      i32.const 6317
      i32.add
      local.set 81
      local.get 81
      i64.load8_u
      local.set 82
      local.get 82
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 1968
        i32.const 70
        i32.const 10
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 82
        i64.const 0
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 2038
            i32.const 70
            i32.const 10
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 82
        i64.const 1
        i64.eq
        if ;; label = @3
          call 0
          local.set 83
          local.get 83
          i32.const 2108
          i32.const 6
          call 4
          local.get 83
          call 5
          br 1 (;@2;)
        end
      end
      local.get 0
      i32.const 3158
      i32.add
      local.set 84
      local.get 84
      i64.load8_u
      i64.const 9
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2114
        i32.const 70
        i32.const 11
        call 6
        unreachable
      end
      local.get 0
      i32.const 3158
      i32.add
      local.set 85
      local.get 85
      i64.load16_u offset=1264 align=1
      i64.const 65000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2184
        i32.const 70
        i32.const 11
        call 6
        unreachable
      end
      local.get 0
      i32.const 3158
      i32.add
      local.set 86
      local.get 86
      i32.const 654
      i32.add
      local.set 87
      local.get 87
      i64.load16_u align=1
      local.set 88
      i64.const 0
      local.set 89
      local.get 89
      local.get 88
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2254
        i32.const 70
        i32.const 11
        call 6
        unreachable
      end
      local.get 87
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 90
      local.get 90
      i64.const 4294967295
      i64.and
      local.get 89
      i64.const 2
      i64.mul
      i64.add
      local.tee 91
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2324
        i32.const 70
        i32.const 11
        call 6
        unreachable
      end
      local.get 90
      i64.const -4294967296
      i64.and
      local.get 91
      i64.or
      i32.wrap_i64
      i64.load16_u align=1
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2394
        i32.const 70
        i32.const 11
        call 6
        unreachable
      end
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.gooselayout/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_layout.goose")
)
