(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32 i32) (result i64)))
  (type (;12;) (func (param i64 i32) (result i64)))
  (type (;13;) (func (param i32) (result i64)))
  (type (;14;) (func (param i32 i32) (result i32)))
  (type (;15;) (func (param i64 i64)))
  (type (;16;) (func (param i64) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (global (;0;) (mut i32) i32.const 10320)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 16
      i32.const 81
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 97
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i32.const 1
      i32.const 0
      call $work.1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 178
        i32.const 81
        i32.const 43
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 1020305060709
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 259
        i32.const 81
        i32.const 43
        call 6
        unreachable
      end
      i32.const 1
      local.set 3
      i32.const 12
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i64.const 1
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store32 1 align=1
      i64.const 91
      local.set 7
      local.get 4
      i32.const 4
      i32.add
      local.get 7
      i64.store 1 align=1
      i32.const 1
      call $partial.4
      i64.const 5
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 340
        i32.const 81
        i32.const 45
        call 6
        unreachable
      end
      i32.const 0
      call $partial.4
      i64.const 9
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 421
        i32.const 81
        i32.const 45
        call 6
        unreachable
      end
      local.get 1
      local.set 8
      local.get 8
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 9
      i64.const 0
      local.set 10
      local.get 8
      local.set 11
      local.get 11
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 10
      i64.const 8
      i64.mul
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 502
        i32.const 81
        i32.const 45
        call 6
        unreachable
      end
      local.get 11
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 91
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 583
        i32.const 81
        i32.const 45
        call 6
        unreachable
      end
      i64.const 0
      local.set 13
      i32.const 8
      local.get 13
      i64.store align=1
      i32.const 0
      i32.const 1
      call $work.1
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 664
        i32.const 81
        i32.const 46
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 1020305060709
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 745
        i32.const 81
        i32.const 46
        call 6
        unreachable
      end
      local.get 1
      local.set 14
      local.get 14
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 15
      i64.const 0
      local.set 16
      local.get 14
      local.set 17
      local.get 17
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 16
      i64.const 8
      i64.mul
      i64.add
      local.tee 18
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 826
        i32.const 81
        i32.const 46
        call 6
        unreachable
      end
      local.get 17
      i64.const -4294967296
      i64.and
      local.get 18
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 91
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 907
        i32.const 81
        i32.const 46
        call 6
        unreachable
      end
      i64.const 0
      local.set 2
      block ;; label = @2
        loop ;; label = @3
          local.get 2
          i64.const 20
          i64.lt_s
          i32.eqz
          br_if 1 (;@2;)
          i64.const 0
          local.set 19
          i32.const 8
          local.get 19
          i64.store align=1
          local.get 2
          i64.const 2
          local.set 20
          local.set 21
          local.get 20
          i64.eqz
          if ;; label = @4
            i32.const 2
            i32.const 988
            i32.const 81
            i32.const 49
            call 6
            unreachable
          end
          local.get 21
          local.get 20
          i64.rem_s
          local.tee 22
          i64.const 0
          i64.lt_s
          if (result i64) ;; label = @4
            local.get 22
            local.get 20
            i64.const 0
            i64.lt_s
            if (result i64) ;; label = @5
              i64.const 0
              local.get 20
              i64.sub
            else
              local.get 20
            end
            i64.add
          else
            local.get 22
          end
          i64.const 0
          i64.eq
          i32.const 1
          call $work.1
          local.get 2
          i64.const 2
          local.set 23
          local.set 24
          local.get 23
          i64.eqz
          if ;; label = @4
            i32.const 2
            i32.const 1069
            i32.const 81
            i32.const 49
            call 6
            unreachable
          end
          local.get 24
          local.get 23
          i64.rem_s
          local.tee 25
          i64.const 0
          i64.lt_s
          if (result i64) ;; label = @4
            local.get 25
            local.get 23
            i64.const 0
            i64.lt_s
            if (result i64) ;; label = @5
              i64.const 0
              local.get 23
              i64.sub
            else
              local.get 23
            end
            i64.add
          else
            local.get 25
          end
          i64.const 0
          i64.eq
          if (result i64) ;; label = @4
            i64.const 4
            local.set 26
            local.get 26
          else
            i64.const 8
          end
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1150
            i32.const 81
            i32.const 49
            call 6
            unreachable
          end
          i32.const 8
          i64.load align=1
          i64.const 1020305060709
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1231
            i32.const 81
            i32.const 50
            call 6
            unreachable
          end
          local.get 1
          local.set 27
          local.get 27
          i32.wrap_i64
          i64.load32_u 1 align=1
          local.set 28
          i64.const 0
          local.set 29
          local.get 27
          local.set 30
          local.get 30
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 29
          i64.const 8
          i64.mul
          i64.add
          local.tee 31
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1312
            i32.const 81
            i32.const 50
            call 6
            unreachable
          end
          local.get 30
          i64.const -4294967296
          i64.and
          local.get 31
          i64.or
          i32.wrap_i64
          i64.load 1 align=1
          i64.const 91
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1393
            i32.const 81
            i32.const 50
            call 6
            unreachable
          end
          local.get 2
          i64.const 1
          i64.add
          local.set 2
          br 0 (;@3;)
        end
      end
      call 0
      local.set 32
      local.get 32
      i32.const 1474
      i32.const 15
      call 4
      local.get 32
      call 5
      local.get 4
      global.set 1
    end
  )
  (func $work.1 (;12;) (type 11) (param i32 i32) (result i64)
    (local i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    i32.const 10
    call $goose.reserve_frame
    local.set 2
    block ;; label = @1
      local.get 1
      i32.const 1
      i32.add
      local.set 8
      local.get 8
      i32.const 24
      call $goose.reserve_data
      local.set 9
      local.get 8
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 9
      i64.extend_i32_u
      i64.or
      local.set 10
      local.get 10
      local.set 3
      local.get 10
      i64.const 2
      call $goose.memory_op.62
      local.get 10
      i64.const 4
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 1
      local.get 1
      i32.const 1
      i32.add
      call $inner.2
      local.set 11
      local.get 10
      i64.const 4
      i64.add
      call $goose.memory_op.49
      local.set 12
      local.get 12
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1489
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1570
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 12
      i64.const 2
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1651
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.tee 13
      local.get 11
      call $goose.memory_op.61
      local.get 10
      i64.const 4
      i64.add
      local.get 12
      i64.const 1
      i64.add
      call $goose.memory_op.60
      i64.const 2
      local.get 1
      i32.const 1
      i32.add
      call $inner.2
      local.set 11
      local.get 10
      i64.const 4
      i64.add
      call $goose.memory_op.49
      local.set 12
      local.get 12
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1732
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1813
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 12
      i64.const 2
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1894
        i32.const 81
        i32.const 16
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.tee 13
      local.get 11
      call $goose.memory_op.61
      local.get 10
      i64.const 4
      i64.add
      local.get 12
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 10
      i64.const 11
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 3
      local.get 1
      i32.const 1
      i32.add
      call $tick.3
      i64.const 255
      i64.and
      local.set 18
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 13
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1975
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      i64.const 4
      call $goose.memory_op.60
      local.get 10
      i64.const 14
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 5
      local.get 1
      i32.const 1
      i32.add
      call $inner.2
      local.set 11
      local.get 10
      i64.const 14
      i64.add
      call $goose.memory_op.49
      local.set 12
      local.get 12
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2056
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 14
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2137
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 12
      i64.const 2
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2218
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.tee 13
      local.get 11
      call $goose.memory_op.61
      local.get 10
      i64.const 14
      i64.add
      local.get 12
      i64.const 1
      i64.add
      call $goose.memory_op.60
      i64.const 6
      local.get 1
      i32.const 1
      i32.add
      call $inner.2
      local.set 11
      local.get 10
      i64.const 14
      i64.add
      call $goose.memory_op.49
      local.set 12
      local.get 12
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2299
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 14
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2380
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 12
      i64.const 2
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2461
        i32.const 81
        i32.const 17
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.tee 13
      local.get 11
      call $goose.memory_op.61
      local.get 10
      i64.const 14
      i64.add
      local.get 12
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 10
      i64.const 21
      i64.add
      i64.const 0
      call $goose.memory_op.60
      i64.const 7
      local.get 1
      i32.const 1
      i32.add
      call $tick.3
      i64.const 255
      i64.and
      local.set 18
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 23
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2542
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      i64.const 8
      call $goose.memory_op.60
      local.get 2
      i32.const 0
      i32.add
      local.set 19
      local.get 3
      local.set 20
      local.get 20
      call $goose.memory_op.53
      local.set 21
      i64.const 0
      local.set 22
      local.get 20
      local.set 23
      local.get 23
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 22
      i64.const 10
      i64.mul
      i64.add
      local.tee 24
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2623
        i32.const 81
        i32.const 23
        call 6
        unreachable
      end
      local.get 23
      i64.const -4294967296
      i64.and
      local.get 24
      i64.or
      local.set 25
      local.get 19
      i64.extend_i32_u
      local.set 26
      local.get 25
      local.set 27
      i32.const 10
      local.set 28
      local.get 26
      i32.wrap_i64
      local.get 27
      local.get 28
      call $goose.copy_to_frame
      local.get 2
      i32.const 0
      i32.add
      local.set 29
      local.get 29
      i64.extend_i32_u
      local.set 30
      local.get 30
      i32.wrap_i64
      i64.load8_u
      local.set 31
      i64.const 0
      local.set 32
      local.get 32
      local.get 31
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2704
        i32.const 81
        i32.const 23
        call 6
        unreachable
      end
      local.get 30
      local.set 33
      local.get 33
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 32
      i64.const 2
      i64.mul
      i64.add
      local.tee 34
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2785
        i32.const 81
        i32.const 23
        call 6
        unreachable
      end
      local.get 33
      i64.const -4294967296
      i64.and
      local.get 34
      i64.or
      local.set 35
      i64.const 19
      local.set 36
      local.get 35
      local.get 36
      local.set 37
      i32.wrap_i64
      local.get 37
      i64.store16 align=1
      local.get 3
      local.set 38
      local.get 38
      call $goose.memory_op.53
      local.set 39
      i64.const 0
      local.set 40
      local.get 38
      local.set 41
      local.get 41
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 40
      i64.const 10
      i64.mul
      i64.add
      local.tee 42
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2866
        i32.const 81
        i32.const 24
        call 6
        unreachable
      end
      local.get 41
      i64.const -4294967296
      i64.and
      local.get 42
      i64.or
      local.set 43
      local.get 43
      local.set 44
      local.get 44
      call $goose.memory_op.49
      local.set 45
      i64.const 0
      local.set 46
      local.get 46
      local.get 45
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2947
        i32.const 81
        i32.const 24
        call 6
        unreachable
      end
      local.get 44
      local.set 47
      local.get 47
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 46
      i64.const 2
      i64.mul
      i64.add
      local.tee 48
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3028
        i32.const 81
        i32.const 24
        call 6
        unreachable
      end
      local.get 47
      i64.const -4294967296
      i64.and
      local.get 48
      i64.or
      call $goose.memory_op.51
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3109
        i32.const 81
        i32.const 24
        call 6
        unreachable
      end
      local.get 2
      i32.const 0
      i32.add
      local.set 49
      local.get 49
      i64.extend_i32_u
      local.set 50
      local.get 50
      i32.wrap_i64
      i64.load8_u
      local.set 51
      i64.const 0
      local.set 52
      local.get 50
      local.set 53
      local.get 53
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 52
      i64.const 2
      i64.mul
      i64.add
      local.tee 54
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3190
        i32.const 81
        i32.const 24
        call 6
        unreachable
      end
      local.get 53
      i64.const -4294967296
      i64.and
      local.get 54
      i64.or
      i32.wrap_i64
      i64.load16_u align=1
      i64.const 19
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3271
        i32.const 81
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      if ;; label = @2
        local.get 2
        i32.const 0
        i32.add
        local.set 55
        local.get 55
        i64.load8_u offset=9
        local.set 7
        local.get 3
        local.set 56
        local.get 56
        call $goose.memory_op.53
        local.set 57
        i64.const 0
        local.set 58
        local.get 58
        local.get 57
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 3352
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 56
        local.set 59
        local.get 59
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 58
        i64.const 10
        i64.mul
        i64.add
        local.tee 60
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3433
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 59
        i64.const -4294967296
        i64.and
        local.get 60
        i64.or
        local.set 61
        local.get 61
        local.set 62
        local.get 62
        call $goose.memory_op.49
        i64.const 2
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 3514
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 3
        local.set 63
        local.get 63
        call $goose.memory_op.53
        local.set 64
        i64.const 1
        local.set 65
        local.get 65
        local.get 64
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 3595
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 63
        local.set 66
        local.get 66
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 65
        i64.const 10
        i64.mul
        i64.add
        local.tee 67
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3676
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 66
        i64.const -4294967296
        i64.and
        local.get 67
        i64.or
        local.set 68
        local.get 68
        local.set 69
        local.get 69
        call $goose.memory_op.49
        local.set 70
        i64.const 1
        local.set 71
        local.get 71
        local.get 70
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 3757
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 69
        local.set 72
        local.get 72
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 71
        i64.const 2
        i64.mul
        i64.add
        local.tee 73
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3838
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 72
        i64.const -4294967296
        i64.and
        local.get 73
        i64.or
        call $goose.memory_op.51
        i64.const 7
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 3919
          i32.const 81
          i32.const 19
          call 6
          unreachable
        end
        local.get 3
        local.set 74
        local.get 74
        call $goose.memory_op.53
        local.set 75
        i64.const 0
        local.set 76
        local.get 74
        local.set 77
        local.get 77
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 76
        i64.const 10
        i64.mul
        i64.add
        local.tee 78
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4000
          i32.const 81
          i32.const 20
          call 6
          unreachable
        end
        local.get 77
        i64.const -4294967296
        i64.and
        local.get 78
        i64.or
        local.set 79
        local.get 79
        i64.const 4294967295
        i64.and
        i64.const 7
        i64.add
        local.tee 16
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4081
          i32.const 81
          i32.const 20
          call 6
          unreachable
        end
        local.get 79
        i64.const -4294967296
        i64.and
        local.get 16
        i64.or
        local.set 80
        local.get 80
        call $goose.memory_op.49
        i64.const 0
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 4162
          i32.const 81
          i32.const 20
          call 6
          unreachable
        end
        local.get 3
        local.set 81
        local.get 81
        call $goose.memory_op.53
        local.set 82
        i64.const 1
        local.set 83
        local.get 81
        local.set 84
        local.get 84
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 83
        i64.const 10
        i64.mul
        i64.add
        local.tee 85
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4243
          i32.const 81
          i32.const 20
          call 6
          unreachable
        end
        local.get 84
        i64.const -4294967296
        i64.and
        local.get 85
        i64.or
        local.set 86
        local.get 86
        i64.const 4294967295
        i64.and
        i64.const 7
        i64.add
        local.tee 16
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4324
          i32.const 81
          i32.const 20
          call 6
          unreachable
        end
        local.get 86
        i64.const -4294967296
        i64.and
        local.get 16
        i64.or
        local.set 87
        local.get 87
        call $goose.memory_op.49
        i64.const 0
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 4405
          i32.const 81
          i32.const 20
          call 6
          unreachable
        end
        i32.const 8
        i64.load align=1
        i64.const 100
        i64.mul
        i64.const 9
        i64.add
        local.set 88
        i32.const 8
        local.get 88
        i64.store align=1
        local.get 8
        local.get 9
        call $goose.restore_data
        br 1 (;@1;)
      end
      i64.const 0
      local.set 4
      block ;; label = @2
        loop ;; label = @3
          local.get 4
          local.get 3
          local.set 89
          local.get 89
          call $goose.memory_op.53
          i64.lt_s
          i32.eqz
          br_if 1 (;@2;)
          local.get 4
          local.set 5
          local.get 1
          i32.const 2
          i32.add
          local.set 90
          local.get 90
          i32.const 12
          call $goose.reserve_data
          local.set 91
          local.get 90
          i64.extend_i32_u
          i64.const 32
          i64.shl
          local.get 91
          i64.extend_i32_u
          i64.or
          local.set 92
          local.get 92
          local.set 6
          local.get 92
          i64.const 1
          call $goose.memory_op.62
          local.get 5
          local.set 93
          local.get 92
          i64.const 4
          i64.add
          local.get 93
          call $goose.memory_op.55
          local.get 4
          i64.const 0
          i64.eq
          if ;; label = @4
            local.get 4
            i64.const 1
            i64.add
            local.set 4
            local.get 6
            local.set 94
            local.get 94
            call $goose.memory_op.53
            local.set 95
            i64.const 0
            local.set 96
            local.get 96
            local.get 95
            i64.ge_u
            if ;; label = @5
              i32.const 8
              i32.const 4486
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 94
            local.set 97
            local.get 97
            i64.const 4294967295
            i64.and
            i64.const 4
            i64.add
            local.get 96
            i64.const 8
            i64.mul
            i64.add
            local.tee 98
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4567
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 97
            i64.const -4294967296
            i64.and
            local.get 98
            i64.or
            call $goose.memory_op.41
            local.get 5
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 4648
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 3
            local.set 99
            local.get 99
            call $goose.memory_op.53
            local.set 100
            i64.const 1
            local.set 101
            local.get 101
            local.get 100
            i64.ge_u
            if ;; label = @5
              i32.const 8
              i32.const 4729
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 99
            local.set 102
            local.get 102
            i64.const 4294967295
            i64.and
            i64.const 4
            i64.add
            local.get 101
            i64.const 10
            i64.mul
            i64.add
            local.tee 103
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4810
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 102
            i64.const -4294967296
            i64.and
            local.get 103
            i64.or
            local.set 104
            local.get 104
            local.set 105
            local.get 105
            call $goose.memory_op.49
            local.set 106
            i64.const 0
            local.set 107
            local.get 107
            local.get 106
            i64.ge_u
            if ;; label = @5
              i32.const 8
              i32.const 4891
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 105
            local.set 108
            local.get 108
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 107
            i64.const 2
            i64.mul
            i64.add
            local.tee 109
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4972
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 108
            i64.const -4294967296
            i64.and
            local.get 109
            i64.or
            call $goose.memory_op.51
            i64.const 7
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 1
              i32.const 5053
              i32.const 81
              i32.const 30
              call 6
              unreachable
            end
            local.get 90
            local.get 91
            call $goose.restore_data
            br 1 (;@3;)
          end
          local.get 6
          local.set 110
          local.get 110
          call $goose.memory_op.53
          local.set 111
          i64.const 0
          local.set 112
          local.get 112
          local.get 111
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 5134
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 110
          local.set 113
          local.get 113
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 112
          i64.const 8
          i64.mul
          i64.add
          local.tee 114
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 5215
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 113
          i64.const -4294967296
          i64.and
          local.get 114
          i64.or
          call $goose.memory_op.41
          local.get 5
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 5296
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 3
          local.set 115
          local.get 115
          call $goose.memory_op.53
          local.set 116
          i64.const 1
          local.set 117
          local.get 117
          local.get 116
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 5377
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 115
          local.set 118
          local.get 118
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 117
          i64.const 10
          i64.mul
          i64.add
          local.tee 119
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 5458
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 118
          i64.const -4294967296
          i64.and
          local.get 119
          i64.or
          local.set 120
          local.get 120
          local.set 121
          local.get 121
          call $goose.memory_op.49
          local.set 122
          i64.const 0
          local.set 123
          local.get 123
          local.get 122
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 5539
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 121
          local.set 124
          local.get 124
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.get 123
          i64.const 2
          i64.mul
          i64.add
          local.tee 125
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 5620
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 124
          i64.const -4294967296
          i64.and
          local.get 125
          i64.or
          call $goose.memory_op.51
          i64.const 7
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 5701
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 90
          local.get 91
          call $goose.restore_data
          br 1 (;@2;)
          local.get 6
          local.set 126
          local.get 126
          call $goose.memory_op.53
          local.set 127
          i64.const 0
          local.set 128
          local.get 128
          local.get 127
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 5782
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 126
          local.set 129
          local.get 129
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 128
          i64.const 8
          i64.mul
          i64.add
          local.tee 130
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 5863
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 129
          i64.const -4294967296
          i64.and
          local.get 130
          i64.or
          call $goose.memory_op.41
          local.get 5
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 5944
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 3
          local.set 131
          local.get 131
          call $goose.memory_op.53
          local.set 132
          i64.const 1
          local.set 133
          local.get 133
          local.get 132
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 6025
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 131
          local.set 134
          local.get 134
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 133
          i64.const 10
          i64.mul
          i64.add
          local.tee 135
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 6106
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 134
          i64.const -4294967296
          i64.and
          local.get 135
          i64.or
          local.set 136
          local.get 136
          local.set 137
          local.get 137
          call $goose.memory_op.49
          local.set 138
          i64.const 0
          local.set 139
          local.get 139
          local.get 138
          i64.ge_u
          if ;; label = @4
            i32.const 8
            i32.const 6187
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 137
          local.set 140
          local.get 140
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.get 139
          i64.const 2
          i64.mul
          i64.add
          local.tee 141
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 6268
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 140
          i64.const -4294967296
          i64.and
          local.get 141
          i64.or
          call $goose.memory_op.51
          i64.const 7
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 6349
            i32.const 81
            i32.const 30
            call 6
            unreachable
          end
          local.get 90
          local.get 91
          call $goose.restore_data
          br 0 (;@3;)
        end
      end
      local.get 3
      local.set 142
      local.get 142
      call $goose.memory_op.53
      local.set 143
      i64.const 1
      local.set 144
      local.get 142
      local.set 145
      local.get 145
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 144
      i64.const 10
      i64.mul
      i64.add
      local.tee 146
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6430
        i32.const 81
        i32.const 34
        call 6
        unreachable
      end
      local.get 145
      i64.const -4294967296
      i64.and
      local.get 146
      i64.or
      local.set 147
      local.get 147
      i64.const 4294967295
      i64.and
      i64.const 9
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6511
        i32.const 81
        i32.const 0
        call 6
        unreachable
      end
      local.get 147
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      call $goose.memory_op.49
      local.set 7
      local.get 3
      local.set 148
      local.get 148
      call $goose.memory_op.53
      local.set 149
      i64.const 0
      local.set 150
      local.get 150
      local.get 149
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 6592
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 148
      local.set 151
      local.get 151
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 150
      i64.const 10
      i64.mul
      i64.add
      local.tee 152
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6673
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 151
      i64.const -4294967296
      i64.and
      local.get 152
      i64.or
      local.set 153
      local.get 153
      local.set 154
      local.get 154
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6754
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 3
      local.set 155
      local.get 155
      call $goose.memory_op.53
      local.set 156
      i64.const 1
      local.set 157
      local.get 157
      local.get 156
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 6835
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 155
      local.set 158
      local.get 158
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 157
      i64.const 10
      i64.mul
      i64.add
      local.tee 159
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6916
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 158
      i64.const -4294967296
      i64.and
      local.get 159
      i64.or
      local.set 160
      local.get 160
      local.set 161
      local.get 161
      call $goose.memory_op.49
      local.set 162
      i64.const 1
      local.set 163
      local.get 163
      local.get 162
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 6997
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 161
      local.set 164
      local.get 164
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 163
      i64.const 2
      i64.mul
      i64.add
      local.tee 165
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7078
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 164
      i64.const -4294967296
      i64.and
      local.get 165
      i64.or
      call $goose.memory_op.51
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7159
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 3
      local.set 166
      local.get 166
      call $goose.memory_op.53
      local.set 167
      i64.const 0
      local.set 168
      local.get 166
      local.set 169
      local.get 169
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 168
      i64.const 10
      i64.mul
      i64.add
      local.tee 170
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7240
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 169
      i64.const -4294967296
      i64.and
      local.get 170
      i64.or
      local.set 171
      local.get 171
      i64.const 4294967295
      i64.and
      i64.const 7
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7321
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 171
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 172
      local.get 172
      call $goose.memory_op.49
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7402
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 3
      local.set 173
      local.get 173
      call $goose.memory_op.53
      local.set 174
      i64.const 1
      local.set 175
      local.get 173
      local.set 176
      local.get 176
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 175
      i64.const 10
      i64.mul
      i64.add
      local.tee 177
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7483
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 176
      i64.const -4294967296
      i64.and
      local.get 177
      i64.or
      local.set 178
      local.get 178
      i64.const 4294967295
      i64.and
      i64.const 7
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7564
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 178
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 179
      local.get 179
      call $goose.memory_op.49
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7645
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 100
      i64.mul
      i64.const 9
      i64.add
      local.set 180
      i32.const 8
      local.get 180
      i64.store align=1
      local.get 8
      local.get 9
      call $goose.restore_data
      br 0 (;@1;)
      local.get 3
      local.set 181
      local.get 181
      call $goose.memory_op.53
      local.set 182
      i64.const 0
      local.set 183
      local.get 183
      local.get 182
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 7726
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 181
      local.set 184
      local.get 184
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 183
      i64.const 10
      i64.mul
      i64.add
      local.tee 185
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 7807
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 184
      i64.const -4294967296
      i64.and
      local.get 185
      i64.or
      local.set 186
      local.get 186
      local.set 187
      local.get 187
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 7888
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 3
      local.set 188
      local.get 188
      call $goose.memory_op.53
      local.set 189
      i64.const 1
      local.set 190
      local.get 190
      local.get 189
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 7969
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 188
      local.set 191
      local.get 191
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 190
      i64.const 10
      i64.mul
      i64.add
      local.tee 192
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8050
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 191
      i64.const -4294967296
      i64.and
      local.get 192
      i64.or
      local.set 193
      local.get 193
      local.set 194
      local.get 194
      call $goose.memory_op.49
      local.set 195
      i64.const 1
      local.set 196
      local.get 196
      local.get 195
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 8131
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 194
      local.set 197
      local.get 197
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 196
      i64.const 2
      i64.mul
      i64.add
      local.tee 198
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8212
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 197
      i64.const -4294967296
      i64.and
      local.get 198
      i64.or
      call $goose.memory_op.51
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 8293
        i32.const 81
        i32.const 19
        call 6
        unreachable
      end
      local.get 3
      local.set 199
      local.get 199
      call $goose.memory_op.53
      local.set 200
      i64.const 0
      local.set 201
      local.get 199
      local.set 202
      local.get 202
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 201
      i64.const 10
      i64.mul
      i64.add
      local.tee 203
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8374
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 202
      i64.const -4294967296
      i64.and
      local.get 203
      i64.or
      local.set 204
      local.get 204
      i64.const 4294967295
      i64.and
      i64.const 7
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8455
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 204
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 205
      local.get 205
      call $goose.memory_op.49
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 8536
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 3
      local.set 206
      local.get 206
      call $goose.memory_op.53
      local.set 207
      i64.const 1
      local.set 208
      local.get 206
      local.set 209
      local.get 209
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 208
      i64.const 10
      i64.mul
      i64.add
      local.tee 210
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8617
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 209
      i64.const -4294967296
      i64.and
      local.get 210
      i64.or
      local.set 211
      local.get 211
      i64.const 4294967295
      i64.and
      i64.const 7
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8698
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      local.get 211
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 212
      local.get 212
      call $goose.memory_op.49
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 8779
        i32.const 81
        i32.const 20
        call 6
        unreachable
      end
      i32.const 8
      i64.load align=1
      i64.const 100
      i64.mul
      i64.const 9
      i64.add
      local.set 213
      i32.const 8
      local.get 213
      i64.store align=1
      local.get 8
      local.get 9
      call $goose.restore_data
    end
    local.get 2
    global.set 0
    local.get 7
  )
  (func $inner.2 (;13;) (type 12) (param i64 i32) (result i64)
    (local i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64)
    i32.const 7
    call $goose.reserve_frame
    local.set 2
    block ;; label = @1
      local.get 2
      i32.const 0
      i32.add
      local.set 4
      local.get 4
      i64.const 0
      i64.store8
      local.get 0
      i64.const 65535
      i64.and
      local.set 5
      local.get 4
      i64.load8_u
      local.set 6
      local.get 6
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 8860
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 4
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 8
      local.get 8
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 2
      i64.mul
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 8941
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 7
      local.get 7
      i32.wrap_i64
      local.get 5
      i64.store16 align=1
      local.get 4
      local.get 6
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i64.const 1
      i64.add
      i64.const 65535
      i64.and
      local.set 5
      local.get 4
      i64.load8_u
      local.set 6
      local.get 6
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 9022
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 4
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 8
      local.get 8
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 2
      i64.mul
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 9103
        i32.const 81
        i32.const 11
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.set 7
      local.get 7
      i32.wrap_i64
      local.get 5
      i64.store16 align=1
      local.get 4
      local.get 6
      i64.const 1
      i64.add
      i64.store8
      local.get 2
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i64.extend_i32_u
      local.set 11
      local.get 11
      i32.wrap_i64
      i64.load8_u
      local.set 12
      i64.const 0
      local.set 13
      local.get 13
      local.get 12
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 9184
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 11
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 13
      i64.const 2
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 9265
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      i32.wrap_i64
      i64.load16_u align=1
      local.get 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 9346
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 2
      i32.const 0
      i32.add
      local.set 16
      local.get 16
      i64.extend_i32_u
      local.set 17
      local.get 17
      i32.wrap_i64
      i64.load8_u
      local.set 18
      i64.const 1
      local.set 19
      local.get 19
      local.get 18
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 9427
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 17
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 19
      i64.const 2
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 9508
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      i32.wrap_i64
      i64.load16_u align=1
      local.get 0
      i64.const 1
      i64.add
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 9589
        i32.const 81
        i32.const 12
        call 6
        unreachable
      end
      local.get 0
      local.get 1
      i32.const 0
      i32.add
      call $tick.3
      i64.const 65535
      i64.and
      local.set 3
      br 0 (;@1;)
    end
    local.get 2
    global.set 0
    local.get 3
  )
  (func $tick.3 (;14;) (type 12) (param i64 i32) (result i64)
    (local i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 8
      i64.load align=1
      i64.const 100
      i64.mul
      local.get 0
      i64.add
      local.set 5
      i32.const 8
      local.get 5
      i64.store align=1
      local.get 1
      i32.const 1
      i32.add
      local.set 6
      local.get 6
      i32.const 12
      call $goose.reserve_data
      local.set 7
      local.get 6
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 7
      i64.extend_i32_u
      i64.or
      local.set 8
      local.get 8
      local.set 3
      local.get 8
      i64.const 1
      call $goose.memory_op.62
      local.get 0
      local.set 9
      local.get 8
      i64.const 4
      i64.add
      local.get 9
      call $goose.memory_op.55
      local.get 3
      local.set 10
      local.get 10
      call $goose.memory_op.53
      local.set 11
      i64.const 0
      local.set 12
      local.get 10
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 9670
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      call $goose.memory_op.41
      local.get 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 9751
        i32.const 81
        i32.const 7
        call 6
        unreachable
      end
      i64.const 7
      local.set 4
      local.get 6
      local.get 7
      call $goose.restore_data
      br 0 (;@1;)
      local.get 6
      local.get 7
      call $goose.restore_data
    end
    local.get 4
  )
  (func $partial.4 (;15;) (type 13) (param i32) (result i64)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 2
      local.set 4
      i32.const 8
      call $goose.reserve_memory.2
      local.set 5
      local.get 4
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 5
      i64.extend_i32_u
      i64.or
      local.set 6
      local.get 6
      local.set 2
      local.get 6
      i64.const 1
      local.set 7
      i32.wrap_i64
      local.get 7
      i64.store32 2 align=1
      local.get 6
      i32.wrap_i64
      i32.const 4
      i32.add
      i32.const 0
      i32.add
      local.get 0
      if (result i64) ;; label = @2
        i64.const 5
        local.set 3
        local.get 5
        global.set 2
        br 1 (;@1;)
      else
        i64.const 7
      end
      i64.store16 2 align=1
      local.get 6
      i32.wrap_i64
      i32.const 4
      i32.add
      i32.const 2
      i32.add
      i64.const 8
      i64.store16 2 align=1
      local.get 2
      local.set 8
      local.get 8
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 9
      i64.const 0
      local.set 10
      local.get 8
      local.set 11
      local.get 11
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 10
      i64.const 4
      i64.mul
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 9832
        i32.const 81
        i32.const 39
        call 6
        unreachable
      end
      local.get 11
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 13
      local.get 13
      local.set 14
      i64.const 2
      local.set 15
      i64.const 0
      local.set 16
      local.get 14
      local.set 17
      local.get 17
      i64.const 4294967295
      i64.and
      local.get 16
      i64.const 2
      i64.mul
      i64.add
      local.tee 18
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 9913
        i32.const 81
        i32.const 39
        call 6
        unreachable
      end
      local.get 17
      i64.const -4294967296
      i64.and
      local.get 18
      i64.or
      i32.wrap_i64
      i64.load16_u 2 align=1
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 9994
        i32.const 81
        i32.const 39
        call 6
        unreachable
      end
      local.get 2
      local.set 19
      local.get 19
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 20
      i64.const 0
      local.set 21
      local.get 19
      local.set 22
      local.get 22
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 21
      i64.const 4
      i64.mul
      i64.add
      local.tee 23
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 10075
        i32.const 81
        i32.const 39
        call 6
        unreachable
      end
      local.get 22
      i64.const -4294967296
      i64.and
      local.get 23
      i64.or
      local.set 24
      local.get 24
      local.set 25
      i64.const 2
      local.set 26
      i64.const 1
      local.set 27
      local.get 25
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      local.get 27
      i64.const 2
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 10156
        i32.const 81
        i32.const 39
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      i32.wrap_i64
      i64.load16_u 2 align=1
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 10237
        i32.const 81
        i32.const 39
        call 6
        unreachable
      end
      i64.const 9
      local.set 3
      local.get 5
      global.set 2
      br 0 (;@1;)
      local.get 5
      global.set 2
    end
    local.get 3
  )
  (func $goose.init (;16;) (type 10)
    (local i32 i64)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
  )
  (func $goose.start (;17;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_data (;19;) (type 14) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            call $goose.reserve_memory.1
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.2
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;21;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.memory_op.62 (;22;) (type 15) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store32 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store32 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store32 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store32 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;23;) (type 15) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store8
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;24;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.61 (;25;) (type 15) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store16 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store16 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store16 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store16 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;26;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load32_u align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_to_frame (;27;) (type 1) (param i32 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 1
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy
              br 4 (;@1;)
            end
            local.get 0
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 0 1
            br 3 (;@1;)
          end
          local.get 0
          local.get 1
          i32.wrap_i64
          local.get 2
          memory.copy 0 2
          br 2 (;@1;)
        end
        local.get 0
        local.get 1
        i32.wrap_i64
        local.get 2
        memory.copy 0 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.51 (;28;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load16_u align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load16_u 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load16_u 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load16_u 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;29;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            i32.eqz
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            i64.extend_i32_u
            memory.size 1
            i64.extend_i32_u
            i64.const 16
            i64.shl
            i64.gt_u
            if ;; label = @5
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            local.get 1
            global.set 1
            br 3 (;@1;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 2
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 2
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 3
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;30;) (type 15) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;31;) (type 16) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goosedata-cleanup=ok/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_data_aggregate_cleanup.goose")
)
