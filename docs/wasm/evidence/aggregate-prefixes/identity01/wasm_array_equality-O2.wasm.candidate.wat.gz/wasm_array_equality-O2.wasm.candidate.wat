(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 4320)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 73
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 81
        i32.const 73
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 f64 f64 i64 i64 i64 i64 i64 i64 f64 f64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32)
    i32.const 190
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 15
      local.get 15
      i32.const 0
      i32.add
      i64.const 1
      i64.store align=1
      local.get 15
      i32.const 8
      i32.add
      i64.const 2
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 16
      local.get 16
      i32.const 0
      i32.add
      i64.const 1
      i64.store align=1
      local.get 16
      i32.const 8
      i32.add
      i64.const 2
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 17
      i64.const 2
      local.set 18
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 19
      i32.const 0
      local.set 20
      local.get 18
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 20
        i64.const 0
        local.set 21
        block ;; label = @3
          loop ;; label = @4
            local.get 21
            local.get 18
            i64.ge_u
            br_if 1 (;@3;)
            local.get 17
            local.set 22
            local.get 22
            i64.const 4294967295
            i64.and
            local.get 21
            i64.const 8
            i64.mul
            i64.add
            local.tee 23
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 154
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 22
            i64.const -4294967296
            i64.and
            local.get 23
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 19
            local.set 24
            local.get 24
            i64.const 4294967295
            i64.and
            local.get 21
            i64.const 8
            i64.mul
            i64.add
            local.tee 25
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 227
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 24
            i64.const -4294967296
            i64.and
            local.get 25
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 20
              br 2 (;@3;)
            end
            local.get 21
            i64.const 1
            i64.add
            local.set 21
            br 0 (;@4;)
          end
        end
      end
      local.get 20
      local.set 26
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 27
      i64.const 2
      local.set 28
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 29
      i32.const 0
      local.set 30
      local.get 28
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 30
        i64.const 0
        local.set 31
        block ;; label = @3
          loop ;; label = @4
            local.get 31
            local.get 28
            i64.ge_u
            br_if 1 (;@3;)
            local.get 27
            local.set 32
            local.get 32
            i64.const 4294967295
            i64.and
            local.get 31
            i64.const 8
            i64.mul
            i64.add
            local.tee 33
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 300
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 32
            i64.const -4294967296
            i64.and
            local.get 33
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 29
            local.set 34
            local.get 34
            i64.const 4294967295
            i64.and
            local.get 31
            i64.const 8
            i64.mul
            i64.add
            local.tee 35
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 373
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 34
            i64.const -4294967296
            i64.and
            local.get 35
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 30
              br 2 (;@3;)
            end
            local.get 31
            i64.const 1
            i64.add
            local.set 31
            br 0 (;@4;)
          end
        end
      end
      local.get 30
      i32.eqz
      local.set 36
      call 0
      local.set 37
      local.get 37
      local.get 26
      call 3
      local.get 37
      i32.const 446
      i32.const 1
      call 4
      local.get 37
      local.get 36
      call 3
      local.get 37
      call 5
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 38
      i64.const 2
      local.set 39
      i64.const 1
      local.set 40
      local.get 38
      local.set 41
      local.get 41
      i64.const 4294967295
      i64.and
      local.get 40
      i64.const 8
      i64.mul
      i64.add
      local.tee 42
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 447
        i32.const 73
        i32.const 5
        call 6
        unreachable
      end
      local.get 41
      i64.const -4294967296
      i64.and
      local.get 42
      i64.or
      local.set 43
      i64.const 9
      local.set 44
      local.get 43
      local.get 44
      local.set 45
      i32.wrap_i64
      local.get 45
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 46
      i64.const 2
      local.set 47
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 48
      i32.const 0
      local.set 49
      local.get 47
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 49
        i64.const 0
        local.set 50
        block ;; label = @3
          loop ;; label = @4
            local.get 50
            local.get 47
            i64.ge_u
            br_if 1 (;@3;)
            local.get 46
            local.set 51
            local.get 51
            i64.const 4294967295
            i64.and
            local.get 50
            i64.const 8
            i64.mul
            i64.add
            local.tee 52
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 520
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 51
            i64.const -4294967296
            i64.and
            local.get 52
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 48
            local.set 53
            local.get 53
            i64.const 4294967295
            i64.and
            local.get 50
            i64.const 8
            i64.mul
            i64.add
            local.tee 54
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 593
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 53
            i64.const -4294967296
            i64.and
            local.get 54
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 49
              br 2 (;@3;)
            end
            local.get 50
            i64.const 1
            i64.add
            local.set 50
            br 0 (;@4;)
          end
        end
      end
      local.get 49
      local.set 55
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 56
      i64.const 2
      local.set 57
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 58
      i32.const 0
      local.set 59
      local.get 57
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 59
        i64.const 0
        local.set 60
        block ;; label = @3
          loop ;; label = @4
            local.get 60
            local.get 57
            i64.ge_u
            br_if 1 (;@3;)
            local.get 56
            local.set 61
            local.get 61
            i64.const 4294967295
            i64.and
            local.get 60
            i64.const 8
            i64.mul
            i64.add
            local.tee 62
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 666
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 61
            i64.const -4294967296
            i64.and
            local.get 62
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 58
            local.set 63
            local.get 63
            i64.const 4294967295
            i64.and
            local.get 60
            i64.const 8
            i64.mul
            i64.add
            local.tee 64
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 739
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 63
            i64.const -4294967296
            i64.and
            local.get 64
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 59
              br 2 (;@3;)
            end
            local.get 60
            i64.const 1
            i64.add
            local.set 60
            br 0 (;@4;)
          end
        end
      end
      local.get 59
      i32.eqz
      local.set 65
      call 0
      local.set 66
      local.get 66
      local.get 55
      call 3
      local.get 66
      i32.const 812
      i32.const 1
      call 4
      local.get 66
      local.get 65
      call 3
      local.get 66
      call 5
      local.get 0
      i32.const 32
      i32.add
      local.set 67
      local.get 67
      i64.const 0
      i64.store8
      i64.const 1
      local.set 68
      local.get 67
      i64.load8_u
      local.set 69
      local.get 69
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 813
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 67
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 71
      local.get 71
      i64.const 4294967295
      i64.and
      local.get 69
      i64.const 1
      i64.mul
      i64.add
      local.tee 72
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 886
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 71
      i64.const -4294967296
      i64.and
      local.get 72
      i64.or
      local.tee 73
      local.get 68
      local.set 74
      i32.wrap_i64
      local.get 74
      i64.store8
      local.get 67
      local.get 69
      i64.const 1
      i64.add
      i64.store8
      i64.const 2
      local.set 75
      local.get 67
      i64.load8_u
      local.set 76
      local.get 76
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 959
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 67
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 78
      local.get 78
      i64.const 4294967295
      i64.and
      local.get 76
      i64.const 1
      i64.mul
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1032
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 78
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.tee 80
      local.get 75
      local.set 81
      i32.wrap_i64
      local.get 81
      i64.store8
      local.get 67
      local.get 76
      i64.const 1
      i64.add
      i64.store8
      local.get 67
      i32.const 3
      i32.add
      i32.const 0
      i32.const 1
      memory.fill
      local.get 0
      i32.const 36
      i32.add
      local.set 82
      local.get 82
      i64.const 0
      i64.store8
      i64.const 1
      local.set 83
      local.get 82
      i64.load8_u
      local.set 84
      local.get 84
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1105
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 82
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 86
      local.get 86
      i64.const 4294967295
      i64.and
      local.get 84
      i64.const 1
      i64.mul
      i64.add
      local.tee 87
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1178
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 86
      i64.const -4294967296
      i64.and
      local.get 87
      i64.or
      local.tee 88
      local.get 83
      local.set 89
      i32.wrap_i64
      local.get 89
      i64.store8
      local.get 82
      local.get 84
      i64.const 1
      i64.add
      i64.store8
      i64.const 2
      local.set 90
      local.get 82
      i64.load8_u
      local.set 91
      local.get 91
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1251
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 82
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 93
      local.get 93
      i64.const 4294967295
      i64.and
      local.get 91
      i64.const 1
      i64.mul
      i64.add
      local.tee 94
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1324
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 93
      i64.const -4294967296
      i64.and
      local.get 94
      i64.or
      local.tee 95
      local.get 90
      local.set 96
      i32.wrap_i64
      local.get 96
      i64.store8
      local.get 82
      local.get 91
      i64.const 1
      i64.add
      i64.store8
      local.get 82
      i32.const 3
      i32.add
      i32.const 0
      i32.const 1
      memory.fill
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 97
      local.get 97
      i32.wrap_i64
      i64.load8_u
      local.set 98
      local.get 0
      i32.const 36
      i32.add
      i64.extend_i32_u
      local.set 99
      i32.const 0
      local.set 100
      local.get 98
      local.get 99
      i32.wrap_i64
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 100
        i64.const 0
        local.set 101
        block ;; label = @3
          loop ;; label = @4
            local.get 101
            local.get 98
            i64.ge_u
            br_if 1 (;@3;)
            local.get 97
            local.set 102
            local.get 102
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 101
            i64.const 1
            i64.mul
            i64.add
            local.tee 103
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1397
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 102
            i64.const -4294967296
            i64.and
            local.get 103
            i64.or
            i32.wrap_i64
            i64.load8_u
            local.get 99
            local.set 104
            local.get 104
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 101
            i64.const 1
            i64.mul
            i64.add
            local.tee 105
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1470
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 104
            i64.const -4294967296
            i64.and
            local.get 105
            i64.or
            i32.wrap_i64
            i64.load8_u
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 100
              br 2 (;@3;)
            end
            local.get 101
            i64.const 1
            i64.add
            local.set 101
            br 0 (;@4;)
          end
        end
      end
      local.get 100
      local.set 106
      call 0
      local.set 107
      local.get 107
      local.get 106
      call 3
      local.get 107
      call 5
      local.get 0
      i32.const 36
      i32.add
      i64.extend_i32_u
      local.set 108
      local.get 108
      i32.wrap_i64
      i64.load8_u
      local.set 109
      local.get 109
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1543
        i32.const 73
        i32.const 7
        call 6
        unreachable
      end
      local.get 109
      i64.const 1
      i64.sub
      local.set 109
      local.get 108
      local.set 110
      local.get 110
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 109
      i64.const 1
      i64.mul
      i64.add
      local.tee 111
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1616
        i32.const 73
        i32.const 7
        call 6
        unreachable
      end
      local.get 110
      i64.const -4294967296
      i64.and
      local.get 111
      i64.or
      local.set 112
      local.get 112
      i32.wrap_i64
      i64.load8_u
      local.set 113
      local.get 108
      local.get 109
      local.set 114
      i32.wrap_i64
      local.get 114
      i64.store8
      local.get 113
      drop
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 115
      local.get 115
      i32.wrap_i64
      i64.load8_u
      local.set 116
      local.get 0
      i32.const 36
      i32.add
      i64.extend_i32_u
      local.set 117
      i32.const 0
      local.set 118
      local.get 116
      local.get 117
      i32.wrap_i64
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 118
        i64.const 0
        local.set 119
        block ;; label = @3
          loop ;; label = @4
            local.get 119
            local.get 116
            i64.ge_u
            br_if 1 (;@3;)
            local.get 115
            local.set 120
            local.get 120
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 119
            i64.const 1
            i64.mul
            i64.add
            local.tee 121
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1689
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 120
            i64.const -4294967296
            i64.and
            local.get 121
            i64.or
            i32.wrap_i64
            i64.load8_u
            local.get 117
            local.set 122
            local.get 122
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 119
            i64.const 1
            i64.mul
            i64.add
            local.tee 123
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1762
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 122
            i64.const -4294967296
            i64.and
            local.get 123
            i64.or
            i32.wrap_i64
            i64.load8_u
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 118
              br 2 (;@3;)
            end
            local.get 119
            i64.const 1
            i64.add
            local.set 119
            br 0 (;@4;)
          end
        end
      end
      local.get 118
      local.set 124
      call 0
      local.set 125
      local.get 125
      local.get 124
      call 3
      local.get 125
      call 5
      i32.const 1
      local.set 126
      global.get 1
      local.set 127
      local.get 0
      i32.const 40
      i32.add
      local.set 128
      local.get 128
      local.get 126
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 127
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 128
      i64.const 0
      i64.store offset=8 align=1
      i64.const 1
      local.set 129
      local.get 128
      i64.load offset=8 align=1
      local.set 130
      i32.const 8
      call $goose.reserve_memory.1
      local.set 131
      local.get 128
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 131
      i64.extend_i32_u
      i64.or
      local.tee 132
      local.get 129
      local.set 133
      i32.wrap_i64
      local.get 133
      i64.store 1 align=1
      local.get 128
      local.get 130
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i64.const 2
      local.set 134
      local.get 128
      i64.load offset=8 align=1
      local.set 135
      i32.const 8
      call $goose.reserve_memory.1
      local.set 136
      local.get 128
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 136
      i64.extend_i32_u
      i64.or
      local.tee 137
      local.get 134
      local.set 138
      i32.wrap_i64
      local.get 138
      i64.store 1 align=1
      local.get 128
      local.get 135
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i32.const 2
      local.set 139
      global.get 2
      local.set 140
      local.get 0
      i32.const 56
      i32.add
      local.set 141
      local.get 141
      local.get 139
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 140
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 141
      i64.const 0
      i64.store offset=8 align=1
      i64.const 1
      local.set 142
      local.get 141
      i64.load offset=8 align=1
      local.set 143
      i32.const 8
      call $goose.reserve_memory.2
      local.set 144
      local.get 141
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 144
      i64.extend_i32_u
      i64.or
      local.tee 145
      local.get 142
      local.set 146
      i32.wrap_i64
      local.get 146
      i64.store 2 align=1
      local.get 141
      local.get 143
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i64.const 2
      local.set 147
      local.get 141
      i64.load offset=8 align=1
      local.set 148
      i32.const 8
      call $goose.reserve_memory.2
      local.set 149
      local.get 141
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 149
      i64.extend_i32_u
      i64.or
      local.tee 150
      local.get 147
      local.set 151
      i32.wrap_i64
      local.get 151
      i64.store 2 align=1
      local.get 141
      local.get 148
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 40
      i32.add
      local.set 152
      local.get 152
      i64.load offset=8 align=1
      local.set 153
      local.get 0
      i32.const 56
      i32.add
      local.set 154
      i32.const 0
      local.set 155
      local.get 153
      local.get 154
      i64.load offset=8 align=1
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 155
        i64.const 0
        local.set 156
        block ;; label = @3
          loop ;; label = @4
            local.get 156
            local.get 153
            i64.ge_u
            br_if 1 (;@3;)
            local.get 152
            i64.load align=1
            local.set 157
            local.get 157
            i64.const 4294967295
            i64.and
            local.get 156
            i64.const 8
            i64.mul
            i64.add
            local.tee 158
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1835
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 157
            i64.const -4294967296
            i64.and
            local.get 158
            i64.or
            i32.wrap_i64
            i64.load 1 align=1
            local.get 154
            i64.load align=1
            local.set 159
            local.get 159
            i64.const 4294967295
            i64.and
            local.get 156
            i64.const 8
            i64.mul
            i64.add
            local.tee 160
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1908
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 159
            i64.const -4294967296
            i64.and
            local.get 160
            i64.or
            i32.wrap_i64
            i64.load 2 align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 155
              br 2 (;@3;)
            end
            local.get 156
            i64.const 1
            i64.add
            local.set 156
            br 0 (;@4;)
          end
        end
      end
      local.get 155
      local.set 161
      block ;; label = @2
        local.get 0
        i32.const 40
        i32.add
        local.set 1
        local.get 0
        i32.const 56
        i32.add
        local.set 2
        local.get 1
        local.tee 163
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1981
          i32.const 73
          i32.const 1
          call 6
          unreachable
        end
        local.get 163
        local.set 164
        local.get 164
        i64.load offset=8 align=1
        local.set 165
        local.get 2
        local.tee 166
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2054
          i32.const 73
          i32.const 1
          call 6
          unreachable
        end
        local.get 166
        local.set 167
        i32.const 0
        local.set 168
        local.get 165
        local.get 167
        i64.load offset=8 align=1
        i64.eq
        if ;; label = @3
          i32.const 1
          local.set 168
          i64.const 0
          local.set 169
          block ;; label = @4
            loop ;; label = @5
              local.get 169
              local.get 165
              i64.ge_u
              br_if 1 (;@4;)
              local.get 164
              i64.load align=1
              local.set 170
              local.get 170
              i64.const 4294967295
              i64.and
              local.get 169
              i64.const 8
              i64.mul
              i64.add
              local.tee 171
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 2127
                i32.const 73
                i32.const 1
                call 6
                unreachable
              end
              local.get 170
              i64.const -4294967296
              i64.and
              local.get 171
              i64.or
              call $goose.memory_op.41
              local.get 167
              i64.load align=1
              local.set 172
              local.get 172
              i64.const 4294967295
              i64.and
              local.get 169
              i64.const 8
              i64.mul
              i64.add
              local.tee 173
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 2200
                i32.const 73
                i32.const 1
                call 6
                unreachable
              end
              local.get 172
              i64.const -4294967296
              i64.and
              local.get 173
              i64.or
              call $goose.memory_op.41
              i64.eq
              i32.eqz
              if ;; label = @6
                i32.const 0
                local.set 168
                br 2 (;@4;)
              end
              local.get 169
              i64.const 1
              i64.add
              local.set 169
              br 0 (;@5;)
            end
          end
        end
        local.get 168
        local.set 174
        local.get 174
        local.set 162
      end
      local.get 162
      local.set 175
      call 0
      local.set 176
      local.get 176
      local.get 161
      call 3
      local.get 176
      i32.const 2273
      i32.const 1
      call 4
      local.get 176
      local.get 175
      call 3
      local.get 176
      call 5
      local.get 0
      i32.const 56
      i32.add
      local.set 177
      i64.const 3
      local.set 178
      local.get 177
      i64.load offset=8 align=1
      local.set 179
      i32.const 8
      call $goose.reserve_memory.2
      local.set 180
      local.get 177
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 180
      i64.extend_i32_u
      i64.or
      local.tee 181
      local.get 178
      local.set 182
      i32.wrap_i64
      local.get 182
      i64.store 2 align=1
      local.get 177
      local.get 179
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 181
      i32.wrap_i64
      i64.load 2 align=1
      drop
      local.get 0
      i32.const 40
      i32.add
      local.set 183
      local.get 183
      i64.load offset=8 align=1
      local.set 184
      local.get 0
      i32.const 56
      i32.add
      local.set 185
      i32.const 0
      local.set 186
      local.get 184
      local.get 185
      i64.load offset=8 align=1
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 186
        i64.const 0
        local.set 187
        block ;; label = @3
          loop ;; label = @4
            local.get 187
            local.get 184
            i64.ge_u
            br_if 1 (;@3;)
            local.get 183
            i64.load align=1
            local.set 188
            local.get 188
            i64.const 4294967295
            i64.and
            local.get 187
            i64.const 8
            i64.mul
            i64.add
            local.tee 189
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2274
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 188
            i64.const -4294967296
            i64.and
            local.get 189
            i64.or
            i32.wrap_i64
            i64.load 1 align=1
            local.get 185
            i64.load align=1
            local.set 190
            local.get 190
            i64.const 4294967295
            i64.and
            local.get 187
            i64.const 8
            i64.mul
            i64.add
            local.tee 191
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2347
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 190
            i64.const -4294967296
            i64.and
            local.get 191
            i64.or
            i32.wrap_i64
            i64.load 2 align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 186
              br 2 (;@3;)
            end
            local.get 187
            i64.const 1
            i64.add
            local.set 187
            br 0 (;@4;)
          end
        end
      end
      local.get 186
      local.set 192
      block ;; label = @2
        local.get 0
        i32.const 40
        i32.add
        local.set 3
        local.get 0
        i32.const 56
        i32.add
        local.set 4
        local.get 3
        local.tee 194
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2420
          i32.const 73
          i32.const 1
          call 6
          unreachable
        end
        local.get 194
        local.set 195
        local.get 195
        i64.load offset=8 align=1
        local.set 196
        local.get 4
        local.tee 197
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2493
          i32.const 73
          i32.const 1
          call 6
          unreachable
        end
        local.get 197
        local.set 198
        i32.const 0
        local.set 199
        local.get 196
        local.get 198
        i64.load offset=8 align=1
        i64.eq
        if ;; label = @3
          i32.const 1
          local.set 199
          i64.const 0
          local.set 200
          block ;; label = @4
            loop ;; label = @5
              local.get 200
              local.get 196
              i64.ge_u
              br_if 1 (;@4;)
              local.get 195
              i64.load align=1
              local.set 201
              local.get 201
              i64.const 4294967295
              i64.and
              local.get 200
              i64.const 8
              i64.mul
              i64.add
              local.tee 202
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 2566
                i32.const 73
                i32.const 1
                call 6
                unreachable
              end
              local.get 201
              i64.const -4294967296
              i64.and
              local.get 202
              i64.or
              call $goose.memory_op.41
              local.get 198
              i64.load align=1
              local.set 203
              local.get 203
              i64.const 4294967295
              i64.and
              local.get 200
              i64.const 8
              i64.mul
              i64.add
              local.tee 204
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 2639
                i32.const 73
                i32.const 1
                call 6
                unreachable
              end
              local.get 203
              i64.const -4294967296
              i64.and
              local.get 204
              i64.or
              call $goose.memory_op.41
              i64.eq
              i32.eqz
              if ;; label = @6
                i32.const 0
                local.set 199
                br 2 (;@4;)
              end
              local.get 200
              i64.const 1
              i64.add
              local.set 200
              br 0 (;@5;)
            end
          end
        end
        local.get 199
        local.set 205
        local.get 205
        local.set 193
      end
      local.get 193
      local.set 206
      call 0
      local.set 207
      local.get 207
      local.get 192
      call 3
      local.get 207
      i32.const 2712
      i32.const 1
      call 4
      local.get 207
      local.get 206
      call 3
      local.get 207
      call 5
      i64.const 4
      local.set 208
      local.get 0
      i32.const 72
      i32.add
      local.get 208
      i64.store align=1
      i64.const 4
      local.set 209
      local.get 0
      i32.const 80
      i32.add
      local.get 209
      i64.store align=1
      local.get 0
      i32.const 88
      i32.add
      local.set 210
      local.get 210
      i32.const 0
      i32.add
      local.get 0
      i32.const 72
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 210
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 211
      i64.const 2
      local.set 212
      i64.const 0
      local.set 213
      local.get 211
      local.set 214
      local.get 214
      i64.const 4294967295
      i64.and
      local.get 213
      i64.const 8
      i64.mul
      i64.add
      local.tee 215
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2713
        i32.const 73
        i32.const 11
        call 6
        unreachable
      end
      local.get 214
      i64.const -4294967296
      i64.and
      local.get 215
      i64.or
      i64.store align=1
      local.get 0
      i32.const 104
      i32.add
      local.set 216
      local.get 216
      i32.const 0
      i32.add
      local.get 0
      i32.const 72
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 216
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 217
      i64.const 2
      local.set 218
      i64.const 0
      local.set 219
      local.get 217
      local.set 220
      local.get 220
      i64.const 4294967295
      i64.and
      local.get 219
      i64.const 8
      i64.mul
      i64.add
      local.tee 221
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2786
        i32.const 73
        i32.const 11
        call 6
        unreachable
      end
      local.get 220
      i64.const -4294967296
      i64.and
      local.get 221
      i64.or
      i64.store align=1
      local.get 0
      i32.const 120
      i32.add
      local.set 222
      local.get 222
      i32.const 0
      i32.add
      local.get 0
      i32.const 80
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 222
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 223
      i64.const 2
      local.set 224
      i64.const 0
      local.set 225
      local.get 223
      local.set 226
      local.get 226
      i64.const 4294967295
      i64.and
      local.get 225
      i64.const 8
      i64.mul
      i64.add
      local.tee 227
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2859
        i32.const 73
        i32.const 12
        call 6
        unreachable
      end
      local.get 226
      i64.const -4294967296
      i64.and
      local.get 227
      i64.or
      i64.store align=1
      local.get 0
      i32.const 88
      i32.add
      i64.extend_i32_u
      local.set 228
      i64.const 2
      local.set 229
      local.get 0
      i32.const 104
      i32.add
      i64.extend_i32_u
      local.set 230
      i32.const 0
      local.set 231
      local.get 229
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 231
        i64.const 0
        local.set 232
        block ;; label = @3
          loop ;; label = @4
            local.get 232
            local.get 229
            i64.ge_u
            br_if 1 (;@3;)
            local.get 228
            local.set 233
            local.get 233
            i64.const 4294967295
            i64.and
            local.get 232
            i64.const 8
            i64.mul
            i64.add
            local.tee 234
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2932
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 233
            i64.const -4294967296
            i64.and
            local.get 234
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 230
            local.set 235
            local.get 235
            i64.const 4294967295
            i64.and
            local.get 232
            i64.const 8
            i64.mul
            i64.add
            local.tee 236
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3005
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 235
            i64.const -4294967296
            i64.and
            local.get 236
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 231
              br 2 (;@3;)
            end
            local.get 232
            i64.const 1
            i64.add
            local.set 232
            br 0 (;@4;)
          end
        end
      end
      local.get 231
      local.set 237
      local.get 0
      i32.const 88
      i32.add
      i64.extend_i32_u
      local.set 238
      i64.const 2
      local.set 239
      local.get 0
      i32.const 120
      i32.add
      i64.extend_i32_u
      local.set 240
      i32.const 0
      local.set 241
      local.get 239
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 241
        i64.const 0
        local.set 242
        block ;; label = @3
          loop ;; label = @4
            local.get 242
            local.get 239
            i64.ge_u
            br_if 1 (;@3;)
            local.get 238
            local.set 243
            local.get 243
            i64.const 4294967295
            i64.and
            local.get 242
            i64.const 8
            i64.mul
            i64.add
            local.tee 244
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3078
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 243
            i64.const -4294967296
            i64.and
            local.get 244
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 240
            local.set 245
            local.get 245
            i64.const 4294967295
            i64.and
            local.get 242
            i64.const 8
            i64.mul
            i64.add
            local.tee 246
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3151
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 245
            i64.const -4294967296
            i64.and
            local.get 246
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 241
              br 2 (;@3;)
            end
            local.get 242
            i64.const 1
            i64.add
            local.set 242
            br 0 (;@4;)
          end
        end
      end
      local.get 241
      local.set 247
      call 0
      local.set 248
      local.get 248
      local.get 237
      call 3
      local.get 248
      i32.const 3224
      i32.const 1
      call 4
      local.get 248
      local.get 247
      call 3
      local.get 248
      call 5
      local.get 0
      i32.const 136
      i32.add
      local.set 249
      local.get 249
      i32.const 0
      i32.add
      f64.const -0x0p+0 (;=-0;)
      f64.store align=1
      local.get 249
      i32.const 8
      i32.add
      f64.const 0x1.4p+1 (;=2.5;)
      f64.store align=1
      local.get 0
      i32.const 152
      i32.add
      local.set 250
      local.get 250
      i32.const 0
      i32.add
      f64.const 0x0p+0 (;=0;)
      f64.store align=1
      local.get 250
      i32.const 8
      i32.add
      f64.const 0x1.4p+1 (;=2.5;)
      f64.store align=1
      local.get 0
      i32.const 136
      i32.add
      i64.extend_i32_u
      local.set 251
      i64.const 2
      local.set 252
      local.get 0
      i32.const 152
      i32.add
      i64.extend_i32_u
      local.set 253
      i32.const 0
      local.set 254
      local.get 252
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 254
        i64.const 0
        local.set 255
        block ;; label = @3
          loop ;; label = @4
            local.get 255
            local.get 252
            i64.ge_u
            br_if 1 (;@3;)
            local.get 251
            local.set 256
            local.get 256
            i64.const 4294967295
            i64.and
            local.get 255
            i64.const 8
            i64.mul
            i64.add
            local.tee 257
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3225
              i32.const 73
              i32.const 15
              call 6
              unreachable
            end
            local.get 256
            i64.const -4294967296
            i64.and
            local.get 257
            i64.or
            i32.wrap_i64
            f64.load align=1
            local.get 253
            local.set 258
            local.get 258
            i64.const 4294967295
            i64.and
            local.get 255
            i64.const 8
            i64.mul
            i64.add
            local.tee 259
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3298
              i32.const 73
              i32.const 15
              call 6
              unreachable
            end
            local.get 258
            i64.const -4294967296
            i64.and
            local.get 259
            i64.or
            i32.wrap_i64
            f64.load align=1
            f64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 254
              br 2 (;@3;)
            end
            local.get 255
            i64.const 1
            i64.add
            local.set 255
            br 0 (;@4;)
          end
        end
      end
      local.get 254
      local.set 260
      call 0
      local.set 261
      local.get 261
      local.get 260
      call 3
      local.get 261
      call 5
      local.get 0
      i32.const 136
      i32.add
      i64.extend_i32_u
      local.set 262
      i64.const 2
      local.set 263
      i64.const 1
      local.set 264
      local.get 262
      local.set 265
      local.get 265
      i64.const 4294967295
      i64.and
      local.get 264
      i64.const 8
      i64.mul
      i64.add
      local.tee 266
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3371
        i32.const 73
        i32.const 15
        call 6
        unreachable
      end
      local.get 265
      i64.const -4294967296
      i64.and
      local.get 266
      i64.or
      local.set 267
      f64.const -nan (;=NaN;)
      local.set 268
      local.get 267
      local.get 268
      local.set 269
      i32.wrap_i64
      local.get 269
      f64.store align=1
      local.get 0
      i32.const 152
      i32.add
      i64.extend_i32_u
      local.set 270
      i64.const 2
      local.set 271
      i64.const 1
      local.set 272
      local.get 270
      local.set 273
      local.get 273
      i64.const 4294967295
      i64.and
      local.get 272
      i64.const 8
      i64.mul
      i64.add
      local.tee 274
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3444
        i32.const 73
        i32.const 15
        call 6
        unreachable
      end
      local.get 273
      i64.const -4294967296
      i64.and
      local.get 274
      i64.or
      local.set 275
      f64.const -nan (;=NaN;)
      local.set 276
      local.get 275
      local.get 276
      local.set 277
      i32.wrap_i64
      local.get 277
      f64.store align=1
      local.get 0
      i32.const 136
      i32.add
      i64.extend_i32_u
      local.set 278
      i64.const 2
      local.set 279
      local.get 0
      i32.const 152
      i32.add
      i64.extend_i32_u
      local.set 280
      i32.const 0
      local.set 281
      local.get 279
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 281
        i64.const 0
        local.set 282
        block ;; label = @3
          loop ;; label = @4
            local.get 282
            local.get 279
            i64.ge_u
            br_if 1 (;@3;)
            local.get 278
            local.set 283
            local.get 283
            i64.const 4294967295
            i64.and
            local.get 282
            i64.const 8
            i64.mul
            i64.add
            local.tee 284
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3517
              i32.const 73
              i32.const 16
              call 6
              unreachable
            end
            local.get 283
            i64.const -4294967296
            i64.and
            local.get 284
            i64.or
            i32.wrap_i64
            f64.load align=1
            local.get 280
            local.set 285
            local.get 285
            i64.const 4294967295
            i64.and
            local.get 282
            i64.const 8
            i64.mul
            i64.add
            local.tee 286
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3590
              i32.const 73
              i32.const 16
              call 6
              unreachable
            end
            local.get 285
            i64.const -4294967296
            i64.and
            local.get 286
            i64.or
            i32.wrap_i64
            f64.load align=1
            f64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 281
              br 2 (;@3;)
            end
            local.get 282
            i64.const 1
            i64.add
            local.set 282
            br 0 (;@4;)
          end
        end
      end
      local.get 281
      local.set 287
      call 0
      local.set 288
      local.get 288
      local.get 287
      call 3
      local.get 288
      call 5
      i64.const 0
      local.set 5
      i64.const 0
      local.set 6
      block ;; label = @2
        local.get 5
        local.set 7
        local.get 6
        local.set 8
        local.get 7
        local.get 8
        i64.eq
        local.set 290
        local.get 290
        local.set 289
      end
      local.get 289
      local.set 291
      call 0
      local.set 292
      local.get 292
      local.get 291
      call 3
      local.get 292
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 5
      block ;; label = @2
        local.get 5
        local.set 9
        local.get 6
        local.set 10
        local.get 9
        local.get 10
        i64.eq
        local.set 294
        local.get 294
        local.set 293
      end
      local.get 293
      local.set 295
      call 0
      local.set 296
      local.get 296
      local.get 295
      call 3
      local.get 296
      call 5
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 6
      block ;; label = @2
        local.get 5
        local.set 11
        local.get 6
        local.set 12
        local.get 11
        local.get 12
        i64.eq
        local.set 298
        local.get 298
        local.set 297
      end
      local.get 297
      local.set 299
      call 0
      local.set 300
      local.get 300
      local.get 299
      call 3
      local.get 300
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 6
      block ;; label = @2
        local.get 5
        local.set 13
        local.get 6
        local.set 14
        local.get 13
        local.get 14
        i64.eq
        local.set 302
        local.get 302
        local.set 301
      end
      local.get 301
      local.set 303
      call 0
      local.set 304
      local.get 304
      local.get 303
      call 3
      local.get 304
      call 5
      local.get 0
      i32.const 168
      i32.add
      local.set 305
      local.get 305
      i32.const 0
      i32.add
      f32.const -0x0p+0 (;=-0;)
      f32.store align=1
      local.get 305
      i32.const 4
      i32.add
      f32.const 0x1.8p+0 (;=1.5;)
      f32.store align=1
      local.get 0
      i32.const 176
      i32.add
      local.set 306
      local.get 306
      i32.const 0
      i32.add
      f32.const 0x0p+0 (;=0;)
      f32.store align=1
      local.get 306
      i32.const 4
      i32.add
      f32.const 0x1.8p+0 (;=1.5;)
      f32.store align=1
      local.get 0
      i32.const 168
      i32.add
      i64.extend_i32_u
      local.set 307
      i64.const 2
      local.set 308
      local.get 0
      i32.const 176
      i32.add
      i64.extend_i32_u
      local.set 309
      i32.const 0
      local.set 310
      local.get 308
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 310
        i64.const 0
        local.set 311
        block ;; label = @3
          loop ;; label = @4
            local.get 311
            local.get 308
            i64.ge_u
            br_if 1 (;@3;)
            local.get 307
            local.set 312
            local.get 312
            i64.const 4294967295
            i64.and
            local.get 311
            i64.const 4
            i64.mul
            i64.add
            local.tee 313
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3663
              i32.const 73
              i32.const 23
              call 6
              unreachable
            end
            local.get 312
            i64.const -4294967296
            i64.and
            local.get 313
            i64.or
            i32.wrap_i64
            f32.load align=1
            local.get 309
            local.set 314
            local.get 314
            i64.const 4294967295
            i64.and
            local.get 311
            i64.const 4
            i64.mul
            i64.add
            local.tee 315
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3736
              i32.const 73
              i32.const 23
              call 6
              unreachable
            end
            local.get 314
            i64.const -4294967296
            i64.and
            local.get 315
            i64.or
            i32.wrap_i64
            f32.load align=1
            f32.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 310
              br 2 (;@3;)
            end
            local.get 311
            i64.const 1
            i64.add
            local.set 311
            br 0 (;@4;)
          end
        end
      end
      local.get 310
      local.set 316
      call 0
      local.set 317
      local.get 317
      local.get 316
      call 3
      local.get 317
      call 5
      local.get 0
      i32.const 184
      i32.add
      local.set 318
      local.get 318
      i32.const 0
      i32.add
      i32.const 1
      i32.store8
      local.get 318
      i32.const 1
      i32.add
      i32.const 0
      i32.store8
      local.get 0
      i32.const 186
      i32.add
      local.set 319
      local.get 319
      i32.const 0
      i32.add
      i32.const 1
      i32.store8
      local.get 319
      i32.const 1
      i32.add
      i32.const 0
      i32.store8
      local.get 0
      i32.const 184
      i32.add
      i64.extend_i32_u
      local.set 320
      i64.const 2
      local.set 321
      local.get 0
      i32.const 186
      i32.add
      i64.extend_i32_u
      local.set 322
      i32.const 0
      local.set 323
      local.get 321
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 323
        i64.const 0
        local.set 324
        block ;; label = @3
          loop ;; label = @4
            local.get 324
            local.get 321
            i64.ge_u
            br_if 1 (;@3;)
            local.get 320
            local.set 325
            local.get 325
            i64.const 4294967295
            i64.and
            local.get 324
            i64.const 1
            i64.mul
            i64.add
            local.tee 326
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3809
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 325
            i64.const -4294967296
            i64.and
            local.get 326
            i64.or
            i32.wrap_i64
            i32.load8_u
            local.get 322
            local.set 327
            local.get 327
            i64.const 4294967295
            i64.and
            local.get 324
            i64.const 1
            i64.mul
            i64.add
            local.tee 328
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3882
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 327
            i64.const -4294967296
            i64.and
            local.get 328
            i64.or
            i32.wrap_i64
            i32.load8_u
            i32.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 323
              br 2 (;@3;)
            end
            local.get 324
            i64.const 1
            i64.add
            local.set 324
            br 0 (;@4;)
          end
        end
      end
      local.get 323
      local.set 329
      call 0
      local.set 330
      local.get 330
      local.get 329
      call 3
      local.get 330
      call 5
      local.get 0
      i32.const 186
      i32.add
      i64.extend_i32_u
      local.set 331
      i64.const 2
      local.set 332
      i64.const 1
      local.set 333
      local.get 331
      local.set 334
      local.get 334
      i64.const 4294967295
      i64.and
      local.get 333
      i64.const 1
      i64.mul
      i64.add
      local.tee 335
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3955
        i32.const 73
        i32.const 25
        call 6
        unreachable
      end
      local.get 334
      i64.const -4294967296
      i64.and
      local.get 335
      i64.or
      local.set 336
      i32.const 1
      local.set 337
      local.get 336
      local.get 337
      local.set 338
      i32.wrap_i64
      local.get 338
      i32.store8
      local.get 0
      i32.const 184
      i32.add
      i64.extend_i32_u
      local.set 339
      i64.const 2
      local.set 340
      local.get 0
      i32.const 186
      i32.add
      i64.extend_i32_u
      local.set 341
      i32.const 0
      local.set 342
      local.get 340
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 342
        i64.const 0
        local.set 343
        block ;; label = @3
          loop ;; label = @4
            local.get 343
            local.get 340
            i64.ge_u
            br_if 1 (;@3;)
            local.get 339
            local.set 344
            local.get 344
            i64.const 4294967295
            i64.and
            local.get 343
            i64.const 1
            i64.mul
            i64.add
            local.tee 345
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4028
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 344
            i64.const -4294967296
            i64.and
            local.get 345
            i64.or
            i32.wrap_i64
            i32.load8_u
            local.get 341
            local.set 346
            local.get 346
            i64.const 4294967295
            i64.and
            local.get 343
            i64.const 1
            i64.mul
            i64.add
            local.tee 347
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4101
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 346
            i64.const -4294967296
            i64.and
            local.get 347
            i64.or
            i32.wrap_i64
            i32.load8_u
            i32.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 342
              br 2 (;@3;)
            end
            local.get 343
            i64.const 1
            i64.add
            local.set 343
            br 0 (;@4;)
          end
        end
      end
      local.get 342
      local.set 348
      call 0
      local.set 349
      local.get 349
      local.get 348
      call 3
      local.get 349
      call 5
      local.get 0
      i32.const 188
      i32.add
      local.set 350
      local.get 0
      i32.const 189
      i32.add
      local.set 351
      local.get 0
      i32.const 188
      i32.add
      i64.extend_i32_u
      local.set 352
      i64.const 0
      local.set 353
      local.get 0
      i32.const 189
      i32.add
      i64.extend_i32_u
      local.set 354
      i32.const 0
      local.set 355
      local.get 353
      i64.const 0
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 355
        i64.const 0
        local.set 356
        block ;; label = @3
          loop ;; label = @4
            local.get 356
            local.get 353
            i64.ge_u
            br_if 1 (;@3;)
            local.get 352
            local.set 357
            local.get 357
            i64.const 4294967295
            i64.and
            local.get 356
            i64.const 8
            i64.mul
            i64.add
            local.tee 358
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4174
              i32.const 73
              i32.const 26
              call 6
              unreachable
            end
            local.get 357
            i64.const -4294967296
            i64.and
            local.get 358
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 354
            local.set 359
            local.get 359
            i64.const 4294967295
            i64.and
            local.get 356
            i64.const 8
            i64.mul
            i64.add
            local.tee 360
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 4247
              i32.const 73
              i32.const 26
              call 6
              unreachable
            end
            local.get 359
            i64.const -4294967296
            i64.and
            local.get 360
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 355
              br 2 (;@3;)
            end
            local.get 356
            i64.const 1
            i64.add
            local.set 356
            br 0 (;@4;)
          end
        end
      end
      local.get 355
      local.set 361
      call 0
      local.set 362
      local.get 362
      local.get 361
      call 3
      local.get 362
      call 5
      local.get 140
      global.set 2
      local.get 127
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.41 (;16;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose")
)
