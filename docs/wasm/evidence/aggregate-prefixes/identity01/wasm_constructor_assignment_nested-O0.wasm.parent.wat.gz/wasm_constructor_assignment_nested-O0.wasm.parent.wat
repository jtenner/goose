(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1520)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 88
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 96
        i32.const 88
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i64 i32 i64 i64 i32 i32 i32 i32 i32 i64 i32)
    i32.const 22
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 1
      local.get 1
      i64.const 1
      i64.store align=1
      local.get 1
      i64.const 0
      i64.store8 offset=8
      i64.const 1
      local.set 2
      local.get 1
      i64.load8_u offset=8
      local.set 3
      local.get 3
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 184
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 1
      i32.const 8
      i32.add
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 1
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 272
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store8
      local.get 1
      local.get 3
      i64.const 1
      i64.add
      i64.store8 offset=8
      local.get 1
      i64.const 0
      i64.store8 offset=12
      local.get 1
      i64.const 2
      i64.store offset=13 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 7
      i32.const 21
      call $goose.reserve_frame
      local.set 8
      local.get 8
      i64.const 7
      i64.store align=1
      local.get 8
      i64.const 0
      i64.store8 offset=8
      i64.const 3
      local.set 2
      local.get 8
      i64.load8_u offset=8
      local.set 3
      local.get 3
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 360
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 8
      i32.const 8
      i32.add
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 1
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 448
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store8
      local.get 8
      local.get 3
      i64.const 1
      i64.add
      i64.store8 offset=8
      i64.const 4
      local.set 2
      local.get 8
      i64.load8_u offset=8
      local.set 3
      local.get 3
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 536
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 8
      i32.const 8
      i32.add
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 1
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 624
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store8
      local.get 8
      local.get 3
      i64.const 1
      i64.add
      i64.store8 offset=8
      local.get 8
      i64.const 1
      i64.store8 offset=12
      local.get 8
      i64.const 9
      i64.store8 offset=13
      local.get 7
      local.get 8
      i32.const 21
      memory.copy
      local.get 8
      global.set 0
      local.get 0
      i32.const 0
      i32.add
      local.set 9
      local.get 9
      i64.load align=1
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 712
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i32.const 8
      i32.add
      local.set 11
      local.get 11
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 800
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 12
      local.get 12
      i32.const 8
      i32.add
      local.set 13
      local.get 13
      i64.load8_u
      local.set 14
      i64.const 1
      local.set 15
      local.get 13
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 16
      local.get 16
      i64.const 4294967295
      i64.and
      local.get 15
      i64.const 1
      i64.mul
      i64.add
      local.tee 17
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 888
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 16
      i64.const -4294967296
      i64.and
      local.get 17
      i64.or
      i32.wrap_i64
      i64.load8_u
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 976
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 18
      local.get 18
      i64.load8_u offset=12
      local.set 19
      local.get 19
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 1064
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 19
        i64.const 1
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 21
          i32.add
          local.set 20
          local.get 20
          i64.extend_i32_u
          local.set 21
          local.get 18
          i32.const 13
          i32.add
          i64.extend_i32_u
          local.set 22
          i32.const 1
          local.set 23
          local.get 21
          i32.wrap_i64
          local.get 22
          i32.wrap_i64
          local.get 23
          memory.copy
          local.get 0
          i32.const 21
          i32.add
          local.set 24
          local.get 24
          i64.load8_u
          i64.const 9
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1152
            i32.const 88
            i32.const 4
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        i32.const 0
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1240
          i32.const 88
          i32.const 4
          call 6
          unreachable
        end
        br 0 (;@2;)
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 25
      i32.const 9
      call $goose.reserve_frame
      local.set 26
      local.get 26
      i64.const 2
      i64.store8
      local.get 25
      i32.const 12
      i32.add
      local.get 26
      i32.const 9
      memory.copy
      local.get 26
      global.set 0
      local.get 0
      i32.const 0
      i32.add
      local.set 27
      local.get 27
      i64.load8_u offset=12
      local.set 28
      local.get 28
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 1328
        i32.const 88
        i32.const 4
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 28
        i64.const 2
        i64.eq
        if ;; label = @3
          br 1 (;@2;)
        end
        i32.const 0
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1416
          i32.const 88
          i32.const 4
          call 6
          unreachable
        end
        br 0 (;@2;)
      end
      call 0
      local.set 29
      local.get 29
      i32.const 1504
      i32.const 6
      call 4
      local.get 29
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_constructor_assignment_nested.goosenested")
)
