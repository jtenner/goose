(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1312)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 98
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 106
        i32.const 98
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i32.const 7
      call $goose.reserve_frame
      local.set 2
      local.get 2
      local.set 3
      local.get 3
      call $first.1
      local.get 2
      i64.load8_u
      local.set 4
      i32.const 9
      call $goose.reserve_frame
      local.set 5
      local.get 5
      local.set 6
      local.get 6
      call $second.2
      i32.const 0
      local.set 7
      local.get 4
      local.get 5
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 7
        i64.const 0
        local.set 8
        block ;; label = @3
          loop ;; label = @4
            local.get 8
            local.get 4
            i64.ge_u
            br_if 1 (;@3;)
            local.get 2
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 9
            local.get 9
            i64.const 4294967295
            i64.and
            local.get 8
            i64.const 2
            i64.mul
            i64.add
            local.tee 10
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 204
              i32.const 98
              i32.const 3
              call 6
              unreachable
            end
            local.get 9
            i64.const -4294967296
            i64.and
            local.get 10
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            local.get 5
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 11
            local.get 11
            i64.const 4294967295
            i64.and
            local.get 8
            i64.const 2
            i64.mul
            i64.add
            local.tee 12
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 302
              i32.const 98
              i32.const 3
              call 6
              unreachable
            end
            local.get 11
            i64.const -4294967296
            i64.and
            local.get 12
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 7
              br 2 (;@3;)
            end
            local.get 8
            i64.const 1
            i64.add
            local.set 8
            br 0 (;@4;)
          end
        end
      end
      local.get 7
      local.set 1
      local.get 5
      global.set 0
      local.get 2
      global.set 0
      local.get 1
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 400
        i32.const 98
        i32.const 3
        call 6
        unreachable
      end
      call 0
      local.set 13
      local.get 13
      i32.const 498
      i32.const 20
      call 4
      local.get 13
      call 5
    end
  )
  (func $first.1 (;12;) (type 5) (param i32)
    (local i32 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      i64.const 0
      i64.store8
      i64.const 7
      local.set 2
      local.get 0
      i64.load8_u
      local.set 3
      local.get 3
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 518
        i32.const 98
        i32.const 1
        call 6
        unreachable
      end
      local.get 0
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 2
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 616
        i32.const 98
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store16 align=1
      local.get 0
      local.get 3
      i64.const 1
      i64.add
      i64.store8
      i64.const 8
      local.set 2
      local.get 0
      i64.load8_u
      local.set 3
      local.get 3
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 714
        i32.const 98
        i32.const 1
        call 6
        unreachable
      end
      local.get 0
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 2
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 812
        i32.const 98
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store16 align=1
      local.get 0
      local.get 3
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 5
      i32.add
      i32.const 0
      i32.const 2
      memory.fill
      br 0 (;@1;)
    end
  )
  (func $second.2 (;13;) (type 5) (param i32)
    (local i32 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      i64.const 0
      i64.store8
      i64.const 7
      local.set 2
      local.get 0
      i64.load8_u
      local.set 3
      local.get 3
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 910
        i32.const 98
        i32.const 2
        call 6
        unreachable
      end
      local.get 0
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 2
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1008
        i32.const 98
        i32.const 2
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store16 align=1
      local.get 0
      local.get 3
      i64.const 1
      i64.add
      i64.store8
      i64.const 8
      local.set 2
      local.get 0
      i64.load8_u
      local.set 3
      local.get 3
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1106
        i32.const 98
        i32.const 2
        call 6
        unreachable
      end
      local.get 0
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 3
      i64.const 2
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1204
        i32.const 98
        i32.const 2
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 4
      local.get 4
      i32.wrap_i64
      local.get 2
      i64.store16 align=1
      local.get 0
      local.get 3
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 5
      i32.add
      i32.const 0
      i32.const 4
      memory.fill
      br 0 (;@1;)
    end
  )
  (func $goose.init (;14;) (type 10)
    (local i32)
  )
  (func $goose.start (;15;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goosedifferent_capacities/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_different_capacities.goose")
)
