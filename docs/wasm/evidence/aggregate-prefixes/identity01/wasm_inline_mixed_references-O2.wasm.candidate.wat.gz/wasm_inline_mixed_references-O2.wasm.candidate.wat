(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 5120)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 82
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 90
        i32.const 82
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 146
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 13
      global.get 1
      local.set 14
      local.get 0
      i32.const 0
      i32.add
      local.set 15
      local.get 15
      local.get 13
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 14
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 15
      i64.const 0
      i64.store offset=8 align=1
      i64.const 3
      local.set 16
      local.get 15
      i64.load offset=8 align=1
      local.set 17
      i32.const 8
      call $goose.reserve_memory.1
      local.set 18
      local.get 15
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 18
      i64.extend_i32_u
      i64.or
      local.tee 19
      local.get 16
      local.set 20
      i32.wrap_i64
      local.get 20
      i64.store 1 align=1
      local.get 15
      local.get 17
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 21
      local.get 21
      i32.const 0
      i32.add
      i64.const 10
      i64.store align=1
      local.get 21
      i32.const 8
      i32.add
      i64.const 20
      i64.store align=1
      local.get 0
      i32.const 32
      i32.add
      local.set 22
      local.get 22
      i64.const 0
      i64.store8
      i64.const 30
      local.set 23
      local.get 22
      i64.load8_u
      local.set 24
      local.get 24
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 172
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 22
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 26
      local.get 26
      i64.const 4294967295
      i64.and
      local.get 24
      i64.const 8
      i64.mul
      i64.add
      local.tee 27
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 254
        i32.const 82
        i32.const 9
        call 6
        unreachable
      end
      local.get 26
      i64.const -4294967296
      i64.and
      local.get 27
      i64.or
      local.tee 28
      local.get 23
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store align=1
      local.get 22
      local.get 24
      i64.const 1
      i64.add
      i64.store8
      local.get 22
      i32.const 9
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      block ;; label = @2
        local.get 0
        i32.const 16
        i32.add
        i64.extend_i32_u
        local.set 1
        local.get 0
        i32.const 32
        i32.add
        i64.extend_i32_u
        local.set 2
        local.get 0
        i32.const 0
        i32.add
        local.set 30
        local.get 30
        i64.load offset=8 align=1
        local.set 31
        i64.const 0
        local.set 32
        local.get 30
        i64.load align=1
        local.set 33
        local.get 33
        i64.const 4294967295
        i64.and
        local.get 32
        i64.const 8
        i64.mul
        i64.add
        local.tee 34
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 336
          i32.const 82
          i32.const 10
          call 6
          unreachable
        end
        local.get 33
        i64.const -4294967296
        i64.and
        local.get 34
        i64.or
        local.set 3
        local.get 1
        local.tee 35
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 418
          i32.const 82
          i32.const 1
          call 6
          unreachable
        end
        local.get 35
        local.set 36
        i64.const 2
        local.set 37
        i64.const 0
        local.set 38
        local.get 36
        local.set 39
        local.get 39
        i64.const 4294967295
        i64.and
        local.get 38
        i64.const 8
        i64.mul
        i64.add
        local.tee 40
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 500
          i32.const 82
          i32.const 2
          call 6
          unreachable
        end
        local.get 39
        i64.const -4294967296
        i64.and
        local.get 40
        i64.or
        local.set 41
        local.get 41
        call $goose.memory_op.41
        local.get 3
        local.tee 42
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 582
          i32.const 82
          i32.const 2
          call 6
          unreachable
        end
        local.get 42
        call $goose.memory_op.41
        i64.add
        local.set 43
        local.get 41
        local.get 43
        call $goose.memory_op.55
        local.get 2
        local.tee 44
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 664
          i32.const 82
          i32.const 1
          call 6
          unreachable
        end
        local.get 44
        local.set 45
        local.get 1
        local.tee 46
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 746
          i32.const 82
          i32.const 1
          call 6
          unreachable
        end
        local.get 46
        local.set 47
        i64.const 2
        local.set 48
        i64.const 0
        local.set 49
        local.get 47
        local.set 50
        local.get 50
        i64.const 4294967295
        i64.and
        local.get 49
        i64.const 8
        i64.mul
        i64.add
        local.tee 51
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 828
          i32.const 82
          i32.const 2
          call 6
          unreachable
        end
        local.get 50
        i64.const -4294967296
        i64.and
        local.get 51
        i64.or
        call $goose.memory_op.41
        local.set 52
        local.get 45
        call $goose.memory_op.49
        local.set 53
        local.get 53
        i64.const 3
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 910
          i32.const 82
          i32.const 2
          call 6
          unreachable
        end
        local.get 45
        local.set 55
        local.get 55
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 53
        i64.const 8
        i64.mul
        i64.add
        local.tee 56
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 992
          i32.const 82
          i32.const 2
          call 6
          unreachable
        end
        local.get 55
        i64.const -4294967296
        i64.and
        local.get 56
        i64.or
        local.tee 57
        local.get 52
        call $goose.memory_op.55
        local.get 45
        local.get 53
        i64.const 1
        i64.add
        call $goose.memory_op.60
        local.get 57
        call $goose.memory_op.41
        drop
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 58
      local.get 58
      i32.const 0
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 59
      i64.const 2
      local.set 60
      i64.const 0
      local.set 61
      local.get 59
      local.set 62
      local.get 62
      i64.const 4294967295
      i64.and
      local.get 61
      i64.const 8
      i64.mul
      i64.add
      local.tee 63
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1074
        i32.const 82
        i32.const 11
        call 6
        unreachable
      end
      local.get 62
      i64.const -4294967296
      i64.and
      local.get 63
      i64.or
      i64.store align=1
      local.get 58
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      local.set 64
      local.get 64
      i64.load offset=8 align=1
      local.set 65
      i64.const 0
      local.set 66
      local.get 64
      i64.load align=1
      local.set 67
      local.get 67
      i64.const 4294967295
      i64.and
      local.get 66
      i64.const 8
      i64.mul
      i64.add
      local.tee 68
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1156
        i32.const 82
        i32.const 11
        call 6
        unreachable
      end
      local.get 67
      i64.const -4294967296
      i64.and
      local.get 68
      i64.or
      i64.store align=1
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 69
      i64.const 2
      local.set 70
      i64.const 0
      local.set 71
      local.get 69
      local.set 72
      local.get 72
      i64.const 4294967295
      i64.and
      local.get 71
      i64.const 8
      i64.mul
      i64.add
      local.tee 73
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1238
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 72
      i64.const -4294967296
      i64.and
      local.get 73
      i64.or
      local.set 74
      local.get 74
      i32.wrap_i64
      i64.load align=1
      local.tee 75
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1320
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 75
      local.set 74
      local.get 74
      call $goose.memory_op.41
      i64.const 1
      i64.add
      local.set 76
      local.get 74
      local.get 76
      call $goose.memory_op.55
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 77
      i64.const 2
      local.set 78
      i64.const 1
      local.set 79
      local.get 77
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      local.get 79
      i64.const 8
      i64.mul
      i64.add
      local.tee 81
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1402
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 81
      i64.or
      local.set 82
      local.get 82
      i32.wrap_i64
      i64.load align=1
      local.tee 83
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1484
        i32.const 82
        i32.const 12
        call 6
        unreachable
      end
      local.get 83
      local.set 82
      local.get 82
      call $goose.memory_op.41
      i64.const 2
      i64.add
      local.set 84
      local.get 82
      local.get 84
      call $goose.memory_op.55
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 85
      i64.const 0
      local.set 86
      block ;; label = @2
        loop ;; label = @3
          local.get 86
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 85
          local.set 87
          local.get 87
          i64.const 4294967295
          i64.and
          local.get 86
          i64.const 8
          i64.mul
          i64.add
          local.tee 88
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1566
            i32.const 82
            i32.const 13
            call 6
            unreachable
          end
          local.get 87
          i64.const -4294967296
          i64.and
          local.get 88
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 4
          block ;; label = @4
            local.get 4
            local.tee 89
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 1648
              i32.const 82
              i32.const 13
              call 6
              unreachable
            end
            local.get 89
            local.set 90
            local.get 90
            call $goose.memory_op.41
            i64.const 10
            i64.add
            local.set 91
            local.get 90
            local.get 91
            call $goose.memory_op.55
          end
          local.get 86
          i64.const 1
          i64.add
          local.set 86
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 92
      i64.const 2
      local.set 93
      i64.const 1
      local.set 94
      local.get 92
      local.set 95
      local.get 95
      i64.const 4294967295
      i64.and
      local.get 94
      i64.const 8
      i64.mul
      i64.add
      local.tee 96
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1730
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 95
      i64.const -4294967296
      i64.and
      local.get 96
      i64.or
      local.set 97
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 98
      i64.const 2
      local.set 99
      i64.const 1
      local.set 100
      local.get 98
      local.set 101
      local.get 101
      i64.const 4294967295
      i64.and
      local.get 100
      i64.const 8
      i64.mul
      i64.add
      local.tee 102
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1812
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 101
      i64.const -4294967296
      i64.and
      local.get 102
      i64.or
      local.set 103
      local.get 97
      local.get 103
      local.set 104
      i32.wrap_i64
      local.get 104
      i64.store align=1
      local.get 0
      i32.const 57
      i32.add
      i64.extend_i32_u
      local.set 105
      i64.const 2
      local.set 106
      i64.const 1
      local.set 107
      local.get 105
      local.set 108
      local.get 108
      i64.const 4294967295
      i64.and
      local.get 107
      i64.const 8
      i64.mul
      i64.add
      local.tee 109
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1894
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 109
      i64.or
      local.set 110
      local.get 110
      i32.wrap_i64
      i64.load align=1
      local.tee 111
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1976
        i32.const 82
        i32.const 14
        call 6
        unreachable
      end
      local.get 111
      local.set 110
      local.get 110
      call $goose.memory_op.41
      i64.const 1
      i64.add
      local.set 112
      local.get 110
      local.get 112
      call $goose.memory_op.55
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 113
      i64.const 2
      local.set 114
      i64.const 0
      local.set 115
      local.get 113
      local.set 116
      local.get 116
      i64.const 4294967295
      i64.and
      local.get 115
      i64.const 8
      i64.mul
      i64.add
      local.tee 117
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2058
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 116
      i64.const -4294967296
      i64.and
      local.get 117
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 118
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 119
      i64.const 2
      local.set 120
      i64.const 1
      local.set 121
      local.get 119
      local.set 122
      local.get 122
      i64.const 4294967295
      i64.and
      local.get 121
      i64.const 8
      i64.mul
      i64.add
      local.tee 123
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2140
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 122
      i64.const -4294967296
      i64.and
      local.get 123
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 124
      local.get 0
      i32.const 0
      i32.add
      local.set 125
      local.get 125
      i64.load offset=8 align=1
      local.set 126
      i64.const 0
      local.set 127
      local.get 125
      i64.load align=1
      local.set 128
      local.get 128
      i64.const 4294967295
      i64.and
      local.get 127
      i64.const 8
      i64.mul
      i64.add
      local.tee 129
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2222
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 128
      i64.const -4294967296
      i64.and
      local.get 129
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 130
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 131
      local.get 131
      i32.wrap_i64
      i64.load8_u
      local.set 132
      i64.const 1
      local.set 133
      local.get 133
      local.get 132
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2304
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 131
      local.set 134
      local.get 134
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 133
      i64.const 8
      i64.mul
      i64.add
      local.tee 135
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2386
        i32.const 82
        i32.const 15
        call 6
        unreachable
      end
      local.get 134
      i64.const -4294967296
      i64.and
      local.get 135
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 136
      call 0
      local.set 137
      local.get 137
      local.get 118
      i32.const 0
      call 1
      local.get 137
      i32.const 2468
      i32.const 1
      call 4
      local.get 137
      local.get 124
      i32.const 0
      call 1
      local.get 137
      i32.const 2469
      i32.const 1
      call 4
      local.get 137
      local.get 130
      i32.const 0
      call 1
      local.get 137
      i32.const 2470
      i32.const 1
      call 4
      local.get 137
      local.get 136
      i32.const 0
      call 1
      local.get 137
      call 5
      local.get 0
      i32.const 73
      i32.add
      local.set 138
      local.get 138
      i32.const 0
      i32.add
      i64.const 40
      i64.store align=1
      local.get 138
      i32.const 8
      i32.add
      i64.const 50
      i64.store align=1
      local.get 0
      i32.const 89
      i32.add
      local.set 139
      local.get 139
      i32.const 0
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 139
      i32.const 8
      i32.add
      local.get 0
      i32.const 73
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 89
      i32.add
      i64.extend_i32_u
      local.set 140
      i64.const 0
      local.set 141
      block ;; label = @2
        loop ;; label = @3
          local.get 141
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 140
          local.set 142
          local.get 142
          i64.const 4294967295
          i64.and
          local.get 141
          i64.const 8
          i64.mul
          i64.add
          local.tee 143
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 2471
            i32.const 82
            i32.const 18
            call 6
            unreachable
          end
          local.get 142
          i64.const -4294967296
          i64.and
          local.get 143
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 5
          block ;; label = @4
            local.get 5
            local.tee 144
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2553
              i32.const 82
              i32.const 17
              call 6
              unreachable
            end
            local.get 144
            local.set 145
            i64.const 2
            local.set 146
            i64.const 0
            local.set 147
            local.get 145
            local.set 148
            local.get 148
            i64.const 4294967295
            i64.and
            local.get 147
            i64.const 8
            i64.mul
            i64.add
            local.tee 149
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2635
              i32.const 82
              i32.const 18
              call 6
              unreachable
            end
            local.get 148
            i64.const -4294967296
            i64.and
            local.get 149
            i64.or
            local.set 150
            local.get 150
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 151
            local.get 150
            local.get 151
            call $goose.memory_op.55
            local.get 5
            local.tee 152
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2717
              i32.const 82
              i32.const 17
              call 6
              unreachable
            end
            local.get 152
            local.set 153
            i64.const 2
            local.set 154
            i64.const 0
            local.set 155
            local.get 153
            local.set 156
            local.get 156
            i64.const 4294967295
            i64.and
            local.get 155
            i64.const 8
            i64.mul
            i64.add
            local.tee 157
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2799
              i32.const 82
              i32.const 18
              call 6
              unreachable
            end
            local.get 156
            i64.const -4294967296
            i64.and
            local.get 157
            i64.or
            call $goose.memory_op.41
            local.set 158
            local.get 5
            local.tee 159
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2881
              i32.const 82
              i32.const 17
              call 6
              unreachable
            end
            local.get 159
            local.set 160
            i64.const 2
            local.set 161
            i64.const 1
            local.set 162
            local.get 160
            local.set 163
            local.get 163
            i64.const 4294967295
            i64.and
            local.get 162
            i64.const 8
            i64.mul
            i64.add
            local.tee 164
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2963
              i32.const 82
              i32.const 18
              call 6
              unreachable
            end
            local.get 163
            i64.const -4294967296
            i64.and
            local.get 164
            i64.or
            call $goose.memory_op.41
            local.set 165
            call 0
            local.set 166
            local.get 166
            local.get 158
            i32.const 0
            call 1
            local.get 166
            i32.const 3045
            i32.const 1
            call 4
            local.get 166
            local.get 165
            i32.const 0
            call 1
            local.get 166
            call 5
          end
          local.get 141
          i64.const 1
          i64.add
          local.set 141
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 105
      i32.add
      local.set 167
      local.get 167
      i64.const 0
      i64.store8
      local.get 167
      i32.const 1
      i32.add
      i32.const 0
      i32.const 24
      memory.fill
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 168
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 169
      i64.const 2
      local.set 170
      i64.const 0
      local.set 171
      local.get 169
      local.set 172
      local.get 172
      i64.const 4294967295
      i64.and
      local.get 171
      i64.const 8
      i64.mul
      i64.add
      local.tee 173
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3046
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 172
      i64.const -4294967296
      i64.and
      local.get 173
      i64.or
      local.set 174
      local.get 168
      i32.wrap_i64
      i64.load8_u
      local.set 175
      local.get 175
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 3128
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 168
      local.set 177
      local.get 177
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 175
      i64.const 8
      i64.mul
      i64.add
      local.tee 178
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3210
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 177
      i64.const -4294967296
      i64.and
      local.get 178
      i64.or
      local.tee 179
      local.get 174
      local.set 180
      i32.wrap_i64
      local.get 180
      i64.store align=1
      local.get 168
      local.get 175
      i64.const 1
      i64.add
      local.set 181
      i32.wrap_i64
      local.get 181
      i64.store8
      local.get 179
      i32.wrap_i64
      i64.load align=1
      local.tee 182
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3292
        i32.const 82
        i32.const 19
        call 6
        unreachable
      end
      local.get 182
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 183
      local.get 0
      i32.const 0
      i32.add
      local.set 184
      local.get 184
      i64.load offset=8 align=1
      local.set 185
      i64.const 0
      local.set 186
      local.get 184
      i64.load align=1
      local.set 187
      local.get 187
      i64.const 4294967295
      i64.and
      local.get 186
      i64.const 8
      i64.mul
      i64.add
      local.tee 188
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3374
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 187
      i64.const -4294967296
      i64.and
      local.get 188
      i64.or
      local.set 189
      local.get 183
      i32.wrap_i64
      i64.load8_u
      local.set 190
      local.get 190
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 3456
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 183
      local.set 192
      local.get 192
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 190
      i64.const 8
      i64.mul
      i64.add
      local.tee 193
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3538
        i32.const 82
        i32.const 20
        call 6
        unreachable
      end
      local.get 192
      i64.const -4294967296
      i64.and
      local.get 193
      i64.or
      local.tee 194
      local.get 189
      local.set 195
      i32.wrap_i64
      local.get 195
      i64.store align=1
      local.get 183
      local.get 190
      i64.const 1
      i64.add
      local.set 181
      i32.wrap_i64
      local.get 181
      i64.store8
      local.get 194
      i32.wrap_i64
      i64.load align=1
      local.tee 196
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3620
        i32.const 82
        i32.const 19
        call 6
        unreachable
      end
      local.get 196
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 197
      i64.const 0
      local.set 198
      block ;; label = @2
        loop ;; label = @3
          local.get 198
          local.get 197
          i32.wrap_i64
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 197
          local.set 199
          local.get 199
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.get 198
          i64.const 8
          i64.mul
          i64.add
          local.tee 200
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 3702
            i32.const 82
            i32.const 21
            call 6
            unreachable
          end
          local.get 199
          i64.const -4294967296
          i64.and
          local.get 200
          i64.or
          i32.wrap_i64
          i64.load align=1
          local.set 6
          block ;; label = @4
            local.get 6
            local.tee 201
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 3784
              i32.const 82
              i32.const 21
              call 6
              unreachable
            end
            local.get 201
            local.set 202
            local.get 202
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 203
            local.get 202
            local.get 203
            call $goose.memory_op.55
          end
          local.get 198
          i64.const 1
          i64.add
          local.set 198
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 204
      i64.const 2
      local.set 205
      i64.const 0
      local.set 206
      local.get 204
      local.set 207
      local.get 207
      i64.const 4294967295
      i64.and
      local.get 206
      i64.const 8
      i64.mul
      i64.add
      local.tee 208
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3866
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 207
      i64.const -4294967296
      i64.and
      local.get 208
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 209
      local.get 0
      i32.const 0
      i32.add
      local.set 210
      local.get 210
      i64.load offset=8 align=1
      local.set 211
      i64.const 0
      local.set 212
      local.get 210
      i64.load align=1
      local.set 213
      local.get 213
      i64.const 4294967295
      i64.and
      local.get 212
      i64.const 8
      i64.mul
      i64.add
      local.tee 214
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3948
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 213
      i64.const -4294967296
      i64.and
      local.get 214
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 215
      local.get 0
      i32.const 105
      i32.add
      i64.extend_i32_u
      local.set 216
      local.get 216
      i32.wrap_i64
      i64.load8_u
      local.set 217
      local.get 217
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 4030
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 217
      i64.const 1
      i64.sub
      local.set 217
      local.get 216
      local.set 218
      local.get 218
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 217
      i64.const 8
      i64.mul
      i64.add
      local.tee 219
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4112
        i32.const 82
        i32.const 22
        call 6
        unreachable
      end
      local.get 218
      i64.const -4294967296
      i64.and
      local.get 219
      i64.or
      local.set 220
      local.get 220
      i32.wrap_i64
      i64.load align=1
      local.set 221
      local.get 216
      local.get 217
      local.set 181
      i32.wrap_i64
      local.get 181
      i64.store8
      local.get 221
      local.tee 222
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4194
        i32.const 82
        i32.const 19
        call 6
        unreachable
      end
      local.get 222
      call $goose.memory_op.41
      local.set 223
      call 0
      local.set 224
      local.get 224
      local.get 209
      i32.const 0
      call 1
      local.get 224
      i32.const 4276
      i32.const 1
      call 4
      local.get 224
      local.get 215
      i32.const 0
      call 1
      local.get 224
      i32.const 4277
      i32.const 1
      call 4
      local.get 224
      local.get 223
      i32.const 0
      call 1
      local.get 224
      call 5
      i32.const 2
      local.set 225
      global.get 2
      local.set 226
      local.get 0
      i32.const 130
      i32.add
      local.set 227
      local.get 227
      local.get 225
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 226
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 227
      i64.const 0
      i64.store offset=8 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 228
      local.get 227
      i64.load offset=8 align=1
      local.set 229
      i32.const 8
      call $goose.reserve_memory.2
      local.set 230
      local.get 227
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 230
      i64.extend_i32_u
      i64.or
      local.tee 231
      local.get 228
      local.set 232
      i32.wrap_i64
      local.get 232
      i64.store 2 align=1
      local.get 227
      local.get 229
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      block ;; label = @2
        local.get 0
        i32.const 130
        i32.add
        local.set 7
        local.get 0
        i32.const 73
        i32.add
        i64.extend_i32_u
        local.set 8
        local.get 7
        local.tee 233
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 4278
          i32.const 82
          i32.const 4
          call 6
          unreachable
        end
        local.get 233
        local.set 234
        local.get 234
        i64.load offset=8 align=1
        local.set 235
        i64.const 0
        local.set 236
        local.get 234
        i64.load align=1
        local.set 237
        local.get 237
        i64.const 4294967295
        i64.and
        local.get 236
        i64.const 8
        i64.mul
        i64.add
        local.tee 238
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4360
          i32.const 82
          i32.const 4
          call 6
          unreachable
        end
        local.get 237
        i64.const -4294967296
        i64.and
        local.get 238
        i64.or
        local.set 239
        local.get 8
        local.set 240
        local.get 239
        local.get 240
        call $goose.memory_op.55
      end
      block ;; label = @2
        local.get 0
        i32.const 130
        i32.add
        local.set 242
        local.get 242
        i64.load offset=8 align=1
        local.set 243
        i64.const 0
        local.set 244
        local.get 242
        i64.load align=1
        local.set 245
        local.get 245
        i64.const 4294967295
        i64.and
        local.get 244
        i64.const 8
        i64.mul
        i64.add
        local.tee 246
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4442
          i32.const 82
          i32.const 24
          call 6
          unreachable
        end
        local.get 245
        i64.const -4294967296
        i64.and
        local.get 246
        i64.or
        i32.wrap_i64
        i64.load 2 align=1
        local.set 9
        local.get 9
        local.tee 247
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 4524
          i32.const 82
          i32.const 5
          call 6
          unreachable
        end
        local.get 247
        local.set 248
        i64.const 2
        local.set 249
        i64.const 0
        local.set 250
        local.get 248
        local.set 251
        local.get 251
        i64.const 4294967295
        i64.and
        local.get 250
        i64.const 8
        i64.mul
        i64.add
        local.tee 252
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4606
          i32.const 82
          i32.const 5
          call 6
          unreachable
        end
        local.get 251
        i64.const -4294967296
        i64.and
        local.get 252
        i64.or
        call $goose.memory_op.41
        local.set 253
        local.get 253
        local.set 241
      end
      local.get 241
      local.set 254
      call 0
      local.set 255
      local.get 255
      i32.const 4688
      i32.const 9
      call 4
      local.get 255
      local.get 254
      i32.const 0
      call 1
      local.get 255
      call 5
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 10
      i64.const 0
      local.set 257
      block ;; label = @2
        loop ;; label = @3
          local.get 10
          local.tee 258
          i64.eqz
          if ;; label = @4
            i32.const 4
            i32.const 4697
            i32.const 82
            i32.const 25
            call 6
            unreachable
          end
          local.get 258
          local.set 259
          local.get 259
          local.set 256
          local.get 257
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 256
          local.set 260
          local.get 260
          i64.const 4294967295
          i64.and
          local.get 257
          i64.const 8
          i64.mul
          i64.add
          local.tee 261
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 4779
            i32.const 82
            i32.const 26
            call 6
            unreachable
          end
          local.get 260
          i64.const -4294967296
          i64.and
          local.get 261
          i64.or
          local.set 11
          local.get 257
          local.set 12
          block ;; label = @4
            local.get 12
            i64.const 0
            i64.eq
            if ;; label = @5
              local.get 0
              i32.const 73
              i32.add
              i64.extend_i32_u
              local.set 10
            end
            local.get 11
            local.tee 262
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 4861
              i32.const 82
              i32.const 26
              call 6
              unreachable
            end
            local.get 262
            local.set 263
            local.get 263
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 264
            local.get 263
            local.get 264
            call $goose.memory_op.55
          end
          local.get 257
          i64.const 1
          i64.add
          local.set 257
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 265
      i64.const 2
      local.set 266
      i64.const 0
      local.set 267
      local.get 265
      local.set 268
      local.get 268
      i64.const 4294967295
      i64.and
      local.get 267
      i64.const 8
      i64.mul
      i64.add
      local.tee 269
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4943
        i32.const 82
        i32.const 27
        call 6
        unreachable
      end
      local.get 268
      i64.const -4294967296
      i64.and
      local.get 269
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 270
      local.get 0
      i32.const 73
      i32.add
      i64.extend_i32_u
      local.set 271
      i64.const 2
      local.set 272
      i64.const 1
      local.set 273
      local.get 271
      local.set 274
      local.get 274
      i64.const 4294967295
      i64.and
      local.get 273
      i64.const 8
      i64.mul
      i64.add
      local.tee 275
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5025
        i32.const 82
        i32.const 27
        call 6
        unreachable
      end
      local.get 274
      i64.const -4294967296
      i64.and
      local.get 275
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 276
      call 0
      local.set 277
      local.get 277
      local.get 270
      i32.const 0
      call 1
      local.get 277
      i32.const 5107
      i32.const 1
      call 4
      local.get 277
      local.get 276
      i32.const 0
      call 1
      local.get 277
      call 5
      local.get 226
      global.set 2
      local.get 14
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.41 (;15;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;16;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;17;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;18;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.2 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.gooseselected=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_mixed_references.goose,")
)
