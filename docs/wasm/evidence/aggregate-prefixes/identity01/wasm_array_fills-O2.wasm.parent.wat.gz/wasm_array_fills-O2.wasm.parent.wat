(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (memory (;5;) 1 65536)
  (memory (;6;) 1 65536)
  (memory (;7;) 1 65536)
  (memory (;8;) 1 65536)
  (memory (;9;) 1 65536)
  (memory (;10;) 1 65536)
  (memory (;11;) 1 65536)
  (memory (;12;) 1 65536)
  (memory (;13;) 1 65536)
  (memory (;14;) 1 65536)
  (global (;0;) (mut i32) i32.const 3456)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (global (;5;) (mut i32) i32.const 1)
  (global (;6;) (mut i32) i32.const 1)
  (global (;7;) (mut i32) i32.const 1)
  (global (;8;) (mut i32) i32.const 1)
  (global (;9;) (mut i32) i32.const 1)
  (global (;10;) (mut i32) i32.const 1)
  (global (;11;) (mut i32) i32.const 1)
  (global (;12;) (mut i32) i32.const 1)
  (global (;13;) (mut i32) i32.const 1)
  (global (;14;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "data_memory_5" (memory 5))
  (export "data_memory_6" (memory 6))
  (export "data_memory_7" (memory 7))
  (export "data_memory_8" (memory 8))
  (export "data_memory_9" (memory 9))
  (export "data_memory_10" (memory 10))
  (export "data_memory_11" (memory 11))
  (export "data_memory_12" (memory 12))
  (export "data_memory_13" (memory 13))
  (export "data_memory_14" (memory 14))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 24
      i32.const 70
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 94
        i32.const 70
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 f32 i64 i64 i32 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 f32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 155
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      block ;; label = @2
        i32.const 1
        local.set 25
        i32.const 72002
        call $goose.reserve_memory.1
        local.set 26
        local.get 25
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 26
        i64.extend_i32_u
        i64.or
        local.set 24
        local.get 24
        local.set 1
        local.get 24
        i64.const 9000
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store16 1 align=1
        block ;; label = @3
          i32.const 8
          i64.load align=1
          i64.const 1
          i64.add
          local.set 30
          i32.const 8
          local.get 30
          i64.store align=1
          i32.const 2
          local.set 31
          i32.const 20
          call $goose.reserve_memory.2
          local.set 32
          local.get 31
          i64.extend_i32_u
          i64.const 32
          i64.shl
          local.get 32
          i64.extend_i32_u
          i64.or
          local.set 33
          local.get 33
          local.set 2
          local.get 33
          i64.const 2
          local.set 27
          i32.wrap_i64
          local.get 27
          i64.store32 2 align=1
          i32.const 8
          i64.load align=1
          local.set 34
          local.get 32
          i32.const 4
          i32.add
          local.get 34
          i64.store 2 align=1
          i64.const 99
          local.set 34
          local.get 32
          i32.const 12
          i32.add
          local.get 34
          i64.store 2 align=1
          local.get 2
          local.set 35
          local.get 35
          i32.wrap_i64
          i64.load32_u 2 align=1
          local.set 36
          i64.const 0
          local.set 37
          local.get 35
          local.set 38
          local.get 38
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 37
          i64.const 8
          i64.mul
          i64.add
          local.tee 39
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 164
            i32.const 70
            i32.const 6
            call 6
            unreachable
          end
          local.get 38
          i64.const -4294967296
          i64.and
          local.get 39
          i64.or
          i32.wrap_i64
          i64.load 2 align=1
          local.set 29
          local.get 32
          global.set 2
          br 0 (;@3;)
          local.get 32
          global.set 2
        end
        local.get 29
        local.set 28
        i64.const 0
        local.set 40
        block ;; label = @3
          loop ;; label = @4
            local.get 40
            i64.const 9000
            i64.ge_u
            br_if 1 (;@3;)
            local.get 24
            i32.wrap_i64
            local.get 40
            i32.wrap_i64
            i32.const 8
            i32.mul
            i32.add
            i32.const 2
            i32.add
            local.get 28
            i64.store 1 align=1
            local.get 40
            i64.const 1
            i64.add
            local.set 40
            br 0 (;@4;)
          end
        end
        local.get 1
        local.set 41
        local.get 41
        i32.wrap_i64
        i64.load16_u 1 align=1
        local.set 42
        i64.const 0
        local.set 43
        local.get 41
        local.set 44
        local.get 44
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 43
        i64.const 8
        i64.mul
        i64.add
        local.tee 45
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 234
          i32.const 70
          i32.const 10
          call 6
          unreachable
        end
        local.get 44
        i64.const -4294967296
        i64.and
        local.get 45
        i64.or
        i32.wrap_i64
        i64.load 1 align=1
        local.get 1
        local.set 46
        local.get 46
        i32.wrap_i64
        i64.load16_u 1 align=1
        local.set 47
        i64.const 8999
        local.set 48
        local.get 46
        local.set 49
        local.get 49
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 48
        i64.const 8
        i64.mul
        i64.add
        local.tee 50
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 304
          i32.const 70
          i32.const 10
          call 6
          unreachable
        end
        local.get 49
        i64.const -4294967296
        i64.and
        local.get 50
        i64.or
        i32.wrap_i64
        i64.load 1 align=1
        i64.add
        local.set 23
        local.get 26
        global.set 1
        br 0 (;@2;)
        local.get 26
        global.set 1
      end
      local.get 23
      local.set 51
      call 0
      local.set 52
      local.get 52
      i32.const 374
      i32.const 7
      call 4
      local.get 52
      local.get 51
      i32.const 0
      call 1
      local.get 52
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 54
      local.get 54
      i64.extend_i32_u
      local.set 53
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 57
        i32.const 8
        local.get 57
        i64.store align=1
        i32.const 1
        local.set 58
        i32.const 20
        call $goose.reserve_memory.1
        local.set 59
        local.get 58
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 59
        i64.extend_i32_u
        i64.or
        local.set 60
        local.get 60
        local.set 3
        local.get 60
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 1 align=1
        i32.const 8
        i64.load align=1
        local.set 61
        local.get 59
        i32.const 4
        i32.add
        local.get 61
        i64.store 1 align=1
        i64.const 99
        local.set 61
        local.get 59
        i32.const 12
        i32.add
        local.get 61
        i64.store 1 align=1
        local.get 3
        local.set 62
        local.get 62
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 63
        i64.const 0
        local.set 64
        local.get 62
        local.set 65
        local.get 65
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 64
        i64.const 8
        i64.mul
        i64.add
        local.tee 66
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 381
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 65
        i64.const -4294967296
        i64.and
        local.get 66
        i64.or
        i32.wrap_i64
        i64.load 1 align=1
        local.set 56
        local.get 59
        global.set 1
        br 0 (;@2;)
        local.get 59
        global.set 1
      end
      local.get 56
      local.set 55
      i64.const 0
      local.set 67
      block ;; label = @2
        loop ;; label = @3
          local.get 67
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 53
          i32.wrap_i64
          local.get 67
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 55
          i64.store align=1
          local.get 67
          i64.const 1
          i64.add
          local.set 67
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 24
      i32.add
      local.set 69
      local.get 69
      i64.const 2
      i64.store8
      local.get 69
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 68
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 72
        i32.const 8
        local.get 72
        i64.store align=1
        i32.const 1
        local.set 73
        i32.const 20
        call $goose.reserve_memory.1
        local.set 74
        local.get 73
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 74
        i64.extend_i32_u
        i64.or
        local.set 75
        local.get 75
        local.set 4
        local.get 75
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 1 align=1
        i32.const 8
        i64.load align=1
        local.set 76
        local.get 74
        i32.const 4
        i32.add
        local.get 76
        i64.store 1 align=1
        i64.const 99
        local.set 76
        local.get 74
        i32.const 12
        i32.add
        local.get 76
        i64.store 1 align=1
        local.get 4
        local.set 77
        local.get 77
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 78
        i64.const 0
        local.set 79
        local.get 77
        local.set 80
        local.get 80
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 79
        i64.const 8
        i64.mul
        i64.add
        local.tee 81
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 451
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 80
        i64.const -4294967296
        i64.and
        local.get 81
        i64.or
        i32.wrap_i64
        i64.load 1 align=1
        local.set 71
        local.get 74
        global.set 1
        br 0 (;@2;)
        local.get 74
        global.set 1
      end
      local.get 71
      local.set 70
      i64.const 0
      local.set 82
      block ;; label = @2
        loop ;; label = @3
          local.get 82
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 68
          i32.wrap_i64
          local.get 82
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 70
          i64.store align=1
          local.get 82
          i64.const 1
          i64.add
          local.set 82
          br 0 (;@3;)
        end
      end
      i32.const 1
      local.set 84
      i32.const 25
      call $goose.reserve_memory.1
      local.set 85
      local.get 84
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 85
      i64.extend_i32_u
      i64.or
      local.set 83
      local.get 83
      local.set 5
      local.get 83
      i64.const 3
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store8 1
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 88
        i32.const 8
        local.get 88
        i64.store align=1
        i32.const 2
        local.set 89
        i32.const 20
        call $goose.reserve_memory.2
        local.set 90
        local.get 89
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 90
        i64.extend_i32_u
        i64.or
        local.set 91
        local.get 91
        local.set 6
        local.get 91
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 2 align=1
        i32.const 8
        i64.load align=1
        local.set 92
        local.get 90
        i32.const 4
        i32.add
        local.get 92
        i64.store 2 align=1
        i64.const 99
        local.set 92
        local.get 90
        i32.const 12
        i32.add
        local.get 92
        i64.store 2 align=1
        local.get 6
        local.set 93
        local.get 93
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 94
        i64.const 0
        local.set 95
        local.get 93
        local.set 96
        local.get 96
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 95
        i64.const 8
        i64.mul
        i64.add
        local.tee 97
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 521
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 96
        i64.const -4294967296
        i64.and
        local.get 97
        i64.or
        i32.wrap_i64
        i64.load 2 align=1
        local.set 87
        local.get 90
        global.set 2
        br 0 (;@2;)
        local.get 90
        global.set 2
      end
      local.get 87
      local.set 86
      i64.const 0
      local.set 98
      block ;; label = @2
        loop ;; label = @3
          local.get 98
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 83
          i32.wrap_i64
          local.get 98
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 1
          i32.add
          local.get 86
          i64.store 1 align=1
          local.get 98
          i64.const 1
          i64.add
          local.set 98
          br 0 (;@3;)
        end
      end
      i32.const 2
      local.set 100
      i32.const 24
      call $goose.reserve_memory.2
      local.set 101
      local.get 100
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 101
      i64.extend_i32_u
      i64.or
      local.set 99
      local.get 0
      i32.const 57
      i32.add
      local.get 99
      i64.store align=1
      local.get 0
      i32.const 57
      i32.add
      i64.const 3
      i64.store offset=8 align=1
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 104
        i32.const 8
        local.get 104
        i64.store align=1
        i32.const 3
        local.set 105
        i32.const 20
        call $goose.reserve_memory.3
        local.set 106
        local.get 105
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 106
        i64.extend_i32_u
        i64.or
        local.set 107
        local.get 107
        local.set 7
        local.get 107
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 3 align=1
        i32.const 8
        i64.load align=1
        local.set 108
        local.get 106
        i32.const 4
        i32.add
        local.get 108
        i64.store 3 align=1
        i64.const 99
        local.set 108
        local.get 106
        i32.const 12
        i32.add
        local.get 108
        i64.store 3 align=1
        local.get 7
        local.set 109
        local.get 109
        i32.wrap_i64
        i64.load32_u 3 align=1
        local.set 110
        i64.const 0
        local.set 111
        local.get 109
        local.set 112
        local.get 112
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 111
        i64.const 8
        i64.mul
        i64.add
        local.tee 113
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 591
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 112
        i64.const -4294967296
        i64.and
        local.get 113
        i64.or
        i32.wrap_i64
        i64.load 3 align=1
        local.set 103
        local.get 106
        global.set 3
        br 0 (;@2;)
        local.get 106
        global.set 3
      end
      local.get 103
      local.set 102
      i64.const 0
      local.set 114
      block ;; label = @2
        loop ;; label = @3
          local.get 114
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 99
          i32.wrap_i64
          local.get 114
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 102
          i64.store 2 align=1
          local.get 114
          i64.const 1
          i64.add
          local.set 114
          br 0 (;@3;)
        end
      end
      i32.const 3
      local.set 116
      i32.const 16
      call $goose.reserve_memory.3
      local.set 117
      local.get 116
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 117
      i64.extend_i32_u
      i64.or
      local.set 115
      local.get 0
      i32.const 73
      i32.add
      local.get 115
      i64.store align=1
      local.get 0
      i32.const 73
      i32.add
      i64.const 2
      i64.store offset=8 align=1
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 120
        i32.const 8
        local.get 120
        i64.store align=1
        i32.const 4
        local.set 121
        i32.const 20
        call $goose.reserve_memory.4
        local.set 122
        local.get 121
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 122
        i64.extend_i32_u
        i64.or
        local.set 123
        local.get 123
        local.set 8
        local.get 123
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 4 align=1
        i32.const 8
        i64.load align=1
        local.set 124
        local.get 122
        i32.const 4
        i32.add
        local.get 124
        i64.store 4 align=1
        i64.const 99
        local.set 124
        local.get 122
        i32.const 12
        i32.add
        local.get 124
        i64.store 4 align=1
        local.get 8
        local.set 125
        local.get 125
        i32.wrap_i64
        i64.load32_u 4 align=1
        local.set 126
        i64.const 0
        local.set 127
        local.get 125
        local.set 128
        local.get 128
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 127
        i64.const 8
        i64.mul
        i64.add
        local.tee 129
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 661
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 128
        i64.const -4294967296
        i64.and
        local.get 129
        i64.or
        i32.wrap_i64
        i64.load 4 align=1
        local.set 119
        local.get 122
        global.set 4
        br 0 (;@2;)
        local.get 122
        global.set 4
      end
      local.get 119
      local.set 118
      i64.const 0
      local.set 130
      block ;; label = @2
        loop ;; label = @3
          local.get 130
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 115
          i32.wrap_i64
          local.get 130
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          local.get 118
          i64.store 3 align=1
          local.get 130
          i64.const 1
          i64.add
          local.set 130
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 131
      i64.const 11
      local.set 132
      local.get 131
      i32.wrap_i64
      i64.load8_u
      local.set 133
      local.get 133
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 731
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 131
      local.set 135
      local.get 135
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 133
      i64.const 8
      i64.mul
      i64.add
      local.tee 136
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 801
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 135
      i64.const -4294967296
      i64.and
      local.get 136
      i64.or
      local.tee 137
      local.get 132
      local.set 138
      i32.wrap_i64
      local.get 138
      i64.store align=1
      local.get 131
      local.get 133
      i64.const 1
      i64.add
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store8
      local.get 137
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 57
      i32.add
      local.set 139
      i64.const 12
      local.set 140
      local.get 139
      i64.load offset=8 align=1
      local.set 141
      i32.const 8
      call $goose.reserve_memory.2
      local.set 142
      local.get 139
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 142
      i64.extend_i32_u
      i64.or
      local.tee 143
      local.get 140
      local.set 144
      i32.wrap_i64
      local.get 144
      i64.store 2 align=1
      local.get 139
      local.get 141
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 143
      i32.wrap_i64
      i64.load 2 align=1
      drop
      local.get 0
      i32.const 73
      i32.add
      local.set 145
      local.get 145
      i64.load offset=8 align=1
      local.set 146
      local.get 146
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 871
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 146
      i64.const 1
      i64.sub
      local.set 146
      local.get 145
      i64.load align=1
      local.set 147
      local.get 147
      i64.const 4294967295
      i64.and
      local.get 146
      i64.const 8
      i64.mul
      i64.add
      local.tee 148
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 941
        i32.const 70
        i32.const 19
        call 6
        unreachable
      end
      local.get 147
      i64.const -4294967296
      i64.and
      local.get 148
      i64.or
      local.set 149
      local.get 149
      i32.wrap_i64
      i64.load 3 align=1
      local.set 150
      local.get 149
      i32.wrap_i64
      global.set 3
      local.get 145
      local.get 146
      i64.store offset=8 align=1
      local.get 150
      drop
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 151
      i64.const 3
      local.set 152
      i64.const 0
      local.set 153
      local.get 151
      local.set 154
      local.get 154
      i64.const 4294967295
      i64.and
      local.get 153
      i64.const 8
      i64.mul
      i64.add
      local.tee 155
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1011
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 154
      i64.const -4294967296
      i64.and
      local.get 155
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 156
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 157
      i64.const 3
      local.set 158
      i64.const 2
      local.set 159
      local.get 157
      local.set 160
      local.get 160
      i64.const 4294967295
      i64.and
      local.get 159
      i64.const 8
      i64.mul
      i64.add
      local.tee 161
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1081
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 160
      i64.const -4294967296
      i64.and
      local.get 161
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 162
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 163
      local.get 163
      i32.wrap_i64
      i64.load8_u
      local.set 164
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 165
      local.get 165
      i32.wrap_i64
      i64.load8_u
      local.set 166
      i64.const 0
      local.set 167
      local.get 165
      local.set 168
      local.get 168
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 167
      i64.const 8
      i64.mul
      i64.add
      local.tee 169
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1151
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 168
      i64.const -4294967296
      i64.and
      local.get 169
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 170
      local.get 0
      i32.const 24
      i32.add
      i64.extend_i32_u
      local.set 171
      local.get 171
      i32.wrap_i64
      i64.load8_u
      local.set 172
      i64.const 2
      local.set 173
      local.get 171
      local.set 174
      local.get 174
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 173
      i64.const 8
      i64.mul
      i64.add
      local.tee 175
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1221
        i32.const 70
        i32.const 20
        call 6
        unreachable
      end
      local.get 174
      i64.const -4294967296
      i64.and
      local.get 175
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 176
      call 0
      local.set 177
      local.get 177
      local.get 156
      i32.const 0
      call 1
      local.get 177
      i32.const 1291
      i32.const 1
      call 4
      local.get 177
      local.get 162
      i32.const 0
      call 1
      local.get 177
      i32.const 1292
      i32.const 1
      call 4
      local.get 177
      local.get 164
      i32.const 0
      call 1
      local.get 177
      i32.const 1293
      i32.const 1
      call 4
      local.get 177
      local.get 170
      i32.const 0
      call 1
      local.get 177
      i32.const 1294
      i32.const 1
      call 4
      local.get 177
      local.get 176
      i32.const 0
      call 1
      local.get 177
      call 5
      local.get 5
      local.set 178
      local.get 178
      i32.wrap_i64
      i64.load8_u 1
      local.set 179
      local.get 5
      local.set 180
      local.get 180
      i32.wrap_i64
      i64.load8_u 1
      local.set 181
      i64.const 0
      local.set 182
      local.get 180
      local.set 183
      local.get 183
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 182
      i64.const 8
      i64.mul
      i64.add
      local.tee 184
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1295
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 183
      i64.const -4294967296
      i64.and
      local.get 184
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 185
      local.get 5
      local.set 186
      local.get 186
      i32.wrap_i64
      i64.load8_u 1
      local.set 187
      i64.const 2
      local.set 188
      local.get 186
      local.set 189
      local.get 189
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 188
      i64.const 8
      i64.mul
      i64.add
      local.tee 190
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1365
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 189
      i64.const -4294967296
      i64.and
      local.get 190
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      local.set 191
      local.get 0
      i32.const 57
      i32.add
      local.set 192
      local.get 192
      i64.load offset=8 align=1
      local.set 193
      local.get 0
      i32.const 57
      i32.add
      local.set 194
      local.get 194
      i64.load offset=8 align=1
      local.set 195
      i64.const 2
      local.set 196
      local.get 194
      i64.load align=1
      local.set 197
      local.get 197
      i64.const 4294967295
      i64.and
      local.get 196
      i64.const 8
      i64.mul
      i64.add
      local.tee 198
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1435
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 197
      i64.const -4294967296
      i64.and
      local.get 198
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 199
      local.get 0
      i32.const 57
      i32.add
      local.set 200
      local.get 200
      i64.load offset=8 align=1
      local.set 201
      i64.const 3
      local.set 202
      local.get 200
      i64.load align=1
      local.set 203
      local.get 203
      i64.const 4294967295
      i64.and
      local.get 202
      i64.const 8
      i64.mul
      i64.add
      local.tee 204
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1505
        i32.const 70
        i32.const 21
        call 6
        unreachable
      end
      local.get 203
      i64.const -4294967296
      i64.and
      local.get 204
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.set 205
      call 0
      local.set 206
      local.get 206
      local.get 179
      i32.const 0
      call 1
      local.get 206
      i32.const 1575
      i32.const 1
      call 4
      local.get 206
      local.get 185
      i32.const 0
      call 1
      local.get 206
      i32.const 1576
      i32.const 1
      call 4
      local.get 206
      local.get 191
      i32.const 0
      call 1
      local.get 206
      i32.const 1577
      i32.const 1
      call 4
      local.get 206
      local.get 193
      i32.const 0
      call 1
      local.get 206
      i32.const 1578
      i32.const 1
      call 4
      local.get 206
      local.get 199
      i32.const 0
      call 1
      local.get 206
      i32.const 1579
      i32.const 1
      call 4
      local.get 206
      local.get 205
      i32.const 0
      call 1
      local.get 206
      call 5
      local.get 0
      i32.const 73
      i32.add
      local.set 207
      local.get 207
      i64.load offset=8 align=1
      local.set 208
      local.get 0
      i32.const 73
      i32.add
      local.set 209
      local.get 209
      i64.load offset=8 align=1
      local.set 210
      i64.const 0
      local.set 211
      local.get 209
      i64.load align=1
      local.set 212
      local.get 212
      i64.const 4294967295
      i64.and
      local.get 211
      i64.const 8
      i64.mul
      i64.add
      local.tee 213
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1580
        i32.const 70
        i32.const 22
        call 6
        unreachable
      end
      local.get 212
      i64.const -4294967296
      i64.and
      local.get 213
      i64.or
      i32.wrap_i64
      i64.load 3 align=1
      local.set 214
      i32.const 8
      i64.load align=1
      local.set 215
      call 0
      local.set 216
      local.get 216
      local.get 208
      i32.const 0
      call 1
      local.get 216
      i32.const 1650
      i32.const 1
      call 4
      local.get 216
      local.get 214
      i32.const 0
      call 1
      local.get 216
      i32.const 1651
      i32.const 1
      call 4
      local.get 216
      local.get 215
      i32.const 0
      call 1
      local.get 216
      call 5
      local.get 0
      i32.const 89
      i32.add
      local.set 218
      local.get 218
      i64.extend_i32_u
      local.set 217
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 221
        i32.const 8
        local.get 221
        i64.store align=1
        i32.const 4
        local.set 222
        i32.const 20
        call $goose.reserve_memory.4
        local.set 223
        local.get 222
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 223
        i64.extend_i32_u
        i64.or
        local.set 224
        local.get 224
        local.set 9
        local.get 224
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 4 align=1
        i32.const 8
        i64.load align=1
        local.set 225
        local.get 223
        i32.const 4
        i32.add
        local.get 225
        i64.store 4 align=1
        i64.const 99
        local.set 225
        local.get 223
        i32.const 12
        i32.add
        local.get 225
        i64.store 4 align=1
        local.get 9
        local.set 226
        local.get 226
        i32.wrap_i64
        i64.load32_u 4 align=1
        local.set 227
        i64.const 0
        local.set 228
        local.get 226
        local.set 229
        local.get 229
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 228
        i64.const 8
        i64.mul
        i64.add
        local.tee 230
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1652
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 229
        i64.const -4294967296
        i64.and
        local.get 230
        i64.or
        i32.wrap_i64
        i64.load 4 align=1
        local.set 220
        local.get 223
        global.set 4
        br 0 (;@2;)
        local.get 223
        global.set 4
      end
      local.get 220
      local.set 219
      local.get 0
      i32.const 90
      i32.add
      local.set 232
      local.get 232
      i64.const 0
      i64.store8
      local.get 232
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 231
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 235
        i32.const 8
        local.get 235
        i64.store align=1
        i32.const 4
        local.set 236
        i32.const 20
        call $goose.reserve_memory.4
        local.set 237
        local.get 236
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 237
        i64.extend_i32_u
        i64.or
        local.set 238
        local.get 238
        local.set 10
        local.get 238
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 4 align=1
        i32.const 8
        i64.load align=1
        local.set 239
        local.get 237
        i32.const 4
        i32.add
        local.get 239
        i64.store 4 align=1
        i64.const 99
        local.set 239
        local.get 237
        i32.const 12
        i32.add
        local.get 239
        i64.store 4 align=1
        local.get 10
        local.set 240
        local.get 240
        i32.wrap_i64
        i64.load32_u 4 align=1
        local.set 241
        i64.const 0
        local.set 242
        local.get 240
        local.set 243
        local.get 243
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 242
        i64.const 8
        i64.mul
        i64.add
        local.tee 244
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1722
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 243
        i64.const -4294967296
        i64.and
        local.get 244
        i64.or
        i32.wrap_i64
        i64.load 4 align=1
        local.set 234
        local.get 237
        global.set 4
        br 0 (;@2;)
        local.get 237
        global.set 4
      end
      local.get 234
      local.set 233
      i32.const 4
      local.set 246
      i32.const 4
      call $goose.reserve_memory.4
      local.set 247
      local.get 246
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 247
      i64.extend_i32_u
      i64.or
      local.set 245
      local.get 245
      local.set 11
      local.get 245
      i64.const 0
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store32 4 align=1
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 250
        i32.const 8
        local.get 250
        i64.store align=1
        i32.const 5
        local.set 251
        i32.const 20
        call $goose.reserve_memory.5
        local.set 252
        local.get 251
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 252
        i64.extend_i32_u
        i64.or
        local.set 253
        local.get 253
        local.set 12
        local.get 253
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 5 align=1
        i32.const 8
        i64.load align=1
        local.set 254
        local.get 252
        i32.const 4
        i32.add
        local.get 254
        i64.store 5 align=1
        i64.const 99
        local.set 254
        local.get 252
        i32.const 12
        i32.add
        local.get 254
        i64.store 5 align=1
        local.get 12
        local.set 255
        local.get 255
        i32.wrap_i64
        i64.load32_u 5 align=1
        local.set 256
        i64.const 0
        local.set 257
        local.get 255
        local.set 258
        local.get 258
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 257
        i64.const 8
        i64.mul
        i64.add
        local.tee 259
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1792
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 258
        i64.const -4294967296
        i64.and
        local.get 259
        i64.or
        i32.wrap_i64
        i64.load 5 align=1
        local.set 249
        local.get 252
        global.set 5
        br 0 (;@2;)
        local.get 252
        global.set 5
      end
      local.get 249
      local.set 248
      i32.const 5
      local.set 261
      i32.const 0
      call $goose.reserve_memory.5
      local.set 262
      local.get 261
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 262
      i64.extend_i32_u
      i64.or
      local.set 260
      local.get 0
      i32.const 115
      i32.add
      local.get 260
      i64.store align=1
      local.get 0
      i32.const 115
      i32.add
      i64.const 0
      i64.store offset=8 align=1
      block ;; label = @2
        i32.const 8
        i64.load align=1
        i64.const 1
        i64.add
        local.set 265
        i32.const 8
        local.get 265
        i64.store align=1
        i32.const 6
        local.set 266
        i32.const 20
        call $goose.reserve_memory.6
        local.set 267
        local.get 266
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 267
        i64.extend_i32_u
        i64.or
        local.set 268
        local.get 268
        local.set 13
        local.get 268
        i64.const 2
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store32 6 align=1
        i32.const 8
        i64.load align=1
        local.set 269
        local.get 267
        i32.const 4
        i32.add
        local.get 269
        i64.store 6 align=1
        i64.const 99
        local.set 269
        local.get 267
        i32.const 12
        i32.add
        local.get 269
        i64.store 6 align=1
        local.get 13
        local.set 270
        local.get 270
        i32.wrap_i64
        i64.load32_u 6 align=1
        local.set 271
        i64.const 0
        local.set 272
        local.get 270
        local.set 273
        local.get 273
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 272
        i64.const 8
        i64.mul
        i64.add
        local.tee 274
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1862
          i32.const 70
          i32.const 6
          call 6
          unreachable
        end
        local.get 273
        i64.const -4294967296
        i64.and
        local.get 274
        i64.or
        i32.wrap_i64
        i64.load 6 align=1
        local.set 264
        local.get 267
        global.set 6
        br 0 (;@2;)
        local.get 267
        global.set 6
      end
      local.get 264
      local.set 263
      i64.const 0
      local.set 275
      local.get 0
      i32.const 90
      i32.add
      i64.extend_i32_u
      local.set 276
      local.get 276
      i32.wrap_i64
      i64.load8_u
      local.set 277
      local.get 11
      local.set 278
      local.get 278
      i32.wrap_i64
      i64.load32_u 4 align=1
      local.set 279
      local.get 0
      i32.const 115
      i32.add
      local.set 280
      local.get 280
      i64.load offset=8 align=1
      local.set 281
      i32.const 8
      i64.load align=1
      local.set 282
      call 0
      local.set 283
      local.get 283
      i32.const 1932
      i32.const 6
      call 4
      local.get 283
      local.get 275
      i32.const 0
      call 1
      local.get 283
      i32.const 1938
      i32.const 1
      call 4
      local.get 283
      local.get 277
      i32.const 0
      call 1
      local.get 283
      i32.const 1939
      i32.const 1
      call 4
      local.get 283
      local.get 279
      i32.const 0
      call 1
      local.get 283
      i32.const 1940
      i32.const 1
      call 4
      local.get 283
      local.get 281
      i32.const 0
      call 1
      local.get 283
      i32.const 1941
      i32.const 1
      call 4
      local.get 283
      local.get 282
      i32.const 0
      call 1
      local.get 283
      call 5
      i64.const 20
      local.set 284
      local.get 0
      i32.const 131
      i32.add
      local.get 284
      i64.store align=1
      i32.const 6
      local.set 286
      i32.const 28
      call $goose.reserve_memory.6
      local.set 287
      local.get 286
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 287
      i64.extend_i32_u
      i64.or
      local.set 285
      local.get 285
      local.set 14
      local.get 285
      i64.const 3
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store32 6 align=1
      local.get 0
      i32.const 131
      i32.add
      i64.extend_i32_u
      local.set 288
      i64.const 0
      local.set 289
      block ;; label = @2
        loop ;; label = @3
          local.get 289
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 285
          i32.wrap_i64
          local.get 289
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 4
          i32.add
          local.get 288
          i64.store 6 align=1
          local.get 289
          i64.const 1
          i64.add
          local.set 289
          br 0 (;@3;)
        end
      end
      local.get 14
      local.set 290
      i64.const 0
      local.set 291
      block ;; label = @2
        loop ;; label = @3
          local.get 291
          local.get 290
          i32.wrap_i64
          i64.load32_u 6 align=1
          i64.ge_u
          br_if 1 (;@2;)
          local.get 290
          local.set 292
          local.get 292
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 291
          i64.const 8
          i64.mul
          i64.add
          local.tee 293
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 1942
            i32.const 70
            i32.const 30
            call 6
            unreachable
          end
          local.get 292
          i64.const -4294967296
          i64.and
          local.get 293
          i64.or
          i32.wrap_i64
          i64.load 6 align=1
          local.set 15
          block ;; label = @4
            local.get 15
            local.tee 294
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 2012
              i32.const 70
              i32.const 30
              call 6
              unreachable
            end
            local.get 294
            local.set 295
            local.get 295
            call $goose.memory_op.41
            i64.const 1
            i64.add
            local.set 296
            local.get 295
            local.get 296
            call $goose.memory_op.55
          end
          local.get 291
          i64.const 1
          i64.add
          local.set 291
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 131
      i32.add
      i64.load align=1
      local.set 297
      local.get 14
      local.set 298
      local.get 298
      i32.wrap_i64
      i64.load32_u 6 align=1
      local.set 299
      i64.const 0
      local.set 300
      local.get 298
      local.set 301
      local.get 301
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 300
      i64.const 8
      i64.mul
      i64.add
      local.tee 302
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2082
        i32.const 70
        i32.const 31
        call 6
        unreachable
      end
      local.get 301
      i64.const -4294967296
      i64.and
      local.get 302
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.tee 303
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2152
        i32.const 70
        i32.const 29
        call 6
        unreachable
      end
      local.get 303
      call $goose.memory_op.41
      local.set 304
      local.get 14
      local.set 305
      local.get 305
      i32.wrap_i64
      i64.load32_u 6 align=1
      local.set 306
      i64.const 2
      local.set 307
      local.get 305
      local.set 308
      local.get 308
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 307
      i64.const 8
      i64.mul
      i64.add
      local.tee 309
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2222
        i32.const 70
        i32.const 31
        call 6
        unreachable
      end
      local.get 308
      i64.const -4294967296
      i64.and
      local.get 309
      i64.or
      i32.wrap_i64
      i64.load 6 align=1
      local.tee 310
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2292
        i32.const 70
        i32.const 29
        call 6
        unreachable
      end
      local.get 310
      call $goose.memory_op.41
      local.set 311
      call 0
      local.set 312
      local.get 312
      i32.const 2362
      i32.const 5
      call 4
      local.get 312
      local.get 297
      i32.const 0
      call 1
      local.get 312
      i32.const 2367
      i32.const 1
      call 4
      local.get 312
      local.get 304
      i32.const 0
      call 1
      local.get 312
      i32.const 2368
      i32.const 1
      call 4
      local.get 312
      local.get 311
      i32.const 0
      call 1
      local.get 312
      call 5
      local.get 0
      i32.const 139
      i32.add
      local.set 313
      local.get 313
      i32.const 0
      i32.add
      i64.const 8
      i64.store align=1
      local.get 313
      i32.const 8
      i32.add
      i64.const 9
      i64.store align=1
      i32.const 7
      local.set 315
      i32.const 20
      call $goose.reserve_memory.7
      local.set 316
      local.get 315
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 316
      i64.extend_i32_u
      i64.or
      local.set 314
      local.get 314
      local.set 16
      local.get 314
      i64.const 2
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store32 7 align=1
      local.get 0
      i32.const 139
      i32.add
      i64.extend_i32_u
      local.set 317
      i64.const 0
      local.set 318
      block ;; label = @2
        loop ;; label = @3
          local.get 318
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 314
          i32.wrap_i64
          local.get 318
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 4
          i32.add
          local.get 317
          i64.store 7 align=1
          local.get 318
          i64.const 1
          i64.add
          local.set 318
          br 0 (;@3;)
        end
      end
      local.get 16
      local.set 319
      local.get 319
      i32.wrap_i64
      i64.load32_u 7 align=1
      local.set 320
      i64.const 0
      local.set 321
      local.get 319
      local.set 322
      local.get 322
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 321
      i64.const 8
      i64.mul
      i64.add
      local.tee 323
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2369
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 322
      i64.const -4294967296
      i64.and
      local.get 323
      i64.or
      i32.wrap_i64
      i64.load 7 align=1
      local.tee 324
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2439
        i32.const 70
        i32.const 33
        call 6
        unreachable
      end
      local.get 324
      local.set 325
      i64.const 2
      local.set 326
      i64.const 0
      local.set 327
      local.get 325
      local.set 328
      local.get 328
      i64.const 4294967295
      i64.and
      local.get 327
      i64.const 8
      i64.mul
      i64.add
      local.tee 329
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2509
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 328
      i64.const -4294967296
      i64.and
      local.get 329
      i64.or
      local.set 330
      local.get 330
      call $goose.memory_op.41
      i64.const 2
      i64.add
      local.set 331
      local.get 330
      local.get 331
      call $goose.memory_op.55
      local.get 16
      local.set 332
      local.get 332
      i32.wrap_i64
      i64.load32_u 7 align=1
      local.set 333
      i64.const 1
      local.set 334
      local.get 332
      local.set 335
      local.get 335
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 334
      i64.const 8
      i64.mul
      i64.add
      local.tee 336
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2579
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 335
      i64.const -4294967296
      i64.and
      local.get 336
      i64.or
      i32.wrap_i64
      i64.load 7 align=1
      local.tee 337
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2649
        i32.const 70
        i32.const 33
        call 6
        unreachable
      end
      local.get 337
      local.set 338
      i64.const 2
      local.set 339
      i64.const 0
      local.set 340
      local.get 338
      local.set 341
      local.get 341
      i64.const 4294967295
      i64.and
      local.get 340
      i64.const 8
      i64.mul
      i64.add
      local.tee 342
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2719
        i32.const 70
        i32.const 34
        call 6
        unreachable
      end
      local.get 341
      i64.const -4294967296
      i64.and
      local.get 342
      i64.or
      call $goose.memory_op.41
      local.set 343
      call 0
      local.set 344
      local.get 344
      i32.const 2789
      i32.const 5
      call 4
      local.get 344
      local.get 343
      i32.const 0
      call 1
      local.get 344
      call 5
      i32.const 8
      local.set 346
      i32.const 16
      call $goose.reserve_memory.8
      local.set 347
      local.get 346
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 347
      i64.extend_i32_u
      i64.or
      local.set 345
      local.get 345
      local.set 17
      local.get 345
      i64.const 2
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store 8 align=1
      f32.const -0x0p+0 (;=-0;)
      local.set 348
      i64.const 0
      local.set 349
      block ;; label = @2
        loop ;; label = @3
          local.get 349
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 345
          i32.wrap_i64
          local.get 349
          i32.wrap_i64
          i32.const 4
          i32.mul
          i32.add
          i32.const 8
          i32.add
          local.get 348
          f32.store 8 align=1
          local.get 349
          i64.const 1
          i64.add
          local.set 349
          br 0 (;@3;)
        end
      end
      i32.const 9
      local.set 351
      i32.const 5
      call $goose.reserve_memory.9
      local.set 352
      local.get 351
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 352
      i64.extend_i32_u
      i64.or
      local.set 350
      local.get 350
      local.set 18
      local.get 350
      i64.const 3
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store16 9 align=1
      i32.const 1
      local.set 353
      i64.const 0
      local.set 354
      block ;; label = @2
        loop ;; label = @3
          local.get 354
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 350
          i32.wrap_i64
          local.get 354
          i32.wrap_i64
          i32.const 1
          i32.mul
          i32.add
          i32.const 2
          i32.add
          local.get 353
          i32.store8 9
          local.get 354
          i64.const 1
          i64.add
          local.set 354
          br 0 (;@3;)
        end
      end
      i32.const 10
      local.set 356
      i32.const 5
      call $goose.reserve_memory.10
      local.set 357
      local.get 356
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 357
      i64.extend_i32_u
      i64.or
      local.set 355
      local.get 355
      local.set 19
      local.get 355
      i64.const 4
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store8 10
      i64.const 255
      local.set 358
      i64.const 0
      local.set 359
      block ;; label = @2
        loop ;; label = @3
          local.get 359
          i64.const 4
          i64.ge_u
          br_if 1 (;@2;)
          local.get 355
          i32.wrap_i64
          local.get 359
          i32.wrap_i64
          i32.const 1
          i32.mul
          i32.add
          i32.const 1
          i32.add
          local.get 358
          i64.store8 10
          local.get 359
          i64.const 1
          i64.add
          local.set 359
          br 0 (;@3;)
        end
      end
      local.get 17
      local.set 360
      local.get 360
      i32.wrap_i64
      i64.load 8 align=1
      local.set 361
      i64.const 1
      local.set 362
      local.get 360
      local.set 363
      local.get 363
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 362
      i64.const 4
      i64.mul
      i64.add
      local.tee 364
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2794
        i32.const 70
        i32.const 38
        call 6
        unreachable
      end
      local.get 363
      i64.const -4294967296
      i64.and
      local.get 364
      i64.or
      i32.wrap_i64
      f32.load 8 align=1
      local.set 365
      local.get 18
      local.set 366
      local.get 366
      i32.wrap_i64
      i64.load16_u 9 align=1
      local.set 367
      i64.const 2
      local.set 368
      local.get 366
      local.set 369
      local.get 369
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 368
      i64.const 1
      i64.mul
      i64.add
      local.tee 370
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2864
        i32.const 70
        i32.const 38
        call 6
        unreachable
      end
      local.get 369
      i64.const -4294967296
      i64.and
      local.get 370
      i64.or
      i32.wrap_i64
      i32.load8_u 9
      local.set 371
      local.get 19
      local.set 372
      local.get 372
      i32.wrap_i64
      i64.load8_u 10
      local.set 373
      i64.const 3
      local.set 374
      local.get 372
      local.set 375
      local.get 375
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 374
      i64.const 1
      i64.mul
      i64.add
      local.tee 376
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2934
        i32.const 70
        i32.const 38
        call 6
        unreachable
      end
      local.get 375
      i64.const -4294967296
      i64.and
      local.get 376
      i64.or
      i32.wrap_i64
      i64.load8_u 10
      local.set 377
      call 0
      local.set 378
      local.get 378
      i32.const 3004
      i32.const 7
      call 4
      local.get 378
      local.get 365
      f64.promote_f32
      i32.const 32
      call 2
      local.get 378
      i32.const 3011
      i32.const 1
      call 4
      local.get 378
      local.get 371
      call 3
      local.get 378
      i32.const 3012
      i32.const 1
      call 4
      local.get 378
      local.get 377
      i32.const 1
      call 1
      local.get 378
      call 5
      i32.const 11
      local.set 380
      i32.const 72004
      call $goose.reserve_memory.11
      local.set 381
      local.get 380
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 381
      i64.extend_i32_u
      i64.or
      local.set 379
      local.get 379
      local.set 20
      local.get 379
      i64.const 9000
      local.set 27
      i32.wrap_i64
      local.get 27
      i64.store32 11 align=1
      i64.const 123
      local.set 382
      i64.const 0
      local.set 383
      block ;; label = @2
        loop ;; label = @3
          local.get 383
          i64.const 9000
          i64.ge_u
          br_if 1 (;@2;)
          local.get 379
          i32.wrap_i64
          local.get 383
          i32.wrap_i64
          i32.const 8
          i32.mul
          i32.add
          i32.const 4
          i32.add
          local.get 382
          i64.store 11 align=1
          local.get 383
          i64.const 1
          i64.add
          local.set 383
          br 0 (;@3;)
        end
      end
      local.get 20
      local.set 384
      local.get 384
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 385
      local.get 20
      local.set 386
      local.get 386
      i32.wrap_i64
      i64.load32_u 11 align=1
      local.set 387
      i64.const 8999
      local.set 388
      local.get 386
      local.set 389
      local.get 389
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 388
      i64.const 8
      i64.mul
      i64.add
      local.tee 390
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3013
        i32.const 70
        i32.const 40
        call 6
        unreachable
      end
      local.get 389
      i64.const -4294967296
      i64.and
      local.get 390
      i64.or
      i32.wrap_i64
      i64.load 11 align=1
      local.set 391
      call 0
      local.set 392
      local.get 392
      i32.const 3083
      i32.const 7
      call 4
      local.get 392
      local.get 385
      i32.const 0
      call 1
      local.get 392
      i32.const 3090
      i32.const 1
      call 4
      local.get 392
      local.get 391
      i32.const 0
      call 1
      local.get 392
      call 5
      block ;; label = @2
        i32.const 12
        local.set 395
        i32.const 72002
        call $goose.reserve_memory.12
        local.set 396
        local.get 395
        i64.extend_i32_u
        i64.const 32
        i64.shl
        local.get 396
        i64.extend_i32_u
        i64.or
        local.set 394
        local.get 394
        local.set 21
        local.get 394
        i64.const 9000
        local.set 27
        i32.wrap_i64
        local.get 27
        i64.store16 12 align=1
        block ;; label = @3
          i32.const 8
          i64.load align=1
          i64.const 1
          i64.add
          local.set 399
          i32.const 8
          local.get 399
          i64.store align=1
          i32.const 13
          local.set 400
          i32.const 20
          call $goose.reserve_memory.13
          local.set 401
          local.get 400
          i64.extend_i32_u
          i64.const 32
          i64.shl
          local.get 401
          i64.extend_i32_u
          i64.or
          local.set 402
          local.get 402
          local.set 22
          local.get 402
          i64.const 2
          local.set 27
          i32.wrap_i64
          local.get 27
          i64.store32 13 align=1
          i32.const 8
          i64.load align=1
          local.set 403
          local.get 401
          i32.const 4
          i32.add
          local.get 403
          i64.store 13 align=1
          i64.const 99
          local.set 403
          local.get 401
          i32.const 12
          i32.add
          local.get 403
          i64.store 13 align=1
          local.get 22
          local.set 404
          local.get 404
          i32.wrap_i64
          i64.load32_u 13 align=1
          local.set 405
          i64.const 0
          local.set 406
          local.get 404
          local.set 407
          local.get 407
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 406
          i64.const 8
          i64.mul
          i64.add
          local.tee 408
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 3091
            i32.const 70
            i32.const 6
            call 6
            unreachable
          end
          local.get 407
          i64.const -4294967296
          i64.and
          local.get 408
          i64.or
          i32.wrap_i64
          i64.load 13 align=1
          local.set 398
          local.get 401
          global.set 13
          br 0 (;@3;)
          local.get 401
          global.set 13
        end
        local.get 398
        local.set 397
        i64.const 0
        local.set 409
        block ;; label = @3
          loop ;; label = @4
            local.get 409
            i64.const 9000
            i64.ge_u
            br_if 1 (;@3;)
            local.get 394
            i32.wrap_i64
            local.get 409
            i32.wrap_i64
            i32.const 8
            i32.mul
            i32.add
            i32.const 2
            i32.add
            local.get 397
            i64.store 12 align=1
            local.get 409
            i64.const 1
            i64.add
            local.set 409
            br 0 (;@4;)
          end
        end
        local.get 21
        local.set 410
        local.get 410
        i32.wrap_i64
        i64.load16_u 12 align=1
        local.set 411
        i64.const 0
        local.set 412
        local.get 410
        local.set 413
        local.get 413
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 412
        i64.const 8
        i64.mul
        i64.add
        local.tee 414
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3161
          i32.const 70
          i32.const 10
          call 6
          unreachable
        end
        local.get 413
        i64.const -4294967296
        i64.and
        local.get 414
        i64.or
        i32.wrap_i64
        i64.load 12 align=1
        local.get 21
        local.set 415
        local.get 415
        i32.wrap_i64
        i64.load16_u 12 align=1
        local.set 416
        i64.const 8999
        local.set 417
        local.get 415
        local.set 418
        local.get 418
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 417
        i64.const 8
        i64.mul
        i64.add
        local.tee 419
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3231
          i32.const 70
          i32.const 10
          call 6
          unreachable
        end
        local.get 418
        i64.const -4294967296
        i64.and
        local.get 419
        i64.or
        i32.wrap_i64
        i64.load 12 align=1
        i64.add
        local.set 393
        local.get 396
        global.set 12
        br 0 (;@2;)
        local.get 396
        global.set 12
      end
      local.get 393
      local.set 420
      i32.const 8
      i64.load align=1
      local.set 421
      i32.const 16
      i64.load align=1
      local.set 422
      local.get 422
      i32.wrap_i64
      i64.load8_u 14
      local.set 423
      i32.const 16
      i64.load align=1
      local.set 424
      local.get 424
      i32.wrap_i64
      i64.load8_u 14
      local.set 425
      i64.const 3
      local.set 426
      local.get 426
      local.get 425
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3301
        i32.const 70
        i32.const 41
        call 6
        unreachable
      end
      local.get 424
      local.set 427
      local.get 427
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 426
      i64.const 2
      i64.mul
      i64.add
      local.tee 428
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3371
        i32.const 70
        i32.const 41
        call 6
        unreachable
      end
      local.get 427
      i64.const -4294967296
      i64.and
      local.get 428
      i64.or
      i32.wrap_i64
      i64.load16_s 14 align=1
      local.set 429
      call 0
      local.set 430
      local.get 430
      i32.const 3441
      i32.const 6
      call 4
      local.get 430
      local.get 420
      i32.const 0
      call 1
      local.get 430
      i32.const 3447
      i32.const 1
      call 4
      local.get 430
      local.get 421
      i32.const 0
      call 1
      local.get 430
      i32.const 3448
      i32.const 1
      call 4
      local.get 430
      local.get 423
      i32.const 0
      call 1
      local.get 430
      i32.const 3449
      i32.const 1
      call 4
      local.get 430
      local.get 429
      i32.const 0
      call 1
      local.get 430
      call 5
      local.get 381
      global.set 11
      local.get 357
      global.set 10
      local.get 352
      global.set 9
      local.get 347
      global.set 8
      local.get 316
      global.set 7
      local.get 287
      global.set 6
      local.get 262
      global.set 5
      local.get 247
      global.set 4
      local.get 117
      global.set 3
      local.get 101
      global.set 2
      local.get 85
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64)
    i64.const 0
    local.set 1
    i32.const 8
    local.get 1
    i64.store align=1
    i32.const 14
    local.set 3
    i32.const 9
    call $goose.reserve_memory.14
    local.set 4
    local.get 3
    i64.extend_i32_u
    i64.const 32
    i64.shl
    local.get 4
    i64.extend_i32_u
    i64.or
    local.set 2
    local.get 2
    local.set 5
    i32.const 16
    local.get 5
    i64.store align=1
    local.get 2
    i64.const 4
    local.set 6
    i32.wrap_i64
    local.get 6
    i64.store8 14
    i64.const 7
    local.set 7
    i64.const 0
    local.set 8
    block ;; label = @1
      loop ;; label = @2
        local.get 8
        i64.const 4
        i64.ge_u
        br_if 1 (;@1;)
        local.get 2
        i32.wrap_i64
        local.get 8
        i32.wrap_i64
        i32.const 2
        i32.mul
        i32.add
        i32.const 1
        i32.add
        local.get 7
        i64.store16 14 align=1
        local.get 8
        i64.const 1
        i64.add
        local.set 8
        br 0 (;@2;)
      end
    end
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_memory.4 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.reserve_memory.5 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 5
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 5
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 5
      i32.sub
      memory.grow 5
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 5
    local.get 1
  )
  (func $goose.reserve_memory.6 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 6
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 6
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 6
      i32.sub
      memory.grow 6
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 6
    local.get 1
  )
  (func $goose.memory_op.41 (;20;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    i64.load align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  i64.load 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                i64.load 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              i64.load 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            i64.load 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          i64.load 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        i64.load 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;21;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        block ;; label = @11
                          block ;; label = @12
                            block ;; label = @13
                              block ;; label = @14
                                block ;; label = @15
                                  block ;; label = @16
                                    block ;; label = @17
                                      local.get 0
                                      i64.const 32
                                      i64.shr_u
                                      i32.wrap_i64
                                      br_table 0 (;@17;) 1 (;@16;) 2 (;@15;) 3 (;@14;) 4 (;@13;) 5 (;@12;) 6 (;@11;) 7 (;@10;) 8 (;@9;) 9 (;@8;) 10 (;@7;) 11 (;@6;) 12 (;@5;) 13 (;@4;) 14 (;@3;) 15 (;@2;)
                                    end
                                    local.get 0
                                    i32.wrap_i64
                                    local.get 1
                                    i64.store align=1
                                    br 15 (;@1;)
                                  end
                                  local.get 0
                                  i32.wrap_i64
                                  local.get 1
                                  i64.store 1 align=1
                                  br 14 (;@1;)
                                end
                                local.get 0
                                i32.wrap_i64
                                local.get 1
                                i64.store 2 align=1
                                br 13 (;@1;)
                              end
                              local.get 0
                              i32.wrap_i64
                              local.get 1
                              i64.store 3 align=1
                              br 12 (;@1;)
                            end
                            local.get 0
                            i32.wrap_i64
                            local.get 1
                            i64.store 4 align=1
                            br 11 (;@1;)
                          end
                          local.get 0
                          i32.wrap_i64
                          local.get 1
                          i64.store 5 align=1
                          br 10 (;@1;)
                        end
                        local.get 0
                        i32.wrap_i64
                        local.get 1
                        i64.store 6 align=1
                        br 9 (;@1;)
                      end
                      local.get 0
                      i32.wrap_i64
                      local.get 1
                      i64.store 7 align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i64.store 8 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i64.store 9 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i64.store 10 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store 11 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 12 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 13 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 14 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.7 (;22;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 7
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 7
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 7
      i32.sub
      memory.grow 7
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 7
    local.get 1
  )
  (func $goose.reserve_memory.8 (;23;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 8
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 8
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 8
      i32.sub
      memory.grow 8
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 8
    local.get 1
  )
  (func $goose.reserve_memory.9 (;24;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 9
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 9
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 9
      i32.sub
      memory.grow 9
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 9
    local.get 1
  )
  (func $goose.reserve_memory.10 (;25;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 10
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 10
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 10
      i32.sub
      memory.grow 10
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 10
    local.get 1
  )
  (func $goose.reserve_memory.11 (;26;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 11
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 11
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 11
      i32.sub
      memory.grow 11
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 11
    local.get 1
  )
  (func $goose.reserve_memory.12 (;27;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 12
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 12
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 12
      i32.sub
      memory.grow 12
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 12
    local.get 1
  )
  (func $goose.reserve_memory.13 (;28;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 13
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 13
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 13
      i32.sub
      memory.grow 13
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 13
    local.get 1
  )
  (func $goose.reserve_memory.14 (;29;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 14
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 14
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 14
      i32.sub
      memory.grow 14
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 14
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosebefore=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose,,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.gooseempty=,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.gooserefs=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosethin=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosescalar=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goosegrowth=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_fills.gooseafter=,,,")
)
