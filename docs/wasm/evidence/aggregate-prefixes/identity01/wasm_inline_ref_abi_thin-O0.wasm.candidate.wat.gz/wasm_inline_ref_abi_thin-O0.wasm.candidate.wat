(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (type (;12;) (func (param i32 i32) (result i32)))
  (type (;13;) (func (param i32) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 5456)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 40
      i32.const 78
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 118
        i32.const 78
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32)
    i32.const 200
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 5
      local.get 5
      i32.const 0
      i32.add
      i64.const 10
      i64.store align=1
      local.get 5
      i32.const 8
      i32.add
      i64.const 20
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 6
      local.get 6
      i32.const 0
      i32.add
      i64.const 30
      i64.store align=1
      local.get 6
      i32.const 8
      i32.add
      i64.const 40
      i64.store align=1
      local.get 0
      i32.const 32
      i32.add
      local.set 7
      local.get 7
      i64.const 0
      i64.store8
      i64.const 50
      local.set 8
      local.get 7
      i64.load8_u
      local.set 9
      local.get 9
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 196
        i32.const 78
        i32.const 16
        call 6
        unreachable
      end
      local.get 7
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 11
      local.get 11
      i64.const 4294967295
      i64.and
      local.get 9
      i64.const 8
      i64.mul
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 274
        i32.const 78
        i32.const 16
        call 6
        unreachable
      end
      local.get 11
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.tee 13
      local.get 8
      local.set 14
      i32.wrap_i64
      local.get 14
      i64.store align=1
      local.get 7
      local.get 9
      i64.const 1
      i64.add
      i64.store8
      local.get 7
      i32.const 9
      i32.add
      i32.const 0
      i32.const 16
      memory.fill
      local.get 0
      i32.const 57
      i32.add
      local.set 15
      local.get 15
      i64.const 7
      i64.store8
      local.get 15
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 15
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      i64.store offset=9 align=1
      local.get 15
      i32.const 0
      i64.extend_i32_u
      i64.store offset=17 align=1
      local.get 15
      i64.const 4000000000
      i64.store32 offset=25 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 16
      local.get 16
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 352
        i32.const 78
        i32.const 18
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 17
      local.get 17
      i64.load32_u offset=25 align=1
      i64.const 4000000000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 430
        i32.const 78
        i32.const 18
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 18
      local.get 18
      i64.load offset=17 align=1
      i32.wrap_i64
      i32.const 0
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 508
        i32.const 78
        i32.const 18
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 19
      local.get 19
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 20
      local.get 20
      i64.load offset=9 align=1
      i32.wrap_i64
      local.tee 21
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 586
        i32.const 78
        i32.const 19
        call 6
        unreachable
      end
      local.get 21
      local.set 22
      i64.const 51
      local.set 23
      local.get 22
      i64.load8_u
      local.set 24
      local.get 24
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 664
        i32.const 78
        i32.const 19
        call 6
        unreachable
      end
      local.get 22
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 26
      local.get 26
      i64.const 4294967295
      i64.and
      local.get 24
      i64.const 8
      i64.mul
      i64.add
      local.tee 27
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 742
        i32.const 78
        i32.const 19
        call 6
        unreachable
      end
      local.get 26
      i64.const -4294967296
      i64.and
      local.get 27
      i64.or
      local.tee 28
      local.get 23
      local.set 29
      i32.wrap_i64
      local.get 29
      i64.store align=1
      local.get 22
      local.get 24
      i64.const 1
      i64.add
      i64.store8
      local.get 28
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 57
      i32.add
      local.set 30
      local.get 30
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=17 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 31
      local.get 31
      i64.load offset=1 align=1
      i32.wrap_i64
      local.get 0
      i32.const 16
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 820
        i32.const 78
        i32.const 20
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 32
      local.get 32
      i64.load offset=9 align=1
      i32.wrap_i64
      local.tee 33
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 898
        i32.const 78
        i32.const 20
        call 6
        unreachable
      end
      local.get 33
      local.set 34
      local.get 34
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 976
        i32.const 78
        i32.const 20
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 35
      local.get 35
      i64.load offset=9 align=1
      i32.wrap_i64
      local.tee 36
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1054
        i32.const 78
        i32.const 20
        call 6
        unreachable
      end
      local.get 36
      local.set 37
      local.get 37
      i64.load8_u
      local.set 38
      i64.const 1
      local.set 39
      local.get 37
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 40
      local.get 40
      i64.const 4294967295
      i64.and
      local.get 39
      i64.const 8
      i64.mul
      i64.add
      local.tee 41
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1132
        i32.const 78
        i32.const 20
        call 6
        unreachable
      end
      local.get 40
      i64.const -4294967296
      i64.and
      local.get 41
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 51
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1210
        i32.const 78
        i32.const 20
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 42
      local.get 42
      i64.load offset=17 align=1
      i32.wrap_i64
      local.set 1
      local.get 1
      if ;; label = @2
        local.get 1
        local.tee 43
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1288
          i32.const 78
          i32.const 21
          call 6
          unreachable
        end
        local.get 43
        local.set 44
        i64.const 2
        local.set 45
        i64.const 1
        local.set 46
        local.get 44
        i64.extend_i32_u
        local.set 47
        local.get 47
        i64.const 4294967295
        i64.and
        local.get 46
        i64.const 8
        i64.mul
        i64.add
        local.tee 48
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1366
          i32.const 78
          i32.const 21
          call 6
          unreachable
        end
        local.get 47
        i64.const -4294967296
        i64.and
        local.get 48
        i64.or
        i32.wrap_i64
        i64.load align=1
        i64.const 20
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1444
          i32.const 78
          i32.const 21
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 86
      i32.add
      local.set 49
      local.get 0
      i32.const 57
      i32.add
      local.set 50
      local.get 49
      i64.extend_i32_u
      local.set 51
      local.get 50
      i64.extend_i32_u
      local.set 52
      i32.const 29
      local.set 53
      local.get 51
      i32.wrap_i64
      local.get 52
      i32.wrap_i64
      local.get 53
      memory.copy
      local.get 0
      i32.const 115
      i32.add
      local.set 54
      local.get 54
      local.get 0
      i32.const 57
      i32.add
      i32.const 29
      memory.copy
      local.get 54
      i32.const 29
      i32.add
      local.get 0
      i32.const 86
      i32.add
      i32.const 29
      memory.copy
      local.get 0
      i32.const 115
      i32.add
      local.set 55
      i64.const 2
      local.set 56
      i64.const 0
      local.set 57
      local.get 55
      i64.extend_i32_u
      local.set 58
      local.get 58
      i64.const 4294967295
      i64.and
      local.get 57
      i64.const 29
      i64.mul
      i64.add
      local.tee 59
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1522
        i32.const 78
        i32.const 23
        call 6
        unreachable
      end
      local.get 58
      i64.const -4294967296
      i64.and
      local.get 59
      i64.or
      local.set 60
      local.get 60
      i32.wrap_i64
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 0
      i32.const 115
      i32.add
      local.set 61
      i64.const 2
      local.set 62
      i64.const 0
      local.set 63
      local.get 61
      i64.extend_i32_u
      local.set 64
      local.get 64
      i64.const 4294967295
      i64.and
      local.get 63
      i64.const 29
      i64.mul
      i64.add
      local.tee 65
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1600
        i32.const 78
        i32.const 23
        call 6
        unreachable
      end
      local.get 64
      i64.const -4294967296
      i64.and
      local.get 65
      i64.or
      local.set 66
      local.get 66
      i32.wrap_i64
      i64.load offset=1 align=1
      i32.wrap_i64
      local.get 0
      i32.const 0
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1678
        i32.const 78
        i32.const 23
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      local.set 67
      i64.const 2
      local.set 68
      i64.const 1
      local.set 69
      local.get 67
      i64.extend_i32_u
      local.set 70
      local.get 70
      i64.const 4294967295
      i64.and
      local.get 69
      i64.const 29
      i64.mul
      i64.add
      local.tee 71
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1756
        i32.const 78
        i32.const 23
        call 6
        unreachable
      end
      local.get 70
      i64.const -4294967296
      i64.and
      local.get 71
      i64.or
      local.set 72
      local.get 72
      i32.wrap_i64
      i64.load offset=1 align=1
      i32.wrap_i64
      local.get 0
      i32.const 16
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1834
        i32.const 78
        i32.const 23
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      local.set 73
      i64.const 2
      local.set 74
      i64.const 0
      local.set 75
      local.get 73
      i64.extend_i32_u
      local.set 76
      local.get 76
      i64.const 4294967295
      i64.and
      local.get 75
      i64.const 29
      i64.mul
      i64.add
      local.tee 77
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1912
        i32.const 78
        i32.const 24
        call 6
        unreachable
      end
      local.get 76
      i64.const -4294967296
      i64.and
      local.get 77
      i64.or
      local.set 78
      local.get 78
      i32.wrap_i64
      i64.load32_u offset=25 align=1
      i64.const 4000000000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1990
        i32.const 78
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      local.set 79
      i64.const 2
      local.set 80
      i64.const 1
      local.set 81
      local.get 79
      i64.extend_i32_u
      local.set 82
      local.get 82
      i64.const 4294967295
      i64.and
      local.get 81
      i64.const 29
      i64.mul
      i64.add
      local.tee 83
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2068
        i32.const 78
        i32.const 24
        call 6
        unreachable
      end
      local.get 82
      i64.const -4294967296
      i64.and
      local.get 83
      i64.or
      local.set 84
      local.get 84
      i32.wrap_i64
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2146
        i32.const 78
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 173
      i32.add
      local.set 85
      local.get 85
      i32.const 0
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 85
      i32.const 8
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 85
      i32.const 16
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 173
      i32.add
      local.set 86
      i64.const 3
      local.set 87
      i64.const 1
      local.set 88
      local.get 86
      i64.extend_i32_u
      local.set 89
      local.get 89
      i64.const 4294967295
      i64.and
      local.get 88
      i64.const 8
      i64.mul
      i64.add
      local.tee 90
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2224
        i32.const 78
        i32.const 26
        call 6
        unreachable
      end
      local.get 89
      i64.const -4294967296
      i64.and
      local.get 90
      i64.or
      local.set 91
      local.get 0
      i32.const 0
      i32.add
      local.set 92
      local.get 91
      local.get 92
      local.set 93
      i32.wrap_i64
      local.get 93
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 173
      i32.add
      local.set 94
      i64.const 3
      local.set 95
      i64.const 1
      local.set 96
      local.get 94
      i64.extend_i32_u
      local.set 97
      local.get 97
      i64.const 4294967295
      i64.and
      local.get 96
      i64.const 8
      i64.mul
      i64.add
      local.tee 98
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2302
        i32.const 78
        i32.const 26
        call 6
        unreachable
      end
      local.get 97
      i64.const -4294967296
      i64.and
      local.get 98
      i64.or
      i32.wrap_i64
      i64.load align=1
      i32.wrap_i64
      local.get 0
      i32.const 0
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2380
        i32.const 78
        i32.const 26
        call 6
        unreachable
      end
      local.get 0
      i32.const 173
      i32.add
      local.set 99
      i64.const 3
      local.set 100
      i64.const 2
      local.set 101
      local.get 99
      i64.extend_i32_u
      local.set 102
      local.get 102
      i64.const 4294967295
      i64.and
      local.get 101
      i64.const 8
      i64.mul
      i64.add
      local.tee 103
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2458
        i32.const 78
        i32.const 26
        call 6
        unreachable
      end
      local.get 102
      i64.const -4294967296
      i64.and
      local.get 103
      i64.or
      i32.wrap_i64
      i64.load align=1
      i32.wrap_i64
      local.get 0
      i32.const 0
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2536
        i32.const 78
        i32.const 26
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      call $fixedref.1
      local.get 0
      i32.const 16
      i32.add
      call $inlineref.2
      i32.const 0
      call $choose.3
      local.set 2
      local.get 2
      local.get 0
      i32.const 16
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2614
        i32.const 78
        i32.const 28
        call 6
        unreachable
      end
      local.get 2
      local.tee 104
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2692
        i32.const 78
        i32.const 27
        call 6
        unreachable
      end
      local.get 104
      local.set 105
      i64.const 2
      local.set 106
      i64.const 0
      local.set 107
      local.get 105
      i64.extend_i32_u
      local.set 108
      local.get 108
      i64.const 4294967295
      i64.and
      local.get 107
      i64.const 8
      i64.mul
      i64.add
      local.tee 109
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2770
        i32.const 78
        i32.const 28
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 109
      i64.or
      local.set 110
      local.get 110
      i32.wrap_i64
      i64.load align=1
      i64.const 1
      i64.add
      local.set 111
      local.get 110
      local.get 111
      local.set 112
      i32.wrap_i64
      local.get 112
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 113
      i64.const 2
      local.set 114
      i64.const 0
      local.set 115
      local.get 113
      i64.extend_i32_u
      local.set 116
      local.get 116
      i64.const 4294967295
      i64.and
      local.get 115
      i64.const 8
      i64.mul
      i64.add
      local.tee 117
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2848
        i32.const 78
        i32.const 28
        call 6
        unreachable
      end
      local.get 116
      i64.const -4294967296
      i64.and
      local.get 117
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 31
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2926
        i32.const 78
        i32.const 28
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i32.const 1
      call $optionalref.4
      local.set 3
      local.get 3
      local.get 0
      i32.const 0
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3004
        i32.const 78
        i32.const 29
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i32.const 0
      call $optionalref.4
      local.set 3
      local.get 3
      i32.const 0
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3082
        i32.const 78
        i32.const 30
        call 6
        unreachable
      end
      local.get 0
      i32.const 32
      i32.add
      call $limitedref.5
      local.tee 118
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3160
        i32.const 78
        i32.const 6
        call 6
        unreachable
      end
      local.get 118
      local.set 119
      i64.const 52
      local.set 120
      local.get 119
      i64.load8_u
      local.set 121
      local.get 121
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 3238
        i32.const 78
        i32.const 31
        call 6
        unreachable
      end
      local.get 119
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 123
      local.get 123
      i64.const 4294967295
      i64.and
      local.get 121
      i64.const 8
      i64.mul
      i64.add
      local.tee 124
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3316
        i32.const 78
        i32.const 31
        call 6
        unreachable
      end
      local.get 123
      i64.const -4294967296
      i64.and
      local.get 124
      i64.or
      local.tee 125
      local.get 120
      local.set 126
      i32.wrap_i64
      local.get 126
      i64.store align=1
      local.get 119
      local.get 121
      i64.const 1
      i64.add
      i64.store8
      local.get 125
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 32
      i32.add
      local.set 127
      local.get 127
      i64.load8_u
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3394
        i32.const 78
        i32.const 31
        call 6
        unreachable
      end
      local.get 0
      i32.const 32
      i32.add
      local.set 128
      local.get 128
      i64.load8_u
      local.set 129
      i64.const 2
      local.set 130
      local.get 128
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 131
      local.get 131
      i64.const 4294967295
      i64.and
      local.get 130
      i64.const 8
      i64.mul
      i64.add
      local.tee 132
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3472
        i32.const 78
        i32.const 31
        call 6
        unreachable
      end
      local.get 131
      i64.const -4294967296
      i64.and
      local.get 132
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 52
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3550
        i32.const 78
        i32.const 31
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      call $invoke.6
      local.get 0
      i32.const 16
      i32.add
      local.set 133
      i64.const 2
      local.set 134
      i64.const 1
      local.set 135
      local.get 133
      i64.extend_i32_u
      local.set 136
      local.get 136
      i64.const 4294967295
      i64.and
      local.get 135
      i64.const 8
      i64.mul
      i64.add
      local.tee 137
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3628
        i32.const 78
        i32.const 33
        call 6
        unreachable
      end
      local.get 136
      i64.const -4294967296
      i64.and
      local.get 137
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 43
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3706
        i32.const 78
        i32.const 33
        call 6
        unreachable
      end
      i32.const 24
      i64.load align=1
      i32.wrap_i64
      local.tee 138
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3784
        i32.const 78
        i32.const 3
        call 6
        unreachable
      end
      local.get 138
      local.set 139
      i64.const 2
      local.set 140
      i64.const 0
      local.set 141
      local.get 139
      i64.extend_i32_u
      local.set 142
      local.get 142
      i64.const 4294967295
      i64.and
      local.get 141
      i64.const 8
      i64.mul
      i64.add
      local.tee 143
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3862
        i32.const 78
        i32.const 34
        call 6
        unreachable
      end
      local.get 142
      i64.const -4294967296
      i64.and
      local.get 143
      i64.or
      local.set 144
      local.get 144
      i32.wrap_i64
      i64.load align=1
      i64.const 4
      i64.add
      local.set 145
      local.get 144
      local.get 145
      local.set 146
      i32.wrap_i64
      local.get 146
      i64.store align=1
      i32.const 8
      local.set 147
      i32.const 32
      local.get 147
      i64.extend_i32_u
      i64.store align=1
      i32.const 32
      i64.load align=1
      i32.wrap_i64
      if ;; label = @2
        i32.const 32
        i64.load align=1
        i32.wrap_i64
        local.tee 148
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 3940
          i32.const 78
          i32.const 4
          call 6
          unreachable
        end
        local.get 148
        local.set 149
        i64.const 2
        local.set 150
        i64.const 0
        local.set 151
        local.get 149
        i64.extend_i32_u
        local.set 152
        local.get 152
        i64.const 4294967295
        i64.and
        local.get 151
        i64.const 8
        i64.mul
        i64.add
        local.tee 153
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4018
          i32.const 78
          i32.const 35
          call 6
          unreachable
        end
        local.get 152
        i64.const -4294967296
        i64.and
        local.get 153
        i64.or
        i32.wrap_i64
        i64.load align=1
        i64.const 5
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 4096
          i32.const 78
          i32.const 35
          call 6
          unreachable
        end
      end
      i32.const 24
      i64.load align=1
      i32.wrap_i64
      i32.const 8
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4174
        i32.const 78
        i32.const 36
        call 6
        unreachable
      end
      local.get 0
      i32.const 197
      i32.add
      local.set 154
      local.get 154
      i32.const 0
      i32.add
      i64.const 65
      i64.store8
      local.get 154
      i32.const 1
      i32.add
      i64.const 66
      i64.store8
      local.get 154
      i32.const 2
      i32.add
      i64.const 67
      i64.store8
      local.get 0
      i32.const 197
      i32.add
      local.set 155
      i64.const 3
      local.set 156
      i64.const 0
      local.set 157
      local.get 155
      i64.extend_i32_u
      local.set 158
      local.get 158
      i64.const 4294967295
      i64.and
      local.get 157
      i64.const 1
      i64.mul
      i64.add
      local.tee 159
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4252
        i32.const 78
        i32.const 38
        call 6
        unreachable
      end
      local.get 158
      i64.const -4294967296
      i64.and
      local.get 159
      i64.or
      local.set 160
      local.get 160
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 160
      i32.wrap_i64
      local.get 156
      i32.wrap_i64
      call 10
      local.set 161
      local.get 0
      i32.const 197
      i32.add
      call $change.7
      local.set 162
      local.get 0
      i32.const 197
      i32.add
      local.set 163
      i64.const 3
      local.set 164
      i64.const 0
      local.set 165
      local.get 163
      i64.extend_i32_u
      local.set 166
      local.get 166
      i64.const 4294967295
      i64.and
      local.get 165
      i64.const 1
      i64.mul
      i64.add
      local.tee 167
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4330
        i32.const 78
        i32.const 38
        call 6
        unreachable
      end
      local.get 166
      i64.const -4294967296
      i64.and
      local.get 167
      i64.or
      local.set 168
      local.get 168
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 168
      i32.wrap_i64
      local.get 164
      i32.wrap_i64
      call 10
      local.set 169
      call 0
      local.set 170
      local.get 170
      i32.const 4408
      i32.const 6
      call 4
      local.get 170
      local.get 161
      call 11
      local.get 170
      i32.const 4414
      i32.const 1
      call 4
      local.get 170
      local.get 162
      i32.const 0
      call 1
      local.get 170
      i32.const 4415
      i32.const 1
      call 4
      local.get 170
      local.get 169
      call 11
      local.get 170
      call 5
      i32.const 0
      local.set 4
      local.get 4
      local.set 171
      i32.const 0
      local.set 172
      local.get 172
      local.get 171
      i32.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 172
      else
        local.get 171
        local.set 173
      end
      local.get 172
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 4416
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 174
        i64.const 0
        local.set 175
        local.get 173
        i64.extend_i32_u
        local.set 176
        local.get 176
        i64.const 4294967295
        i64.and
        local.get 175
        i64.const 1
        i64.mul
        i64.add
        local.tee 177
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4420
          i32.const 78
          i32.const 39
          call 6
          unreachable
        end
        local.get 176
        i64.const -4294967296
        i64.and
        local.get 177
        i64.or
        local.set 178
        local.get 178
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 178
        i32.wrap_i64
        local.get 174
        i32.wrap_i64
        call 10
      end
      local.set 179
      call 0
      local.set 180
      local.get 180
      i32.const 4498
      i32.const 9
      call 4
      local.get 180
      local.get 179
      call 11
      local.get 180
      call 5
      local.get 0
      i32.const 197
      i32.add
      local.set 4
      local.get 4
      local.tee 181
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4507
        i32.const 78
        i32.const 40
        call 6
        unreachable
      end
      local.get 181
      local.set 182
      i64.const 3
      local.set 183
      i64.const 0
      local.set 184
      local.get 182
      i64.extend_i32_u
      local.set 185
      local.get 185
      i64.const 4294967295
      i64.and
      local.get 184
      i64.const 1
      i64.mul
      i64.add
      local.tee 186
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4585
        i32.const 78
        i32.const 40
        call 6
        unreachable
      end
      local.get 185
      i64.const -4294967296
      i64.and
      local.get 186
      i64.or
      local.set 187
      local.get 187
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 187
      i32.wrap_i64
      local.get 183
      i32.wrap_i64
      call 10
      local.set 188
      call 0
      local.set 189
      local.get 189
      i32.const 4663
      i32.const 6
      call 4
      local.get 189
      local.get 188
      call 11
      local.get 189
      call 5
      call 0
      local.set 190
      local.get 190
      i32.const 4669
      i32.const 6
      call 4
      local.get 190
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $fixedref.1 (;15;) (type 10) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $inlineref.2 (;16;) (type 10) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $choose.3 (;17;) (type 9) (param i32 i32 i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 2
      if ;; label = @2
        local.get 0
        local.set 4
        br 1 (;@1;)
      end
      local.get 1
      local.set 4
      br 0 (;@1;)
    end
    local.get 4
  )
  (func $optionalref.4 (;18;) (type 12) (param i32 i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 1
      if ;; label = @2
        local.get 0
        local.set 3
        br 1 (;@1;)
      end
      i32.const 0
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $limitedref.5 (;19;) (type 10) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $invoke.6 (;20;) (type 5) (param i32)
    (local i32 i32 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.tee 3
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4675
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 2
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      i64.extend_i32_u
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 8
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4753
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 31
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4831
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 2
      local.tee 9
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4909
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 9
      local.set 10
      i64.const 2
      local.set 11
      i64.const 1
      local.set 12
      local.get 10
      i64.extend_i32_u
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4987
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 40
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5065
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 2
      local.tee 15
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5143
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 15
      local.set 16
      i64.const 2
      local.set 17
      i64.const 1
      local.set 18
      local.get 16
      i64.extend_i32_u
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5221
        i32.const 78
        i32.const 32
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load align=1
      i64.const 3
      i64.add
      local.set 22
      local.get 21
      local.get 22
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store align=1
    end
  )
  (func $change.7 (;21;) (type 13) (param i32) (result i64)
    (local i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5299
        i32.const 78
        i32.const 13
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 3
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      i64.extend_i32_u
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 1
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5377
        i32.const 78
        i32.const 13
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      i64.const 88
      local.set 10
      local.get 9
      local.get 10
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store8
      i64.const 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;22;) (type 11)
    (local i32 i32 i32 i32)
    i32.const 8
    local.set 1
    local.get 1
    i32.const 0
    i32.add
    i64.const 1
    i64.store align=1
    local.get 1
    i32.const 8
    i32.add
    i64.const 2
    i64.store align=1
    i32.const 8
    local.set 2
    i32.const 24
    local.get 2
    i64.extend_i32_u
    i64.store align=1
    i32.const 0
    local.set 3
    i32.const 32
    local.get 3
    i64.extend_i32_u
    i64.store align=1
  )
  (func $goose.start (;23;) (type 11)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 24) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goosebytes=||null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goosebytes=ABI=ok/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_thin.goose")
)
