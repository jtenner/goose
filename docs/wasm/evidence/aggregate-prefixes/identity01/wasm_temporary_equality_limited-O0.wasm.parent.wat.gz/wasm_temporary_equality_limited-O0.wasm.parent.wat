(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1472)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 85
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 93
        i32.const 85
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i32.const 9
      call $goose.reserve_frame
      local.set 2
      local.get 2
      local.set 3
      i64.const 0
      local.set 4
      local.get 4
      local.get 3
      call $make.1
      local.get 2
      i64.load8_u
      local.set 5
      i32.const 9
      call $goose.reserve_frame
      local.set 6
      local.get 6
      local.set 7
      i64.const 0
      local.set 8
      local.get 8
      local.get 7
      call $make.1
      i32.const 0
      local.set 9
      local.get 5
      local.get 6
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 9
        i64.const 0
        local.set 10
        block ;; label = @3
          loop ;; label = @4
            local.get 10
            local.get 5
            i64.ge_u
            br_if 1 (;@3;)
            local.get 2
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 11
            local.get 11
            i64.const 4294967295
            i64.and
            local.get 10
            i64.const 2
            i64.mul
            i64.add
            local.tee 12
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 178
              i32.const 85
              i32.const 2
              call 6
              unreachable
            end
            local.get 11
            i64.const -4294967296
            i64.and
            local.get 12
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            local.get 6
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 13
            local.get 13
            i64.const 4294967295
            i64.and
            local.get 10
            i64.const 2
            i64.mul
            i64.add
            local.tee 14
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 263
              i32.const 85
              i32.const 2
              call 6
              unreachable
            end
            local.get 13
            i64.const -4294967296
            i64.and
            local.get 14
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 9
              br 2 (;@3;)
            end
            local.get 10
            i64.const 1
            i64.add
            local.set 10
            br 0 (;@4;)
          end
        end
      end
      local.get 9
      local.set 1
      local.get 6
      global.set 0
      local.get 2
      global.set 0
      local.get 1
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 348
        i32.const 85
        i32.const 2
        call 6
        unreachable
      end
      i32.const 9
      call $goose.reserve_frame
      local.set 16
      local.get 16
      local.set 17
      i64.const 1
      local.set 18
      local.get 18
      local.get 17
      call $make.1
      local.get 16
      i64.load8_u
      local.set 19
      i32.const 9
      call $goose.reserve_frame
      local.set 20
      local.get 20
      local.set 21
      i64.const 2
      local.set 22
      local.get 22
      local.get 21
      call $make.1
      i32.const 0
      local.set 23
      local.get 19
      local.get 20
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 23
        i64.const 0
        local.set 24
        block ;; label = @3
          loop ;; label = @4
            local.get 24
            local.get 19
            i64.ge_u
            br_if 1 (;@3;)
            local.get 16
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 25
            local.get 25
            i64.const 4294967295
            i64.and
            local.get 24
            i64.const 2
            i64.mul
            i64.add
            local.tee 26
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 433
              i32.const 85
              i32.const 2
              call 6
              unreachable
            end
            local.get 25
            i64.const -4294967296
            i64.and
            local.get 26
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            local.get 20
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 27
            local.get 27
            i64.const 4294967295
            i64.and
            local.get 24
            i64.const 2
            i64.mul
            i64.add
            local.tee 28
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 518
              i32.const 85
              i32.const 2
              call 6
              unreachable
            end
            local.get 27
            i64.const -4294967296
            i64.and
            local.get 28
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 23
              br 2 (;@3;)
            end
            local.get 24
            i64.const 1
            i64.add
            local.set 24
            br 0 (;@4;)
          end
        end
      end
      local.get 23
      i32.eqz
      local.set 15
      local.get 20
      global.set 0
      local.get 16
      global.set 0
      local.get 15
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 603
        i32.const 85
        i32.const 2
        call 6
        unreachable
      end
      i32.const 9
      call $goose.reserve_frame
      local.set 30
      local.get 30
      local.set 31
      i64.const 2
      local.set 32
      local.get 32
      local.get 31
      call $make.1
      local.get 30
      i64.load8_u
      local.set 33
      i32.const 9
      call $goose.reserve_frame
      local.set 34
      local.get 34
      local.set 35
      i64.const 2
      local.set 36
      local.get 36
      local.get 35
      call $make.1
      i32.const 0
      local.set 37
      local.get 33
      local.get 34
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 37
        i64.const 0
        local.set 38
        block ;; label = @3
          loop ;; label = @4
            local.get 38
            local.get 33
            i64.ge_u
            br_if 1 (;@3;)
            local.get 30
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 39
            local.get 39
            i64.const 4294967295
            i64.and
            local.get 38
            i64.const 2
            i64.mul
            i64.add
            local.tee 40
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 688
              i32.const 85
              i32.const 2
              call 6
              unreachable
            end
            local.get 39
            i64.const -4294967296
            i64.and
            local.get 40
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            local.get 34
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 41
            local.get 41
            i64.const 4294967295
            i64.and
            local.get 38
            i64.const 2
            i64.mul
            i64.add
            local.tee 42
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 773
              i32.const 85
              i32.const 2
              call 6
              unreachable
            end
            local.get 41
            i64.const -4294967296
            i64.and
            local.get 42
            i64.or
            i32.wrap_i64
            i64.load16_u align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 37
              br 2 (;@3;)
            end
            local.get 38
            i64.const 1
            i64.add
            local.set 38
            br 0 (;@4;)
          end
        end
      end
      local.get 37
      local.set 29
      local.get 34
      global.set 0
      local.get 30
      global.set 0
      local.get 29
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 858
        i32.const 85
        i32.const 2
        call 6
        unreachable
      end
      call 0
      local.set 43
      local.get 43
      i32.const 943
      i32.const 7
      call 4
      local.get 43
      call 5
    end
  )
  (func $make.1 (;12;) (type 11) (param i64 i32)
    (local i32 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      i64.const 0
      i64.eq
      if ;; label = @2
        local.get 1
        i64.const 0
        i64.store8
        br 1 (;@1;)
      end
      local.get 0
      i64.const 1
      i64.eq
      if ;; label = @2
        local.get 1
        i64.const 0
        i64.store8
        i64.const 7
        local.set 3
        local.get 1
        i64.load8_u
        local.set 4
        local.get 4
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 950
          i32.const 85
          i32.const 1
          call 6
          unreachable
        end
        local.get 1
        i32.const 1
        i32.add
        i64.extend_i32_u
        local.set 6
        local.get 6
        i64.const 4294967295
        i64.and
        local.get 4
        i64.const 2
        i64.mul
        i64.add
        local.tee 7
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1035
          i32.const 85
          i32.const 1
          call 6
          unreachable
        end
        local.get 6
        i64.const -4294967296
        i64.and
        local.get 7
        i64.or
        local.set 5
        local.get 5
        i32.wrap_i64
        local.get 3
        i64.store16 align=1
        local.get 1
        local.get 4
        i64.const 1
        i64.add
        i64.store8
        br 1 (;@1;)
      end
      local.get 1
      i64.const 0
      i64.store8
      i64.const 7
      local.set 3
      local.get 1
      i64.load8_u
      local.set 4
      local.get 4
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1120
        i32.const 85
        i32.const 1
        call 6
        unreachable
      end
      local.get 1
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 2
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1205
        i32.const 85
        i32.const 1
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 5
      local.get 5
      i32.wrap_i64
      local.get 3
      i64.store16 align=1
      local.get 1
      local.get 4
      i64.const 1
      i64.add
      i64.store8
      i64.const 8
      local.set 3
      local.get 1
      i64.load8_u
      local.set 4
      local.get 4
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1290
        i32.const 85
        i32.const 1
        call 6
        unreachable
      end
      local.get 1
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 2
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1375
        i32.const 85
        i32.const 1
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 5
      local.get 5
      i32.wrap_i64
      local.get 3
      i64.store16 align=1
      local.get 1
      local.get 4
      i64.const 1
      i64.add
      i64.store8
      br 0 (;@1;)
    end
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.gooselimited/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_temporary_equality_limited.goose")
)
