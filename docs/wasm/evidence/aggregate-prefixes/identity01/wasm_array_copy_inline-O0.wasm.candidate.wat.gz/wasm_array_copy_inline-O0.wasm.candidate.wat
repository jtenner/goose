(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 864)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 76
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 84
        i32.const 76
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i32)
    i32.const 29
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 2
      local.get 2
      i64.extend_i32_u
      local.set 1
      local.get 1
      i32.wrap_i64
      i32.const 160
      i32.const 3
      memory.copy
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      i32.const 3
      local.set 4
      local.get 3
      i64.extend_i32_u
      local.set 5
      local.get 0
      i32.const 3
      i32.add
      i64.extend_i32_u
      local.set 6
      local.get 6
      i32.wrap_i64
      local.get 5
      i32.wrap_i64
      local.get 4
      memory.copy
      local.get 0
      i32.const 3
      i32.add
      local.set 7
      i64.const 3
      local.set 8
      i64.const 0
      local.set 9
      local.get 7
      i64.extend_i32_u
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      local.get 9
      i64.const 1
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 163
        i32.const 76
        i32.const 3
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 12
      i64.const 90
      local.set 13
      local.get 12
      local.get 13
      local.set 14
      i32.wrap_i64
      local.get 14
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      call $echo.1
      local.tee 15
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 239
        i32.const 76
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      local.set 16
      i32.const 3
      local.set 17
      local.get 16
      i64.extend_i32_u
      local.set 18
      local.get 0
      i32.const 6
      i32.add
      i64.extend_i32_u
      local.set 19
      local.get 19
      i32.wrap_i64
      local.get 18
      i32.wrap_i64
      local.get 17
      memory.copy
      local.get 0
      i32.const 9
      i32.add
      local.set 21
      local.get 21
      i64.const 2
      i64.store8
      local.get 21
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 20
      local.get 20
      i32.wrap_i64
      i32.const 315
      i32.const 2
      memory.copy
      local.get 21
      i32.const 3
      i32.add
      i32.const 0
      i32.const 6
      memory.fill
      local.get 0
      i32.const 9
      i32.add
      local.set 22
      i32.const 9
      local.set 23
      local.get 22
      i64.extend_i32_u
      local.set 24
      local.get 0
      i32.const 18
      i32.add
      i64.extend_i32_u
      local.set 25
      local.get 25
      i32.wrap_i64
      local.get 24
      i32.wrap_i64
      local.get 23
      memory.copy
      local.get 0
      i32.const 18
      i32.add
      local.set 26
      i64.const 33
      local.set 27
      local.get 26
      i64.load8_u
      local.set 28
      local.get 28
      i64.const 8
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 317
        i32.const 76
        i32.const 5
        call 6
        unreachable
      end
      local.get 26
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 30
      local.get 30
      i64.const 4294967295
      i64.and
      local.get 28
      i64.const 1
      i64.mul
      i64.add
      local.tee 31
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 393
        i32.const 76
        i32.const 5
        call 6
        unreachable
      end
      local.get 30
      i64.const -4294967296
      i64.and
      local.get 31
      i64.or
      local.tee 32
      local.get 27
      local.set 33
      i32.wrap_i64
      local.get 33
      i64.store8
      local.get 26
      local.get 28
      i64.const 1
      i64.add
      i64.store8
      local.get 32
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 27
      i32.add
      local.set 34
      local.get 0
      i32.const 27
      i32.add
      local.set 35
      i32.const 0
      local.set 36
      local.get 35
      i64.extend_i32_u
      local.set 37
      local.get 0
      i32.const 28
      i32.add
      i64.extend_i32_u
      local.set 38
      local.get 38
      i32.wrap_i64
      local.get 37
      i32.wrap_i64
      local.get 36
      memory.copy
      local.get 0
      i32.const 0
      i32.add
      local.set 39
      i64.const 3
      local.set 40
      i64.const 0
      local.set 41
      local.get 39
      i64.extend_i32_u
      local.set 42
      local.get 42
      i64.const 4294967295
      i64.and
      local.get 41
      i64.const 1
      i64.mul
      i64.add
      local.tee 43
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 469
        i32.const 76
        i32.const 7
        call 6
        unreachable
      end
      local.get 42
      i64.const -4294967296
      i64.and
      local.get 43
      i64.or
      local.set 44
      local.get 44
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 44
      i32.wrap_i64
      local.get 40
      i32.wrap_i64
      call 10
      local.set 45
      local.get 0
      i32.const 3
      i32.add
      local.set 46
      i64.const 3
      local.set 47
      i64.const 0
      local.set 48
      local.get 46
      i64.extend_i32_u
      local.set 49
      local.get 49
      i64.const 4294967295
      i64.and
      local.get 48
      i64.const 1
      i64.mul
      i64.add
      local.tee 50
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 545
        i32.const 76
        i32.const 7
        call 6
        unreachable
      end
      local.get 49
      i64.const -4294967296
      i64.and
      local.get 50
      i64.or
      local.set 51
      local.get 51
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 51
      i32.wrap_i64
      local.get 47
      i32.wrap_i64
      call 10
      local.set 52
      local.get 0
      i32.const 6
      i32.add
      local.set 53
      i64.const 3
      local.set 54
      i64.const 0
      local.set 55
      local.get 53
      i64.extend_i32_u
      local.set 56
      local.get 56
      i64.const 4294967295
      i64.and
      local.get 55
      i64.const 1
      i64.mul
      i64.add
      local.tee 57
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 621
        i32.const 76
        i32.const 7
        call 6
        unreachable
      end
      local.get 56
      i64.const -4294967296
      i64.and
      local.get 57
      i64.or
      local.set 58
      local.get 58
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 58
      i32.wrap_i64
      local.get 54
      i32.wrap_i64
      call 10
      local.set 59
      local.get 0
      i32.const 9
      i32.add
      local.set 60
      local.get 60
      i64.load8_u
      local.set 61
      i64.const 0
      local.set 62
      local.get 60
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 63
      local.get 63
      i64.const 4294967295
      i64.and
      local.get 62
      i64.const 1
      i64.mul
      i64.add
      local.tee 64
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 697
        i32.const 76
        i32.const 7
        call 6
        unreachable
      end
      local.get 63
      i64.const -4294967296
      i64.and
      local.get 64
      i64.or
      local.set 65
      local.get 65
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 65
      i32.wrap_i64
      local.get 61
      i32.wrap_i64
      call 10
      local.set 66
      local.get 0
      i32.const 18
      i32.add
      local.set 67
      local.get 67
      i64.load8_u
      local.set 68
      i64.const 0
      local.set 69
      local.get 67
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 70
      local.get 70
      i64.const 4294967295
      i64.and
      local.get 69
      i64.const 1
      i64.mul
      i64.add
      local.tee 71
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 773
        i32.const 76
        i32.const 7
        call 6
        unreachable
      end
      local.get 70
      i64.const -4294967296
      i64.and
      local.get 71
      i64.or
      local.set 72
      local.get 72
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 72
      i32.wrap_i64
      local.get 68
      i32.wrap_i64
      call 10
      local.set 73
      i64.const 0
      local.set 74
      call 0
      local.set 75
      local.get 75
      local.get 45
      call 11
      local.get 75
      i32.const 849
      i32.const 1
      call 4
      local.get 75
      local.get 52
      call 11
      local.get 75
      i32.const 850
      i32.const 1
      call 4
      local.get 75
      local.get 59
      call 11
      local.get 75
      i32.const 851
      i32.const 1
      call 4
      local.get 75
      local.get 66
      call 11
      local.get 75
      i32.const 852
      i32.const 1
      call 4
      local.get 75
      local.get 73
      call 11
      local.get 75
      i32.const 853
      i32.const 1
      call 4
      local.get 75
      local.get 74
      i32.const 0
      call 1
      local.get 75
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $echo.1 (;15;) (type 10) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;16;) (type 11)
    (local i32)
  )
  (func $goose.start (;17;) (type 11)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goosea\00b/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goosehi/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_copy_inline.goose,,,,,")
)
