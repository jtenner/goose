(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 2864)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 83
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 91
        i32.const 83
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i32)
    i32.const 41
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 9
      local.get 9
      i32.const 0
      i32.add
      i64.const 11
      i64.store align=1
      local.get 9
      i32.const 8
      i32.add
      i64.const 22
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 10
      local.get 10
      i64.const 0
      i64.store8
      i64.const 33
      local.set 11
      local.get 10
      i64.load8_u
      local.set 12
      local.get 12
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 174
        i32.const 83
        i32.const 9
        call 6
        unreachable
      end
      local.get 10
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 8
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 257
        i32.const 83
        i32.const 9
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.tee 16
      local.get 11
      local.set 17
      i32.wrap_i64
      local.get 17
      i64.store align=1
      local.get 10
      local.get 12
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      call $relayFixed.1
      local.set 1
      local.get 1
      local.get 0
      i32.const 0
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 340
        i32.const 83
        i32.const 11
        call 6
        unreachable
      end
      local.get 1
      local.tee 18
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 423
        i32.const 83
        i32.const 10
        call 6
        unreachable
      end
      local.get 18
      local.set 19
      i64.const 2
      local.set 20
      i64.const 0
      local.set 21
      local.get 19
      i64.extend_i32_u
      local.set 22
      local.get 22
      i64.const 4294967295
      i64.and
      local.get 21
      i64.const 8
      i64.mul
      i64.add
      local.tee 23
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 506
        i32.const 83
        i32.const 11
        call 6
        unreachable
      end
      local.get 22
      i64.const -4294967296
      i64.and
      local.get 23
      i64.or
      local.set 24
      local.get 24
      i32.wrap_i64
      i64.load align=1
      i64.const 4
      i64.add
      local.set 25
      local.get 24
      local.get 25
      local.set 26
      i32.wrap_i64
      local.get 26
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 27
      i64.const 2
      local.set 28
      i64.const 0
      local.set 29
      local.get 27
      i64.extend_i32_u
      local.set 30
      local.get 30
      i64.const 4294967295
      i64.and
      local.get 29
      i64.const 8
      i64.mul
      i64.add
      local.tee 31
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 589
        i32.const 83
        i32.const 11
        call 6
        unreachable
      end
      local.get 30
      i64.const -4294967296
      i64.and
      local.get 31
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 15
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 672
        i32.const 83
        i32.const 11
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      call $relayLimited.3
      local.set 2
      local.get 2
      local.get 0
      i32.const 16
      i32.add
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 755
        i32.const 83
        i32.const 13
        call 6
        unreachable
      end
      local.get 2
      local.tee 32
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 838
        i32.const 83
        i32.const 12
        call 6
        unreachable
      end
      local.get 32
      local.set 33
      i64.const 44
      local.set 34
      local.get 33
      i64.load8_u
      local.set 35
      local.get 35
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 921
        i32.const 83
        i32.const 13
        call 6
        unreachable
      end
      local.get 33
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 37
      local.get 37
      i64.const 4294967295
      i64.and
      local.get 35
      i64.const 8
      i64.mul
      i64.add
      local.tee 38
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1004
        i32.const 83
        i32.const 13
        call 6
        unreachable
      end
      local.get 37
      i64.const -4294967296
      i64.and
      local.get 38
      i64.or
      local.tee 39
      local.get 34
      local.set 40
      i32.wrap_i64
      local.get 40
      i64.store align=1
      local.get 33
      local.get 35
      i64.const 1
      i64.add
      i64.store8
      local.get 39
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 0
      i32.const 16
      i32.add
      local.set 41
      local.get 41
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1087
        i32.const 83
        i32.const 14
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      local.set 42
      local.get 42
      i64.load8_u
      local.set 43
      i64.const 0
      local.set 44
      local.get 42
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 45
      local.get 45
      i64.const 4294967295
      i64.and
      local.get 44
      i64.const 8
      i64.mul
      i64.add
      local.tee 46
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1170
        i32.const 83
        i32.const 14
        call 6
        unreachable
      end
      local.get 45
      i64.const -4294967296
      i64.and
      local.get 46
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 33
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1253
        i32.const 83
        i32.const 14
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      local.set 47
      local.get 47
      i64.load8_u
      local.set 48
      i64.const 1
      local.set 49
      local.get 47
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 50
      local.get 50
      i64.const 4294967295
      i64.and
      local.get 49
      i64.const 8
      i64.mul
      i64.add
      local.tee 51
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1336
        i32.const 83
        i32.const 14
        call 6
        unreachable
      end
      local.get 50
      i64.const -4294967296
      i64.and
      local.get 51
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 44
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1419
        i32.const 83
        i32.const 14
        call 6
        unreachable
      end
      i32.const 0
      local.set 3
      local.get 3
      call $relayMaybeFixed.5
      local.set 4
      local.get 4
      i32.const 0
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1502
        i32.const 83
        i32.const 17
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      call $relayMaybeFixed.6
      local.set 5
      local.get 5
      if ;; label = @2
        local.get 5
        local.get 0
        i32.const 0
        i32.add
        i32.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1585
          i32.const 83
          i32.const 19
          call 6
          unreachable
        end
        local.get 5
        local.tee 52
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1668
          i32.const 83
          i32.const 18
          call 6
          unreachable
        end
        local.get 52
        local.set 53
        i64.const 2
        local.set 54
        i64.const 1
        local.set 55
        local.get 53
        i64.extend_i32_u
        local.set 56
        local.get 56
        i64.const 4294967295
        i64.and
        local.get 55
        i64.const 8
        i64.mul
        i64.add
        local.tee 57
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1751
          i32.const 83
          i32.const 19
          call 6
          unreachable
        end
        local.get 56
        i64.const -4294967296
        i64.and
        local.get 57
        i64.or
        local.set 58
        local.get 58
        i32.wrap_i64
        i64.load align=1
        i64.const 5
        i64.add
        local.set 59
        local.get 58
        local.get 59
        local.set 60
        i32.wrap_i64
        local.get 60
        i64.store align=1
      else
        i32.const 0
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1834
          i32.const 83
          i32.const 19
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 0
      i32.add
      local.set 61
      i64.const 2
      local.set 62
      i64.const 1
      local.set 63
      local.get 61
      i64.extend_i32_u
      local.set 64
      local.get 64
      i64.const 4294967295
      i64.and
      local.get 63
      i64.const 8
      i64.mul
      i64.add
      local.tee 65
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1917
        i32.const 83
        i32.const 20
        call 6
        unreachable
      end
      local.get 64
      i64.const -4294967296
      i64.and
      local.get 65
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 27
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2000
        i32.const 83
        i32.const 20
        call 6
        unreachable
      end
      i32.const 0
      local.set 6
      local.get 6
      call $relayMaybeLimited.7
      local.set 7
      local.get 7
      i32.const 0
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2083
        i32.const 83
        i32.const 23
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      local.set 6
      local.get 6
      call $relayMaybeLimited.8
      local.set 8
      local.get 8
      if ;; label = @2
        local.get 8
        local.get 0
        i32.const 16
        i32.add
        i32.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 2166
          i32.const 83
          i32.const 25
          call 6
          unreachable
        end
        local.get 8
        local.tee 66
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2249
          i32.const 83
          i32.const 25
          call 6
          unreachable
        end
        local.get 66
        local.set 67
        i64.const 55
        local.set 68
        local.get 67
        i64.load8_u
        local.set 69
        local.get 69
        i64.const 3
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 2332
          i32.const 83
          i32.const 25
          call 6
          unreachable
        end
        local.get 67
        i32.const 1
        i32.add
        i64.extend_i32_u
        local.set 71
        local.get 71
        i64.const 4294967295
        i64.and
        local.get 69
        i64.const 8
        i64.mul
        i64.add
        local.tee 72
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2415
          i32.const 83
          i32.const 25
          call 6
          unreachable
        end
        local.get 71
        i64.const -4294967296
        i64.and
        local.get 72
        i64.or
        local.tee 73
        local.get 68
        local.set 74
        i32.wrap_i64
        local.get 74
        i64.store align=1
        local.get 67
        local.get 69
        i64.const 1
        i64.add
        i64.store8
        local.get 73
        i32.wrap_i64
        i64.load align=1
        drop
      else
        i32.const 0
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 2498
          i32.const 83
          i32.const 25
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 16
      i32.add
      local.set 75
      local.get 75
      i64.load8_u
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2581
        i32.const 83
        i32.const 26
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      local.set 76
      local.get 76
      i64.load8_u
      local.set 77
      i64.const 2
      local.set 78
      local.get 76
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 79
      local.get 79
      i64.const 4294967295
      i64.and
      local.get 78
      i64.const 8
      i64.mul
      i64.add
      local.tee 80
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2664
        i32.const 83
        i32.const 26
        call 6
        unreachable
      end
      local.get 79
      i64.const -4294967296
      i64.and
      local.get 80
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 55
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2747
        i32.const 83
        i32.const 26
        call 6
        unreachable
      end
      call 0
      local.set 81
      local.get 81
      i32.const 2830
      i32.const 21
      call 4
      local.get 81
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $relayFixed.1 (;12;) (type 9) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      call $fixedIdentity.2
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $fixedIdentity.2 (;13;) (type 9) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $relayLimited.3 (;14;) (type 9) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      call $limitedIdentity.4
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $limitedIdentity.4 (;15;) (type 9) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $relayMaybeFixed.5 (;16;) (type 9) (param i32) (result i32)
    (local i32 i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $relayMaybeFixed.6 (;17;) (type 9) (param i32) (result i32)
    (local i32 i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $relayMaybeLimited.7 (;18;) (type 9) (param i32) (result i32)
    (local i32 i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $relayMaybeLimited.8 (;19;) (type 9) (param i32) (result i32)
    (local i32 i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $goose.init (;20;) (type 10)
    (local i32)
  )
  (func $goose.start (;21;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_thin.goosecallback-reference=ok")
)
