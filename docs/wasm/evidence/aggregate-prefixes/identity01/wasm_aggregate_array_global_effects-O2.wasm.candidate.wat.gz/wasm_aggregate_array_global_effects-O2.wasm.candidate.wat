(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 880)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 66
      i32.const 89
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 155
        i32.const 89
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.1 (;11;) (type 10)
    (local i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32)
    block ;; label = @1
      i32.const 33
      i64.load align=1
      local.set 1
      i32.const 41
      local.set 2
      local.get 2
      i64.load8_u
      local.set 3
      i64.const 0
      local.set 4
      local.get 4
      local.get 3
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 244
        i32.const 89
        i32.const 6
        call 6
        unreachable
      end
      local.get 2
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 8
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 333
        i32.const 89
        i32.const 6
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 7
      local.get 7
      i32.wrap_i64
      i64.load align=1
      local.set 8
      i32.const 41
      local.set 9
      local.get 9
      i64.load8_u
      local.set 10
      i64.const 1
      local.set 11
      local.get 11
      local.get 10
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 422
        i32.const 89
        i32.const 6
        call 6
        unreachable
      end
      local.get 9
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      local.get 11
      i64.const 8
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 511
        i32.const 89
        i32.const 6
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      local.set 14
      local.get 14
      i32.wrap_i64
      i64.load align=1
      local.set 15
      i32.const 41
      local.set 16
      local.get 16
      i64.load8_u
      local.set 17
      call 0
      local.set 18
      local.get 18
      i32.const 600
      i32.const 7
      call 4
      local.get 18
      local.get 1
      i32.const 0
      call 1
      local.get 18
      i32.const 607
      i32.const 1
      call 4
      local.get 18
      local.get 8
      i32.const 0
      call 1
      local.get 18
      i32.const 608
      i32.const 1
      call 4
      local.get 18
      local.get 15
      i32.const 0
      call 1
      local.get 18
      i32.const 609
      i32.const 1
      call 4
      local.get 18
      local.get 17
      i32.const 0
      call 1
      local.get 18
      call 5
    end
  )
  (func $goose.init (;12;) (type 10)
    (local i32 i32 i64 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64)
    i32.const 8
    local.set 1
    local.get 1
    i64.const 1
    i64.store8
    local.get 1
    i64.const 7
    i64.store offset=1 align=1
    local.get 1
    i32.const 9
    i32.add
    i32.const 0
    i32.const 16
    memory.fill
    i64.const 0
    local.set 2
    i32.const 33
    local.get 2
    i64.store align=1
    i32.const 41
    local.set 3
    local.get 3
    i64.const 2
    i64.store8
    local.get 3
    block ;; label = @1
      i32.const 33
      i64.load align=1
      i64.const 10
      i64.mul
      i32.const 8
      local.set 5
      local.get 5
      i64.load8_u
      i64.add
      local.set 6
      i32.const 33
      local.get 6
      i64.store align=1
      i32.const 8
      local.set 7
      local.get 7
      i64.load8_u
      local.set 8
      i64.const 0
      local.set 9
      local.get 9
      local.get 8
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 610
        i32.const 89
        i32.const 4
        call 6
        unreachable
      end
      local.get 7
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      local.get 9
      i64.const 8
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 699
        i32.const 89
        i32.const 4
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 12
      local.get 12
      i32.wrap_i64
      i64.load align=1
      local.set 4
      br 0 (;@1;)
    end
    local.get 4
    i64.store offset=1 align=1
    local.get 3
    block ;; label = @1
      i32.const 33
      i64.load align=1
      i64.const 10
      i64.mul
      i32.const 8
      local.set 14
      local.get 14
      i64.load8_u
      i64.add
      local.set 15
      i32.const 33
      local.get 15
      i64.store align=1
      i32.const 8
      local.set 16
      local.get 16
      i64.load8_u
      local.set 17
      i64.const 0
      local.set 18
      local.get 16
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 788
        i32.const 89
        i32.const 4
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load align=1
      local.set 13
      br 0 (;@1;)
    end
    local.get 13
    i64.store offset=9 align=1
    local.get 3
    i32.const 17
    i32.add
    i32.const 0
    i32.const 8
    memory.fill
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 33) "\00\00\00\00\00\00\00\00")
  (data (;2;) (i32.const 66) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.gooseglobal=,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_aggregate_array_global_effects.goose")
)
