(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1712)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 76
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 84
        i32.const 76
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32)
    i32.const 131593
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 0
      i32.const 1
      i32.add
      local.set 4
      local.get 0
      i32.const 0
      i32.add
      local.get 0
      i32.const 1
      i32.add
      call $zero.1
      local.get 0
      i32.const 2
      i32.add
      local.set 5
      local.get 5
      i64.const 0
      i64.store8
      local.get 0
      i32.const 258
      i32.add
      local.set 6
      local.get 6
      i64.const 0
      i64.store16 align=1
      i64.const 0
      local.set 7
      i64.const 255
      local.set 8
      block ;; label = @2
        loop ;; label = @3
          local.get 7
          local.get 8
          i64.ge_s
          br_if 1 (;@2;)
          local.get 7
          local.set 1
          block ;; label = @4
            local.get 0
            i32.const 2
            i32.add
            local.set 9
            local.get 1
            i64.const 255
            i64.and
            local.set 10
            local.get 9
            i64.load8_u
            local.set 11
            local.get 11
            i64.const 255
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 160
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 9
            i32.const 1
            i32.add
            i64.extend_i32_u
            local.set 13
            local.get 13
            i64.const 4294967295
            i64.and
            local.get 11
            i64.const 1
            i64.mul
            i64.add
            local.tee 14
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 236
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 13
            i64.const -4294967296
            i64.and
            local.get 14
            i64.or
            local.tee 15
            local.get 10
            local.set 16
            i32.wrap_i64
            local.get 16
            i64.store8
            local.get 9
            local.get 11
            i64.const 1
            i64.add
            i64.store8
            local.get 15
            i32.wrap_i64
            i64.load8_u
            drop
            local.get 0
            i32.const 258
            i32.add
            local.set 17
            local.get 1
            i64.const 255
            i64.and
            local.set 18
            local.get 17
            i64.load16_u align=1
            local.set 19
            local.get 19
            i64.const 256
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 312
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 17
            i32.const 2
            i32.add
            i64.extend_i32_u
            local.set 21
            local.get 21
            i64.const 4294967295
            i64.and
            local.get 19
            i64.const 1
            i64.mul
            i64.add
            local.tee 22
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 388
              i32.const 76
              i32.const 9
              call 6
              unreachable
            end
            local.get 21
            i64.const -4294967296
            i64.and
            local.get 22
            i64.or
            local.tee 23
            local.get 18
            local.set 24
            i32.wrap_i64
            local.get 24
            i64.store8
            local.get 17
            local.get 19
            i64.const 1
            i64.add
            i64.store16 align=1
            local.get 23
            i32.wrap_i64
            i64.load8_u
            drop
          end
          local.get 7
          i64.const 1
          i64.add
          local.set 7
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 258
      i32.add
      local.set 25
      i64.const 255
      local.set 26
      local.get 25
      i64.load16_u align=1
      local.set 27
      local.get 27
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 464
        i32.const 76
        i32.const 10
        call 6
        unreachable
      end
      local.get 25
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      local.get 27
      i64.const 1
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 540
        i32.const 76
        i32.const 10
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      local.tee 31
      local.get 26
      local.set 32
      i32.wrap_i64
      local.get 32
      i64.store8
      local.get 25
      local.get 27
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 31
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 2
      i32.add
      local.set 33
      local.get 33
      i64.load8_u
      local.set 34
      local.get 0
      i32.const 2
      i32.add
      local.set 35
      local.get 35
      i64.load8_u
      local.set 36
      i64.const 254
      local.set 37
      local.get 35
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 38
      local.get 38
      i64.const 4294967295
      i64.and
      local.get 37
      i64.const 1
      i64.mul
      i64.add
      local.tee 39
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 616
        i32.const 76
        i32.const 11
        call 6
        unreachable
      end
      local.get 38
      i64.const -4294967296
      i64.and
      local.get 39
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 40
      local.get 0
      i32.const 258
      i32.add
      local.set 41
      local.get 41
      i64.load16_u align=1
      local.set 42
      local.get 0
      i32.const 258
      i32.add
      local.set 43
      local.get 43
      i64.load16_u align=1
      local.set 44
      i64.const 255
      local.set 45
      local.get 43
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 46
      local.get 46
      i64.const 4294967295
      i64.and
      local.get 45
      i64.const 1
      i64.mul
      i64.add
      local.tee 47
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 692
        i32.const 76
        i32.const 11
        call 6
        unreachable
      end
      local.get 46
      i64.const -4294967296
      i64.and
      local.get 47
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 48
      call 0
      local.set 49
      local.get 49
      local.get 34
      i32.const 0
      call 1
      local.get 49
      i32.const 768
      i32.const 1
      call 4
      local.get 49
      local.get 40
      i32.const 1
      call 1
      local.get 49
      i32.const 769
      i32.const 1
      call 4
      local.get 49
      local.get 42
      i32.const 0
      call 1
      local.get 49
      i32.const 770
      i32.const 1
      call 4
      local.get 49
      local.get 48
      i32.const 1
      call 1
      local.get 49
      call 5
      local.get 0
      i32.const 516
      i32.add
      local.set 50
      local.get 50
      i64.const 0
      i64.store16 align=1
      local.get 0
      i32.const 66053
      i32.add
      local.set 51
      local.get 51
      i64.const 0
      i64.store32 align=1
      i64.const 0
      local.set 52
      i64.const 65535
      local.set 53
      block ;; label = @2
        loop ;; label = @3
          local.get 52
          local.get 53
          i64.ge_s
          br_if 1 (;@2;)
          local.get 52
          local.set 2
          block ;; label = @4
            local.get 0
            i32.const 516
            i32.add
            local.set 54
            local.get 2
            i64.const 255
            i64.and
            local.set 55
            local.get 54
            i64.load16_u align=1
            local.set 56
            local.get 56
            i64.const 65535
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 771
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 54
            i32.const 2
            i32.add
            i64.extend_i32_u
            local.set 58
            local.get 58
            i64.const 4294967295
            i64.and
            local.get 56
            i64.const 1
            i64.mul
            i64.add
            local.tee 59
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 847
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 58
            i64.const -4294967296
            i64.and
            local.get 59
            i64.or
            local.tee 60
            local.get 55
            local.set 61
            i32.wrap_i64
            local.get 61
            i64.store8
            local.get 54
            local.get 56
            i64.const 1
            i64.add
            i64.store16 align=1
            local.get 60
            i32.wrap_i64
            i64.load8_u
            drop
            local.get 0
            i32.const 66053
            i32.add
            local.set 62
            local.get 2
            i64.const 255
            i64.and
            local.set 63
            local.get 62
            i64.load32_u align=1
            local.set 64
            local.get 64
            i64.const 65536
            i64.ge_u
            if ;; label = @5
              i32.const 10
              i32.const 923
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 62
            i32.const 4
            i32.add
            i64.extend_i32_u
            local.set 66
            local.get 66
            i64.const 4294967295
            i64.and
            local.get 64
            i64.const 1
            i64.mul
            i64.add
            local.tee 67
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 999
              i32.const 76
              i32.const 13
              call 6
              unreachable
            end
            local.get 66
            i64.const -4294967296
            i64.and
            local.get 67
            i64.or
            local.tee 68
            local.get 63
            local.set 69
            i32.wrap_i64
            local.get 69
            i64.store8
            local.get 62
            local.get 64
            i64.const 1
            i64.add
            i64.store32 align=1
            local.get 68
            i32.wrap_i64
            i64.load8_u
            drop
          end
          local.get 52
          i64.const 1
          i64.add
          local.set 52
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 66053
      i32.add
      local.set 70
      i64.const 255
      local.set 71
      local.get 70
      i64.load32_u align=1
      local.set 72
      local.get 72
      i64.const 65536
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1075
        i32.const 76
        i32.const 14
        call 6
        unreachable
      end
      local.get 70
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 74
      local.get 74
      i64.const 4294967295
      i64.and
      local.get 72
      i64.const 1
      i64.mul
      i64.add
      local.tee 75
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1151
        i32.const 76
        i32.const 14
        call 6
        unreachable
      end
      local.get 74
      i64.const -4294967296
      i64.and
      local.get 75
      i64.or
      local.tee 76
      local.get 71
      local.set 77
      i32.wrap_i64
      local.get 77
      i64.store8
      local.get 70
      local.get 72
      i64.const 1
      i64.add
      i64.store32 align=1
      local.get 76
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 516
      i32.add
      local.set 78
      local.get 78
      i64.load16_u align=1
      local.set 79
      local.get 0
      i32.const 516
      i32.add
      local.set 80
      local.get 80
      i64.load16_u align=1
      local.set 81
      i64.const 65534
      local.set 82
      local.get 80
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 83
      local.get 83
      i64.const 4294967295
      i64.and
      local.get 82
      i64.const 1
      i64.mul
      i64.add
      local.tee 84
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1227
        i32.const 76
        i32.const 15
        call 6
        unreachable
      end
      local.get 83
      i64.const -4294967296
      i64.and
      local.get 84
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 85
      local.get 0
      i32.const 66053
      i32.add
      local.set 86
      local.get 86
      i64.load32_u align=1
      local.set 87
      local.get 0
      i32.const 66053
      i32.add
      local.set 88
      local.get 88
      i64.load32_u align=1
      local.set 89
      i64.const 65535
      local.set 90
      local.get 88
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 91
      local.get 91
      i64.const 4294967295
      i64.and
      local.get 90
      i64.const 1
      i64.mul
      i64.add
      local.tee 92
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1303
        i32.const 76
        i32.const 15
        call 6
        unreachable
      end
      local.get 91
      i64.const -4294967296
      i64.and
      local.get 92
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 93
      call 0
      local.set 94
      local.get 94
      local.get 79
      i32.const 0
      call 1
      local.get 94
      i32.const 1379
      i32.const 1
      call 4
      local.get 94
      local.get 85
      i32.const 1
      call 1
      local.get 94
      i32.const 1380
      i32.const 1
      call 4
      local.get 94
      local.get 87
      i32.const 0
      call 1
      local.get 94
      i32.const 1381
      i32.const 1
      call 4
      local.get 94
      local.get 93
      i32.const 1
      call 1
      local.get 94
      call 5
      local.get 0
      i32.const 258
      i32.add
      local.set 95
      local.get 95
      i64.load16_u align=1
      local.set 96
      local.get 96
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1382
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 96
      i64.const 1
      i64.sub
      local.set 96
      local.get 95
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 97
      local.get 97
      i64.const 4294967295
      i64.and
      local.get 96
      i64.const 1
      i64.mul
      i64.add
      local.tee 98
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1458
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 97
      i64.const -4294967296
      i64.and
      local.get 98
      i64.or
      local.set 99
      local.get 99
      i32.wrap_i64
      i64.load8_u
      local.set 100
      local.get 95
      local.get 96
      i64.store16 align=1
      local.get 100
      local.set 101
      local.get 0
      i32.const 258
      i32.add
      local.set 102
      local.get 102
      i64.load16_u align=1
      local.set 103
      local.get 0
      i32.const 66053
      i32.add
      local.set 104
      local.get 104
      i64.load32_u align=1
      local.set 105
      local.get 105
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1534
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 105
      i64.const 1
      i64.sub
      local.set 105
      local.get 104
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 106
      local.get 106
      i64.const 4294967295
      i64.and
      local.get 105
      i64.const 1
      i64.mul
      i64.add
      local.tee 107
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1610
        i32.const 76
        i32.const 16
        call 6
        unreachable
      end
      local.get 106
      i64.const -4294967296
      i64.and
      local.get 107
      i64.or
      local.set 108
      local.get 108
      i32.wrap_i64
      i64.load8_u
      local.set 109
      local.get 104
      local.get 105
      i64.store32 align=1
      local.get 109
      local.set 110
      local.get 0
      i32.const 66053
      i32.add
      local.set 111
      local.get 111
      i64.load32_u align=1
      local.set 112
      call 0
      local.set 113
      local.get 113
      local.get 101
      i32.const 1
      call 1
      local.get 113
      i32.const 1686
      i32.const 1
      call 4
      local.get 113
      local.get 103
      i32.const 0
      call 1
      local.get 113
      i32.const 1687
      i32.const 1
      call 4
      local.get 113
      local.get 110
      i32.const 1
      call 1
      local.get 113
      i32.const 1688
      i32.const 1
      call 4
      local.get 113
      local.get 112
      i32.const 0
      call 1
      local.get 113
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $zero.1 (;12;) (type 3) (param i32 i32)
    (local i32 i32 i32 i64 i64 i32)
    block ;; label = @1
      local.get 0
      local.get 1
      i32.ne
      local.set 3
      call 0
      local.set 4
      local.get 4
      i32.const 1689
      i32.const 9
      call 4
      local.get 4
      local.get 3
      call 3
      local.get 4
      call 5
      i64.const 0
      local.set 5
      i64.const 0
      local.set 6
      call 0
      local.set 7
      local.get 7
      i32.const 1698
      i32.const 5
      call 4
      local.get 7
      local.get 5
      i32.const 0
      call 1
      local.get 7
      i32.const 1703
      i32.const 1
      call 4
      local.get 7
      local.get 6
      i32.const 0
      call 1
      local.get 7
      call 5
    end
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_boundaries.goose,,,distinct=zero=,")
)
