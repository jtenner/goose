(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 2 65536)
  (global (;0;) (mut i32) i32.const 69344)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 65562
      i32.const 72
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 65634
        i32.const 72
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 i32 i32 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 f32 i64 i32 i64 i64 i64 f32 f32 i64 i32 i64 i64 i64 f32 i32 i64 i64 i32 i64 i64 i64 i64 f32 i32 i64 i64 i64 i64 f32 f32 i32 i32 f32 i64 i32 i64 i64 i64 f32 i32 i64 i64 i64 i64 f32 i32 i32 i64 i32 i32 i32 i64 i64 i32 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32)
    i32.const 1039
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i32.const 0
      i32.add
      i64.const 1
      i64.store16 align=1
      local.get 10
      i32.const 2
      i32.add
      i64.const 2
      i64.store16 align=1
      local.get 10
      i32.const 4
      i32.add
      i64.const 3
      i64.store16 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 11
      i64.const 3
      local.set 12
      i64.const 0
      local.set 13
      local.get 11
      i64.extend_i32_u
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      local.get 13
      i64.const 2
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 65706
        i32.const 72
        i32.const 9
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      i32.wrap_i64
      local.set 1
      block ;; label = @2
        local.get 0
        i32.const 0
        i32.add
        local.set 2
        local.get 2
        local.tee 16
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 65778
          i32.const 72
          i32.const 4
          call 6
          unreachable
        end
        local.get 16
        local.set 17
        i64.const 3
        local.set 18
        i64.const 1
        local.set 19
        local.get 17
        i64.extend_i32_u
        local.set 20
        local.get 20
        i64.const 4294967295
        i64.and
        local.get 19
        i64.const 2
        i64.mul
        i64.add
        local.tee 21
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 65850
          i32.const 72
          i32.const 4
          call 6
          unreachable
        end
        local.get 20
        i64.const -4294967296
        i64.and
        local.get 21
        i64.or
        local.set 22
        local.get 22
        i32.wrap_i64
        i64.load16_s align=1
        i64.const 5
        i64.add
        i64.extend16_s
        local.set 23
        local.get 22
        local.get 23
        local.set 24
        i32.wrap_i64
        local.get 24
        i64.store16 align=1
        local.get 2
        local.tee 25
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 65922
          i32.const 72
          i32.const 4
          call 6
          unreachable
        end
        local.get 25
        local.set 26
        i64.const 0
        local.set 27
        block ;; label = @3
          loop ;; label = @4
            local.get 27
            i64.const 3
            i64.ge_u
            br_if 1 (;@3;)
            local.get 26
            i64.extend_i32_u
            local.set 28
            local.get 28
            i64.const 4294967295
            i64.and
            local.get 27
            i64.const 2
            i64.mul
            i64.add
            local.tee 29
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 65994
              i32.const 72
              i32.const 4
              call 6
              unreachable
            end
            local.get 28
            i64.const -4294967296
            i64.and
            local.get 29
            i64.or
            i32.wrap_i64
            local.set 3
            block ;; label = @5
              local.get 3
              local.tee 30
              i32.eqz
              if ;; label = @6
                i32.const 4
                i32.const 66066
                i32.const 72
                i32.const 4
                call 6
                unreachable
              end
              local.get 30
              local.set 31
              local.get 31
              i64.load16_s align=1
              i64.const 1
              i64.add
              i64.extend16_s
              local.set 32
              local.get 31
              local.get 32
              i64.store16 align=1
            end
            local.get 27
            i64.const 1
            i64.add
            local.set 27
            br 0 (;@4;)
          end
        end
      end
      i64.const 3
      local.set 33
      local.get 0
      i32.const 0
      i32.add
      local.set 34
      i64.const 3
      local.set 35
      i64.const 0
      local.set 36
      local.get 34
      i64.extend_i32_u
      local.set 37
      local.get 37
      i64.const 4294967295
      i64.and
      local.get 36
      i64.const 2
      i64.mul
      i64.add
      local.tee 38
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66138
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 37
      i64.const -4294967296
      i64.and
      local.get 38
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 39
      local.get 0
      i32.const 0
      i32.add
      local.set 40
      i64.const 3
      local.set 41
      i64.const 1
      local.set 42
      local.get 40
      i64.extend_i32_u
      local.set 43
      local.get 43
      i64.const 4294967295
      i64.and
      local.get 42
      i64.const 2
      i64.mul
      i64.add
      local.tee 44
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66210
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 43
      i64.const -4294967296
      i64.and
      local.get 44
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 45
      local.get 0
      i32.const 0
      i32.add
      local.set 46
      i64.const 3
      local.set 47
      i64.const 2
      local.set 48
      local.get 46
      i64.extend_i32_u
      local.set 49
      local.get 49
      i64.const 4294967295
      i64.and
      local.get 48
      i64.const 2
      i64.mul
      i64.add
      local.tee 50
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66282
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 49
      i64.const -4294967296
      i64.and
      local.get 50
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 51
      local.get 1
      local.tee 52
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 66354
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 52
      i64.load16_s align=1
      local.set 53
      call 0
      local.set 54
      local.get 54
      local.get 33
      i32.const 0
      call 1
      local.get 54
      i32.const 66426
      i32.const 1
      call 4
      local.get 54
      local.get 39
      i32.const 0
      call 1
      local.get 54
      i32.const 66427
      i32.const 1
      call 4
      local.get 54
      local.get 45
      i32.const 0
      call 1
      local.get 54
      i32.const 66428
      i32.const 1
      call 4
      local.get 54
      local.get 51
      i32.const 0
      call 1
      local.get 54
      i32.const 66429
      i32.const 1
      call 4
      local.get 54
      local.get 53
      i32.const 0
      call 1
      local.get 54
      call 5
      local.get 1
      local.get 0
      i32.const 0
      i32.add
      local.set 55
      i64.const 3
      local.set 56
      i64.const 0
      local.set 57
      local.get 55
      i64.extend_i32_u
      local.set 58
      local.get 58
      i64.const 4294967295
      i64.and
      local.get 57
      i64.const 2
      i64.mul
      i64.add
      local.tee 59
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66430
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 58
      i64.const -4294967296
      i64.and
      local.get 59
      i64.or
      i32.wrap_i64
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 66502
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 0
      i32.const 6
      i32.add
      local.set 60
      local.get 60
      i64.const 0
      i64.store8
      i64.const 7
      local.set 61
      local.get 60
      i64.load8_u
      local.set 62
      local.get 62
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 66574
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 60
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 64
      local.get 64
      i64.const 4294967295
      i64.and
      local.get 62
      i64.const 1
      i64.mul
      i64.add
      local.tee 65
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66646
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 64
      i64.const -4294967296
      i64.and
      local.get 65
      i64.or
      local.tee 66
      local.get 61
      local.set 67
      i32.wrap_i64
      local.get 67
      i64.store8
      local.get 60
      local.get 62
      i64.const 1
      i64.add
      i64.store8
      i64.const 8
      local.set 68
      local.get 60
      i64.load8_u
      local.set 69
      local.get 69
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 66718
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 60
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 71
      local.get 71
      i64.const 4294967295
      i64.and
      local.get 69
      i64.const 1
      i64.mul
      i64.add
      local.tee 72
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66790
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 71
      i64.const -4294967296
      i64.and
      local.get 72
      i64.or
      local.tee 73
      local.get 68
      local.set 74
      i32.wrap_i64
      local.get 74
      i64.store8
      local.get 60
      local.get 69
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 6
      i32.add
      local.set 75
      local.get 75
      i64.load8_u
      local.set 76
      i64.const 0
      local.set 77
      local.get 75
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 78
      local.get 78
      i64.const 4294967295
      i64.and
      local.get 77
      i64.const 1
      i64.mul
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66862
        i32.const 72
        i32.const 14
        call 6
        unreachable
      end
      local.get 78
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      i32.wrap_i64
      local.set 4
      block ;; label = @2
        local.get 0
        i32.const 6
        i32.add
        local.set 5
        local.get 5
        local.tee 80
        i32.eqz
        if ;; label = @3
          i32.const 4
          i32.const 66934
          i32.const 72
          i32.const 5
          call 6
          unreachable
        end
        local.get 80
        local.set 81
        i64.const 9
        local.set 82
        local.get 81
        i64.load8_u
        local.set 83
        local.get 83
        i64.const 4
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 67006
          i32.const 72
          i32.const 5
          call 6
          unreachable
        end
        local.get 81
        i32.const 1
        i32.add
        i64.extend_i32_u
        local.set 85
        local.get 85
        i64.const 4294967295
        i64.and
        local.get 83
        i64.const 1
        i64.mul
        i64.add
        local.tee 86
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 67078
          i32.const 72
          i32.const 5
          call 6
          unreachable
        end
        local.get 85
        i64.const -4294967296
        i64.and
        local.get 86
        i64.or
        local.tee 87
        local.get 82
        local.set 88
        i32.wrap_i64
        local.get 88
        i64.store8
        local.get 81
        local.get 83
        i64.const 1
        i64.add
        i64.store8
        local.get 87
        i32.wrap_i64
        i64.load8_u
        drop
      end
      local.get 0
      i32.const 6
      i32.add
      local.set 89
      local.get 89
      i64.load8_u
      local.set 90
      i64.const 4
      local.set 91
      local.get 0
      i32.const 6
      i32.add
      local.set 92
      local.get 92
      i64.load8_u
      local.set 93
      i64.const 2
      local.set 94
      local.get 94
      local.get 93
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 67150
        i32.const 72
        i32.const 16
        call 6
        unreachable
      end
      local.get 92
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 95
      local.get 95
      i64.const 4294967295
      i64.and
      local.get 94
      i64.const 1
      i64.mul
      i64.add
      local.tee 96
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67222
        i32.const 72
        i32.const 16
        call 6
        unreachable
      end
      local.get 95
      i64.const -4294967296
      i64.and
      local.get 96
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 97
      local.get 4
      local.tee 98
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 67294
        i32.const 72
        i32.const 16
        call 6
        unreachable
      end
      local.get 98
      i64.load8_u
      local.set 99
      call 0
      local.set 100
      local.get 100
      local.get 90
      i32.const 0
      call 1
      local.get 100
      i32.const 67366
      i32.const 1
      call 4
      local.get 100
      local.get 91
      i32.const 0
      call 1
      local.get 100
      i32.const 67367
      i32.const 1
      call 4
      local.get 100
      local.get 97
      i32.const 1
      call 1
      local.get 100
      i32.const 67368
      i32.const 1
      call 4
      local.get 100
      local.get 99
      i32.const 1
      call 1
      local.get 100
      call 5
      local.get 0
      i32.const 6
      i32.add
      local.set 101
      local.get 101
      i64.load8_u
      local.set 102
      local.get 102
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 67369
        i32.const 72
        i32.const 17
        call 6
        unreachable
      end
      local.get 102
      i64.const 1
      i64.sub
      local.set 102
      local.get 101
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 103
      local.get 103
      i64.const 4294967295
      i64.and
      local.get 102
      i64.const 1
      i64.mul
      i64.add
      local.tee 104
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67441
        i32.const 72
        i32.const 17
        call 6
        unreachable
      end
      local.get 103
      i64.const -4294967296
      i64.and
      local.get 104
      i64.or
      local.set 105
      local.get 105
      i32.wrap_i64
      i64.load8_u
      local.set 106
      local.get 101
      local.get 102
      i64.store8
      local.get 106
      local.set 107
      local.get 0
      i32.const 6
      i32.add
      local.set 108
      local.get 108
      i64.load8_u
      local.set 109
      local.get 4
      local.tee 110
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 67513
        i32.const 72
        i32.const 17
        call 6
        unreachable
      end
      local.get 110
      i64.load8_u
      local.set 111
      call 0
      local.set 112
      local.get 112
      local.get 107
      i32.const 1
      call 1
      local.get 112
      i32.const 67585
      i32.const 1
      call 4
      local.get 112
      local.get 109
      i32.const 0
      call 1
      local.get 112
      i32.const 67586
      i32.const 1
      call 4
      local.get 112
      local.get 111
      i32.const 1
      call 1
      local.get 112
      call 5
      local.get 0
      i32.const 6
      i32.add
      local.set 113
      local.get 113
      i64.load8_u
      local.set 114
      i64.const 0
      local.set 114
      local.get 113
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 115
      local.get 115
      i64.const 4294967295
      i64.and
      local.get 114
      i64.const 1
      i64.mul
      i64.add
      local.tee 116
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67587
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 115
      i64.const -4294967296
      i64.and
      local.get 116
      i64.or
      local.set 117
      local.get 113
      local.get 114
      i64.store8
      local.get 0
      i32.const 6
      i32.add
      local.set 118
      i64.const 42
      local.set 119
      local.get 118
      i64.load8_u
      local.set 120
      local.get 120
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 67659
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 118
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 122
      local.get 122
      i64.const 4294967295
      i64.and
      local.get 120
      i64.const 1
      i64.mul
      i64.add
      local.tee 123
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67731
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 122
      i64.const -4294967296
      i64.and
      local.get 123
      i64.or
      local.tee 124
      local.get 119
      local.set 125
      i32.wrap_i64
      local.get 125
      i64.store8
      local.get 118
      local.get 120
      i64.const 1
      i64.add
      i64.store8
      local.get 124
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 6
      i32.add
      local.set 126
      i64.const 0
      local.set 127
      block ;; label = @2
        loop ;; label = @3
          local.get 127
          local.get 126
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 126
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 128
          local.get 128
          i64.const 4294967295
          i64.and
          local.get 127
          i64.const 1
          i64.mul
          i64.add
          local.tee 129
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 67803
            i32.const 72
            i32.const 19
            call 6
            unreachable
          end
          local.get 128
          i64.const -4294967296
          i64.and
          local.get 129
          i64.or
          i32.wrap_i64
          local.set 6
          local.get 127
          local.set 7
          block ;; label = @4
            local.get 6
            local.tee 130
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 67875
              i32.const 72
              i32.const 19
              call 6
              unreachable
            end
            local.get 130
            local.set 131
            local.get 131
            i64.load8_u
            local.get 7
            i64.const 255
            i64.and
            i64.add
            i64.const 255
            i64.and
            local.set 132
            local.get 131
            local.get 132
            i64.store8
          end
          local.get 127
          i64.const 1
          i64.add
          local.set 127
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 6
      i32.add
      local.set 133
      local.get 133
      i64.load8_u
      local.set 134
      local.get 0
      i32.const 6
      i32.add
      local.set 135
      local.get 135
      i64.load8_u
      local.set 136
      i64.const 0
      local.set 137
      local.get 135
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 138
      local.get 138
      i64.const 4294967295
      i64.and
      local.get 137
      i64.const 1
      i64.mul
      i64.add
      local.tee 139
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67947
        i32.const 72
        i32.const 20
        call 6
        unreachable
      end
      local.get 138
      i64.const -4294967296
      i64.and
      local.get 139
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 140
      call 0
      local.set 141
      local.get 141
      local.get 134
      i32.const 0
      call 1
      local.get 141
      i32.const 68019
      i32.const 1
      call 4
      local.get 141
      local.get 140
      i32.const 1
      call 1
      local.get 141
      call 5
      local.get 0
      i32.const 11
      i32.add
      local.set 142
      local.get 142
      i64.const 0
      i64.store16 align=1
      f32.const -0x0p+0 (;=-0;)
      local.set 143
      local.get 142
      i64.load16_u align=1
      local.set 144
      local.get 144
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 68020
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 142
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 146
      local.get 146
      i64.const 4294967295
      i64.and
      local.get 144
      i64.const 4
      i64.mul
      i64.add
      local.tee 147
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68092
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 146
      i64.const -4294967296
      i64.and
      local.get 147
      i64.or
      local.tee 148
      local.get 143
      local.set 149
      i32.wrap_i64
      local.get 149
      f32.store align=1
      local.get 142
      local.get 144
      i64.const 1
      i64.add
      i64.store16 align=1
      f32.const 0x1.8p+0 (;=1.5;)
      local.set 150
      local.get 142
      i64.load16_u align=1
      local.set 151
      local.get 151
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 68164
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 142
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 153
      local.get 153
      i64.const 4294967295
      i64.and
      local.get 151
      i64.const 4
      i64.mul
      i64.add
      local.tee 154
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68236
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 153
      i64.const -4294967296
      i64.and
      local.get 154
      i64.or
      local.tee 155
      local.get 150
      local.set 156
      i32.wrap_i64
      local.get 156
      f32.store align=1
      local.get 142
      local.get 151
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 0
      i32.const 11
      i32.add
      local.set 157
      local.get 157
      i64.load16_u align=1
      local.set 158
      i64.const 256
      local.set 159
      local.get 0
      i32.const 11
      i32.add
      local.set 160
      local.get 160
      i64.load16_u align=1
      local.set 161
      i64.const 0
      local.set 162
      local.get 160
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 163
      local.get 163
      i64.const 4294967295
      i64.and
      local.get 162
      i64.const 4
      i64.mul
      i64.add
      local.tee 164
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68308
        i32.const 72
        i32.const 22
        call 6
        unreachable
      end
      local.get 163
      i64.const -4294967296
      i64.and
      local.get 164
      i64.or
      i32.wrap_i64
      f32.load align=1
      local.set 165
      local.get 0
      i32.const 11
      i32.add
      local.set 166
      local.get 166
      i64.load16_u align=1
      local.set 167
      local.get 167
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 68380
        i32.const 72
        i32.const 22
        call 6
        unreachable
      end
      local.get 167
      i64.const 1
      i64.sub
      local.set 167
      local.get 166
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 168
      local.get 168
      i64.const 4294967295
      i64.and
      local.get 167
      i64.const 4
      i64.mul
      i64.add
      local.tee 169
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68452
        i32.const 72
        i32.const 22
        call 6
        unreachable
      end
      local.get 168
      i64.const -4294967296
      i64.and
      local.get 169
      i64.or
      local.set 170
      local.get 170
      i32.wrap_i64
      f32.load align=1
      local.set 171
      local.get 166
      local.get 167
      i64.store16 align=1
      local.get 171
      local.set 172
      call 0
      local.set 173
      local.get 173
      local.get 158
      i32.const 0
      call 1
      local.get 173
      i32.const 68524
      i32.const 1
      call 4
      local.get 173
      local.get 159
      i32.const 0
      call 1
      local.get 173
      i32.const 68525
      i32.const 1
      call 4
      local.get 173
      local.get 165
      f64.promote_f32
      i32.const 32
      call 2
      local.get 173
      i32.const 68526
      i32.const 1
      call 4
      local.get 173
      local.get 172
      f64.promote_f32
      i32.const 32
      call 2
      local.get 173
      call 5
      local.get 0
      i32.const 11
      i32.add
      local.set 174
      f32.const 0x1.4p+1 (;=2.5;)
      local.set 175
      local.get 174
      i64.load16_u align=1
      local.set 176
      local.get 176
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 68527
        i32.const 72
        i32.const 23
        call 6
        unreachable
      end
      local.get 174
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 178
      local.get 178
      i64.const 4294967295
      i64.and
      local.get 176
      i64.const 4
      i64.mul
      i64.add
      local.tee 179
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68599
        i32.const 72
        i32.const 23
        call 6
        unreachable
      end
      local.get 178
      i64.const -4294967296
      i64.and
      local.get 179
      i64.or
      local.tee 180
      local.get 175
      local.set 181
      i32.wrap_i64
      local.get 181
      f32.store align=1
      local.get 174
      local.get 176
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 180
      i32.wrap_i64
      f32.load align=1
      drop
      local.get 0
      i32.const 11
      i32.add
      local.set 182
      local.get 182
      i64.load16_u align=1
      local.set 183
      i64.const 1
      local.set 184
      local.get 182
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 185
      local.get 185
      i64.const 4294967295
      i64.and
      local.get 184
      i64.const 4
      i64.mul
      i64.add
      local.tee 186
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68671
        i32.const 72
        i32.const 23
        call 6
        unreachable
      end
      local.get 185
      i64.const -4294967296
      i64.and
      local.get 186
      i64.or
      i32.wrap_i64
      f32.load align=1
      local.set 187
      call 0
      local.set 188
      local.get 188
      local.get 187
      f64.promote_f32
      i32.const 32
      call 2
      local.get 188
      call 5
      local.get 0
      i32.const 1037
      i32.add
      local.set 189
      block ;; label = @2
        local.get 0
        i32.const 1037
        i32.add
        local.set 8
        i64.const 0
        local.set 190
        call 0
        local.set 191
        local.get 191
        i32.const 68743
        i32.const 6
        call 4
        local.get 191
        local.get 190
        i32.const 0
        call 1
        local.get 191
        call 5
      end
      local.get 0
      i32.const 1038
      i32.add
      local.set 192
      local.get 192
      i64.const 0
      i64.store8
      local.get 0
      i32.const 1038
      i32.add
      local.set 193
      local.get 193
      i64.load8_u
      local.set 194
      i64.const 0
      local.set 195
      call 0
      local.set 196
      local.get 196
      local.get 194
      i32.const 0
      call 1
      local.get 196
      i32.const 68749
      i32.const 1
      call 4
      local.get 196
      local.get 195
      i32.const 0
      call 1
      local.get 196
      call 5
      i32.const 0
      local.set 9
      local.get 9
      i32.const 0
      i32.eq
      local.set 197
      call 0
      local.set 198
      local.get 198
      local.get 197
      call 3
      local.get 198
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 9
      i64.const 3
      local.set 199
      local.get 9
      local.tee 200
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 68750
        i32.const 72
        i32.const 26
        call 6
        unreachable
      end
      local.get 200
      local.set 201
      i64.const 3
      local.set 202
      i64.const 2
      local.set 203
      local.get 201
      i64.extend_i32_u
      local.set 204
      local.get 204
      i64.const 4294967295
      i64.and
      local.get 203
      i64.const 2
      i64.mul
      i64.add
      local.tee 205
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68822
        i32.const 72
        i32.const 27
        call 6
        unreachable
      end
      local.get 204
      i64.const -4294967296
      i64.and
      local.get 205
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 206
      call 0
      local.set 207
      local.get 207
      local.get 199
      i32.const 0
      call 1
      local.get 207
      i32.const 68894
      i32.const 1
      call 4
      local.get 207
      local.get 206
      i32.const 0
      call 1
      local.get 207
      call 5
      i32.const 14
      local.set 208
      i64.const 33
      local.set 209
      local.get 208
      i64.load32_u align=1
      local.set 210
      local.get 210
      i64.const 65536
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 68895
        i32.const 72
        i32.const 28
        call 6
        unreachable
      end
      local.get 208
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 212
      local.get 212
      i64.const 4294967295
      i64.and
      local.get 210
      i64.const 1
      i64.mul
      i64.add
      local.tee 213
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68967
        i32.const 72
        i32.const 28
        call 6
        unreachable
      end
      local.get 212
      i64.const -4294967296
      i64.and
      local.get 213
      i64.or
      local.tee 214
      local.get 209
      local.set 215
      i32.wrap_i64
      local.get 215
      i64.store8
      local.get 208
      local.get 210
      i64.const 1
      i64.add
      i64.store32 align=1
      local.get 214
      i32.wrap_i64
      i64.load8_u
      drop
      i32.const 8
      local.set 216
      i64.const 3
      local.set 217
      i64.const 0
      local.set 218
      local.get 216
      i64.extend_i32_u
      local.set 219
      local.get 219
      i64.const 4294967295
      i64.and
      local.get 218
      i64.const 2
      i64.mul
      i64.add
      local.tee 220
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 69039
        i32.const 72
        i32.const 29
        call 6
        unreachable
      end
      local.get 219
      i64.const -4294967296
      i64.and
      local.get 220
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 221
      i32.const 8
      local.set 222
      i64.const 3
      local.set 223
      i64.const 1
      local.set 224
      local.get 222
      i64.extend_i32_u
      local.set 225
      local.get 225
      i64.const 4294967295
      i64.and
      local.get 224
      i64.const 2
      i64.mul
      i64.add
      local.tee 226
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 69111
        i32.const 72
        i32.const 29
        call 6
        unreachable
      end
      local.get 225
      i64.const -4294967296
      i64.and
      local.get 226
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 227
      i32.const 8
      local.set 228
      i64.const 3
      local.set 229
      i64.const 2
      local.set 230
      local.get 228
      i64.extend_i32_u
      local.set 231
      local.get 231
      i64.const 4294967295
      i64.and
      local.get 230
      i64.const 2
      i64.mul
      i64.add
      local.tee 232
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 69183
        i32.const 72
        i32.const 29
        call 6
        unreachable
      end
      local.get 231
      i64.const -4294967296
      i64.and
      local.get 232
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 233
      call 0
      local.set 234
      local.get 234
      local.get 221
      i32.const 0
      call 1
      local.get 234
      i32.const 69255
      i32.const 1
      call 4
      local.get 234
      local.get 227
      i32.const 0
      call 1
      local.get 234
      i32.const 69256
      i32.const 1
      call 4
      local.get 234
      local.get 233
      i32.const 0
      call 1
      local.get 234
      call 5
      i32.const 14
      local.set 235
      local.get 235
      i64.load32_u align=1
      local.set 236
      i64.const 65536
      local.set 237
      i32.const 14
      local.set 238
      local.get 238
      i64.load32_u align=1
      local.set 239
      i64.const 0
      local.set 240
      local.get 238
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 241
      local.get 241
      i64.const 4294967295
      i64.and
      local.get 240
      i64.const 1
      i64.mul
      i64.add
      local.tee 242
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 69257
        i32.const 72
        i32.const 30
        call 6
        unreachable
      end
      local.get 241
      i64.const -4294967296
      i64.and
      local.get 242
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 243
      i64.const 123
      local.set 244
      call 0
      local.set 245
      local.get 245
      local.get 236
      i32.const 0
      call 1
      local.get 245
      i32.const 69329
      i32.const 1
      call 4
      local.get 245
      local.get 237
      i32.const 0
      call 1
      local.get 245
      i32.const 69330
      i32.const 1
      call 4
      local.get 245
      local.get 243
      i32.const 1
      call 1
      local.get 245
      i32.const 69331
      i32.const 1
      call 4
      local.get 245
      local.get 244
      i32.const 0
      call 1
      local.get 245
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32 i32 i32 i64)
    i32.const 8
    local.set 1
    local.get 1
    i32.const 0
    i32.add
    i64.const -32768
    i64.store16 align=1
    local.get 1
    i32.const 2
    i32.add
    i64.const 2
    i64.store16 align=1
    local.get 1
    i32.const 4
    i32.add
    i64.const -1
    i64.store16 align=1
    i32.const 14
    local.set 2
    local.get 2
    i64.const 0
    i64.store32 align=1
    i64.const 123
    local.set 3
    i32.const 65554
    local.get 3
    i64.store align=1
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 65554) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.gooseempty=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,")
)
