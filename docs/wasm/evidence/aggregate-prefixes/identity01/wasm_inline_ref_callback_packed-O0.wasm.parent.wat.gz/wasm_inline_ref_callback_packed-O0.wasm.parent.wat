(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (global (;0;) (mut i32) i32.const 3104)
  (global (;1;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 85
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 93
        i32.const 85
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 41
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 10
      i32.const 12
      call $goose.reserve_memory.1
      local.set 11
      local.get 10
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 11
      i64.extend_i32_u
      i64.or
      local.set 12
      local.get 12
      local.set 1
      local.get 12
      i64.const 1
      local.set 13
      i32.wrap_i64
      local.get 13
      i64.store32 1 align=1
      i64.const 91
      local.set 14
      local.get 11
      i32.const 4
      i32.add
      local.get 14
      i64.store 1 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 15
      local.get 15
      i32.const 0
      i32.add
      i64.const 11
      i64.store align=1
      local.get 15
      i32.const 8
      i32.add
      i64.const 22
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 16
      local.get 16
      i64.const 0
      i64.store8
      i64.const 33
      local.set 17
      local.get 16
      i64.load8_u
      local.set 18
      local.get 18
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 178
        i32.const 85
        i32.const 10
        call 6
        unreachable
      end
      local.get 16
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 263
        i32.const 85
        i32.const 10
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      local.tee 22
      local.get 17
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store align=1
      local.get 16
      local.get 18
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      call $relayFixed.1
      local.set 2
      local.get 2
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 348
        i32.const 85
        i32.const 12
        call 6
        unreachable
      end
      local.get 2
      local.tee 24
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 433
        i32.const 85
        i32.const 11
        call 6
        unreachable
      end
      local.get 24
      local.set 25
      i64.const 2
      local.set 26
      i64.const 0
      local.set 27
      local.get 25
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      local.get 27
      i64.const 8
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 518
        i32.const 85
        i32.const 12
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      local.set 30
      local.get 30
      call $goose.memory_op.41
      i64.const 4
      i64.add
      local.set 31
      local.get 30
      local.get 31
      call $goose.memory_op.55
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 32
      i64.const 2
      local.set 33
      i64.const 0
      local.set 34
      local.get 32
      local.set 35
      local.get 35
      i64.const 4294967295
      i64.and
      local.get 34
      i64.const 8
      i64.mul
      i64.add
      local.tee 36
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 603
        i32.const 85
        i32.const 12
        call 6
        unreachable
      end
      local.get 35
      i64.const -4294967296
      i64.and
      local.get 36
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 15
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 688
        i32.const 85
        i32.const 12
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      call $relayLimited.3
      local.set 3
      local.get 3
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 773
        i32.const 85
        i32.const 14
        call 6
        unreachable
      end
      local.get 3
      local.tee 37
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 858
        i32.const 85
        i32.const 13
        call 6
        unreachable
      end
      local.get 37
      local.set 38
      i64.const 44
      local.set 39
      local.get 38
      call $goose.memory_op.49
      local.set 40
      local.get 40
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 943
        i32.const 85
        i32.const 14
        call 6
        unreachable
      end
      local.get 38
      local.set 42
      local.get 42
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 40
      i64.const 8
      i64.mul
      i64.add
      local.tee 43
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1028
        i32.const 85
        i32.const 14
        call 6
        unreachable
      end
      local.get 42
      i64.const -4294967296
      i64.and
      local.get 43
      i64.or
      local.tee 44
      local.get 39
      call $goose.memory_op.55
      local.get 38
      local.get 40
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 44
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 45
      local.get 45
      i32.wrap_i64
      i64.load8_u
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1113
        i32.const 85
        i32.const 15
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 46
      local.get 46
      i32.wrap_i64
      i64.load8_u
      local.set 47
      i64.const 0
      local.set 48
      local.get 46
      local.set 49
      local.get 49
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 48
      i64.const 8
      i64.mul
      i64.add
      local.tee 50
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1198
        i32.const 85
        i32.const 15
        call 6
        unreachable
      end
      local.get 49
      i64.const -4294967296
      i64.and
      local.get 50
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 33
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1283
        i32.const 85
        i32.const 15
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 51
      local.get 51
      i32.wrap_i64
      i64.load8_u
      local.set 52
      i64.const 1
      local.set 53
      local.get 51
      local.set 54
      local.get 54
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 53
      i64.const 8
      i64.mul
      i64.add
      local.tee 55
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1368
        i32.const 85
        i32.const 15
        call 6
        unreachable
      end
      local.get 54
      i64.const -4294967296
      i64.and
      local.get 55
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 44
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1453
        i32.const 85
        i32.const 15
        call 6
        unreachable
      end
      i64.const 0
      local.set 4
      local.get 4
      call $relayMaybeFixed.5
      local.set 5
      local.get 5
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1538
        i32.const 85
        i32.const 18
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 4
      local.get 4
      call $relayMaybeFixed.6
      local.set 6
      local.get 6
      i64.eqz
      i32.eqz
      if ;; label = @2
        local.get 6
        local.get 0
        i32.const 0
        i32.add
        i64.extend_i32_u
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1623
          i32.const 85
          i32.const 20
          call 6
          unreachable
        end
        local.get 6
        local.tee 56
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1708
          i32.const 85
          i32.const 19
          call 6
          unreachable
        end
        local.get 56
        local.set 57
        i64.const 2
        local.set 58
        i64.const 1
        local.set 59
        local.get 57
        local.set 60
        local.get 60
        i64.const 4294967295
        i64.and
        local.get 59
        i64.const 8
        i64.mul
        i64.add
        local.tee 61
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1793
          i32.const 85
          i32.const 20
          call 6
          unreachable
        end
        local.get 60
        i64.const -4294967296
        i64.and
        local.get 61
        i64.or
        local.set 62
        local.get 62
        call $goose.memory_op.41
        i64.const 5
        i64.add
        local.set 63
        local.get 62
        local.get 63
        call $goose.memory_op.55
      else
        i32.const 0
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1878
          i32.const 85
          i32.const 20
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 64
      i64.const 2
      local.set 65
      i64.const 1
      local.set 66
      local.get 64
      local.set 67
      local.get 67
      i64.const 4294967295
      i64.and
      local.get 66
      i64.const 8
      i64.mul
      i64.add
      local.tee 68
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1963
        i32.const 85
        i32.const 21
        call 6
        unreachable
      end
      local.get 67
      i64.const -4294967296
      i64.and
      local.get 68
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 27
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2048
        i32.const 85
        i32.const 21
        call 6
        unreachable
      end
      i64.const 0
      local.set 7
      local.get 7
      call $relayMaybeLimited.7
      local.set 8
      local.get 8
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2133
        i32.const 85
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 7
      local.get 7
      call $relayMaybeLimited.8
      local.set 9
      local.get 9
      i64.eqz
      i32.eqz
      if ;; label = @2
        local.get 9
        local.get 0
        i32.const 16
        i32.add
        i64.extend_i32_u
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 2218
          i32.const 85
          i32.const 26
          call 6
          unreachable
        end
        local.get 9
        local.tee 69
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 2303
          i32.const 85
          i32.const 26
          call 6
          unreachable
        end
        local.get 69
        local.set 70
        i64.const 55
        local.set 71
        local.get 70
        call $goose.memory_op.49
        local.set 72
        local.get 72
        i64.const 3
        i64.ge_u
        if ;; label = @3
          i32.const 10
          i32.const 2388
          i32.const 85
          i32.const 26
          call 6
          unreachable
        end
        local.get 70
        local.set 74
        local.get 74
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.get 72
        i64.const 8
        i64.mul
        i64.add
        local.tee 75
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2473
          i32.const 85
          i32.const 26
          call 6
          unreachable
        end
        local.get 74
        i64.const -4294967296
        i64.and
        local.get 75
        i64.or
        local.tee 76
        local.get 71
        call $goose.memory_op.55
        local.get 70
        local.get 72
        i64.const 1
        i64.add
        call $goose.memory_op.60
        local.get 76
        call $goose.memory_op.41
        drop
      else
        i32.const 0
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 2558
          i32.const 85
          i32.const 26
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 77
      local.get 77
      i32.wrap_i64
      i64.load8_u
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2643
        i32.const 85
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 78
      local.get 78
      i32.wrap_i64
      i64.load8_u
      local.set 79
      i64.const 2
      local.set 80
      local.get 78
      local.set 81
      local.get 81
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 80
      i64.const 8
      i64.mul
      i64.add
      local.tee 82
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2728
        i32.const 85
        i32.const 27
        call 6
        unreachable
      end
      local.get 81
      i64.const -4294967296
      i64.and
      local.get 82
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 55
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2813
        i32.const 85
        i32.const 27
        call 6
        unreachable
      end
      local.get 1
      local.set 83
      local.get 83
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 84
      i64.const 0
      local.set 85
      local.get 83
      local.set 86
      local.get 86
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 85
      i64.const 8
      i64.mul
      i64.add
      local.tee 87
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2898
        i32.const 85
        i32.const 28
        call 6
        unreachable
      end
      local.get 86
      i64.const -4294967296
      i64.and
      local.get 87
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 91
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2983
        i32.const 85
        i32.const 28
        call 6
        unreachable
      end
      call 0
      local.set 88
      local.get 88
      i32.const 3068
      i32.const 21
      call 4
      local.get 88
      call 5
      local.get 11
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $relayFixed.1 (;12;) (type 11) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      call $fixedIdentity.2
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $fixedIdentity.2 (;13;) (type 11) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $relayLimited.3 (;14;) (type 11) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      call $limitedIdentity.4
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $limitedIdentity.4 (;15;) (type 11) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $relayMaybeFixed.5 (;16;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $relayMaybeFixed.6 (;17;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $relayMaybeLimited.7 (;18;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $relayMaybeLimited.8 (;19;) (type 11) (param i64) (result i64)
    (local i32 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      local.get 2
      local.set 4
      local.get 4
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $goose.init (;20;) (type 10)
    (local i32)
  )
  (func $goose.start (;21;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;22;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.41 (;23;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          i64.load align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;24;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;25;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;26;) (type 12) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_callback_packed.goosecallback-reference=ok")
)
