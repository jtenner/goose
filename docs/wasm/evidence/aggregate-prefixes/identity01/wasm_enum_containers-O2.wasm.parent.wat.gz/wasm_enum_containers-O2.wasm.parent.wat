(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64) (result i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (memory (;4;) 1 65536)
  (memory (;5;) 1 65536)
  (memory (;6;) 1 65536)
  (memory (;7;) 1 65536)
  (global (;0;) (mut i32) i32.const 4768)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (global (;4;) (mut i32) i32.const 1)
  (global (;5;) (mut i32) i32.const 1)
  (global (;6;) (mut i32) i32.const 1)
  (global (;7;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "data_memory_4" (memory 4))
  (export "data_memory_5" (memory 5))
  (export "data_memory_6" (memory 6))
  (export "data_memory_7" (memory 7))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 74
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 82
        i32.const 74
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i32 i32 i32 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i32 i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32)
    i32.const 180
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 1
      local.set 8
      i32.const 12
      call $goose.reserve_memory.1
      local.set 9
      local.get 8
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 9
      i64.extend_i32_u
      i64.or
      local.set 10
      local.get 10
      local.set 1
      local.get 10
      i64.const 1
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store32 1 align=1
      i64.const 10
      local.set 12
      local.get 9
      i32.const 4
      i32.add
      local.get 12
      i64.store 1 align=1
      i32.const 2
      local.set 13
      i32.const 12
      call $goose.reserve_memory.2
      local.set 14
      local.get 13
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 14
      i64.extend_i32_u
      i64.or
      local.set 15
      local.get 15
      local.set 2
      local.get 15
      i64.const 1
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store32 2 align=1
      i64.const 20
      local.set 16
      local.get 14
      i32.const 4
      i32.add
      local.get 16
      i64.store 2 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 17
      local.get 17
      i64.const 0
      i64.store8
      local.get 17
      i64.const 1
      i64.store8 offset=1
      local.get 17
      local.get 1
      local.set 18
      local.get 18
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 19
      i64.const 0
      local.set 20
      local.get 18
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 20
      i64.const 8
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 156
        i32.const 74
        i32.const 4
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      i64.store offset=2 align=1
      local.get 17
      i64.const 60000
      i64.store16 offset=10 align=1
      local.get 0
      i32.const 12
      i32.add
      local.set 23
      local.get 23
      i64.const 0
      i64.store8
      local.get 23
      i64.const 2
      i64.store8 offset=1
      local.get 23
      local.get 2
      local.set 24
      local.get 24
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 25
      i64.const 0
      local.set 26
      local.get 24
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 26
      i64.const 8
      i64.mul
      i64.add
      local.tee 28
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 230
        i32.const 74
        i32.const 4
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 28
      i64.or
      i64.store offset=2 align=1
      local.get 23
      i64.const 65000
      i64.store16 offset=10 align=1
      i32.const 3
      local.set 29
      i32.const 20
      call $goose.reserve_memory.3
      local.set 30
      local.get 29
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 30
      i64.extend_i32_u
      i64.or
      local.set 31
      local.get 31
      local.set 3
      local.get 31
      i64.const 2
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store32 3 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 32
      local.get 30
      i32.const 4
      i32.add
      local.get 32
      i64.store 3 align=1
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 32
      local.get 30
      i32.const 12
      i32.add
      local.get 32
      i64.store 3 align=1
      local.get 3
      local.set 33
      local.get 33
      i32.wrap_i64
      i64.load32_u 3 align=1
      local.set 34
      i64.const 0
      local.set 35
      local.get 33
      local.set 36
      local.get 36
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 35
      i64.const 8
      i64.mul
      i64.add
      local.tee 37
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 304
        i32.const 74
        i32.const 6
        call 6
        unreachable
      end
      local.get 36
      i64.const -4294967296
      i64.and
      local.get 37
      i64.or
      local.set 38
      local.get 38
      i32.wrap_i64
      i64.load 3 align=1
      local.tee 39
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 378
        i32.const 74
        i32.const 6
        call 6
        unreachable
      end
      local.get 39
      call $goose.memory_op.49
      local.set 40
      local.get 40
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 452
        i32.const 74
        i32.const 6
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 40
        i64.const 0
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 24
          i32.add
          local.set 41
          local.get 41
          i64.extend_i32_u
          local.set 42
          local.get 39
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.tee 45
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 526
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          local.get 39
          i64.const -4294967296
          i64.and
          local.get 45
          i64.or
          local.set 43
          i32.const 11
          local.set 44
          local.get 42
          i32.wrap_i64
          local.get 43
          local.get 44
          call $goose.copy_to_frame
          local.get 3
          local.set 46
          local.get 46
          i32.wrap_i64
          i64.load32_u 3 align=1
          local.set 47
          i64.const 0
          local.set 48
          local.get 46
          local.set 49
          local.get 49
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 48
          i64.const 8
          i64.mul
          i64.add
          local.tee 50
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 600
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          local.get 49
          i64.const -4294967296
          i64.and
          local.get 50
          i64.or
          local.set 51
          local.get 0
          i32.const 12
          i32.add
          i64.extend_i32_u
          local.set 52
          local.get 51
          local.get 52
          local.set 53
          i32.wrap_i64
          local.get 53
          i64.store 3 align=1
          local.get 1
          local.set 54
          local.get 54
          i32.wrap_i64
          i64.load32_u 1 align=1
          local.set 55
          i64.const 0
          local.set 56
          local.get 54
          local.set 57
          local.get 57
          i64.const 4294967295
          i64.and
          i64.const 4
          i64.add
          local.get 56
          i64.const 8
          i64.mul
          i64.add
          local.tee 58
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 674
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          local.get 57
          i64.const -4294967296
          i64.and
          local.get 58
          i64.or
          local.set 59
          local.get 59
          i32.wrap_i64
          i64.load 1 align=1
          i64.const 3
          i64.add
          local.set 60
          local.get 59
          local.get 60
          local.set 61
          i32.wrap_i64
          local.get 61
          i64.store 1 align=1
          local.get 0
          i32.const 24
          i32.add
          local.set 62
          local.get 62
          i64.load8_u
          i64.const 1
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 748
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          local.get 0
          i32.const 24
          i32.add
          local.set 63
          local.get 63
          i64.load offset=1 align=1
          local.tee 64
          i64.eqz
          if ;; label = @4
            i32.const 4
            i32.const 822
            i32.const 74
            i32.const 1
            call 6
            unreachable
          end
          local.get 64
          call $goose.memory_op.41
          i64.const 13
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 896
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          local.get 0
          i32.const 24
          i32.add
          local.set 65
          local.get 65
          i64.load16_u offset=9 align=1
          i64.const 60000
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 970
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 40
        i64.const 1
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1044
            i32.const 74
            i32.const 6
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
      end
      local.get 0
      i32.const 35
      i32.add
      local.set 66
      local.get 3
      local.set 67
      local.get 67
      i32.wrap_i64
      i64.load32_u 3 align=1
      local.set 68
      i64.const 0
      local.set 69
      local.get 67
      local.set 70
      local.get 70
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 69
      i64.const 8
      i64.mul
      i64.add
      local.tee 71
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1118
        i32.const 74
        i32.const 7
        call 6
        unreachable
      end
      local.get 70
      i64.const -4294967296
      i64.and
      local.get 71
      i64.or
      local.set 72
      local.get 72
      i32.wrap_i64
      i64.load 3 align=1
      local.tee 73
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1192
        i32.const 74
        i32.const 7
        call 6
        unreachable
      end
      local.get 66
      i64.extend_i32_u
      local.set 74
      local.get 73
      local.set 75
      i32.const 12
      local.set 76
      local.get 74
      i32.wrap_i64
      local.get 75
      local.get 76
      call $goose.copy_to_frame
      local.get 2
      local.set 77
      local.get 77
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 78
      i64.const 0
      local.set 79
      local.get 77
      local.set 80
      local.get 80
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 79
      i64.const 8
      i64.mul
      i64.add
      local.tee 81
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1266
        i32.const 74
        i32.const 7
        call 6
        unreachable
      end
      local.get 80
      i64.const -4294967296
      i64.and
      local.get 81
      i64.or
      local.set 82
      local.get 82
      i32.wrap_i64
      i64.load 2 align=1
      i64.const 4
      i64.add
      local.set 83
      local.get 82
      local.get 83
      local.set 84
      i32.wrap_i64
      local.get 84
      i64.store 2 align=1
      local.get 0
      i32.const 35
      i32.add
      local.set 85
      local.get 85
      i64.load8_u
      local.set 86
      local.get 86
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 1340
        i32.const 74
        i32.const 8
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 86
        i64.const 0
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 47
          i32.add
          local.set 87
          local.get 87
          i64.extend_i32_u
          local.set 88
          local.get 85
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 89
          i32.const 11
          local.set 90
          local.get 88
          i32.wrap_i64
          local.get 89
          i32.wrap_i64
          local.get 90
          memory.copy
          local.get 0
          i32.const 47
          i32.add
          local.set 91
          local.get 91
          i64.load8_u
          i64.const 2
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1414
            i32.const 74
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 47
          i32.add
          local.set 92
          local.get 92
          i64.load offset=1 align=1
          local.tee 93
          i64.eqz
          if ;; label = @4
            i32.const 4
            i32.const 1488
            i32.const 74
            i32.const 1
            call 6
            unreachable
          end
          local.get 93
          call $goose.memory_op.41
          i64.const 24
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1562
            i32.const 74
            i32.const 8
            call 6
            unreachable
          end
          local.get 0
          i32.const 47
          i32.add
          local.set 94
          local.get 94
          i64.load16_u offset=9 align=1
          i64.const 65000
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1636
            i32.const 74
            i32.const 8
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 86
        i64.const 1
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 1710
            i32.const 74
            i32.const 8
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
      end
      local.get 0
      i32.const 58
      i32.add
      local.set 95
      local.get 95
      i32.const 0
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 95
      i32.const 8
      i32.add
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 74
      i32.add
      local.set 96
      local.get 96
      i64.const 0
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 97
      local.get 96
      i64.load8_u
      local.set 98
      local.get 98
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1784
        i32.const 74
        i32.const 9
        call 6
        unreachable
      end
      local.get 96
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 100
      local.get 100
      i64.const 4294967295
      i64.and
      local.get 98
      i64.const 8
      i64.mul
      i64.add
      local.tee 101
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1858
        i32.const 74
        i32.const 9
        call 6
        unreachable
      end
      local.get 100
      i64.const -4294967296
      i64.and
      local.get 101
      i64.or
      local.tee 102
      local.get 97
      local.set 103
      i32.wrap_i64
      local.get 103
      i64.store align=1
      local.get 96
      local.get 98
      i64.const 1
      i64.add
      i64.store8
      i64.const 3
      local.set 104
      local.get 104
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 12
        i32.const 1932
        i32.const 74
        i32.const 9
        call 6
        unreachable
      end
      local.get 104
      i64.const 536870910
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 2006
        i32.const 74
        i32.const 9
        call 6
        unreachable
      end
      i32.const 4
      local.set 105
      local.get 104
      i64.const 8
      i64.mul
      i64.const 8
      i64.add
      i32.wrap_i64
      call $goose.reserve_memory.4
      local.set 106
      local.get 105
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 106
      i64.extend_i32_u
      i64.or
      local.set 107
      local.get 107
      local.set 4
      local.get 107
      local.get 104
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store32 4 align=1
      local.get 107
      i64.const 0
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store32 4 offset=4 align=1
      i32.const 5
      local.set 108
      i32.const 17
      call $goose.reserve_memory.5
      local.set 109
      local.get 108
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 109
      i64.extend_i32_u
      i64.or
      local.set 110
      local.get 110
      local.set 5
      local.get 110
      i32.wrap_i64
      i64.const 2
      i64.store8 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 111
      local.get 109
      i32.const 1
      i32.add
      local.get 111
      i64.store 5 align=1
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 111
      local.get 109
      i32.const 9
      i32.add
      local.get 111
      i64.store 5 align=1
      i32.const 6
      local.set 112
      global.get 6
      local.set 113
      local.get 0
      i32.const 99
      i32.add
      local.set 114
      local.get 114
      local.get 112
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 113
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 114
      i64.const 0
      i64.store offset=8 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 115
      local.get 114
      i64.load offset=8 align=1
      local.set 116
      i32.const 8
      call $goose.reserve_memory.6
      local.set 117
      local.get 114
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 117
      i64.extend_i32_u
      i64.or
      local.tee 118
      local.get 115
      local.set 119
      i32.wrap_i64
      local.get 119
      i64.store 6 align=1
      local.get 114
      local.get 116
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i32.const 7
      local.set 120
      global.get 7
      local.set 121
      local.get 0
      i32.const 115
      i32.add
      local.set 122
      local.get 122
      local.get 120
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 121
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 122
      i64.const 0
      i64.store offset=8 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 123
      local.get 122
      i64.load offset=8 align=1
      local.set 124
      i32.const 8
      call $goose.reserve_memory.7
      local.set 125
      local.get 122
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 125
      i64.extend_i32_u
      i64.or
      local.tee 126
      local.get 123
      local.set 127
      i32.wrap_i64
      local.get 127
      i64.store 7 align=1
      local.get 122
      local.get 124
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 74
      i32.add
      i64.extend_i32_u
      local.set 128
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 129
      local.get 128
      i32.wrap_i64
      i64.load8_u
      local.set 130
      local.get 130
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2080
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 128
      local.set 132
      local.get 132
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 130
      i64.const 8
      i64.mul
      i64.add
      local.tee 133
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2154
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 132
      i64.const -4294967296
      i64.and
      local.get 133
      i64.or
      local.tee 134
      local.get 129
      local.set 135
      i32.wrap_i64
      local.get 135
      i64.store align=1
      local.get 128
      local.get 130
      i64.const 1
      i64.add
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store8
      local.get 134
      i32.wrap_i64
      i64.load align=1
      drop
      local.get 4
      local.set 136
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 137
      local.get 136
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 138
      local.get 138
      local.get 136
      i32.wrap_i64
      i64.load32_u 4 align=1
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2228
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 136
      local.set 140
      local.get 140
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 138
      i64.const 8
      i64.mul
      i64.add
      local.tee 141
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2302
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 140
      i64.const -4294967296
      i64.and
      local.get 141
      i64.or
      local.tee 142
      local.get 137
      local.set 143
      i32.wrap_i64
      local.get 143
      i64.store 4 align=1
      local.get 136
      local.get 138
      i64.const 1
      i64.add
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store32 4 offset=4 align=1
      local.get 142
      i32.wrap_i64
      i64.load 4 align=1
      drop
      local.get 0
      i32.const 99
      i32.add
      local.set 144
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 145
      local.get 144
      i64.load offset=8 align=1
      local.set 146
      i32.const 8
      call $goose.reserve_memory.6
      local.set 147
      local.get 144
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 147
      i64.extend_i32_u
      i64.or
      local.tee 148
      local.get 145
      local.set 149
      i32.wrap_i64
      local.get 149
      i64.store 6 align=1
      local.get 144
      local.get 146
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 148
      i32.wrap_i64
      i64.load 6 align=1
      drop
      local.get 0
      i32.const 115
      i32.add
      local.set 150
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 151
      local.get 150
      i64.load offset=8 align=1
      local.set 152
      i32.const 8
      call $goose.reserve_memory.7
      local.set 153
      local.get 150
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 153
      i64.extend_i32_u
      i64.or
      local.tee 154
      local.get 151
      local.set 155
      i32.wrap_i64
      local.get 155
      i64.store 7 align=1
      local.get 150
      local.get 152
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 154
      i32.wrap_i64
      i64.load 7 align=1
      drop
      local.get 0
      i32.const 115
      i32.add
      local.set 156
      local.get 156
      i64.load offset=8 align=1
      local.set 157
      local.get 157
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 2376
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 157
      i64.const 1
      i64.sub
      local.set 157
      local.get 156
      i64.load align=1
      local.set 158
      local.get 158
      i64.const 4294967295
      i64.and
      local.get 157
      i64.const 8
      i64.mul
      i64.add
      local.tee 159
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2450
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 158
      i64.const -4294967296
      i64.and
      local.get 159
      i64.or
      local.set 160
      local.get 160
      i32.wrap_i64
      i64.load 7 align=1
      local.set 161
      local.get 160
      i32.wrap_i64
      global.set 7
      local.get 156
      local.get 157
      i64.store offset=8 align=1
      local.get 161
      local.set 6
      local.get 6
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2524
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      local.set 162
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 163
      local.get 162
      i64.load offset=8 align=1
      local.set 164
      i32.const 8
      call $goose.reserve_memory.7
      local.set 165
      local.get 162
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 165
      i64.extend_i32_u
      i64.or
      local.tee 166
      local.get 163
      local.set 167
      i32.wrap_i64
      local.get 167
      i64.store 7 align=1
      local.get 162
      local.get 164
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 166
      i32.wrap_i64
      i64.load 7 align=1
      drop
      local.get 0
      i32.const 115
      i32.add
      local.set 168
      local.get 168
      i64.load offset=8 align=1
      local.set 169
      local.get 169
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 2598
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 169
      i64.const 1
      i64.sub
      local.set 169
      local.get 168
      i64.load align=1
      local.set 170
      local.get 170
      i64.const 4294967295
      i64.and
      local.get 169
      i64.const 8
      i64.mul
      i64.add
      local.tee 171
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2672
        i32.const 74
        i32.const 10
        call 6
        unreachable
      end
      local.get 170
      i64.const -4294967296
      i64.and
      local.get 171
      i64.or
      local.set 172
      local.get 172
      i32.wrap_i64
      i64.load 7 align=1
      local.set 173
      local.get 172
      i32.wrap_i64
      global.set 7
      local.get 168
      local.get 169
      i64.store offset=8 align=1
      local.get 173
      drop
      local.get 0
      i32.const 58
      i32.add
      i64.extend_i32_u
      local.set 174
      i32.const 16
      local.set 175
      local.get 174
      local.set 176
      local.get 0
      i32.const 131
      i32.add
      i64.extend_i32_u
      local.set 177
      local.get 177
      i32.wrap_i64
      local.get 176
      i32.wrap_i64
      local.get 175
      memory.copy
      local.get 0
      i32.const 131
      i32.add
      i64.extend_i32_u
      local.set 178
      i64.const 2
      local.set 179
      i64.const 0
      local.set 180
      local.get 178
      local.set 181
      local.get 181
      i64.const 4294967295
      i64.and
      local.get 180
      i64.const 8
      i64.mul
      i64.add
      local.tee 182
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2746
        i32.const 74
        i32.const 11
        call 6
        unreachable
      end
      local.get 181
      i64.const -4294967296
      i64.and
      local.get 182
      i64.or
      local.set 183
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      local.set 184
      local.get 183
      local.get 184
      local.set 185
      i32.wrap_i64
      local.get 185
      i64.store align=1
      local.get 0
      i32.const 58
      i32.add
      i64.extend_i32_u
      local.set 186
      i64.const 2
      local.set 187
      i64.const 0
      local.set 188
      local.get 186
      local.set 189
      local.get 189
      i64.const 4294967295
      i64.and
      local.get 188
      i64.const 8
      i64.mul
      i64.add
      local.tee 190
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2820
        i32.const 74
        i32.const 11
        call 6
        unreachable
      end
      local.get 189
      i64.const -4294967296
      i64.and
      local.get 190
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2894
        i32.const 74
        i32.const 11
        call 6
        unreachable
      end
      local.get 0
      i32.const 131
      i32.add
      i64.extend_i32_u
      local.set 191
      i64.const 2
      local.set 192
      i64.const 0
      local.set 193
      local.get 191
      local.set 194
      local.get 194
      i64.const 4294967295
      i64.and
      local.get 193
      i64.const 8
      i64.mul
      i64.add
      local.tee 195
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2968
        i32.const 74
        i32.const 11
        call 6
        unreachable
      end
      local.get 194
      i64.const -4294967296
      i64.and
      local.get 195
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.get 0
      i32.const 12
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3042
        i32.const 74
        i32.const 11
        call 6
        unreachable
      end
      local.get 0
      i32.const 99
      i32.add
      local.set 196
      i64.const 0
      local.set 197
      block ;; label = @2
        loop ;; label = @3
          local.get 197
          local.get 196
          i64.load offset=8 align=1
          i64.ge_u
          br_if 1 (;@2;)
          local.get 196
          i64.load align=1
          local.set 198
          local.get 198
          i64.const 4294967295
          i64.and
          local.get 197
          i64.const 8
          i64.mul
          i64.add
          local.tee 199
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 3116
            i32.const 74
            i32.const 12
            call 6
            unreachable
          end
          local.get 198
          i64.const -4294967296
          i64.and
          local.get 199
          i64.or
          i32.wrap_i64
          i64.load 6 align=1
          local.set 7
          block ;; label = @4
            local.get 7
            local.tee 200
            i64.eqz
            if ;; label = @5
              i32.const 4
              i32.const 3190
              i32.const 74
              i32.const 12
              call 6
              unreachable
            end
            local.get 200
            call $goose.memory_op.49
            local.set 201
            local.get 201
            i64.const 2
            i64.ge_u
            if ;; label = @5
              i32.const 14
              i32.const 3264
              i32.const 74
              i32.const 12
              call 6
              unreachable
            end
            block ;; label = @5
              local.get 201
              i64.const 0
              i64.eq
              if ;; label = @6
                local.get 0
                i32.const 147
                i32.add
                local.set 202
                local.get 202
                i64.extend_i32_u
                local.set 203
                local.get 200
                i64.const 4294967295
                i64.and
                i64.const 1
                i64.add
                local.tee 45
                i64.const 4294967295
                i64.gt_u
                if ;; label = @7
                  i32.const 11
                  i32.const 3338
                  i32.const 74
                  i32.const 12
                  call 6
                  unreachable
                end
                local.get 200
                i64.const -4294967296
                i64.and
                local.get 45
                i64.or
                local.set 204
                i32.const 11
                local.set 205
                local.get 203
                i32.wrap_i64
                local.get 204
                local.get 205
                call $goose.copy_to_frame
                local.get 0
                i32.const 147
                i32.add
                local.set 206
                local.get 206
                i64.load offset=1 align=1
                local.tee 207
                i64.eqz
                if ;; label = @7
                  i32.const 4
                  i32.const 3412
                  i32.const 74
                  i32.const 1
                  call 6
                  unreachable
                end
                local.get 207
                call $goose.memory_op.41
                i64.const 13
                i64.ge_s
                i32.eqz
                if ;; label = @7
                  i32.const 1
                  i32.const 3486
                  i32.const 74
                  i32.const 12
                  call 6
                  unreachable
                end
                br 1 (;@5;)
              end
              local.get 201
              i64.const 1
              i64.eq
              if ;; label = @6
                i32.const 0
                i32.eqz
                if ;; label = @7
                  i32.const 1
                  i32.const 3560
                  i32.const 74
                  i32.const 12
                  call 6
                  unreachable
                end
                br 1 (;@5;)
              end
            end
          end
          local.get 197
          i64.const 1
          i64.add
          local.set 197
          br 0 (;@3;)
        end
      end
      local.get 5
      local.set 208
      local.get 208
      call $goose.read_array_prefix
      local.set 211
      local.set 209
      i64.const 1
      local.set 210
      local.get 208
      local.set 212
      local.get 212
      i64.const 4294967295
      i64.and
      local.get 211
      i64.extend_i32_u
      i64.add
      local.get 210
      i64.const 8
      i64.mul
      i64.add
      local.tee 213
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3634
        i32.const 74
        i32.const 13
        call 6
        unreachable
      end
      local.get 212
      i64.const -4294967296
      i64.and
      local.get 213
      i64.or
      local.set 214
      local.get 214
      i32.wrap_i64
      i64.load 5 align=1
      local.tee 215
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3708
        i32.const 74
        i32.const 13
        call 6
        unreachable
      end
      local.get 215
      call $goose.memory_op.49
      local.set 216
      local.get 216
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 3782
        i32.const 74
        i32.const 13
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 216
        i64.const 0
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 158
          i32.add
          local.set 217
          local.get 217
          i64.extend_i32_u
          local.set 218
          local.get 215
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.tee 45
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 3856
            i32.const 74
            i32.const 13
            call 6
            unreachable
          end
          local.get 215
          i64.const -4294967296
          i64.and
          local.get 45
          i64.or
          local.set 219
          i32.const 11
          local.set 220
          local.get 218
          i32.wrap_i64
          local.get 219
          local.get 220
          call $goose.copy_to_frame
          local.get 0
          i32.const 158
          i32.add
          local.set 221
          local.get 221
          i64.load offset=1 align=1
          local.tee 222
          i64.eqz
          if ;; label = @4
            i32.const 4
            i32.const 3930
            i32.const 74
            i32.const 1
            call 6
            unreachable
          end
          local.get 222
          call $goose.memory_op.41
          i64.const 24
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 4004
            i32.const 74
            i32.const 13
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 216
        i64.const 1
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 4078
            i32.const 74
            i32.const 13
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
      end
      local.get 4
      local.set 223
      local.get 223
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 224
      i64.const 0
      local.set 225
      local.get 223
      local.set 226
      local.get 226
      i64.const 4294967295
      i64.and
      i64.const 8
      i64.add
      local.get 225
      i64.const 8
      i64.mul
      i64.add
      local.tee 227
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4152
        i32.const 74
        i32.const 14
        call 6
        unreachable
      end
      local.get 226
      i64.const -4294967296
      i64.and
      local.get 227
      i64.or
      local.set 228
      local.get 228
      i32.wrap_i64
      i64.load 4 align=1
      local.tee 229
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4226
        i32.const 74
        i32.const 14
        call 6
        unreachable
      end
      local.get 229
      call $goose.memory_op.49
      local.set 230
      local.get 230
      i64.const 2
      i64.ge_u
      if ;; label = @2
        i32.const 14
        i32.const 4300
        i32.const 74
        i32.const 14
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 230
        i64.const 0
        i64.eq
        if ;; label = @3
          local.get 0
          i32.const 169
          i32.add
          local.set 231
          local.get 231
          i64.extend_i32_u
          local.set 232
          local.get 229
          i64.const 4294967295
          i64.and
          i64.const 1
          i64.add
          local.tee 45
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 4374
            i32.const 74
            i32.const 14
            call 6
            unreachable
          end
          local.get 229
          i64.const -4294967296
          i64.and
          local.get 45
          i64.or
          local.set 233
          i32.const 11
          local.set 234
          local.get 232
          i32.wrap_i64
          local.get 233
          local.get 234
          call $goose.copy_to_frame
          local.get 0
          i32.const 169
          i32.add
          local.set 235
          local.get 235
          i64.load8_u
          i64.const 2
          i64.eq
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 4448
            i32.const 74
            i32.const 14
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
        local.get 230
        i64.const 1
        i64.eq
        if ;; label = @3
          i32.const 0
          i32.eqz
          if ;; label = @4
            i32.const 1
            i32.const 4522
            i32.const 74
            i32.const 14
            call 6
            unreachable
          end
          br 1 (;@2;)
        end
      end
      local.get 1
      local.set 236
      local.get 236
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 237
      i64.const 0
      local.set 238
      local.get 236
      local.set 239
      local.get 239
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 238
      i64.const 8
      i64.mul
      i64.add
      local.tee 240
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4596
        i32.const 74
        i32.const 15
        call 6
        unreachable
      end
      local.get 239
      i64.const -4294967296
      i64.and
      local.get 240
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 13
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4670
        i32.const 74
        i32.const 15
        call 6
        unreachable
      end
      local.get 0
      i32.const 74
      i32.add
      i64.extend_i32_u
      local.set 241
      local.get 241
      i32.wrap_i64
      i64.load8_u
      local.set 242
      local.get 4
      local.set 243
      local.get 243
      i32.wrap_i64
      i64.load32_u 4 offset=4 align=1
      local.set 244
      local.get 0
      i32.const 99
      i32.add
      local.set 245
      local.get 245
      i64.load offset=8 align=1
      local.set 246
      local.get 0
      i32.const 115
      i32.add
      local.set 247
      local.get 247
      i64.load offset=8 align=1
      local.set 248
      call 0
      local.set 249
      local.get 249
      i32.const 4744
      i32.const 7
      call 4
      local.get 249
      local.get 242
      i32.const 0
      call 1
      local.get 249
      i32.const 4751
      i32.const 1
      call 4
      local.get 249
      local.get 244
      i32.const 0
      call 1
      local.get 249
      i32.const 4752
      i32.const 1
      call 4
      local.get 249
      local.get 246
      i32.const 0
      call 1
      local.get 249
      i32.const 4753
      i32.const 1
      call 4
      local.get 249
      local.get 248
      i32.const 0
      call 1
      local.get 249
      call 5
      local.get 121
      global.set 7
      local.get 113
      global.set 6
      local.get 109
      global.set 5
      local.get 106
      global.set 4
      local.get 30
      global.set 3
      local.get 14
      global.set 2
      local.get 9
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.memory_op.49 (;17;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load8_u
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load8_u 1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load8_u 2
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load8_u 3
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u 4
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 5
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 6
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 7
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_to_frame (;18;) (type 1) (param i32 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 1
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      local.get 1
                      i32.wrap_i64
                      local.get 2
                      memory.copy
                      br 8 (;@1;)
                    end
                    local.get 0
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy 0 1
                    br 7 (;@1;)
                  end
                  local.get 0
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 0 2
                  br 6 (;@1;)
                end
                local.get 0
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 0 3
                br 5 (;@1;)
              end
              local.get 0
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 0 4
              br 4 (;@1;)
            end
            local.get 0
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 0 5
            br 3 (;@1;)
          end
          local.get 0
          local.get 1
          i32.wrap_i64
          local.get 2
          memory.copy 0 6
          br 2 (;@1;)
        end
        local.get 0
        local.get 1
        i32.wrap_i64
        local.get 2
        memory.copy 0 7
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;19;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load align=1
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load 1 align=1
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load 2 align=1
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load 3 align=1
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load 4 align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 5 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 6 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 7 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.4 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 4
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 4
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 4
      i32.sub
      memory.grow 4
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 4
    local.get 1
  )
  (func $goose.reserve_memory.5 (;21;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 5
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 5
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 5
      i32.sub
      memory.grow 5
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 5
    local.get 1
  )
  (func $goose.reserve_memory.6 (;22;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 6
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 6
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 6
      i32.sub
      memory.grow 6
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 6
    local.get 1
  )
  (func $goose.reserve_memory.7 (;23;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 7
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 7
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 7
      i32.sub
      memory.grow 7
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 7
    local.get 1
  )
  (func $goose.read_array_prefix (;24;) (type 12) (param i64) (result i64 i32)
    (local i64 i32 i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      block ;; label = @10
                        local.get 0
                        i64.const 32
                        i64.shr_u
                        i32.wrap_i64
                        br_table 0 (;@10;) 1 (;@9;) 2 (;@8;) 3 (;@7;) 4 (;@6;) 5 (;@5;) 6 (;@4;) 7 (;@3;) 8 (;@2;)
                      end
                      local.get 0
                      i32.wrap_i64
                      i64.load8_u
                      local.tee 3
                      i64.const 128
                      i64.lt_u
                      if ;; label = @10
                        local.get 3
                        local.set 1
                        i32.const 1
                        local.set 2
                      else
                        local.get 3
                        i64.const 127
                        i64.and
                        local.set 1
                        i32.const 1
                        local.set 2
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 0
                            i64.const 4294967295
                            i64.and
                            local.get 2
                            i64.extend_i32_u
                            i64.add
                            local.tee 4
                            i64.const 4294967295
                            i64.gt_u
                            if ;; label = @13
                              i32.const 11
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            local.get 4
                            i32.wrap_i64
                            i64.load8_u
                            local.set 3
                            local.get 2
                            i32.const 9
                            i32.eq
                            local.get 3
                            i64.const 1
                            i64.gt_u
                            i32.and
                            local.get 3
                            i64.eqz
                            i32.or
                            if ;; label = @13
                              i32.const 13
                              i32.const 0
                              i32.const 0
                              i32.const 0
                              call 6
                              unreachable
                            end
                            local.get 1
                            local.get 3
                            i64.const 127
                            i64.and
                            local.get 2
                            i32.const 7
                            i32.mul
                            i64.extend_i32_u
                            i64.shl
                            i64.or
                            local.set 1
                            local.get 2
                            i32.const 1
                            i32.add
                            local.set 2
                            local.get 3
                            i64.const 128
                            i64.and
                            i64.eqz
                            br_if 1 (;@11;)
                            br 0 (;@12;)
                          end
                        end
                      end
                      br 8 (;@1;)
                    end
                    local.get 0
                    i32.wrap_i64
                    i64.load8_u 1
                    local.tee 3
                    i64.const 128
                    i64.lt_u
                    if ;; label = @9
                      local.get 3
                      local.set 1
                      i32.const 1
                      local.set 2
                    else
                      local.get 3
                      i64.const 127
                      i64.and
                      local.set 1
                      i32.const 1
                      local.set 2
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 0
                          i64.const 4294967295
                          i64.and
                          local.get 2
                          i64.extend_i32_u
                          i64.add
                          local.tee 4
                          i64.const 4294967295
                          i64.gt_u
                          if ;; label = @12
                            i32.const 11
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          local.get 4
                          i32.wrap_i64
                          i64.load8_u 1
                          local.set 3
                          local.get 2
                          i32.const 9
                          i32.eq
                          local.get 3
                          i64.const 1
                          i64.gt_u
                          i32.and
                          local.get 3
                          i64.eqz
                          i32.or
                          if ;; label = @12
                            i32.const 13
                            i32.const 0
                            i32.const 0
                            i32.const 0
                            call 6
                            unreachable
                          end
                          local.get 1
                          local.get 3
                          i64.const 127
                          i64.and
                          local.get 2
                          i32.const 7
                          i32.mul
                          i64.extend_i32_u
                          i64.shl
                          i64.or
                          local.set 1
                          local.get 2
                          i32.const 1
                          i32.add
                          local.set 2
                          local.get 3
                          i64.const 128
                          i64.and
                          i64.eqz
                          br_if 1 (;@10;)
                          br 0 (;@11;)
                        end
                      end
                    end
                    br 7 (;@1;)
                  end
                  local.get 0
                  i32.wrap_i64
                  i64.load8_u 2
                  local.tee 3
                  i64.const 128
                  i64.lt_u
                  if ;; label = @8
                    local.get 3
                    local.set 1
                    i32.const 1
                    local.set 2
                  else
                    local.get 3
                    i64.const 127
                    i64.and
                    local.set 1
                    i32.const 1
                    local.set 2
                    block ;; label = @9
                      loop ;; label = @10
                        local.get 0
                        i64.const 4294967295
                        i64.and
                        local.get 2
                        i64.extend_i32_u
                        i64.add
                        local.tee 4
                        i64.const 4294967295
                        i64.gt_u
                        if ;; label = @11
                          i32.const 11
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        local.get 4
                        i32.wrap_i64
                        i64.load8_u 2
                        local.set 3
                        local.get 2
                        i32.const 9
                        i32.eq
                        local.get 3
                        i64.const 1
                        i64.gt_u
                        i32.and
                        local.get 3
                        i64.eqz
                        i32.or
                        if ;; label = @11
                          i32.const 13
                          i32.const 0
                          i32.const 0
                          i32.const 0
                          call 6
                          unreachable
                        end
                        local.get 1
                        local.get 3
                        i64.const 127
                        i64.and
                        local.get 2
                        i32.const 7
                        i32.mul
                        i64.extend_i32_u
                        i64.shl
                        i64.or
                        local.set 1
                        local.get 2
                        i32.const 1
                        i32.add
                        local.set 2
                        local.get 3
                        i64.const 128
                        i64.and
                        i64.eqz
                        br_if 1 (;@9;)
                        br 0 (;@10;)
                      end
                    end
                  end
                  br 6 (;@1;)
                end
                local.get 0
                i32.wrap_i64
                i64.load8_u 3
                local.tee 3
                i64.const 128
                i64.lt_u
                if ;; label = @7
                  local.get 3
                  local.set 1
                  i32.const 1
                  local.set 2
                else
                  local.get 3
                  i64.const 127
                  i64.and
                  local.set 1
                  i32.const 1
                  local.set 2
                  block ;; label = @8
                    loop ;; label = @9
                      local.get 0
                      i64.const 4294967295
                      i64.and
                      local.get 2
                      i64.extend_i32_u
                      i64.add
                      local.tee 4
                      i64.const 4294967295
                      i64.gt_u
                      if ;; label = @10
                        i32.const 11
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      local.get 4
                      i32.wrap_i64
                      i64.load8_u 3
                      local.set 3
                      local.get 2
                      i32.const 9
                      i32.eq
                      local.get 3
                      i64.const 1
                      i64.gt_u
                      i32.and
                      local.get 3
                      i64.eqz
                      i32.or
                      if ;; label = @10
                        i32.const 13
                        i32.const 0
                        i32.const 0
                        i32.const 0
                        call 6
                        unreachable
                      end
                      local.get 1
                      local.get 3
                      i64.const 127
                      i64.and
                      local.get 2
                      i32.const 7
                      i32.mul
                      i64.extend_i32_u
                      i64.shl
                      i64.or
                      local.set 1
                      local.get 2
                      i32.const 1
                      i32.add
                      local.set 2
                      local.get 3
                      i64.const 128
                      i64.and
                      i64.eqz
                      br_if 1 (;@8;)
                      br 0 (;@9;)
                    end
                  end
                end
                br 5 (;@1;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u 4
              local.tee 3
              i64.const 128
              i64.lt_u
              if ;; label = @6
                local.get 3
                local.set 1
                i32.const 1
                local.set 2
              else
                local.get 3
                i64.const 127
                i64.and
                local.set 1
                i32.const 1
                local.set 2
                block ;; label = @7
                  loop ;; label = @8
                    local.get 0
                    i64.const 4294967295
                    i64.and
                    local.get 2
                    i64.extend_i32_u
                    i64.add
                    local.tee 4
                    i64.const 4294967295
                    i64.gt_u
                    if ;; label = @9
                      i32.const 11
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 4
                    i32.wrap_i64
                    i64.load8_u 4
                    local.set 3
                    local.get 2
                    i32.const 9
                    i32.eq
                    local.get 3
                    i64.const 1
                    i64.gt_u
                    i32.and
                    local.get 3
                    i64.eqz
                    i32.or
                    if ;; label = @9
                      i32.const 13
                      i32.const 0
                      i32.const 0
                      i32.const 0
                      call 6
                      unreachable
                    end
                    local.get 1
                    local.get 3
                    i64.const 127
                    i64.and
                    local.get 2
                    i32.const 7
                    i32.mul
                    i64.extend_i32_u
                    i64.shl
                    i64.or
                    local.set 1
                    local.get 2
                    i32.const 1
                    i32.add
                    local.set 2
                    local.get 3
                    i64.const 128
                    i64.and
                    i64.eqz
                    br_if 1 (;@7;)
                    br 0 (;@8;)
                  end
                end
              end
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 5
            local.tee 3
            i64.const 128
            i64.lt_u
            if ;; label = @5
              local.get 3
              local.set 1
              i32.const 1
              local.set 2
            else
              local.get 3
              i64.const 127
              i64.and
              local.set 1
              i32.const 1
              local.set 2
              block ;; label = @6
                loop ;; label = @7
                  local.get 0
                  i64.const 4294967295
                  i64.and
                  local.get 2
                  i64.extend_i32_u
                  i64.add
                  local.tee 4
                  i64.const 4294967295
                  i64.gt_u
                  if ;; label = @8
                    i32.const 11
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 4
                  i32.wrap_i64
                  i64.load8_u 5
                  local.set 3
                  local.get 2
                  i32.const 9
                  i32.eq
                  local.get 3
                  i64.const 1
                  i64.gt_u
                  i32.and
                  local.get 3
                  i64.eqz
                  i32.or
                  if ;; label = @8
                    i32.const 13
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 1
                  local.get 3
                  i64.const 127
                  i64.and
                  local.get 2
                  i32.const 7
                  i32.mul
                  i64.extend_i32_u
                  i64.shl
                  i64.or
                  local.set 1
                  local.get 2
                  i32.const 1
                  i32.add
                  local.set 2
                  local.get 3
                  i64.const 128
                  i64.and
                  i64.eqz
                  br_if 1 (;@6;)
                  br 0 (;@7;)
                end
              end
            end
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 6
          local.tee 3
          i64.const 128
          i64.lt_u
          if ;; label = @4
            local.get 3
            local.set 1
            i32.const 1
            local.set 2
          else
            local.get 3
            i64.const 127
            i64.and
            local.set 1
            i32.const 1
            local.set 2
            block ;; label = @5
              loop ;; label = @6
                local.get 0
                i64.const 4294967295
                i64.and
                local.get 2
                i64.extend_i32_u
                i64.add
                local.tee 4
                i64.const 4294967295
                i64.gt_u
                if ;; label = @7
                  i32.const 11
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 4
                i32.wrap_i64
                i64.load8_u 6
                local.set 3
                local.get 2
                i32.const 9
                i32.eq
                local.get 3
                i64.const 1
                i64.gt_u
                i32.and
                local.get 3
                i64.eqz
                i32.or
                if ;; label = @7
                  i32.const 13
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 1
                local.get 3
                i64.const 127
                i64.and
                local.get 2
                i32.const 7
                i32.mul
                i64.extend_i32_u
                i64.shl
                i64.or
                local.set 1
                local.get 2
                i32.const 1
                i32.add
                local.set 2
                local.get 3
                i64.const 128
                i64.and
                i64.eqz
                br_if 1 (;@5;)
                br 0 (;@6;)
              end
            end
          end
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 7
        local.tee 3
        i64.const 128
        i64.lt_u
        if ;; label = @3
          local.get 3
          local.set 1
          i32.const 1
          local.set 2
        else
          local.get 3
          i64.const 127
          i64.and
          local.set 1
          i32.const 1
          local.set 2
          block ;; label = @4
            loop ;; label = @5
              local.get 0
              i64.const 4294967295
              i64.and
              local.get 2
              i64.extend_i32_u
              i64.add
              local.tee 4
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 4
              i32.wrap_i64
              i64.load8_u 7
              local.set 3
              local.get 2
              i32.const 9
              i32.eq
              local.get 3
              i64.const 1
              i64.gt_u
              i32.and
              local.get 3
              i64.eqz
              i32.or
              if ;; label = @6
                i32.const 13
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 1
              local.get 3
              i64.const 127
              i64.and
              local.get 2
              i32.const 7
              i32.mul
              i64.extend_i32_u
              i64.shl
              i64.or
              local.set 1
              local.get 2
              i32.const 1
              i32.add
              local.set 2
              local.get 3
              i64.const 128
              i64.and
              i64.eqz
              br_if 1 (;@4;)
              br 0 (;@5;)
            end
          end
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 1
    local.get 2
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_enum_containers.goosepacked=,,,")
)
