(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (global (;0;) (mut i32) i32.const 2496)
  (global (;1;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 99
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 107
        i32.const 99
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    i32.const 16
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 2
      local.get 2
      i32.const 0
      i32.add
      i64.const 7
      i64.store align=1
      local.get 2
      i32.const 8
      i32.add
      i64.const -8
      i64.store align=1
      i32.const 1
      local.set 3
      i32.const 2057
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i64.const 1
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store32 1 align=1
      local.get 5
      i32.wrap_i64
      i64.const 7
      i64.store8 1 offset=4
      local.get 5
      i64.const 0
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=5 align=1
      i64.const 1
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load16_u 1 offset=5 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 206
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 305
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 8
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 404
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=5 align=1
      i64.const 2
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load16_u 1 offset=5 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 503
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 602
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 8
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 701
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=5 align=1
      i64.const 3
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load16_u 1 offset=5 align=1
      local.set 8
      local.get 8
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 800
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 899
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 2
      i64.add
      local.get 8
      i64.const 8
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 998
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store 1 align=1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=5 align=1
      local.get 5
      i32.wrap_i64
      i64.const 65000
      i64.store16 1 offset=2055 align=1
      call 0
      local.set 13
      local.get 13
      i32.const 1097
      i32.const 6
      call 4
      local.get 13
      call 5
      local.get 1
      local.set 14
      local.get 14
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 15
      i64.const 0
      local.set 16
      local.get 14
      local.set 17
      local.get 17
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 16
      i64.const 2053
      i64.mul
      i64.add
      local.tee 18
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1103
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 17
      i64.const -4294967296
      i64.and
      local.get 18
      i64.or
      local.set 19
      local.get 0
      i32.const 0
      i32.add
      local.set 20
      local.get 19
      i32.wrap_i64
      i32.const 3
      i32.add
      local.get 20
      i32.const 16
      memory.copy 1 0
      local.get 19
      i64.const 2
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store16 1 offset=1 align=1
      call 0
      local.set 21
      local.get 21
      i32.const 1202
      i32.const 5
      call 4
      local.get 21
      call 5
      local.get 1
      local.set 22
      local.get 22
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 23
      i64.const 0
      local.set 24
      local.get 22
      local.set 25
      local.get 25
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 24
      i64.const 2053
      i64.mul
      i64.add
      local.tee 26
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1207
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 25
      i64.const -4294967296
      i64.and
      local.get 26
      i64.or
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1306
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 28
      local.get 28
      i32.wrap_i64
      i64.load16_u 1 align=1
      i64.const 2
      i64.eq
      if (result i32) ;; label = @2
        local.get 1
        local.set 29
        local.get 29
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 30
        i64.const 0
        local.set 31
        local.get 29
        local.set 32
        local.get 32
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 31
        i64.const 2053
        i64.mul
        i64.add
        local.tee 33
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1405
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 32
        i64.const -4294967296
        i64.and
        local.get 33
        i64.or
        local.set 34
        local.get 34
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.tee 12
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1504
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 34
        i64.const -4294967296
        i64.and
        local.get 12
        i64.or
        local.set 35
        local.get 35
        i32.wrap_i64
        i64.load16_u 1 align=1
        local.set 36
        i64.const 0
        local.set 37
        local.get 37
        local.get 36
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 1603
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 35
        local.set 38
        local.get 38
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 37
        i64.const 8
        i64.mul
        i64.add
        local.tee 39
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1702
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 38
        i64.const -4294967296
        i64.and
        local.get 39
        i64.or
        i32.wrap_i64
        i64.load 1 align=1
        i64.const 7
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 1
        local.set 40
        local.get 40
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 41
        i64.const 0
        local.set 42
        local.get 40
        local.set 43
        local.get 43
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 42
        i64.const 2053
        i64.mul
        i64.add
        local.tee 44
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1801
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 43
        i64.const -4294967296
        i64.and
        local.get 44
        i64.or
        local.set 45
        local.get 45
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.tee 12
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1900
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 45
        i64.const -4294967296
        i64.and
        local.get 12
        i64.or
        local.set 46
        local.get 46
        i32.wrap_i64
        i64.load16_u 1 align=1
        local.set 47
        i64.const 1
        local.set 48
        local.get 48
        local.get 47
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 1999
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 46
        local.set 49
        local.get 49
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 48
        i64.const 8
        i64.mul
        i64.add
        local.tee 50
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2098
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 49
        i64.const -4294967296
        i64.and
        local.get 50
        i64.or
        i32.wrap_i64
        i64.load 1 align=1
        i64.const -8
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 1
        local.set 51
        local.get 51
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 52
        i64.const 0
        local.set 53
        local.get 51
        local.set 54
        local.get 54
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 53
        i64.const 2053
        i64.mul
        i64.add
        local.tee 55
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2197
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 54
        i64.const -4294967296
        i64.and
        local.get 55
        i64.or
        local.set 56
        local.get 56
        i32.wrap_i64
        i64.load8_u 1
        i64.const 7
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 1
        local.set 57
        local.get 57
        i32.wrap_i64
        i64.load32_u 1 align=1
        local.set 58
        i64.const 0
        local.set 59
        local.get 57
        local.set 60
        local.get 60
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 59
        i64.const 2053
        i64.mul
        i64.add
        local.tee 61
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 2296
          i32.const 99
          i32.const 1
          call 6
          unreachable
        end
        local.get 60
        i64.const -4294967296
        i64.and
        local.get 61
        i64.or
        local.set 62
        local.get 62
        i32.wrap_i64
        i64.load16_u 1 offset=2051 align=1
        i64.const 65000
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2395
        i32.const 99
        i32.const 1
        call 6
        unreachable
      end
      local.get 4
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goosebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.gooseafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_array_assignment_layout_owner_data.goose")
)
