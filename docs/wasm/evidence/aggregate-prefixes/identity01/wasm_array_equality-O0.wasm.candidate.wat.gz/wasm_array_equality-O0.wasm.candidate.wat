(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32 i32) (result i32)))
  (type (;12;) (func (param i64 i64) (result i32)))
  (type (;13;) (func (param i64) (result i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 4032)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 73
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 81
        i32.const 73
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i32 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 f64 f64 i64 i64 i64 i64 i64 i64 f64 f64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32)
    i32.const 190
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      i32.const 0
      i32.add
      i64.const 1
      i64.store align=1
      local.get 3
      i32.const 8
      i32.add
      i64.const 2
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 4
      local.get 4
      i32.const 0
      i32.add
      i64.const 1
      i64.store align=1
      local.get 4
      i32.const 8
      i32.add
      i64.const 2
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 5
      i64.const 2
      local.set 6
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 7
      i32.const 0
      local.set 8
      local.get 6
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 8
        i64.const 0
        local.set 9
        block ;; label = @3
          loop ;; label = @4
            local.get 9
            local.get 6
            i64.ge_u
            br_if 1 (;@3;)
            local.get 5
            local.set 10
            local.get 10
            i64.const 4294967295
            i64.and
            local.get 9
            i64.const 8
            i64.mul
            i64.add
            local.tee 11
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 154
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 10
            i64.const -4294967296
            i64.and
            local.get 11
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 7
            local.set 12
            local.get 12
            i64.const 4294967295
            i64.and
            local.get 9
            i64.const 8
            i64.mul
            i64.add
            local.tee 13
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 227
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 12
            i64.const -4294967296
            i64.and
            local.get 13
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 8
              br 2 (;@3;)
            end
            local.get 9
            i64.const 1
            i64.add
            local.set 9
            br 0 (;@4;)
          end
        end
      end
      local.get 8
      local.set 14
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 15
      i64.const 2
      local.set 16
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 17
      i32.const 0
      local.set 18
      local.get 16
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 18
        i64.const 0
        local.set 19
        block ;; label = @3
          loop ;; label = @4
            local.get 19
            local.get 16
            i64.ge_u
            br_if 1 (;@3;)
            local.get 15
            local.set 20
            local.get 20
            i64.const 4294967295
            i64.and
            local.get 19
            i64.const 8
            i64.mul
            i64.add
            local.tee 21
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 300
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 20
            i64.const -4294967296
            i64.and
            local.get 21
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 17
            local.set 22
            local.get 22
            i64.const 4294967295
            i64.and
            local.get 19
            i64.const 8
            i64.mul
            i64.add
            local.tee 23
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 373
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 22
            i64.const -4294967296
            i64.and
            local.get 23
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 18
              br 2 (;@3;)
            end
            local.get 19
            i64.const 1
            i64.add
            local.set 19
            br 0 (;@4;)
          end
        end
      end
      local.get 18
      i32.eqz
      local.set 24
      call 0
      local.set 25
      local.get 25
      local.get 14
      call 3
      local.get 25
      i32.const 446
      i32.const 1
      call 4
      local.get 25
      local.get 24
      call 3
      local.get 25
      call 5
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 26
      i64.const 2
      local.set 27
      i64.const 1
      local.set 28
      local.get 26
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      local.get 28
      i64.const 8
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 447
        i32.const 73
        i32.const 5
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      local.set 31
      i64.const 9
      local.set 32
      local.get 31
      local.get 32
      local.set 33
      i32.wrap_i64
      local.get 33
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 34
      i64.const 2
      local.set 35
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 36
      i32.const 0
      local.set 37
      local.get 35
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 37
        i64.const 0
        local.set 38
        block ;; label = @3
          loop ;; label = @4
            local.get 38
            local.get 35
            i64.ge_u
            br_if 1 (;@3;)
            local.get 34
            local.set 39
            local.get 39
            i64.const 4294967295
            i64.and
            local.get 38
            i64.const 8
            i64.mul
            i64.add
            local.tee 40
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 520
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 39
            i64.const -4294967296
            i64.and
            local.get 40
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 36
            local.set 41
            local.get 41
            i64.const 4294967295
            i64.and
            local.get 38
            i64.const 8
            i64.mul
            i64.add
            local.tee 42
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 593
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 41
            i64.const -4294967296
            i64.and
            local.get 42
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 37
              br 2 (;@3;)
            end
            local.get 38
            i64.const 1
            i64.add
            local.set 38
            br 0 (;@4;)
          end
        end
      end
      local.get 37
      local.set 43
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 44
      i64.const 2
      local.set 45
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 46
      i32.const 0
      local.set 47
      local.get 45
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 47
        i64.const 0
        local.set 48
        block ;; label = @3
          loop ;; label = @4
            local.get 48
            local.get 45
            i64.ge_u
            br_if 1 (;@3;)
            local.get 44
            local.set 49
            local.get 49
            i64.const 4294967295
            i64.and
            local.get 48
            i64.const 8
            i64.mul
            i64.add
            local.tee 50
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 666
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 49
            i64.const -4294967296
            i64.and
            local.get 50
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 46
            local.set 51
            local.get 51
            i64.const 4294967295
            i64.and
            local.get 48
            i64.const 8
            i64.mul
            i64.add
            local.tee 52
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 739
              i32.const 73
              i32.const 5
              call 6
              unreachable
            end
            local.get 51
            i64.const -4294967296
            i64.and
            local.get 52
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 47
              br 2 (;@3;)
            end
            local.get 48
            i64.const 1
            i64.add
            local.set 48
            br 0 (;@4;)
          end
        end
      end
      local.get 47
      i32.eqz
      local.set 53
      call 0
      local.set 54
      local.get 54
      local.get 43
      call 3
      local.get 54
      i32.const 812
      i32.const 1
      call 4
      local.get 54
      local.get 53
      call 3
      local.get 54
      call 5
      local.get 0
      i32.const 32
      i32.add
      local.set 55
      local.get 55
      i64.const 0
      i64.store8
      i64.const 1
      local.set 56
      local.get 55
      i64.load8_u
      local.set 57
      local.get 57
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 813
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 55
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 59
      local.get 59
      i64.const 4294967295
      i64.and
      local.get 57
      i64.const 1
      i64.mul
      i64.add
      local.tee 60
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 886
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 59
      i64.const -4294967296
      i64.and
      local.get 60
      i64.or
      local.tee 61
      local.get 56
      local.set 62
      i32.wrap_i64
      local.get 62
      i64.store8
      local.get 55
      local.get 57
      i64.const 1
      i64.add
      i64.store8
      i64.const 2
      local.set 63
      local.get 55
      i64.load8_u
      local.set 64
      local.get 64
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 959
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 55
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 66
      local.get 66
      i64.const 4294967295
      i64.and
      local.get 64
      i64.const 1
      i64.mul
      i64.add
      local.tee 67
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1032
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 66
      i64.const -4294967296
      i64.and
      local.get 67
      i64.or
      local.tee 68
      local.get 63
      local.set 69
      i32.wrap_i64
      local.get 69
      i64.store8
      local.get 55
      local.get 64
      i64.const 1
      i64.add
      i64.store8
      local.get 55
      i32.const 3
      i32.add
      i32.const 0
      i32.const 1
      memory.fill
      local.get 0
      i32.const 36
      i32.add
      local.set 70
      local.get 70
      i64.const 0
      i64.store8
      i64.const 1
      local.set 71
      local.get 70
      i64.load8_u
      local.set 72
      local.get 72
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1105
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 70
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 74
      local.get 74
      i64.const 4294967295
      i64.and
      local.get 72
      i64.const 1
      i64.mul
      i64.add
      local.tee 75
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1178
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 74
      i64.const -4294967296
      i64.and
      local.get 75
      i64.or
      local.tee 76
      local.get 71
      local.set 77
      i32.wrap_i64
      local.get 77
      i64.store8
      local.get 70
      local.get 72
      i64.const 1
      i64.add
      i64.store8
      i64.const 2
      local.set 78
      local.get 70
      i64.load8_u
      local.set 79
      local.get 79
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 1251
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 70
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 81
      local.get 81
      i64.const 4294967295
      i64.and
      local.get 79
      i64.const 1
      i64.mul
      i64.add
      local.tee 82
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1324
        i32.const 73
        i32.const 6
        call 6
        unreachable
      end
      local.get 81
      i64.const -4294967296
      i64.and
      local.get 82
      i64.or
      local.tee 83
      local.get 78
      local.set 84
      i32.wrap_i64
      local.get 84
      i64.store8
      local.get 70
      local.get 79
      i64.const 1
      i64.add
      i64.store8
      local.get 70
      i32.const 3
      i32.add
      i32.const 0
      i32.const 1
      memory.fill
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 85
      local.get 85
      i32.wrap_i64
      i64.load8_u
      local.set 86
      local.get 0
      i32.const 36
      i32.add
      i64.extend_i32_u
      local.set 87
      i32.const 0
      local.set 88
      local.get 86
      local.get 87
      i32.wrap_i64
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 88
        i64.const 0
        local.set 89
        block ;; label = @3
          loop ;; label = @4
            local.get 89
            local.get 86
            i64.ge_u
            br_if 1 (;@3;)
            local.get 85
            local.set 90
            local.get 90
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 89
            i64.const 1
            i64.mul
            i64.add
            local.tee 91
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1397
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 90
            i64.const -4294967296
            i64.and
            local.get 91
            i64.or
            i32.wrap_i64
            i64.load8_u
            local.get 87
            local.set 92
            local.get 92
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 89
            i64.const 1
            i64.mul
            i64.add
            local.tee 93
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1470
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 92
            i64.const -4294967296
            i64.and
            local.get 93
            i64.or
            i32.wrap_i64
            i64.load8_u
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 88
              br 2 (;@3;)
            end
            local.get 89
            i64.const 1
            i64.add
            local.set 89
            br 0 (;@4;)
          end
        end
      end
      local.get 88
      local.set 94
      call 0
      local.set 95
      local.get 95
      local.get 94
      call 3
      local.get 95
      call 5
      local.get 0
      i32.const 36
      i32.add
      i64.extend_i32_u
      local.set 96
      local.get 96
      i32.wrap_i64
      i64.load8_u
      local.set 97
      local.get 97
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 1543
        i32.const 73
        i32.const 7
        call 6
        unreachable
      end
      local.get 97
      i64.const 1
      i64.sub
      local.set 97
      local.get 96
      local.set 98
      local.get 98
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 97
      i64.const 1
      i64.mul
      i64.add
      local.tee 99
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1616
        i32.const 73
        i32.const 7
        call 6
        unreachable
      end
      local.get 98
      i64.const -4294967296
      i64.and
      local.get 99
      i64.or
      local.set 100
      local.get 100
      i32.wrap_i64
      i64.load8_u
      local.set 101
      local.get 96
      local.get 97
      local.set 102
      i32.wrap_i64
      local.get 102
      i64.store8
      local.get 101
      drop
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 103
      local.get 103
      i32.wrap_i64
      i64.load8_u
      local.set 104
      local.get 0
      i32.const 36
      i32.add
      i64.extend_i32_u
      local.set 105
      i32.const 0
      local.set 106
      local.get 104
      local.get 105
      i32.wrap_i64
      i64.load8_u
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 106
        i64.const 0
        local.set 107
        block ;; label = @3
          loop ;; label = @4
            local.get 107
            local.get 104
            i64.ge_u
            br_if 1 (;@3;)
            local.get 103
            local.set 108
            local.get 108
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 107
            i64.const 1
            i64.mul
            i64.add
            local.tee 109
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1689
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 108
            i64.const -4294967296
            i64.and
            local.get 109
            i64.or
            i32.wrap_i64
            i64.load8_u
            local.get 105
            local.set 110
            local.get 110
            i64.const 4294967295
            i64.and
            i64.const 1
            i64.add
            local.get 107
            i64.const 1
            i64.mul
            i64.add
            local.tee 111
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1762
              i32.const 73
              i32.const 7
              call 6
              unreachable
            end
            local.get 110
            i64.const -4294967296
            i64.and
            local.get 111
            i64.or
            i32.wrap_i64
            i64.load8_u
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 106
              br 2 (;@3;)
            end
            local.get 107
            i64.const 1
            i64.add
            local.set 107
            br 0 (;@4;)
          end
        end
      end
      local.get 106
      local.set 112
      call 0
      local.set 113
      local.get 113
      local.get 112
      call 3
      local.get 113
      call 5
      i32.const 1
      local.set 114
      global.get 1
      local.set 115
      local.get 0
      i32.const 40
      i32.add
      local.set 116
      local.get 116
      local.get 114
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 115
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 116
      i64.const 0
      i64.store offset=8 align=1
      i64.const 1
      local.set 117
      local.get 116
      i64.load offset=8 align=1
      local.set 118
      i32.const 8
      call $goose.reserve_memory.1
      local.set 119
      local.get 116
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 119
      i64.extend_i32_u
      i64.or
      local.tee 120
      local.get 117
      local.set 121
      i32.wrap_i64
      local.get 121
      i64.store 1 align=1
      local.get 116
      local.get 118
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i64.const 2
      local.set 122
      local.get 116
      i64.load offset=8 align=1
      local.set 123
      i32.const 8
      call $goose.reserve_memory.1
      local.set 124
      local.get 116
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 124
      i64.extend_i32_u
      i64.or
      local.tee 125
      local.get 122
      local.set 126
      i32.wrap_i64
      local.get 126
      i64.store 1 align=1
      local.get 116
      local.get 123
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i32.const 2
      local.set 127
      global.get 2
      local.set 128
      local.get 0
      i32.const 56
      i32.add
      local.set 129
      local.get 129
      local.get 127
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 128
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 129
      i64.const 0
      i64.store offset=8 align=1
      i64.const 1
      local.set 130
      local.get 129
      i64.load offset=8 align=1
      local.set 131
      i32.const 8
      call $goose.reserve_memory.2
      local.set 132
      local.get 129
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 132
      i64.extend_i32_u
      i64.or
      local.tee 133
      local.get 130
      local.set 134
      i32.wrap_i64
      local.get 134
      i64.store 2 align=1
      local.get 129
      local.get 131
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      i64.const 2
      local.set 135
      local.get 129
      i64.load offset=8 align=1
      local.set 136
      i32.const 8
      call $goose.reserve_memory.2
      local.set 137
      local.get 129
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 137
      i64.extend_i32_u
      i64.or
      local.tee 138
      local.get 135
      local.set 139
      i32.wrap_i64
      local.get 139
      i64.store 2 align=1
      local.get 129
      local.get 136
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 40
      i32.add
      local.set 140
      local.get 140
      i64.load offset=8 align=1
      local.set 141
      local.get 0
      i32.const 56
      i32.add
      local.set 142
      i32.const 0
      local.set 143
      local.get 141
      local.get 142
      i64.load offset=8 align=1
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 143
        i64.const 0
        local.set 144
        block ;; label = @3
          loop ;; label = @4
            local.get 144
            local.get 141
            i64.ge_u
            br_if 1 (;@3;)
            local.get 140
            i64.load align=1
            local.set 145
            local.get 145
            i64.const 4294967295
            i64.and
            local.get 144
            i64.const 8
            i64.mul
            i64.add
            local.tee 146
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1835
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 145
            i64.const -4294967296
            i64.and
            local.get 146
            i64.or
            i32.wrap_i64
            i64.load 1 align=1
            local.get 142
            i64.load align=1
            local.set 147
            local.get 147
            i64.const 4294967295
            i64.and
            local.get 144
            i64.const 8
            i64.mul
            i64.add
            local.tee 148
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1908
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 147
            i64.const -4294967296
            i64.and
            local.get 148
            i64.or
            i32.wrap_i64
            i64.load 2 align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 143
              br 2 (;@3;)
            end
            local.get 144
            i64.const 1
            i64.add
            local.set 144
            br 0 (;@4;)
          end
        end
      end
      local.get 143
      local.set 149
      local.get 0
      i32.const 40
      i32.add
      local.get 0
      i32.const 56
      i32.add
      call $same.1
      local.set 150
      call 0
      local.set 151
      local.get 151
      local.get 149
      call 3
      local.get 151
      i32.const 1981
      i32.const 1
      call 4
      local.get 151
      local.get 150
      call 3
      local.get 151
      call 5
      local.get 0
      i32.const 56
      i32.add
      local.set 152
      i64.const 3
      local.set 153
      local.get 152
      i64.load offset=8 align=1
      local.set 154
      i32.const 8
      call $goose.reserve_memory.2
      local.set 155
      local.get 152
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 155
      i64.extend_i32_u
      i64.or
      local.tee 156
      local.get 153
      local.set 157
      i32.wrap_i64
      local.get 157
      i64.store 2 align=1
      local.get 152
      local.get 154
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 156
      i32.wrap_i64
      i64.load 2 align=1
      drop
      local.get 0
      i32.const 40
      i32.add
      local.set 158
      local.get 158
      i64.load offset=8 align=1
      local.set 159
      local.get 0
      i32.const 56
      i32.add
      local.set 160
      i32.const 0
      local.set 161
      local.get 159
      local.get 160
      i64.load offset=8 align=1
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 161
        i64.const 0
        local.set 162
        block ;; label = @3
          loop ;; label = @4
            local.get 162
            local.get 159
            i64.ge_u
            br_if 1 (;@3;)
            local.get 158
            i64.load align=1
            local.set 163
            local.get 163
            i64.const 4294967295
            i64.and
            local.get 162
            i64.const 8
            i64.mul
            i64.add
            local.tee 164
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 1982
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 163
            i64.const -4294967296
            i64.and
            local.get 164
            i64.or
            i32.wrap_i64
            i64.load 1 align=1
            local.get 160
            i64.load align=1
            local.set 165
            local.get 165
            i64.const 4294967295
            i64.and
            local.get 162
            i64.const 8
            i64.mul
            i64.add
            local.tee 166
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2055
              i32.const 73
              i32.const 9
              call 6
              unreachable
            end
            local.get 165
            i64.const -4294967296
            i64.and
            local.get 166
            i64.or
            i32.wrap_i64
            i64.load 2 align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 161
              br 2 (;@3;)
            end
            local.get 162
            i64.const 1
            i64.add
            local.set 162
            br 0 (;@4;)
          end
        end
      end
      local.get 161
      local.set 167
      local.get 0
      i32.const 40
      i32.add
      local.get 0
      i32.const 56
      i32.add
      call $same.1
      local.set 168
      call 0
      local.set 169
      local.get 169
      local.get 167
      call 3
      local.get 169
      i32.const 2128
      i32.const 1
      call 4
      local.get 169
      local.get 168
      call 3
      local.get 169
      call 5
      i64.const 4
      local.set 170
      local.get 0
      i32.const 72
      i32.add
      local.get 170
      i64.store align=1
      i64.const 4
      local.set 171
      local.get 0
      i32.const 80
      i32.add
      local.get 171
      i64.store align=1
      local.get 0
      i32.const 88
      i32.add
      local.set 172
      local.get 172
      i32.const 0
      i32.add
      local.get 0
      i32.const 72
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 172
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 173
      i64.const 2
      local.set 174
      i64.const 0
      local.set 175
      local.get 173
      local.set 176
      local.get 176
      i64.const 4294967295
      i64.and
      local.get 175
      i64.const 8
      i64.mul
      i64.add
      local.tee 177
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2129
        i32.const 73
        i32.const 11
        call 6
        unreachable
      end
      local.get 176
      i64.const -4294967296
      i64.and
      local.get 177
      i64.or
      i64.store align=1
      local.get 0
      i32.const 104
      i32.add
      local.set 178
      local.get 178
      i32.const 0
      i32.add
      local.get 0
      i32.const 72
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 178
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 179
      i64.const 2
      local.set 180
      i64.const 0
      local.set 181
      local.get 179
      local.set 182
      local.get 182
      i64.const 4294967295
      i64.and
      local.get 181
      i64.const 8
      i64.mul
      i64.add
      local.tee 183
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2202
        i32.const 73
        i32.const 11
        call 6
        unreachable
      end
      local.get 182
      i64.const -4294967296
      i64.and
      local.get 183
      i64.or
      i64.store align=1
      local.get 0
      i32.const 120
      i32.add
      local.set 184
      local.get 184
      i32.const 0
      i32.add
      local.get 0
      i32.const 80
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 184
      i32.const 8
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 185
      i64.const 2
      local.set 186
      i64.const 0
      local.set 187
      local.get 185
      local.set 188
      local.get 188
      i64.const 4294967295
      i64.and
      local.get 187
      i64.const 8
      i64.mul
      i64.add
      local.tee 189
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2275
        i32.const 73
        i32.const 12
        call 6
        unreachable
      end
      local.get 188
      i64.const -4294967296
      i64.and
      local.get 189
      i64.or
      i64.store align=1
      local.get 0
      i32.const 88
      i32.add
      i64.extend_i32_u
      local.set 190
      i64.const 2
      local.set 191
      local.get 0
      i32.const 104
      i32.add
      i64.extend_i32_u
      local.set 192
      i32.const 0
      local.set 193
      local.get 191
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 193
        i64.const 0
        local.set 194
        block ;; label = @3
          loop ;; label = @4
            local.get 194
            local.get 191
            i64.ge_u
            br_if 1 (;@3;)
            local.get 190
            local.set 195
            local.get 195
            i64.const 4294967295
            i64.and
            local.get 194
            i64.const 8
            i64.mul
            i64.add
            local.tee 196
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2348
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 195
            i64.const -4294967296
            i64.and
            local.get 196
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 192
            local.set 197
            local.get 197
            i64.const 4294967295
            i64.and
            local.get 194
            i64.const 8
            i64.mul
            i64.add
            local.tee 198
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2421
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 197
            i64.const -4294967296
            i64.and
            local.get 198
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 193
              br 2 (;@3;)
            end
            local.get 194
            i64.const 1
            i64.add
            local.set 194
            br 0 (;@4;)
          end
        end
      end
      local.get 193
      local.set 199
      local.get 0
      i32.const 88
      i32.add
      i64.extend_i32_u
      local.set 200
      i64.const 2
      local.set 201
      local.get 0
      i32.const 120
      i32.add
      i64.extend_i32_u
      local.set 202
      i32.const 0
      local.set 203
      local.get 201
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 203
        i64.const 0
        local.set 204
        block ;; label = @3
          loop ;; label = @4
            local.get 204
            local.get 201
            i64.ge_u
            br_if 1 (;@3;)
            local.get 200
            local.set 205
            local.get 205
            i64.const 4294967295
            i64.and
            local.get 204
            i64.const 8
            i64.mul
            i64.add
            local.tee 206
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2494
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 205
            i64.const -4294967296
            i64.and
            local.get 206
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 202
            local.set 207
            local.get 207
            i64.const 4294967295
            i64.and
            local.get 204
            i64.const 8
            i64.mul
            i64.add
            local.tee 208
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2567
              i32.const 73
              i32.const 13
              call 6
              unreachable
            end
            local.get 207
            i64.const -4294967296
            i64.and
            local.get 208
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 203
              br 2 (;@3;)
            end
            local.get 204
            i64.const 1
            i64.add
            local.set 204
            br 0 (;@4;)
          end
        end
      end
      local.get 203
      local.set 209
      call 0
      local.set 210
      local.get 210
      local.get 199
      call 3
      local.get 210
      i32.const 2640
      i32.const 1
      call 4
      local.get 210
      local.get 209
      call 3
      local.get 210
      call 5
      local.get 0
      i32.const 136
      i32.add
      local.set 211
      local.get 211
      i32.const 0
      i32.add
      f64.const -0x0p+0 (;=-0;)
      f64.store align=1
      local.get 211
      i32.const 8
      i32.add
      f64.const 0x1.4p+1 (;=2.5;)
      f64.store align=1
      local.get 0
      i32.const 152
      i32.add
      local.set 212
      local.get 212
      i32.const 0
      i32.add
      f64.const 0x0p+0 (;=0;)
      f64.store align=1
      local.get 212
      i32.const 8
      i32.add
      f64.const 0x1.4p+1 (;=2.5;)
      f64.store align=1
      local.get 0
      i32.const 136
      i32.add
      i64.extend_i32_u
      local.set 213
      i64.const 2
      local.set 214
      local.get 0
      i32.const 152
      i32.add
      i64.extend_i32_u
      local.set 215
      i32.const 0
      local.set 216
      local.get 214
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 216
        i64.const 0
        local.set 217
        block ;; label = @3
          loop ;; label = @4
            local.get 217
            local.get 214
            i64.ge_u
            br_if 1 (;@3;)
            local.get 213
            local.set 218
            local.get 218
            i64.const 4294967295
            i64.and
            local.get 217
            i64.const 8
            i64.mul
            i64.add
            local.tee 219
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2641
              i32.const 73
              i32.const 15
              call 6
              unreachable
            end
            local.get 218
            i64.const -4294967296
            i64.and
            local.get 219
            i64.or
            i32.wrap_i64
            f64.load align=1
            local.get 215
            local.set 220
            local.get 220
            i64.const 4294967295
            i64.and
            local.get 217
            i64.const 8
            i64.mul
            i64.add
            local.tee 221
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2714
              i32.const 73
              i32.const 15
              call 6
              unreachable
            end
            local.get 220
            i64.const -4294967296
            i64.and
            local.get 221
            i64.or
            i32.wrap_i64
            f64.load align=1
            f64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 216
              br 2 (;@3;)
            end
            local.get 217
            i64.const 1
            i64.add
            local.set 217
            br 0 (;@4;)
          end
        end
      end
      local.get 216
      local.set 222
      call 0
      local.set 223
      local.get 223
      local.get 222
      call 3
      local.get 223
      call 5
      local.get 0
      i32.const 136
      i32.add
      i64.extend_i32_u
      local.set 224
      i64.const 2
      local.set 225
      i64.const 1
      local.set 226
      local.get 224
      local.set 227
      local.get 227
      i64.const 4294967295
      i64.and
      local.get 226
      i64.const 8
      i64.mul
      i64.add
      local.tee 228
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2787
        i32.const 73
        i32.const 15
        call 6
        unreachable
      end
      local.get 227
      i64.const -4294967296
      i64.and
      local.get 228
      i64.or
      local.set 229
      f64.const -nan (;=NaN;)
      local.set 230
      local.get 229
      local.get 230
      local.set 231
      i32.wrap_i64
      local.get 231
      f64.store align=1
      local.get 0
      i32.const 152
      i32.add
      i64.extend_i32_u
      local.set 232
      i64.const 2
      local.set 233
      i64.const 1
      local.set 234
      local.get 232
      local.set 235
      local.get 235
      i64.const 4294967295
      i64.and
      local.get 234
      i64.const 8
      i64.mul
      i64.add
      local.tee 236
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2860
        i32.const 73
        i32.const 15
        call 6
        unreachable
      end
      local.get 235
      i64.const -4294967296
      i64.and
      local.get 236
      i64.or
      local.set 237
      f64.const -nan (;=NaN;)
      local.set 238
      local.get 237
      local.get 238
      local.set 239
      i32.wrap_i64
      local.get 239
      f64.store align=1
      local.get 0
      i32.const 136
      i32.add
      i64.extend_i32_u
      local.set 240
      i64.const 2
      local.set 241
      local.get 0
      i32.const 152
      i32.add
      i64.extend_i32_u
      local.set 242
      i32.const 0
      local.set 243
      local.get 241
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 243
        i64.const 0
        local.set 244
        block ;; label = @3
          loop ;; label = @4
            local.get 244
            local.get 241
            i64.ge_u
            br_if 1 (;@3;)
            local.get 240
            local.set 245
            local.get 245
            i64.const 4294967295
            i64.and
            local.get 244
            i64.const 8
            i64.mul
            i64.add
            local.tee 246
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 2933
              i32.const 73
              i32.const 16
              call 6
              unreachable
            end
            local.get 245
            i64.const -4294967296
            i64.and
            local.get 246
            i64.or
            i32.wrap_i64
            f64.load align=1
            local.get 242
            local.set 247
            local.get 247
            i64.const 4294967295
            i64.and
            local.get 244
            i64.const 8
            i64.mul
            i64.add
            local.tee 248
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3006
              i32.const 73
              i32.const 16
              call 6
              unreachable
            end
            local.get 247
            i64.const -4294967296
            i64.and
            local.get 248
            i64.or
            i32.wrap_i64
            f64.load align=1
            f64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 243
              br 2 (;@3;)
            end
            local.get 244
            i64.const 1
            i64.add
            local.set 244
            br 0 (;@4;)
          end
        end
      end
      local.get 243
      local.set 249
      call 0
      local.set 250
      local.get 250
      local.get 249
      call 3
      local.get 250
      call 5
      i64.const 0
      local.set 1
      i64.const 0
      local.set 2
      local.get 1
      local.get 2
      call $optional_same.2
      local.set 251
      call 0
      local.set 252
      local.get 252
      local.get 251
      call 3
      local.get 252
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 1
      local.get 1
      local.get 2
      call $optional_same.3
      local.set 253
      call 0
      local.set 254
      local.get 254
      local.get 253
      call 3
      local.get 254
      call 5
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 2
      local.get 1
      local.get 2
      call $optional_same.4
      local.set 255
      call 0
      local.set 256
      local.get 256
      local.get 255
      call 3
      local.get 256
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 2
      local.get 1
      local.get 2
      call $optional_same.5
      local.set 257
      call 0
      local.set 258
      local.get 258
      local.get 257
      call 3
      local.get 258
      call 5
      local.get 0
      i32.const 168
      i32.add
      local.set 259
      local.get 259
      i32.const 0
      i32.add
      f32.const -0x0p+0 (;=-0;)
      f32.store align=1
      local.get 259
      i32.const 4
      i32.add
      f32.const 0x1.8p+0 (;=1.5;)
      f32.store align=1
      local.get 0
      i32.const 176
      i32.add
      local.set 260
      local.get 260
      i32.const 0
      i32.add
      f32.const 0x0p+0 (;=0;)
      f32.store align=1
      local.get 260
      i32.const 4
      i32.add
      f32.const 0x1.8p+0 (;=1.5;)
      f32.store align=1
      local.get 0
      i32.const 168
      i32.add
      i64.extend_i32_u
      local.set 261
      i64.const 2
      local.set 262
      local.get 0
      i32.const 176
      i32.add
      i64.extend_i32_u
      local.set 263
      i32.const 0
      local.set 264
      local.get 262
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 264
        i64.const 0
        local.set 265
        block ;; label = @3
          loop ;; label = @4
            local.get 265
            local.get 262
            i64.ge_u
            br_if 1 (;@3;)
            local.get 261
            local.set 266
            local.get 266
            i64.const 4294967295
            i64.and
            local.get 265
            i64.const 4
            i64.mul
            i64.add
            local.tee 267
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3079
              i32.const 73
              i32.const 23
              call 6
              unreachable
            end
            local.get 266
            i64.const -4294967296
            i64.and
            local.get 267
            i64.or
            i32.wrap_i64
            f32.load align=1
            local.get 263
            local.set 268
            local.get 268
            i64.const 4294967295
            i64.and
            local.get 265
            i64.const 4
            i64.mul
            i64.add
            local.tee 269
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3152
              i32.const 73
              i32.const 23
              call 6
              unreachable
            end
            local.get 268
            i64.const -4294967296
            i64.and
            local.get 269
            i64.or
            i32.wrap_i64
            f32.load align=1
            f32.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 264
              br 2 (;@3;)
            end
            local.get 265
            i64.const 1
            i64.add
            local.set 265
            br 0 (;@4;)
          end
        end
      end
      local.get 264
      local.set 270
      call 0
      local.set 271
      local.get 271
      local.get 270
      call 3
      local.get 271
      call 5
      local.get 0
      i32.const 184
      i32.add
      local.set 272
      local.get 272
      i32.const 0
      i32.add
      i32.const 1
      i32.store8
      local.get 272
      i32.const 1
      i32.add
      i32.const 0
      i32.store8
      local.get 0
      i32.const 186
      i32.add
      local.set 273
      local.get 273
      i32.const 0
      i32.add
      i32.const 1
      i32.store8
      local.get 273
      i32.const 1
      i32.add
      i32.const 0
      i32.store8
      local.get 0
      i32.const 184
      i32.add
      i64.extend_i32_u
      local.set 274
      i64.const 2
      local.set 275
      local.get 0
      i32.const 186
      i32.add
      i64.extend_i32_u
      local.set 276
      i32.const 0
      local.set 277
      local.get 275
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 277
        i64.const 0
        local.set 278
        block ;; label = @3
          loop ;; label = @4
            local.get 278
            local.get 275
            i64.ge_u
            br_if 1 (;@3;)
            local.get 274
            local.set 279
            local.get 279
            i64.const 4294967295
            i64.and
            local.get 278
            i64.const 1
            i64.mul
            i64.add
            local.tee 280
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3225
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 279
            i64.const -4294967296
            i64.and
            local.get 280
            i64.or
            i32.wrap_i64
            i32.load8_u
            local.get 276
            local.set 281
            local.get 281
            i64.const 4294967295
            i64.and
            local.get 278
            i64.const 1
            i64.mul
            i64.add
            local.tee 282
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3298
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 281
            i64.const -4294967296
            i64.and
            local.get 282
            i64.or
            i32.wrap_i64
            i32.load8_u
            i32.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 277
              br 2 (;@3;)
            end
            local.get 278
            i64.const 1
            i64.add
            local.set 278
            br 0 (;@4;)
          end
        end
      end
      local.get 277
      local.set 283
      call 0
      local.set 284
      local.get 284
      local.get 283
      call 3
      local.get 284
      call 5
      local.get 0
      i32.const 186
      i32.add
      i64.extend_i32_u
      local.set 285
      i64.const 2
      local.set 286
      i64.const 1
      local.set 287
      local.get 285
      local.set 288
      local.get 288
      i64.const 4294967295
      i64.and
      local.get 287
      i64.const 1
      i64.mul
      i64.add
      local.tee 289
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3371
        i32.const 73
        i32.const 25
        call 6
        unreachable
      end
      local.get 288
      i64.const -4294967296
      i64.and
      local.get 289
      i64.or
      local.set 290
      i32.const 1
      local.set 291
      local.get 290
      local.get 291
      local.set 292
      i32.wrap_i64
      local.get 292
      i32.store8
      local.get 0
      i32.const 184
      i32.add
      i64.extend_i32_u
      local.set 293
      i64.const 2
      local.set 294
      local.get 0
      i32.const 186
      i32.add
      i64.extend_i32_u
      local.set 295
      i32.const 0
      local.set 296
      local.get 294
      i64.const 2
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 296
        i64.const 0
        local.set 297
        block ;; label = @3
          loop ;; label = @4
            local.get 297
            local.get 294
            i64.ge_u
            br_if 1 (;@3;)
            local.get 293
            local.set 298
            local.get 298
            i64.const 4294967295
            i64.and
            local.get 297
            i64.const 1
            i64.mul
            i64.add
            local.tee 299
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3444
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 298
            i64.const -4294967296
            i64.and
            local.get 299
            i64.or
            i32.wrap_i64
            i32.load8_u
            local.get 295
            local.set 300
            local.get 300
            i64.const 4294967295
            i64.and
            local.get 297
            i64.const 1
            i64.mul
            i64.add
            local.tee 301
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3517
              i32.const 73
              i32.const 25
              call 6
              unreachable
            end
            local.get 300
            i64.const -4294967296
            i64.and
            local.get 301
            i64.or
            i32.wrap_i64
            i32.load8_u
            i32.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 296
              br 2 (;@3;)
            end
            local.get 297
            i64.const 1
            i64.add
            local.set 297
            br 0 (;@4;)
          end
        end
      end
      local.get 296
      local.set 302
      call 0
      local.set 303
      local.get 303
      local.get 302
      call 3
      local.get 303
      call 5
      local.get 0
      i32.const 188
      i32.add
      local.set 304
      local.get 0
      i32.const 189
      i32.add
      local.set 305
      local.get 0
      i32.const 188
      i32.add
      i64.extend_i32_u
      local.set 306
      i64.const 0
      local.set 307
      local.get 0
      i32.const 189
      i32.add
      i64.extend_i32_u
      local.set 308
      i32.const 0
      local.set 309
      local.get 307
      i64.const 0
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 309
        i64.const 0
        local.set 310
        block ;; label = @3
          loop ;; label = @4
            local.get 310
            local.get 307
            i64.ge_u
            br_if 1 (;@3;)
            local.get 306
            local.set 311
            local.get 311
            i64.const 4294967295
            i64.and
            local.get 310
            i64.const 8
            i64.mul
            i64.add
            local.tee 312
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3590
              i32.const 73
              i32.const 26
              call 6
              unreachable
            end
            local.get 311
            i64.const -4294967296
            i64.and
            local.get 312
            i64.or
            i32.wrap_i64
            i64.load align=1
            local.get 308
            local.set 313
            local.get 313
            i64.const 4294967295
            i64.and
            local.get 310
            i64.const 8
            i64.mul
            i64.add
            local.tee 314
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3663
              i32.const 73
              i32.const 26
              call 6
              unreachable
            end
            local.get 313
            i64.const -4294967296
            i64.and
            local.get 314
            i64.or
            i32.wrap_i64
            i64.load align=1
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 309
              br 2 (;@3;)
            end
            local.get 310
            i64.const 1
            i64.add
            local.set 310
            br 0 (;@4;)
          end
        end
      end
      local.get 309
      local.set 315
      call 0
      local.set 316
      local.get 316
      local.get 315
      call 3
      local.get 316
      call 5
      local.get 128
      global.set 2
      local.get 115
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $same.1 (;12;) (type 11) (param i32 i32) (result i32)
    (local i32 i32 i32 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      local.get 0
      local.tee 4
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3736
        i32.const 73
        i32.const 1
        call 6
        unreachable
      end
      local.get 4
      local.set 5
      local.get 5
      i64.load offset=8 align=1
      local.set 6
      local.get 1
      local.tee 7
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3809
        i32.const 73
        i32.const 1
        call 6
        unreachable
      end
      local.get 7
      local.set 8
      i32.const 0
      local.set 9
      local.get 6
      local.get 8
      i64.load offset=8 align=1
      i64.eq
      if ;; label = @2
        i32.const 1
        local.set 9
        i64.const 0
        local.set 10
        block ;; label = @3
          loop ;; label = @4
            local.get 10
            local.get 6
            i64.ge_u
            br_if 1 (;@3;)
            local.get 5
            i64.load align=1
            local.set 11
            local.get 11
            i64.const 4294967295
            i64.and
            local.get 10
            i64.const 8
            i64.mul
            i64.add
            local.tee 12
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3882
              i32.const 73
              i32.const 1
              call 6
              unreachable
            end
            local.get 11
            i64.const -4294967296
            i64.and
            local.get 12
            i64.or
            call $goose.memory_op.41
            local.get 8
            i64.load align=1
            local.set 13
            local.get 13
            i64.const 4294967295
            i64.and
            local.get 10
            i64.const 8
            i64.mul
            i64.add
            local.tee 14
            i64.const 4294967295
            i64.gt_u
            if ;; label = @5
              i32.const 11
              i32.const 3955
              i32.const 73
              i32.const 1
              call 6
              unreachable
            end
            local.get 13
            i64.const -4294967296
            i64.and
            local.get 14
            i64.or
            call $goose.memory_op.41
            i64.eq
            i32.eqz
            if ;; label = @5
              i32.const 0
              local.set 9
              br 2 (;@3;)
            end
            local.get 10
            i64.const 1
            i64.add
            local.set 10
            br 0 (;@4;)
          end
        end
      end
      local.get 9
      local.set 15
      local.get 15
      local.set 3
    end
    local.get 3
  )
  (func $optional_same.2 (;13;) (type 12) (param i64 i64) (result i32)
    (local i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.get 1
      i64.eq
      local.set 4
      local.get 4
      local.set 3
    end
    local.get 3
  )
  (func $optional_same.3 (;14;) (type 12) (param i64 i64) (result i32)
    (local i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.get 1
      i64.eq
      local.set 4
      local.get 4
      local.set 3
    end
    local.get 3
  )
  (func $optional_same.4 (;15;) (type 12) (param i64 i64) (result i32)
    (local i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.get 1
      i64.eq
      local.set 4
      local.get 4
      local.set 3
    end
    local.get 3
  )
  (func $optional_same.5 (;16;) (type 12) (param i64 i64) (result i32)
    (local i32 i32 i32)
    block ;; label = @1
      local.get 0
      local.get 1
      i64.eq
      local.set 4
      local.get 4
      local.set 3
    end
    local.get 3
  )
  (func $goose.init (;17;) (type 10)
    (local i32)
  )
  (func $goose.start (;18;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;19;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;20;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.41 (;21;) (type 13) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_equality.goose")
)
