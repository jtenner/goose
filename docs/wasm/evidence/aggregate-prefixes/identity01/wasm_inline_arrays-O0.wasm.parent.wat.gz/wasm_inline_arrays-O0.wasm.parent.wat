(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i32 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 2 65536)
  (global (;0;) (mut i32) i32.const 69344)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 65562
      i32.const 72
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 65634
        i32.const 72
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i64 i32 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i32 i32 i64 i64 i64 i64 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i32 f32 i64 i32 i64 i64 i64 f32 f32 i64 i32 i64 i64 i64 f32 i32 i64 i64 i32 i64 i64 i64 i64 f32 i32 i64 i64 i64 i64 f32 f32 i32 i32 f32 i64 i32 i64 i64 i64 f32 i32 i64 i64 i64 i64 f32 i32 i32 i32 i32 i64 i64 i32 i32 i32 i64 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32)
    i32.const 1039
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 6
      local.get 6
      i32.const 0
      i32.add
      i64.const 1
      i64.store16 align=1
      local.get 6
      i32.const 2
      i32.add
      i64.const 2
      i64.store16 align=1
      local.get 6
      i32.const 4
      i32.add
      i64.const 3
      i64.store16 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 7
      i64.const 3
      local.set 8
      i64.const 0
      local.set 9
      local.get 7
      i64.extend_i32_u
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      local.get 9
      i64.const 2
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 65706
        i32.const 72
        i32.const 9
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      i32.wrap_i64
      local.set 1
      local.get 0
      i32.const 0
      i32.add
      call $mutate.1
      i64.const 3
      local.set 12
      local.get 0
      i32.const 0
      i32.add
      local.set 13
      i64.const 3
      local.set 14
      i64.const 0
      local.set 15
      local.get 13
      i64.extend_i32_u
      local.set 16
      local.get 16
      i64.const 4294967295
      i64.and
      local.get 15
      i64.const 2
      i64.mul
      i64.add
      local.tee 17
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 65778
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 16
      i64.const -4294967296
      i64.and
      local.get 17
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 18
      local.get 0
      i32.const 0
      i32.add
      local.set 19
      i64.const 3
      local.set 20
      i64.const 1
      local.set 21
      local.get 19
      i64.extend_i32_u
      local.set 22
      local.get 22
      i64.const 4294967295
      i64.and
      local.get 21
      i64.const 2
      i64.mul
      i64.add
      local.tee 23
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 65850
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 22
      i64.const -4294967296
      i64.and
      local.get 23
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 24
      local.get 0
      i32.const 0
      i32.add
      local.set 25
      i64.const 3
      local.set 26
      i64.const 2
      local.set 27
      local.get 25
      i64.extend_i32_u
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      local.get 27
      i64.const 2
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 65922
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 30
      local.get 1
      local.tee 31
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 65994
        i32.const 72
        i32.const 11
        call 6
        unreachable
      end
      local.get 31
      i64.load16_s align=1
      local.set 32
      call 0
      local.set 33
      local.get 33
      local.get 12
      i32.const 0
      call 1
      local.get 33
      i32.const 66066
      i32.const 1
      call 4
      local.get 33
      local.get 18
      i32.const 0
      call 1
      local.get 33
      i32.const 66067
      i32.const 1
      call 4
      local.get 33
      local.get 24
      i32.const 0
      call 1
      local.get 33
      i32.const 66068
      i32.const 1
      call 4
      local.get 33
      local.get 30
      i32.const 0
      call 1
      local.get 33
      i32.const 66069
      i32.const 1
      call 4
      local.get 33
      local.get 32
      i32.const 0
      call 1
      local.get 33
      call 5
      local.get 1
      local.get 0
      i32.const 0
      i32.add
      local.set 34
      i64.const 3
      local.set 35
      i64.const 0
      local.set 36
      local.get 34
      i64.extend_i32_u
      local.set 37
      local.get 37
      i64.const 4294967295
      i64.and
      local.get 36
      i64.const 2
      i64.mul
      i64.add
      local.tee 38
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66070
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 37
      i64.const -4294967296
      i64.and
      local.get 38
      i64.or
      i32.wrap_i64
      i32.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 66142
        i32.const 72
        i32.const 12
        call 6
        unreachable
      end
      local.get 0
      i32.const 6
      i32.add
      local.set 39
      local.get 39
      i64.const 0
      i64.store8
      i64.const 7
      local.set 40
      local.get 39
      i64.load8_u
      local.set 41
      local.get 41
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 66214
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 39
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 43
      local.get 43
      i64.const 4294967295
      i64.and
      local.get 41
      i64.const 1
      i64.mul
      i64.add
      local.tee 44
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66286
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 43
      i64.const -4294967296
      i64.and
      local.get 44
      i64.or
      local.tee 45
      local.get 40
      local.set 46
      i32.wrap_i64
      local.get 46
      i64.store8
      local.get 39
      local.get 41
      i64.const 1
      i64.add
      i64.store8
      i64.const 8
      local.set 47
      local.get 39
      i64.load8_u
      local.set 48
      local.get 48
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 66358
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 39
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 50
      local.get 50
      i64.const 4294967295
      i64.and
      local.get 48
      i64.const 1
      i64.mul
      i64.add
      local.tee 51
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66430
        i32.const 72
        i32.const 13
        call 6
        unreachable
      end
      local.get 50
      i64.const -4294967296
      i64.and
      local.get 51
      i64.or
      local.tee 52
      local.get 47
      local.set 53
      i32.wrap_i64
      local.get 53
      i64.store8
      local.get 39
      local.get 48
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 6
      i32.add
      local.set 54
      local.get 54
      i64.load8_u
      local.set 55
      i64.const 0
      local.set 56
      local.get 54
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 57
      local.get 57
      i64.const 4294967295
      i64.and
      local.get 56
      i64.const 1
      i64.mul
      i64.add
      local.tee 58
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66502
        i32.const 72
        i32.const 14
        call 6
        unreachable
      end
      local.get 57
      i64.const -4294967296
      i64.and
      local.get 58
      i64.or
      i32.wrap_i64
      local.set 2
      local.get 0
      i32.const 6
      i32.add
      i64.const 9
      call $append.2
      local.get 0
      i32.const 6
      i32.add
      local.set 59
      local.get 59
      i64.load8_u
      local.set 60
      i64.const 4
      local.set 61
      local.get 0
      i32.const 6
      i32.add
      local.set 62
      local.get 62
      i64.load8_u
      local.set 63
      i64.const 2
      local.set 64
      local.get 64
      local.get 63
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 66574
        i32.const 72
        i32.const 16
        call 6
        unreachable
      end
      local.get 62
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 65
      local.get 65
      i64.const 4294967295
      i64.and
      local.get 64
      i64.const 1
      i64.mul
      i64.add
      local.tee 66
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66646
        i32.const 72
        i32.const 16
        call 6
        unreachable
      end
      local.get 65
      i64.const -4294967296
      i64.and
      local.get 66
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 67
      local.get 2
      local.tee 68
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 66718
        i32.const 72
        i32.const 16
        call 6
        unreachable
      end
      local.get 68
      i64.load8_u
      local.set 69
      call 0
      local.set 70
      local.get 70
      local.get 60
      i32.const 0
      call 1
      local.get 70
      i32.const 66790
      i32.const 1
      call 4
      local.get 70
      local.get 61
      i32.const 0
      call 1
      local.get 70
      i32.const 66791
      i32.const 1
      call 4
      local.get 70
      local.get 67
      i32.const 1
      call 1
      local.get 70
      i32.const 66792
      i32.const 1
      call 4
      local.get 70
      local.get 69
      i32.const 1
      call 1
      local.get 70
      call 5
      local.get 0
      i32.const 6
      i32.add
      local.set 71
      local.get 71
      i64.load8_u
      local.set 72
      local.get 72
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 66793
        i32.const 72
        i32.const 17
        call 6
        unreachable
      end
      local.get 72
      i64.const 1
      i64.sub
      local.set 72
      local.get 71
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 73
      local.get 73
      i64.const 4294967295
      i64.and
      local.get 72
      i64.const 1
      i64.mul
      i64.add
      local.tee 74
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 66865
        i32.const 72
        i32.const 17
        call 6
        unreachable
      end
      local.get 73
      i64.const -4294967296
      i64.and
      local.get 74
      i64.or
      local.set 75
      local.get 75
      i32.wrap_i64
      i64.load8_u
      local.set 76
      local.get 71
      local.get 72
      i64.store8
      local.get 76
      local.set 77
      local.get 0
      i32.const 6
      i32.add
      local.set 78
      local.get 78
      i64.load8_u
      local.set 79
      local.get 2
      local.tee 80
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 66937
        i32.const 72
        i32.const 17
        call 6
        unreachable
      end
      local.get 80
      i64.load8_u
      local.set 81
      call 0
      local.set 82
      local.get 82
      local.get 77
      i32.const 1
      call 1
      local.get 82
      i32.const 67009
      i32.const 1
      call 4
      local.get 82
      local.get 79
      i32.const 0
      call 1
      local.get 82
      i32.const 67010
      i32.const 1
      call 4
      local.get 82
      local.get 81
      i32.const 1
      call 1
      local.get 82
      call 5
      local.get 0
      i32.const 6
      i32.add
      local.set 83
      local.get 83
      i64.load8_u
      local.set 84
      i64.const 0
      local.set 84
      local.get 83
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 85
      local.get 85
      i64.const 4294967295
      i64.and
      local.get 84
      i64.const 1
      i64.mul
      i64.add
      local.tee 86
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67011
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 85
      i64.const -4294967296
      i64.and
      local.get 86
      i64.or
      local.set 87
      local.get 83
      local.get 84
      i64.store8
      local.get 0
      i32.const 6
      i32.add
      local.set 88
      i64.const 42
      local.set 89
      local.get 88
      i64.load8_u
      local.set 90
      local.get 90
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 67083
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 88
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 92
      local.get 92
      i64.const 4294967295
      i64.and
      local.get 90
      i64.const 1
      i64.mul
      i64.add
      local.tee 93
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67155
        i32.const 72
        i32.const 18
        call 6
        unreachable
      end
      local.get 92
      i64.const -4294967296
      i64.and
      local.get 93
      i64.or
      local.tee 94
      local.get 89
      local.set 95
      i32.wrap_i64
      local.get 95
      i64.store8
      local.get 88
      local.get 90
      i64.const 1
      i64.add
      i64.store8
      local.get 94
      i32.wrap_i64
      i64.load8_u
      drop
      local.get 0
      i32.const 6
      i32.add
      local.set 96
      i64.const 0
      local.set 97
      block ;; label = @2
        loop ;; label = @3
          local.get 97
          local.get 96
          i64.load8_u
          i64.ge_u
          br_if 1 (;@2;)
          local.get 96
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 98
          local.get 98
          i64.const 4294967295
          i64.and
          local.get 97
          i64.const 1
          i64.mul
          i64.add
          local.tee 99
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 67227
            i32.const 72
            i32.const 19
            call 6
            unreachable
          end
          local.get 98
          i64.const -4294967296
          i64.and
          local.get 99
          i64.or
          i32.wrap_i64
          local.set 3
          local.get 97
          local.set 4
          block ;; label = @4
            local.get 3
            local.tee 100
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 67299
              i32.const 72
              i32.const 19
              call 6
              unreachable
            end
            local.get 100
            local.set 101
            local.get 101
            i64.load8_u
            local.get 4
            i64.const 255
            i64.and
            i64.add
            i64.const 255
            i64.and
            local.set 102
            local.get 101
            local.get 102
            i64.store8
          end
          local.get 97
          i64.const 1
          i64.add
          local.set 97
          br 0 (;@3;)
        end
      end
      local.get 0
      i32.const 6
      i32.add
      local.set 103
      local.get 103
      i64.load8_u
      local.set 104
      local.get 0
      i32.const 6
      i32.add
      local.set 105
      local.get 105
      i64.load8_u
      local.set 106
      i64.const 0
      local.set 107
      local.get 105
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 108
      local.get 108
      i64.const 4294967295
      i64.and
      local.get 107
      i64.const 1
      i64.mul
      i64.add
      local.tee 109
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67371
        i32.const 72
        i32.const 20
        call 6
        unreachable
      end
      local.get 108
      i64.const -4294967296
      i64.and
      local.get 109
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 110
      call 0
      local.set 111
      local.get 111
      local.get 104
      i32.const 0
      call 1
      local.get 111
      i32.const 67443
      i32.const 1
      call 4
      local.get 111
      local.get 110
      i32.const 1
      call 1
      local.get 111
      call 5
      local.get 0
      i32.const 11
      i32.add
      local.set 112
      local.get 112
      i64.const 0
      i64.store16 align=1
      f32.const -0x0p+0 (;=-0;)
      local.set 113
      local.get 112
      i64.load16_u align=1
      local.set 114
      local.get 114
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 67444
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 112
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 116
      local.get 116
      i64.const 4294967295
      i64.and
      local.get 114
      i64.const 4
      i64.mul
      i64.add
      local.tee 117
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67516
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 116
      i64.const -4294967296
      i64.and
      local.get 117
      i64.or
      local.tee 118
      local.get 113
      local.set 119
      i32.wrap_i64
      local.get 119
      f32.store align=1
      local.get 112
      local.get 114
      i64.const 1
      i64.add
      i64.store16 align=1
      f32.const 0x1.8p+0 (;=1.5;)
      local.set 120
      local.get 112
      i64.load16_u align=1
      local.set 121
      local.get 121
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 67588
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 112
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 123
      local.get 123
      i64.const 4294967295
      i64.and
      local.get 121
      i64.const 4
      i64.mul
      i64.add
      local.tee 124
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67660
        i32.const 72
        i32.const 21
        call 6
        unreachable
      end
      local.get 123
      i64.const -4294967296
      i64.and
      local.get 124
      i64.or
      local.tee 125
      local.get 120
      local.set 126
      i32.wrap_i64
      local.get 126
      f32.store align=1
      local.get 112
      local.get 121
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 0
      i32.const 11
      i32.add
      local.set 127
      local.get 127
      i64.load16_u align=1
      local.set 128
      i64.const 256
      local.set 129
      local.get 0
      i32.const 11
      i32.add
      local.set 130
      local.get 130
      i64.load16_u align=1
      local.set 131
      i64.const 0
      local.set 132
      local.get 130
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 133
      local.get 133
      i64.const 4294967295
      i64.and
      local.get 132
      i64.const 4
      i64.mul
      i64.add
      local.tee 134
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67732
        i32.const 72
        i32.const 22
        call 6
        unreachable
      end
      local.get 133
      i64.const -4294967296
      i64.and
      local.get 134
      i64.or
      i32.wrap_i64
      f32.load align=1
      local.set 135
      local.get 0
      i32.const 11
      i32.add
      local.set 136
      local.get 136
      i64.load16_u align=1
      local.set 137
      local.get 137
      i64.eqz
      if ;; label = @2
        i32.const 9
        i32.const 67804
        i32.const 72
        i32.const 22
        call 6
        unreachable
      end
      local.get 137
      i64.const 1
      i64.sub
      local.set 137
      local.get 136
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 138
      local.get 138
      i64.const 4294967295
      i64.and
      local.get 137
      i64.const 4
      i64.mul
      i64.add
      local.tee 139
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 67876
        i32.const 72
        i32.const 22
        call 6
        unreachable
      end
      local.get 138
      i64.const -4294967296
      i64.and
      local.get 139
      i64.or
      local.set 140
      local.get 140
      i32.wrap_i64
      f32.load align=1
      local.set 141
      local.get 136
      local.get 137
      i64.store16 align=1
      local.get 141
      local.set 142
      call 0
      local.set 143
      local.get 143
      local.get 128
      i32.const 0
      call 1
      local.get 143
      i32.const 67948
      i32.const 1
      call 4
      local.get 143
      local.get 129
      i32.const 0
      call 1
      local.get 143
      i32.const 67949
      i32.const 1
      call 4
      local.get 143
      local.get 135
      f64.promote_f32
      i32.const 32
      call 2
      local.get 143
      i32.const 67950
      i32.const 1
      call 4
      local.get 143
      local.get 142
      f64.promote_f32
      i32.const 32
      call 2
      local.get 143
      call 5
      local.get 0
      i32.const 11
      i32.add
      local.set 144
      f32.const 0x1.4p+1 (;=2.5;)
      local.set 145
      local.get 144
      i64.load16_u align=1
      local.set 146
      local.get 146
      i64.const 256
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 67951
        i32.const 72
        i32.const 23
        call 6
        unreachable
      end
      local.get 144
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 148
      local.get 148
      i64.const 4294967295
      i64.and
      local.get 146
      i64.const 4
      i64.mul
      i64.add
      local.tee 149
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68023
        i32.const 72
        i32.const 23
        call 6
        unreachable
      end
      local.get 148
      i64.const -4294967296
      i64.and
      local.get 149
      i64.or
      local.tee 150
      local.get 145
      local.set 151
      i32.wrap_i64
      local.get 151
      f32.store align=1
      local.get 144
      local.get 146
      i64.const 1
      i64.add
      i64.store16 align=1
      local.get 150
      i32.wrap_i64
      f32.load align=1
      drop
      local.get 0
      i32.const 11
      i32.add
      local.set 152
      local.get 152
      i64.load16_u align=1
      local.set 153
      i64.const 1
      local.set 154
      local.get 152
      i32.const 2
      i32.add
      i64.extend_i32_u
      local.set 155
      local.get 155
      i64.const 4294967295
      i64.and
      local.get 154
      i64.const 4
      i64.mul
      i64.add
      local.tee 156
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68095
        i32.const 72
        i32.const 23
        call 6
        unreachable
      end
      local.get 155
      i64.const -4294967296
      i64.and
      local.get 156
      i64.or
      i32.wrap_i64
      f32.load align=1
      local.set 157
      call 0
      local.set 158
      local.get 158
      local.get 157
      f64.promote_f32
      i32.const 32
      call 2
      local.get 158
      call 5
      local.get 0
      i32.const 1037
      i32.add
      local.set 159
      local.get 0
      i32.const 1037
      i32.add
      call $empty.3
      local.get 0
      i32.const 1038
      i32.add
      local.set 160
      local.get 160
      i64.const 0
      i64.store8
      local.get 0
      i32.const 1038
      i32.add
      local.set 161
      local.get 161
      i64.load8_u
      local.set 162
      i64.const 0
      local.set 163
      call 0
      local.set 164
      local.get 164
      local.get 162
      i32.const 0
      call 1
      local.get 164
      i32.const 68167
      i32.const 1
      call 4
      local.get 164
      local.get 163
      i32.const 0
      call 1
      local.get 164
      call 5
      i32.const 0
      local.set 5
      local.get 5
      i32.const 0
      i32.eq
      local.set 165
      call 0
      local.set 166
      local.get 166
      local.get 165
      call 3
      local.get 166
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 5
      i64.const 3
      local.set 167
      local.get 5
      local.tee 168
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 68168
        i32.const 72
        i32.const 26
        call 6
        unreachable
      end
      local.get 168
      local.set 169
      i64.const 3
      local.set 170
      i64.const 2
      local.set 171
      local.get 169
      i64.extend_i32_u
      local.set 172
      local.get 172
      i64.const 4294967295
      i64.and
      local.get 171
      i64.const 2
      i64.mul
      i64.add
      local.tee 173
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68240
        i32.const 72
        i32.const 27
        call 6
        unreachable
      end
      local.get 172
      i64.const -4294967296
      i64.and
      local.get 173
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 174
      call 0
      local.set 175
      local.get 175
      local.get 167
      i32.const 0
      call 1
      local.get 175
      i32.const 68312
      i32.const 1
      call 4
      local.get 175
      local.get 174
      i32.const 0
      call 1
      local.get 175
      call 5
      i32.const 14
      local.set 176
      i64.const 33
      local.set 177
      local.get 176
      i64.load32_u align=1
      local.set 178
      local.get 178
      i64.const 65536
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 68313
        i32.const 72
        i32.const 28
        call 6
        unreachable
      end
      local.get 176
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 180
      local.get 180
      i64.const 4294967295
      i64.and
      local.get 178
      i64.const 1
      i64.mul
      i64.add
      local.tee 181
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68385
        i32.const 72
        i32.const 28
        call 6
        unreachable
      end
      local.get 180
      i64.const -4294967296
      i64.and
      local.get 181
      i64.or
      local.tee 182
      local.get 177
      local.set 183
      i32.wrap_i64
      local.get 183
      i64.store8
      local.get 176
      local.get 178
      i64.const 1
      i64.add
      i64.store32 align=1
      local.get 182
      i32.wrap_i64
      i64.load8_u
      drop
      i32.const 8
      local.set 184
      i64.const 3
      local.set 185
      i64.const 0
      local.set 186
      local.get 184
      i64.extend_i32_u
      local.set 187
      local.get 187
      i64.const 4294967295
      i64.and
      local.get 186
      i64.const 2
      i64.mul
      i64.add
      local.tee 188
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68457
        i32.const 72
        i32.const 29
        call 6
        unreachable
      end
      local.get 187
      i64.const -4294967296
      i64.and
      local.get 188
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 189
      i32.const 8
      local.set 190
      i64.const 3
      local.set 191
      i64.const 1
      local.set 192
      local.get 190
      i64.extend_i32_u
      local.set 193
      local.get 193
      i64.const 4294967295
      i64.and
      local.get 192
      i64.const 2
      i64.mul
      i64.add
      local.tee 194
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68529
        i32.const 72
        i32.const 29
        call 6
        unreachable
      end
      local.get 193
      i64.const -4294967296
      i64.and
      local.get 194
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 195
      i32.const 8
      local.set 196
      i64.const 3
      local.set 197
      i64.const 2
      local.set 198
      local.get 196
      i64.extend_i32_u
      local.set 199
      local.get 199
      i64.const 4294967295
      i64.and
      local.get 198
      i64.const 2
      i64.mul
      i64.add
      local.tee 200
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68601
        i32.const 72
        i32.const 29
        call 6
        unreachable
      end
      local.get 199
      i64.const -4294967296
      i64.and
      local.get 200
      i64.or
      i32.wrap_i64
      i64.load16_s align=1
      local.set 201
      call 0
      local.set 202
      local.get 202
      local.get 189
      i32.const 0
      call 1
      local.get 202
      i32.const 68673
      i32.const 1
      call 4
      local.get 202
      local.get 195
      i32.const 0
      call 1
      local.get 202
      i32.const 68674
      i32.const 1
      call 4
      local.get 202
      local.get 201
      i32.const 0
      call 1
      local.get 202
      call 5
      i32.const 14
      local.set 203
      local.get 203
      i64.load32_u align=1
      local.set 204
      i64.const 65536
      local.set 205
      i32.const 14
      local.set 206
      local.get 206
      i64.load32_u align=1
      local.set 207
      i64.const 0
      local.set 208
      local.get 206
      i32.const 4
      i32.add
      i64.extend_i32_u
      local.set 209
      local.get 209
      i64.const 4294967295
      i64.and
      local.get 208
      i64.const 1
      i64.mul
      i64.add
      local.tee 210
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68675
        i32.const 72
        i32.const 30
        call 6
        unreachable
      end
      local.get 209
      i64.const -4294967296
      i64.and
      local.get 210
      i64.or
      i32.wrap_i64
      i64.load8_u
      local.set 211
      i64.const 123
      local.set 212
      call 0
      local.set 213
      local.get 213
      local.get 204
      i32.const 0
      call 1
      local.get 213
      i32.const 68747
      i32.const 1
      call 4
      local.get 213
      local.get 205
      i32.const 0
      call 1
      local.get 213
      i32.const 68748
      i32.const 1
      call 4
      local.get 213
      local.get 211
      i32.const 1
      call 1
      local.get 213
      i32.const 68749
      i32.const 1
      call 4
      local.get 213
      local.get 212
      i32.const 0
      call 1
      local.get 213
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $mutate.1 (;12;) (type 5) (param i32)
    (local i32 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i32 i32 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 68750
        i32.const 72
        i32.const 4
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      i64.const 3
      local.set 5
      i64.const 1
      local.set 6
      local.get 4
      i64.extend_i32_u
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 2
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 68822
        i32.const 72
        i32.const 4
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      i64.load16_s align=1
      i64.const 5
      i64.add
      i64.extend16_s
      local.set 10
      local.get 9
      local.get 10
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store16 align=1
      local.get 0
      local.tee 12
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 68894
        i32.const 72
        i32.const 4
        call 6
        unreachable
      end
      local.get 12
      local.set 13
      i64.const 0
      local.set 14
      block ;; label = @2
        loop ;; label = @3
          local.get 14
          i64.const 3
          i64.ge_u
          br_if 1 (;@2;)
          local.get 13
          i64.extend_i32_u
          local.set 15
          local.get 15
          i64.const 4294967295
          i64.and
          local.get 14
          i64.const 2
          i64.mul
          i64.add
          local.tee 16
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 68966
            i32.const 72
            i32.const 4
            call 6
            unreachable
          end
          local.get 15
          i64.const -4294967296
          i64.and
          local.get 16
          i64.or
          i32.wrap_i64
          local.set 2
          block ;; label = @4
            local.get 2
            local.tee 17
            i32.eqz
            if ;; label = @5
              i32.const 4
              i32.const 69038
              i32.const 72
              i32.const 4
              call 6
              unreachable
            end
            local.get 17
            local.set 18
            local.get 18
            i64.load16_s align=1
            i64.const 1
            i64.add
            i64.extend16_s
            local.set 19
            local.get 18
            local.get 19
            i64.store16 align=1
          end
          local.get 14
          i64.const 1
          i64.add
          local.set 14
          br 0 (;@3;)
        end
      end
    end
  )
  (func $append.2 (;13;) (type 11) (param i32 i64)
    (local i32 i32 i32 i64 i64 i32 i64 i64 i64 i64)
    block ;; label = @1
      local.get 0
      local.tee 3
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 69110
        i32.const 72
        i32.const 5
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      local.get 1
      local.set 5
      local.get 4
      i64.load8_u
      local.set 6
      local.get 6
      i64.const 4
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 69182
        i32.const 72
        i32.const 5
        call 6
        unreachable
      end
      local.get 4
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 8
      local.get 8
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 1
      i64.mul
      i64.add
      local.tee 9
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 69254
        i32.const 72
        i32.const 5
        call 6
        unreachable
      end
      local.get 8
      i64.const -4294967296
      i64.and
      local.get 9
      i64.or
      local.tee 10
      local.get 5
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store8
      local.get 4
      local.get 6
      i64.const 1
      i64.add
      i64.store8
      local.get 10
      i32.wrap_i64
      i64.load8_u
      drop
    end
  )
  (func $empty.3 (;14;) (type 5) (param i32)
    (local i32 i64 i32)
    block ;; label = @1
      i64.const 0
      local.set 2
      call 0
      local.set 3
      local.get 3
      i32.const 69326
      i32.const 6
      call 4
      local.get 3
      local.get 2
      i32.const 0
      call 1
      local.get 3
      call 5
    end
  )
  (func $goose.init (;15;) (type 10)
    (local i32 i32 i32 i64)
    i32.const 8
    local.set 1
    local.get 1
    i32.const 0
    i32.add
    i64.const -32768
    i64.store16 align=1
    local.get 1
    i32.const 2
    i32.add
    i64.const 2
    i64.store16 align=1
    local.get 1
    i32.const 4
    i32.add
    i64.const -1
    i64.store16 align=1
    i32.const 14
    local.set 2
    local.get 2
    i64.const 0
    i64.store32 align=1
    i64.const 123
    local.set 3
    i32.const 65554
    local.get 3
    i64.store align=1
  )
  (func $goose.start (;16;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 65554) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose,,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_arrays.gooseempty=")
)
