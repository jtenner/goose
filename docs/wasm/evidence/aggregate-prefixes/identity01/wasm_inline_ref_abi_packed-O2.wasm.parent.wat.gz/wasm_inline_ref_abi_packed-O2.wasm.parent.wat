(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32 i32 i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func))
  (type (;12;) (func (param i64) (result i64)))
  (type (;13;) (func (param i64 i64 i32) (result i64)))
  (type (;14;) (func (param i64 i32) (result i64)))
  (type (;15;) (func (param i64 i64)))
  (type (;16;) (func (param i32 i32) (result i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (import "goose" "snapshot_memory_bytes_v1" (func (;10;) (type 9) (param i32 i32 i32) (result i32)))
  (import "goose" "print_snapshot_v1" (func (;11;) (type 3) (param i32 i32)))
  (import "goose" "drop_snapshot_v1" (func (;12;) (type 5) (param i32)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (memory (;3;) 1 65536)
  (global (;0;) (mut i32) i32.const 6960)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (global (;3;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "data_memory_3" (memory 3))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;13;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 40
      i32.const 80
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 120
        i32.const 80
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;14;) (type 11)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i32 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i32 i64 i64 i32 i64 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i64 i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 216
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 14
      local.get 14
      i32.const 0
      i32.add
      i64.const 10
      i64.store align=1
      local.get 14
      i32.const 8
      i32.add
      i64.const 20
      i64.store align=1
      local.get 0
      i32.const 16
      i32.add
      local.set 15
      local.get 15
      i32.const 0
      i32.add
      i64.const 30
      i64.store align=1
      local.get 15
      i32.const 8
      i32.add
      i64.const 40
      i64.store align=1
      local.get 0
      i32.const 32
      i32.add
      local.set 16
      local.get 16
      i64.const 0
      i64.store8
      i64.const 50
      local.set 17
      local.get 16
      i64.load8_u
      local.set 18
      local.get 18
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 200
        i32.const 80
        i32.const 17
        call 6
        unreachable
      end
      local.get 16
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      local.get 18
      i64.const 8
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 280
        i32.const 80
        i32.const 17
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      local.tee 22
      local.get 17
      local.set 23
      i32.wrap_i64
      local.get 23
      i64.store align=1
      local.get 16
      local.get 18
      i64.const 1
      i64.add
      i64.store8
      local.get 0
      i32.const 57
      i32.add
      local.set 24
      local.get 24
      i64.const 7
      i64.store8
      local.get 24
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 24
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      i64.store offset=9 align=1
      local.get 24
      i64.const 0
      i64.store offset=17 align=1
      local.get 24
      i64.const 4000000000
      i64.store32 offset=25 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 25
      local.get 25
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 360
        i32.const 80
        i32.const 19
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 26
      local.get 26
      i64.load32_u offset=25 align=1
      i64.const 4000000000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 440
        i32.const 80
        i32.const 19
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 27
      local.get 27
      i64.load offset=17 align=1
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 520
        i32.const 80
        i32.const 19
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 28
      local.get 28
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 29
      local.get 29
      i64.load offset=9 align=1
      local.tee 30
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 600
        i32.const 80
        i32.const 20
        call 6
        unreachable
      end
      local.get 30
      local.set 31
      i64.const 51
      local.set 32
      local.get 31
      call $goose.memory_op.49
      local.set 33
      local.get 33
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 680
        i32.const 80
        i32.const 20
        call 6
        unreachable
      end
      local.get 31
      local.set 35
      local.get 35
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 33
      i64.const 8
      i64.mul
      i64.add
      local.tee 36
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 760
        i32.const 80
        i32.const 20
        call 6
        unreachable
      end
      local.get 35
      i64.const -4294967296
      i64.and
      local.get 36
      i64.or
      local.tee 37
      local.get 32
      call $goose.memory_op.55
      local.get 31
      local.get 33
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 37
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 57
      i32.add
      local.set 38
      local.get 38
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=17 align=1
      local.get 0
      i32.const 57
      i32.add
      local.set 39
      local.get 39
      i64.load offset=1 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 840
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 40
      local.get 40
      i64.load offset=9 align=1
      local.tee 41
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 920
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 41
      local.set 42
      local.get 42
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1000
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 43
      local.get 43
      i64.load offset=9 align=1
      local.tee 44
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1080
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 44
      local.set 45
      local.get 45
      call $goose.memory_op.49
      local.set 46
      i64.const 1
      local.set 47
      local.get 45
      local.set 48
      local.get 48
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 47
      i64.const 8
      i64.mul
      i64.add
      local.tee 49
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1160
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 48
      i64.const -4294967296
      i64.and
      local.get 49
      i64.or
      call $goose.memory_op.41
      i64.const 51
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1240
        i32.const 80
        i32.const 21
        call 6
        unreachable
      end
      local.get 0
      i32.const 57
      i32.add
      local.set 50
      local.get 50
      i64.load offset=17 align=1
      local.set 1
      local.get 1
      i64.eqz
      i32.eqz
      if ;; label = @2
        local.get 1
        local.tee 51
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 1320
          i32.const 80
          i32.const 22
          call 6
          unreachable
        end
        local.get 51
        local.set 52
        i64.const 2
        local.set 53
        i64.const 1
        local.set 54
        local.get 52
        local.set 55
        local.get 55
        i64.const 4294967295
        i64.and
        local.get 54
        i64.const 8
        i64.mul
        i64.add
        local.tee 56
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1400
          i32.const 80
          i32.const 22
          call 6
          unreachable
        end
        local.get 55
        i64.const -4294967296
        i64.and
        local.get 56
        i64.or
        call $goose.memory_op.41
        i64.const 20
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 1480
          i32.const 80
          i32.const 22
          call 6
          unreachable
        end
      end
      local.get 0
      i32.const 86
      i32.add
      local.set 57
      local.get 0
      i32.const 57
      i32.add
      local.set 58
      local.get 57
      i64.extend_i32_u
      local.set 59
      local.get 58
      i64.extend_i32_u
      local.set 60
      i32.const 29
      local.set 61
      local.get 59
      i32.wrap_i64
      local.get 60
      i32.wrap_i64
      local.get 61
      memory.copy
      local.get 0
      i32.const 115
      i32.add
      local.set 62
      local.get 62
      local.get 0
      i32.const 57
      i32.add
      i32.const 29
      memory.copy
      local.get 62
      i32.const 29
      i32.add
      local.get 0
      i32.const 86
      i32.add
      i32.const 29
      memory.copy
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 63
      i64.const 2
      local.set 64
      i64.const 0
      local.set 65
      local.get 63
      local.set 66
      local.get 66
      i64.const 4294967295
      i64.and
      local.get 65
      i64.const 29
      i64.mul
      i64.add
      local.tee 67
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1560
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 66
      i64.const -4294967296
      i64.and
      local.get 67
      i64.or
      local.set 68
      local.get 68
      i32.wrap_i64
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store offset=1 align=1
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 69
      i64.const 2
      local.set 70
      i64.const 0
      local.set 71
      local.get 69
      local.set 72
      local.get 72
      i64.const 4294967295
      i64.and
      local.get 71
      i64.const 29
      i64.mul
      i64.add
      local.tee 73
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1640
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 72
      i64.const -4294967296
      i64.and
      local.get 73
      i64.or
      local.set 74
      local.get 74
      i32.wrap_i64
      i64.load offset=1 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1720
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 75
      i64.const 2
      local.set 76
      i64.const 1
      local.set 77
      local.get 75
      local.set 78
      local.get 78
      i64.const 4294967295
      i64.and
      local.get 77
      i64.const 29
      i64.mul
      i64.add
      local.tee 79
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1800
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 78
      i64.const -4294967296
      i64.and
      local.get 79
      i64.or
      local.set 80
      local.get 80
      i32.wrap_i64
      i64.load offset=1 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1880
        i32.const 80
        i32.const 24
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 81
      i64.const 2
      local.set 82
      i64.const 0
      local.set 83
      local.get 81
      local.set 84
      local.get 84
      i64.const 4294967295
      i64.and
      local.get 83
      i64.const 29
      i64.mul
      i64.add
      local.tee 85
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1960
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 84
      i64.const -4294967296
      i64.and
      local.get 85
      i64.or
      local.set 86
      local.get 86
      i32.wrap_i64
      i64.load32_u offset=25 align=1
      i64.const 4000000000
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2040
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 0
      i32.const 115
      i32.add
      i64.extend_i32_u
      local.set 87
      i64.const 2
      local.set 88
      i64.const 1
      local.set 89
      local.get 87
      local.set 90
      local.get 90
      i64.const 4294967295
      i64.and
      local.get 89
      i64.const 29
      i64.mul
      i64.add
      local.tee 91
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2120
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 90
      i64.const -4294967296
      i64.and
      local.get 91
      i64.or
      local.set 92
      local.get 92
      i32.wrap_i64
      i64.load8_u
      i64.const 7
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2200
        i32.const 80
        i32.const 25
        call 6
        unreachable
      end
      local.get 0
      i32.const 173
      i32.add
      local.set 93
      local.get 93
      i32.const 0
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 93
      i32.const 8
      i32.add
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 93
      i32.const 16
      i32.add
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.store align=1
      local.get 0
      i32.const 173
      i32.add
      i64.extend_i32_u
      local.set 94
      i64.const 3
      local.set 95
      i64.const 1
      local.set 96
      local.get 94
      local.set 97
      local.get 97
      i64.const 4294967295
      i64.and
      local.get 96
      i64.const 8
      i64.mul
      i64.add
      local.tee 98
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2280
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 97
      i64.const -4294967296
      i64.and
      local.get 98
      i64.or
      local.set 99
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 100
      local.get 99
      local.get 100
      local.set 101
      i32.wrap_i64
      local.get 101
      i64.store align=1
      local.get 0
      i32.const 173
      i32.add
      i64.extend_i32_u
      local.set 102
      i64.const 3
      local.set 103
      i64.const 1
      local.set 104
      local.get 102
      local.set 105
      local.get 105
      i64.const 4294967295
      i64.and
      local.get 104
      i64.const 8
      i64.mul
      i64.add
      local.tee 106
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2360
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 105
      i64.const -4294967296
      i64.and
      local.get 106
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2440
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 173
      i32.add
      i64.extend_i32_u
      local.set 107
      i64.const 3
      local.set 108
      i64.const 2
      local.set 109
      local.get 107
      local.set 110
      local.get 110
      i64.const 4294967295
      i64.and
      local.get 109
      i64.const 8
      i64.mul
      i64.add
      local.tee 111
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2520
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 110
      i64.const -4294967296
      i64.and
      local.get 111
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2600
        i32.const 80
        i32.const 27
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      call $fixedref.1
      block ;; label = @2
        local.get 0
        i32.const 16
        i32.add
        i64.extend_i32_u
        local.set 3
        local.get 3
        local.set 112
        br 0 (;@2;)
      end
      local.get 112
      i32.const 0
      call $choose.3
      local.set 2
      local.get 2
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2680
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 2
      local.tee 113
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 2760
        i32.const 80
        i32.const 28
        call 6
        unreachable
      end
      local.get 113
      local.set 114
      i64.const 2
      local.set 115
      i64.const 0
      local.set 116
      local.get 114
      local.set 117
      local.get 117
      i64.const 4294967295
      i64.and
      local.get 116
      i64.const 8
      i64.mul
      i64.add
      local.tee 118
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2840
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 117
      i64.const -4294967296
      i64.and
      local.get 118
      i64.or
      local.set 119
      local.get 119
      call $goose.memory_op.41
      i64.const 1
      i64.add
      local.set 120
      local.get 119
      local.get 120
      call $goose.memory_op.55
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 121
      i64.const 2
      local.set 122
      i64.const 0
      local.set 123
      local.get 121
      local.set 124
      local.get 124
      i64.const 4294967295
      i64.and
      local.get 123
      i64.const 8
      i64.mul
      i64.add
      local.tee 125
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2920
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 124
      i64.const -4294967296
      i64.and
      local.get 125
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 31
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3000
        i32.const 80
        i32.const 29
        call 6
        unreachable
      end
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i32.const 1
      call $optionalref.4
      local.set 4
      local.get 4
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3080
        i32.const 80
        i32.const 30
        call 6
        unreachable
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i32.const 0
      call $optionalref.4
      local.set 4
      local.get 4
      i64.const 0
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3160
        i32.const 80
        i32.const 31
        call 6
        unreachable
      end
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      call $limitedref.5
      local.tee 126
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 3240
        i32.const 80
        i32.const 6
        call 6
        unreachable
      end
      local.get 126
      local.set 127
      i64.const 52
      local.set 128
      local.get 127
      call $goose.memory_op.49
      local.set 129
      local.get 129
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 3320
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 127
      local.set 131
      local.get 131
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 129
      i64.const 8
      i64.mul
      i64.add
      local.tee 132
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3400
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 131
      i64.const -4294967296
      i64.and
      local.get 132
      i64.or
      local.tee 133
      local.get 128
      call $goose.memory_op.55
      local.get 127
      local.get 129
      i64.const 1
      i64.add
      call $goose.memory_op.60
      local.get 133
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 134
      local.get 134
      i32.wrap_i64
      i64.load8_u
      i64.const 3
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3480
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 0
      i32.const 32
      i32.add
      i64.extend_i32_u
      local.set 135
      local.get 135
      i32.wrap_i64
      i64.load8_u
      local.set 136
      i64.const 2
      local.set 137
      local.get 135
      local.set 138
      local.get 138
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 137
      i64.const 8
      i64.mul
      i64.add
      local.tee 139
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3560
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      local.get 138
      i64.const -4294967296
      i64.and
      local.get 139
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 52
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3640
        i32.const 80
        i32.const 32
        call 6
        unreachable
      end
      block ;; label = @2
        local.get 0
        i32.const 16
        i32.add
        i64.extend_i32_u
        local.set 5
        local.get 5
        local.set 6
        local.get 6
        local.tee 140
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 3720
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 140
        local.set 141
        i64.const 2
        local.set 142
        i64.const 0
        local.set 143
        local.get 141
        local.set 144
        local.get 144
        i64.const 4294967295
        i64.and
        local.get 143
        i64.const 8
        i64.mul
        i64.add
        local.tee 145
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 3800
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 144
        i64.const -4294967296
        i64.and
        local.get 145
        i64.or
        call $goose.memory_op.41
        i64.const 31
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 3880
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 6
        local.tee 146
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 3960
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 146
        local.set 147
        i64.const 2
        local.set 148
        i64.const 1
        local.set 149
        local.get 147
        local.set 150
        local.get 150
        i64.const 4294967295
        i64.and
        local.get 149
        i64.const 8
        i64.mul
        i64.add
        local.tee 151
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4040
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 150
        i64.const -4294967296
        i64.and
        local.get 151
        i64.or
        call $goose.memory_op.41
        i64.const 40
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 4120
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 6
        local.tee 152
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 4200
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 152
        local.set 153
        i64.const 2
        local.set 154
        i64.const 1
        local.set 155
        local.get 153
        local.set 156
        local.get 156
        i64.const 4294967295
        i64.and
        local.get 155
        i64.const 8
        i64.mul
        i64.add
        local.tee 157
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4280
          i32.const 80
          i32.const 33
          call 6
          unreachable
        end
        local.get 156
        i64.const -4294967296
        i64.and
        local.get 157
        i64.or
        local.set 158
        local.get 158
        call $goose.memory_op.41
        i64.const 3
        i64.add
        local.set 159
        local.get 158
        local.get 159
        call $goose.memory_op.55
      end
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 160
      i64.const 2
      local.set 161
      i64.const 1
      local.set 162
      local.get 160
      local.set 163
      local.get 163
      i64.const 4294967295
      i64.and
      local.get 162
      i64.const 8
      i64.mul
      i64.add
      local.tee 164
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4360
        i32.const 80
        i32.const 34
        call 6
        unreachable
      end
      local.get 163
      i64.const -4294967296
      i64.and
      local.get 164
      i64.or
      i32.wrap_i64
      i64.load align=1
      i64.const 43
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4440
        i32.const 80
        i32.const 34
        call 6
        unreachable
      end
      i32.const 24
      i64.load align=1
      local.tee 165
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 4520
        i32.const 80
        i32.const 3
        call 6
        unreachable
      end
      local.get 165
      local.set 166
      i64.const 2
      local.set 167
      i64.const 0
      local.set 168
      local.get 166
      local.set 169
      local.get 169
      i64.const 4294967295
      i64.and
      local.get 168
      i64.const 8
      i64.mul
      i64.add
      local.tee 170
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 4600
        i32.const 80
        i32.const 35
        call 6
        unreachable
      end
      local.get 169
      i64.const -4294967296
      i64.and
      local.get 170
      i64.or
      local.set 171
      local.get 171
      call $goose.memory_op.41
      i64.const 4
      i64.add
      local.set 172
      local.get 171
      local.get 172
      call $goose.memory_op.55
      i32.const 8
      i64.extend_i32_u
      local.set 173
      i32.const 32
      local.get 173
      i64.store align=1
      i32.const 32
      i64.load align=1
      i64.eqz
      i32.eqz
      if ;; label = @2
        i32.const 32
        i64.load align=1
        local.tee 174
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 4680
          i32.const 80
          i32.const 4
          call 6
          unreachable
        end
        local.get 174
        local.set 175
        i64.const 2
        local.set 176
        i64.const 0
        local.set 177
        local.get 175
        local.set 178
        local.get 178
        i64.const 4294967295
        i64.and
        local.get 177
        i64.const 8
        i64.mul
        i64.add
        local.tee 179
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 4760
          i32.const 80
          i32.const 36
          call 6
          unreachable
        end
        local.get 178
        i64.const -4294967296
        i64.and
        local.get 179
        i64.or
        call $goose.memory_op.41
        i64.const 5
        i64.eq
        i32.eqz
        if ;; label = @3
          i32.const 1
          i32.const 4840
          i32.const 80
          i32.const 36
          call 6
          unreachable
        end
      end
      i32.const 24
      i64.load align=1
      i32.const 8
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 4920
        i32.const 80
        i32.const 37
        call 6
        unreachable
      end
      local.get 0
      i32.const 197
      i32.add
      local.set 180
      local.get 180
      i32.const 0
      i32.add
      i64.const 65
      i64.store8
      local.get 180
      i32.const 1
      i32.add
      i64.const 66
      i64.store8
      local.get 180
      i32.const 2
      i32.add
      i64.const 67
      i64.store8
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      local.set 181
      i64.const 3
      local.set 182
      i64.const 0
      local.set 183
      local.get 181
      local.set 184
      local.get 184
      i64.const 4294967295
      i64.and
      local.get 183
      i64.const 1
      i64.mul
      i64.add
      local.tee 185
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5000
        i32.const 80
        i32.const 39
        call 6
        unreachable
      end
      local.get 184
      i64.const -4294967296
      i64.and
      local.get 185
      i64.or
      local.set 186
      local.get 186
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 186
      i32.wrap_i64
      local.get 182
      i32.wrap_i64
      call 10
      local.set 187
      block ;; label = @2
        local.get 0
        i32.const 197
        i32.add
        i64.extend_i32_u
        local.set 7
        local.get 7
        local.tee 189
        i64.eqz
        if ;; label = @3
          i32.const 4
          i32.const 5080
          i32.const 80
          i32.const 13
          call 6
          unreachable
        end
        local.get 189
        local.set 190
        i64.const 3
        local.set 191
        i64.const 0
        local.set 192
        local.get 190
        local.set 193
        local.get 193
        i64.const 4294967295
        i64.and
        local.get 192
        i64.const 1
        i64.mul
        i64.add
        local.tee 194
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 5160
          i32.const 80
          i32.const 13
          call 6
          unreachable
        end
        local.get 193
        i64.const -4294967296
        i64.and
        local.get 194
        i64.or
        local.set 195
        i64.const 88
        local.set 196
        local.get 195
        local.get 196
        call $goose.memory_op.60
        i64.const 0
        local.set 188
        br 0 (;@2;)
      end
      local.get 188
      local.set 197
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      local.set 198
      i64.const 3
      local.set 199
      i64.const 0
      local.set 200
      local.get 198
      local.set 201
      local.get 201
      i64.const 4294967295
      i64.and
      local.get 200
      i64.const 1
      i64.mul
      i64.add
      local.tee 202
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5240
        i32.const 80
        i32.const 39
        call 6
        unreachable
      end
      local.get 201
      i64.const -4294967296
      i64.and
      local.get 202
      i64.or
      local.set 203
      local.get 203
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 203
      i32.wrap_i64
      local.get 199
      i32.wrap_i64
      call 10
      local.set 204
      call 0
      local.set 205
      local.get 205
      i32.const 5320
      i32.const 6
      call 4
      local.get 205
      local.get 187
      call 11
      local.get 205
      i32.const 5326
      i32.const 1
      call 4
      local.get 205
      local.get 197
      i32.const 0
      call 1
      local.get 205
      i32.const 5327
      i32.const 1
      call 4
      local.get 205
      local.get 204
      call 11
      local.get 205
      call 5
      i64.const 0
      local.set 8
      local.get 8
      local.set 206
      i32.const 0
      local.set 207
      local.get 207
      local.get 206
      i64.eqz
      i32.or
      if ;; label = @2
        i32.const 1
        local.set 207
      else
        local.get 206
        local.set 208
      end
      local.get 207
      if (result i32) ;; label = @2
        i32.const 0
        i32.const 5328
        i32.const 4
        call 10
      else
        i64.const 3
        local.set 209
        i64.const 0
        local.set 210
        local.get 208
        local.set 211
        local.get 211
        i64.const 4294967295
        i64.and
        local.get 210
        i64.const 1
        i64.mul
        i64.add
        local.tee 212
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 5332
          i32.const 80
          i32.const 40
          call 6
          unreachable
        end
        local.get 211
        i64.const -4294967296
        i64.and
        local.get 212
        i64.or
        local.set 213
        local.get 213
        i64.const 32
        i64.shr_u
        i32.wrap_i64
        local.get 213
        i32.wrap_i64
        local.get 209
        i32.wrap_i64
        call 10
      end
      local.set 214
      call 0
      local.set 215
      local.get 215
      i32.const 5412
      i32.const 9
      call 4
      local.get 215
      local.get 214
      call 11
      local.get 215
      call 5
      local.get 0
      i32.const 197
      i32.add
      i64.extend_i32_u
      local.set 8
      local.get 8
      local.tee 216
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5421
        i32.const 80
        i32.const 41
        call 6
        unreachable
      end
      local.get 216
      local.set 217
      i64.const 3
      local.set 218
      i64.const 0
      local.set 219
      local.get 217
      local.set 220
      local.get 220
      i64.const 4294967295
      i64.and
      local.get 219
      i64.const 1
      i64.mul
      i64.add
      local.tee 221
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5501
        i32.const 80
        i32.const 41
        call 6
        unreachable
      end
      local.get 220
      i64.const -4294967296
      i64.and
      local.get 221
      i64.or
      local.set 222
      local.get 222
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      local.get 222
      i32.wrap_i64
      local.get 218
      i32.wrap_i64
      call 10
      local.set 223
      call 0
      local.set 224
      local.get 224
      i32.const 5581
      i32.const 6
      call 4
      local.get 224
      local.get 223
      call 11
      local.get 224
      call 5
      i32.const 1
      local.set 225
      i32.const 12
      call $goose.reserve_memory.1
      local.set 226
      local.get 225
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 226
      i64.extend_i32_u
      i64.or
      local.set 227
      local.get 227
      local.set 9
      local.get 227
      i64.const 1
      local.set 228
      i32.wrap_i64
      local.get 228
      i64.store32 1 align=1
      i64.const 99
      local.set 229
      local.get 226
      i32.const 4
      i32.add
      local.get 229
      i64.store 1 align=1
      i32.const 2
      local.set 230
      i32.const 20
      call $goose.reserve_memory.2
      local.set 231
      local.get 230
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 231
      i64.extend_i32_u
      i64.or
      local.set 232
      local.get 232
      local.set 10
      local.get 232
      i64.const 2
      local.set 228
      i32.wrap_i64
      local.get 228
      i64.store32 2 align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 233
      local.get 231
      i32.const 4
      i32.add
      local.get 233
      i64.store 2 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 233
      local.get 231
      i32.const 12
      i32.add
      local.get 233
      i64.store 2 align=1
      local.get 10
      local.set 234
      local.get 234
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 235
      i64.const 0
      local.set 236
      local.get 234
      local.set 237
      local.get 237
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 236
      i64.const 8
      i64.mul
      i64.add
      local.tee 238
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5587
        i32.const 80
        i32.const 43
        call 6
        unreachable
      end
      local.get 237
      i64.const -4294967296
      i64.and
      local.get 238
      i64.or
      local.set 239
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      local.set 240
      local.get 239
      local.get 240
      local.set 241
      i32.wrap_i64
      local.get 241
      i64.store 2 align=1
      local.get 10
      local.set 242
      local.get 242
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 243
      i64.const 0
      local.set 244
      local.get 242
      local.set 245
      local.get 245
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 244
      i64.const 8
      i64.mul
      i64.add
      local.tee 246
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5667
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 245
      i64.const -4294967296
      i64.and
      local.get 246
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.get 0
      i32.const 16
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 5747
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 10
      local.set 247
      local.get 247
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 248
      i64.const 1
      local.set 249
      local.get 247
      local.set 250
      local.get 250
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 249
      i64.const 8
      i64.mul
      i64.add
      local.tee 251
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5827
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 250
      i64.const -4294967296
      i64.and
      local.get 251
      i64.or
      i32.wrap_i64
      i64.load 2 align=1
      local.tee 252
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 5907
        i32.const 80
        i32.const 43
        call 6
        unreachable
      end
      local.get 252
      local.set 253
      i64.const 2
      local.set 254
      i64.const 1
      local.set 255
      local.get 253
      local.set 256
      local.get 256
      i64.const 4294967295
      i64.and
      local.get 255
      i64.const 8
      i64.mul
      i64.add
      local.tee 257
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 5987
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      local.get 256
      i64.const -4294967296
      i64.and
      local.get 257
      i64.or
      call $goose.memory_op.41
      i64.const 43
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6067
        i32.const 80
        i32.const 44
        call 6
        unreachable
      end
      i32.const 3
      local.set 258
      global.get 3
      local.set 259
      local.get 0
      i32.const 200
      i32.add
      local.set 260
      local.get 260
      local.get 258
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 259
      i64.extend_i32_u
      i64.or
      i64.store align=1
      local.get 260
      i64.const 0
      i64.store offset=8 align=1
      i64.const 7
      local.set 261
      local.get 260
      i64.load offset=8 align=1
      local.set 262
      i32.const 8
      call $goose.reserve_memory.3
      local.set 263
      local.get 260
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 263
      i64.extend_i32_u
      i64.or
      local.tee 264
      local.get 261
      local.set 265
      i32.wrap_i64
      local.get 265
      i64.store 3 align=1
      local.get 260
      local.get 262
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 0
      i32.const 200
      i32.add
      local.set 11
      local.get 11
      local.tee 266
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6147
        i32.const 80
        i32.const 46
        call 6
        unreachable
      end
      local.get 266
      local.set 267
      i64.const 8
      local.set 268
      local.get 267
      i64.load offset=8 align=1
      local.set 269
      local.get 267
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 270
      local.get 267
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 270
      i64.extend_i32_u
      i64.or
      local.tee 271
      local.get 268
      call $goose.memory_op.55
      local.get 267
      local.get 269
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 271
      call $goose.memory_op.41
      drop
      local.get 11
      local.set 12
      local.get 12
      local.tee 272
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6227
        i32.const 80
        i32.const 47
        call 6
        unreachable
      end
      local.get 272
      local.set 273
      i64.const 9
      local.set 274
      local.get 273
      i64.load offset=8 align=1
      local.set 275
      local.get 273
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 276
      local.get 273
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 276
      i64.extend_i32_u
      i64.or
      local.tee 277
      local.get 274
      call $goose.memory_op.55
      local.get 273
      local.get 275
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 277
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 200
      i32.add
      call $headerref.8
      local.set 13
      local.get 13
      local.tee 278
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 6307
        i32.const 80
        i32.const 48
        call 6
        unreachable
      end
      local.get 278
      local.set 279
      i64.const 10
      local.set 280
      local.get 279
      i64.load offset=8 align=1
      local.set 281
      local.get 279
      i64.load align=1
      i64.const 32
      i64.shr_u
      i32.wrap_i64
      i32.const 8
      call $goose.reserve_data
      local.set 282
      local.get 279
      i64.load align=1
      i64.const -4294967296
      i64.and
      local.get 282
      i64.extend_i32_u
      i64.or
      local.tee 283
      local.get 280
      call $goose.memory_op.55
      local.get 279
      local.get 281
      i64.const 1
      i64.add
      i64.store offset=8 align=1
      local.get 283
      call $goose.memory_op.41
      drop
      local.get 0
      i32.const 200
      i32.add
      local.set 284
      local.get 284
      i64.load offset=8 align=1
      i64.const 4
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6387
        i32.const 80
        i32.const 49
        call 6
        unreachable
      end
      local.get 0
      i32.const 200
      i32.add
      local.set 285
      local.get 285
      i64.load offset=8 align=1
      local.set 286
      i64.const 3
      local.set 287
      local.get 285
      i64.load align=1
      local.set 288
      local.get 288
      i64.const 4294967295
      i64.and
      local.get 287
      i64.const 8
      i64.mul
      i64.add
      local.tee 289
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6467
        i32.const 80
        i32.const 49
        call 6
        unreachable
      end
      local.get 288
      i64.const -4294967296
      i64.and
      local.get 289
      i64.or
      i32.wrap_i64
      i64.load 3 align=1
      i64.const 10
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6547
        i32.const 80
        i32.const 49
        call 6
        unreachable
      end
      local.get 11
      i64.extend_i32_u
      local.get 0
      i32.const 200
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6627
        i32.const 80
        i32.const 50
        call 6
        unreachable
      end
      local.get 12
      i64.extend_i32_u
      local.get 0
      i32.const 200
      i32.add
      i64.extend_i32_u
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6707
        i32.const 80
        i32.const 50
        call 6
        unreachable
      end
      local.get 9
      local.set 290
      local.get 290
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 291
      i64.const 0
      local.set 292
      local.get 290
      local.set 293
      local.get 293
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 292
      i64.const 8
      i64.mul
      i64.add
      local.tee 294
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 6787
        i32.const 80
        i32.const 51
        call 6
        unreachable
      end
      local.get 293
      i64.const -4294967296
      i64.and
      local.get 294
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 99
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 6867
        i32.const 80
        i32.const 51
        call 6
        unreachable
      end
      call 0
      local.set 295
      local.get 295
      i32.const 6947
      i32.const 6
      call 4
      local.get 295
      call 5
      local.get 259
      global.set 3
      local.get 231
      global.set 2
      local.get 226
      global.set 1
    end
    local.get 0
    global.set 0
  )
  (func $fixedref.1 (;15;) (type 12) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $choose.3 (;16;) (type 13) (param i64 i64 i32) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 2
      if ;; label = @2
        local.get 0
        local.set 4
        br 1 (;@1;)
      end
      local.get 1
      local.set 4
      br 0 (;@1;)
    end
    local.get 4
  )
  (func $optionalref.4 (;17;) (type 14) (param i64 i32) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 1
      if ;; label = @2
        local.get 0
        local.set 3
        br 1 (;@1;)
      end
      i64.const 0
      local.set 3
      br 0 (;@1;)
    end
    local.get 3
  )
  (func $limitedref.5 (;18;) (type 12) (param i64) (result i64)
    (local i32 i64)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $headerref.8 (;19;) (type 10) (param i32) (result i32)
    (local i32 i32)
    block ;; label = @1
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;20;) (type 11)
    (local i32 i32 i64 i64)
    i32.const 8
    local.set 1
    local.get 1
    i32.const 0
    i32.add
    i64.const 1
    i64.store align=1
    local.get 1
    i32.const 8
    i32.add
    i64.const 2
    i64.store align=1
    i32.const 8
    i64.extend_i32_u
    local.set 2
    i32.const 24
    local.get 2
    i64.store align=1
    i64.const 0
    local.set 3
    i32.const 32
    local.get 3
    i64.store align=1
  )
  (func $goose.start (;21;) (type 11)
    call $goose.init
    call $main.0
  )
  (func $goose.memory_op.49 (;22;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load8_u
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;23;) (type 15) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;24;) (type 15) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i64.store8
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8 1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 2
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;25;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                local.get 0
                i64.const 32
                i64.shr_u
                i32.wrap_i64
                br_table 0 (;@6;) 1 (;@5;) 2 (;@4;) 3 (;@3;) 4 (;@2;)
              end
              local.get 0
              i32.wrap_i64
              i64.load align=1
              br 4 (;@1;)
            end
            local.get 0
            i32.wrap_i64
            i64.load 1 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 2 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 3 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.1 (;26;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;27;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.reserve_memory.3 (;28;) (type 10) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 3
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 3
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 3
      i32.sub
      memory.grow 3
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 3
    local.get 1
  )
  (func $goose.reserve_data (;29;) (type 16) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i32.const 1
              i32.sub
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 1
            call $goose.reserve_memory.1
            br 3 (;@1;)
          end
          local.get 1
          call $goose.reserve_memory.2
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.3
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 24) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goosebytes=||null/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.gooseoptional=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goosebytes=/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_inline_ref_abi_packed.gooseABI=ok")
)
