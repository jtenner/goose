(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 832)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 32
      i32.const 86
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 118
        i32.const 86
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i32 i32 i64 i64 i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i32)
    i32.const 16
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      call 0
      local.set 1
      local.get 1
      i32.const 204
      i32.const 6
      call 4
      local.get 1
      call 5
      local.get 0
      i32.const 0
      i32.add
      local.set 2
      i32.const 16
      call $goose.reserve_frame
      local.set 3
      call $source_value.1
      local.tee 4
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 210
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      i64.extend_i32_u
      local.set 5
      local.get 4
      i64.extend_i32_u
      local.set 6
      i32.const 16
      local.set 7
      local.get 5
      i32.wrap_i64
      local.get 6
      i32.wrap_i64
      local.get 7
      memory.copy
      i32.const 16
      call $goose.reserve_frame
      local.set 8
      local.get 8
      local.set 9
      local.get 9
      call $change.2
      i64.const 0
      local.set 10
      block ;; label = @2
        loop ;; label = @3
          local.get 10
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 2
          i64.extend_i32_u
          local.set 11
          local.get 11
          i64.const 4294967295
          i64.and
          local.get 10
          i64.const 8
          i64.mul
          i64.add
          local.tee 12
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 296
            i32.const 86
            i32.const 1
            call 6
            unreachable
          end
          local.get 11
          i64.const -4294967296
          i64.and
          local.get 12
          i64.or
          local.set 13
          local.get 3
          i64.extend_i32_u
          local.set 14
          local.get 14
          i64.const 4294967295
          i64.and
          local.get 10
          i64.const 8
          i64.mul
          i64.add
          local.tee 15
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 382
            i32.const 86
            i32.const 1
            call 6
            unreachable
          end
          local.get 14
          i64.const -4294967296
          i64.and
          local.get 15
          i64.or
          local.set 16
          local.get 8
          i64.extend_i32_u
          local.set 17
          local.get 17
          i64.const 4294967295
          i64.and
          local.get 10
          i64.const 8
          i64.mul
          i64.add
          local.tee 18
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 468
            i32.const 86
            i32.const 1
            call 6
            unreachable
          end
          local.get 17
          i64.const -4294967296
          i64.and
          local.get 18
          i64.or
          local.set 19
          local.get 13
          i32.wrap_i64
          local.get 16
          i32.wrap_i64
          i64.load align=1
          local.get 19
          i32.wrap_i64
          i64.load align=1
          i64.add
          i64.store align=1
          local.get 10
          i64.const 1
          i64.add
          local.set 10
          br 0 (;@3;)
        end
      end
      local.get 8
      global.set 0
      local.get 3
      global.set 0
      local.get 0
      i32.const 0
      i32.add
      local.set 20
      i64.const 2
      local.set 21
      i64.const 0
      local.set 22
      local.get 20
      i64.extend_i32_u
      local.set 23
      local.get 23
      i64.const 4294967295
      i64.and
      local.get 22
      i64.const 8
      i64.mul
      i64.add
      local.tee 24
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 554
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 23
      i64.const -4294967296
      i64.and
      local.get 24
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 25
      local.get 0
      i32.const 0
      i32.add
      local.set 26
      i64.const 2
      local.set 27
      i64.const 1
      local.set 28
      local.get 26
      i64.extend_i32_u
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      local.get 28
      i64.const 8
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 640
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      i32.wrap_i64
      i64.load align=1
      local.set 31
      i32.const 24
      i64.load align=1
      local.set 32
      call 0
      local.set 33
      local.get 33
      i32.const 726
      i32.const 6
      call 4
      local.get 33
      local.get 25
      i32.const 0
      call 1
      local.get 33
      i32.const 732
      i32.const 1
      call 4
      local.get 33
      local.get 31
      i32.const 0
      call 1
      local.get 33
      i32.const 733
      i32.const 1
      call 4
      local.get 33
      local.get 32
      i32.const 0
      call 1
      local.get 33
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $source_value.1 (;12;) (type 0) (result i32)
    (local i32 i32 i64)
    block ;; label = @1
      i32.const 24
      i64.load align=1
      i64.const 1
      i64.add
      local.set 2
      i32.const 24
      local.get 2
      i64.store align=1
      i32.const 8
      local.set 1
      br 0 (;@1;)
    end
    local.get 1
  )
  (func $change.2 (;13;) (type 5) (param i32)
    (local i32 i32 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      i32.const 8
      local.set 2
      i64.const 2
      local.set 3
      i64.const 0
      local.set 4
      local.get 2
      i64.extend_i32_u
      local.set 5
      local.get 5
      i64.const 4294967295
      i64.and
      local.get 4
      i64.const 8
      i64.mul
      i64.add
      local.tee 6
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 734
        i32.const 86
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 6
      i64.or
      local.set 7
      i64.const 99
      local.set 8
      local.get 7
      local.get 8
      local.set 9
      i32.wrap_i64
      local.get 9
      i64.store align=1
      call 0
      local.set 10
      local.get 10
      i32.const 820
      i32.const 5
      call 4
      local.get 10
      call 5
      local.get 0
      i32.const 0
      i32.add
      i64.const 3
      i64.store align=1
      local.get 0
      i32.const 8
      i32.add
      i64.const 4
      i64.store align=1
      br 0 (;@1;)
    end
  )
  (func $goose.init (;14;) (type 10)
    (local i32 i32 i64)
    i32.const 8
    local.set 1
    local.get 1
    i32.const 0
    i32.add
    i64.const 7
    i64.store align=1
    local.get 1
    i32.const 8
    i32.add
    i64.const -8
    i64.store align=1
    i64.const 0
    local.set 2
    i32.const 24
    local.get 2
    i64.store align=1
  )
  (func $goose.start (;15;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 24) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goosebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.gooseafter=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_binary_snapshot_owner.gooseright")
)
