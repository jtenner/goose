# Fixed array assignment review

Baseline: `a765ccb77007dc07d70b02180e0c49e86c768f88` in `/home/dev/Projects/goose-wasm-backend`.
Reviewed change: the current uncommitted diff in `src/wasm_fixed.h`, `src/wasm_codegen.h`, `src/wasm_arrays.h`, and `test/wasm_backend.py`, plus all 12 new array assignment fixtures and their expected outputs.

Scope: exact stored images of fixed arrays and arrays with static limited capacity. This was a read-only correctness review. I ran no builds, tests, benchmarks, timing runs, or source edits. The saved test results below were produced before this review.

## Confirmed finding

### P2: The full backend suite still expects an exact stored array assignment to fail

Location: `test/wasm_aggregate_admission.py:84` and `:95`; test input at `:65`.

Trigger: run `test/wasm_backend.py` with the candidate compiler. The runner calls `check_aggregate_admission` at `test/wasm_backend.py:283`. That function compiles its native-valid `array-assign` case:

```goose
struct S { x: i64 }
fn main() {
    var a: S[1] = [S { x: 1 }];
    var b: S[1] = [S { x: 2 }];
    a = b;
    print(a[0].x);
}
```

The case remains in the rejection table, and the success list at line 84 omits `array-assign`. Line 95 therefore requires a nonzero compiler exit. The change intentionally accepts this exact stored-image assignment: `wasm_codegen.h:994-996` routes the owner to `AssignFixed`, and `wasm_fixed.h:290-321` accepts equal stored fixed array types. The saved candidate nominal-array case proves this admitted form with two elements at both optimization levels. The stale rejection thus makes the full suite fail when it reaches this case.

Risk: the focused new cases pass while the required full correctness suite cannot pass.

Suggested fix: add `array-assign` to the accepted cases and require native and Wasm output `b'2\n'`, including the existing validator and optional second-host checks. Retain the input as accepted behavior coverage. Then run this specific checker first and the full correctness suite. This review did not execute the exact stale checker, so the finding is based on its valid input, the current control flow, and the saved equivalent candidate result.

## Backend checks

No confirmed backend defect was found within the stated scope.

- Complete layout: `AssignFixed` derives the stored source type through `ActualType`, removes reference wrappers, and checks `TEq` before and after place resolution. `TEq` includes array kind, capacity, and element type. `RequireFixed` runs on the full destination type and uses checked size arithmetic. Static limited arrays include their length field and their full capacity image. This check also runs for an opaque destination reference, without relying on a planned owner size.
- Capture order: owner, field, and index callers obtain their destination place before `AssignFixed` resolves the source. `PointeePlace` saves and null-checks the reference value. Field offsets remain tied to that saved base. The thin and fat field-order fixtures check RHS rebinding after destination capture.
- References in images: byte copy retains reference values without deep copy or rebinding the destination reference. The scalar-array reference and nominal-array reference fixtures check this behavior. Fixed reference storage remains eight bytes even when the reference value ABI is thin.
- Copy semantics: `CopyBytes` retains all four existing dispatch choices. Known memory pairs emit `memory.copy`; frame-to-unknown, unknown-to-frame, and unknown pairs call helpers that dispatch to `memory.copy`. The dispatch table includes Memory 0 and rejects invalid identities. No loop or manual forward copy was added. Same-address and overlap behavior therefore retain the existing copy semantics. Zero-length assignment still resolves the source and emits the copy, so source effects remain observable.
- Bounds: unbounded field offsets use the existing checked low-u32 address addition. The final `memory.copy` retains the Wasm memory bounds check for the full image. This is a memory bounds check, not a separate runtime proof of an arbitrary opaque reference object's extent.
- Scope guards: array literals, strings, defaults, and other array temporaries remain outside the `addressable` source set. Type adaptation still fails before copy. Nonfixed assignment remains rejected at the callers. `RequireCallValue` still rejects by-value array arguments and array results. Nominal constructor assignment retains its temporary path. The new array branch does not widen that constructor path.

## Evidence read

Evidence root: `/tmp/goose-wasm-array-assignment-20261107`.

- `parent-first/results.json`: 12 valid native passes and baseline Wasm rejections, six cases at `-O0` and `-O2`.
- `parent-extra/results.json`: 10 valid native passes and baseline Wasm rejections, five cases at both levels.
- `parent-image/results.json`: two valid native passes and baseline Wasm rejections for the corrected image fixture.
- `candidate01/results.json` and `candidate-extra/results.json`: 24 case/optimization rows pass on Node and Wasmtime. Both command logs contain 48 zero-exit commands. The harness asserts exact stdout and empty stderr.
- `compiler-identity.json`, the saved compiler hash, and `build01/source-hashes.json`: the compiler hash matches the recorded identity. All three changed backend source hashes match the build record.
- Existing private place and copy matrix source checks cover memory dispatch, overlapping spans, invalid memory identities, zero count, and full-copy memory bounds failure. I read these checks but did not run them.
- Existing aggregate admission, copy admission, fixed assignment checks, fixed layout tests, and reference completion helpers were read for shared checks and suite integration.

The original `parent-extra` image input used reserved word `guard` and is excluded as invalid. The corrected `parent-image` case uses `sentinel`. The view-policy capacity-change reference is frontend-invalid and supplies no backend guard evidence.

## Untested paths and evidence limits

These are coverage limits, not confirmed defects:

1. New whole-array assignment through hostile opaque references has no direct saved test for null, invalid memory identity, full-image out-of-bounds span, or low-u32 field offset carry. Existing generic helper tests cover parts of this behavior but do not prove the new source-language route.
2. The image fixture checks length, active values, source state, and an adjacent sentinel. It does not poison and compare unused capacity bytes. The existing nominal fixed-image controls test another caller of the shared copy, not the new array image extent.
3. New array-specific literal/default/string rejection and exact assignment adaptation rejection are supported by source inspection. The saved new-case runs contain no direct valid negative oracle for them. Existing array ABI and adaptation checks cover other entry points.
4. Direct element target capture with index effects, self-copy through an opaque array reference, limited-array copies at larger prefix widths, and overlapping opaque array spans lack new direct saved cases. Overlap at the common helper is covered by existing test source.
5. I did not run the full suite or inspect every saved stdout/stderr file. I read the aggregate results, command records, relevant harness, compiler identity, and source hashes. No performance acceptance claim is made.
