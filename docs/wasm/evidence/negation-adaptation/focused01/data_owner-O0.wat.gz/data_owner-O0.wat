(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64)))
  (type (;12;) (func (param i64 f32)))
  (type (;13;) (func (param i64 f64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (global (;0;) (mut i32) i32.const 2128)
  (global (;1;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 36
      i32.const 90
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 126
        i32.const 90
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32)
    block ;; label = @1
      i32.const 8
      i64.extend_i32_u
      call $prepare.1
      i32.const 1
      local.set 2
      i32.const 47
      call $goose.reserve_memory.1
      local.set 3
      local.get 2
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 3
      i64.extend_i32_u
      i64.or
      local.set 4
      local.get 4
      local.set 1
      local.get 4
      i64.const 1
      local.set 5
      i32.wrap_i64
      local.get 5
      i64.store32 1 align=1
      i32.const 8
      local.set 6
      i64.const 0
      local.set 7
      block ;; label = @2
        loop ;; label = @3
          local.get 7
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 4
          i64.const 4294967295
          i64.and
          i64.const 5
          i64.add
          local.tee 10
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 216
            i32.const 90
            i32.const 4
            call 6
            unreachable
          end
          local.get 4
          i64.const -4294967296
          i64.and
          local.get 10
          i64.or
          local.set 8
          local.get 8
          i64.const 4294967295
          i64.and
          local.get 7
          i64.const 14
          i64.mul
          i64.add
          local.tee 9
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 306
            i32.const 90
            i32.const 4
            call 6
            unreachable
          end
          local.get 8
          i64.const -4294967296
          i64.and
          local.get 9
          i64.or
          local.set 11
          local.get 6
          i64.extend_i32_u
          local.set 12
          local.get 12
          i64.const 4294967295
          i64.and
          local.get 7
          i64.const 14
          i64.mul
          i64.add
          local.tee 13
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 396
            i32.const 90
            i32.const 4
            call 6
            unreachable
          end
          local.get 12
          i64.const -4294967296
          i64.and
          local.get 13
          i64.or
          local.set 14
          local.get 11
          i32.wrap_i64
          local.get 14
          i32.wrap_i64
          f32.load align=1
          f32.neg
          f32.store 1 align=1
          local.get 11
          i32.wrap_i64
          local.get 14
          i32.wrap_i64
          f64.load offset=6 align=1
          f64.neg
          f64.store 1 offset=6 align=1
          local.get 7
          i64.const 1
          i64.add
          local.set 7
          br 0 (;@3;)
        end
      end
      local.get 4
      i64.const 2
      local.set 5
      i32.wrap_i64
      local.get 5
      i64.store8 1 offset=4
      local.get 1
      local.set 15
      local.get 15
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 16
      i64.const 0
      local.set 17
      local.get 15
      local.set 18
      local.get 18
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 17
      i64.const 43
      i64.mul
      i64.add
      local.tee 19
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 486
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 18
      i64.const -4294967296
      i64.and
      local.get 19
      i64.or
      local.set 20
      local.get 20
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load8_u 1
      local.set 22
      local.get 1
      local.set 23
      local.get 23
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 24
      i64.const 0
      local.set 25
      local.get 23
      local.set 26
      local.get 26
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 25
      i64.const 43
      i64.mul
      i64.add
      local.tee 27
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 576
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 26
      i64.const -4294967296
      i64.and
      local.get 27
      i64.or
      local.set 28
      local.get 28
      local.set 29
      local.get 29
      i32.wrap_i64
      i64.load8_u 1
      local.set 30
      i64.const 0
      local.set 31
      local.get 31
      local.get 30
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 666
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 29
      local.set 32
      local.get 32
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 31
      i64.const 14
      i64.mul
      i64.add
      local.tee 33
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 756
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 32
      i64.const -4294967296
      i64.and
      local.get 33
      i64.or
      local.set 34
      local.get 34
      i32.wrap_i64
      f32.load 1 align=1
      local.get 1
      local.set 35
      local.get 35
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 36
      i64.const 0
      local.set 37
      local.get 35
      local.set 38
      local.get 38
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 37
      i64.const 43
      i64.mul
      i64.add
      local.tee 39
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 846
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 38
      i64.const -4294967296
      i64.and
      local.get 39
      i64.or
      local.set 40
      local.get 40
      local.set 41
      local.get 41
      i32.wrap_i64
      i64.load8_u 1
      local.set 42
      i64.const 0
      local.set 43
      local.get 43
      local.get 42
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 936
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 41
      local.set 44
      local.get 44
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 43
      i64.const 14
      i64.mul
      i64.add
      local.tee 45
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1026
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 44
      i64.const -4294967296
      i64.and
      local.get 45
      i64.or
      local.set 46
      local.get 46
      i32.wrap_i64
      f32.load 1 align=1
      f32.eq
      local.set 47
      local.get 1
      local.set 48
      local.get 48
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 49
      i64.const 0
      local.set 50
      local.get 48
      local.set 51
      local.get 51
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 50
      i64.const 43
      i64.mul
      i64.add
      local.tee 52
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1116
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 51
      i64.const -4294967296
      i64.and
      local.get 52
      i64.or
      local.set 53
      local.get 53
      local.set 54
      local.get 54
      i32.wrap_i64
      i64.load8_u 1
      local.set 55
      i64.const 0
      local.set 56
      local.get 56
      local.get 55
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1206
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 54
      local.set 57
      local.get 57
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 56
      i64.const 14
      i64.mul
      i64.add
      local.tee 58
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1296
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 57
      i64.const -4294967296
      i64.and
      local.get 58
      i64.or
      local.set 59
      local.get 59
      i32.wrap_i64
      f64.load 1 offset=6 align=1
      local.get 1
      local.set 60
      local.get 60
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 61
      i64.const 0
      local.set 62
      local.get 60
      local.set 63
      local.get 63
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 62
      i64.const 43
      i64.mul
      i64.add
      local.tee 64
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1386
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 63
      i64.const -4294967296
      i64.and
      local.get 64
      i64.or
      local.set 65
      local.get 65
      local.set 66
      local.get 66
      i32.wrap_i64
      i64.load8_u 1
      local.set 67
      i64.const 0
      local.set 68
      local.get 68
      local.get 67
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1476
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 66
      local.set 69
      local.get 69
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 68
      i64.const 14
      i64.mul
      i64.add
      local.tee 70
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1566
        i32.const 90
        i32.const 4
        call 6
        unreachable
      end
      local.get 69
      i64.const -4294967296
      i64.and
      local.get 70
      i64.or
      local.set 71
      local.get 71
      i32.wrap_i64
      f64.load 1 offset=6 align=1
      f64.eq
      local.set 72
      call 0
      local.set 73
      local.get 73
      i32.const 1656
      i32.const 6
      call 4
      local.get 73
      local.get 22
      i32.const 0
      call 1
      local.get 73
      i32.const 1662
      i32.const 1
      call 4
      local.get 73
      local.get 47
      call 3
      local.get 73
      i32.const 1663
      i32.const 1
      call 4
      local.get 73
      local.get 72
      call 3
      local.get 73
      call 5
      local.get 3
      global.set 1
    end
  )
  (func $prepare.1 (;12;) (type 11) (param i64)
    (local i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      local.get 0
      local.tee 2
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1664
        i32.const 90
        i32.const 3
        call 6
        unreachable
      end
      local.get 2
      local.set 3
      i64.const 2
      local.set 4
      i64.const 0
      local.set 5
      local.get 3
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 5
      i64.const 14
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1754
        i32.const 90
        i32.const 3
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 8
      local.get 8
      f32.const 0x1.4p+0 (;=1.25;)
      call $goose.memory_op.56
      local.get 0
      local.tee 9
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1844
        i32.const 90
        i32.const 3
        call 6
        unreachable
      end
      local.get 9
      local.set 10
      i64.const 2
      local.set 11
      i64.const 1
      local.set 12
      local.get 10
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 14
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1934
        i32.const 90
        i32.const 3
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 6
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2024
        i32.const 90
        i32.const 0
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      f64.const -0x1.2ap+5 (;=-37.25;)
      call $goose.memory_op.57
      call 0
      local.set 17
      local.get 17
      i32.const 2114
      i32.const 6
      call 4
      local.get 17
      call 5
    end
  )
  (func $goose.init (;13;) (type 10)
    (local i32 i32)
    i32.const 8
    local.set 1
    local.get 1
    f32.const 0x1.4p+0 (;=1.25;)
    f32.store align=1
    local.get 1
    f64.const 0x1.69p+5 (;=45.125;)
    f64.store offset=6 align=1
    local.get 1
    f32.const -0x1.4p+1 (;=-2.5;)
    f32.store offset=14 align=1
    local.get 1
    f64.const -0x1.2ap+5 (;=-37.25;)
    f64.store offset=20 align=1
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.56 (;16;) (type 12) (param i64 f32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          f32.store align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        f32.store 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.57 (;17;) (type 13) (param i64 f64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          f64.store align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        f64.store 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 36) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.gooseafter=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_data_owner.goosebefore")
)
