(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (global (;0;) (mut i32) i32.const 1168)
  (export "memory" (memory 0))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 36
      i32.const 85
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 121
        i32.const 85
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i32 i32 i64 i64 i64 i64 i64 i64 i64 i32 i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i32 i32)
    i32.const 43
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      i32.const 8
      call $prepare.1
      local.get 0
      i32.const 0
      i32.add
      local.set 1
      i32.const 8
      local.set 2
      i64.const 0
      local.set 3
      block ;; label = @2
        loop ;; label = @3
          local.get 3
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 1
          i32.const 1
          i32.add
          i64.extend_i32_u
          local.set 4
          local.get 4
          i64.const 4294967295
          i64.and
          local.get 3
          i64.const 14
          i64.mul
          i64.add
          local.tee 5
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 206
            i32.const 85
            i32.const 4
            call 6
            unreachable
          end
          local.get 4
          i64.const -4294967296
          i64.and
          local.get 5
          i64.or
          local.set 6
          local.get 2
          i64.extend_i32_u
          local.set 7
          local.get 7
          i64.const 4294967295
          i64.and
          local.get 3
          i64.const 14
          i64.mul
          i64.add
          local.tee 8
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 291
            i32.const 85
            i32.const 4
            call 6
            unreachable
          end
          local.get 7
          i64.const -4294967296
          i64.and
          local.get 8
          i64.or
          local.set 9
          local.get 6
          i32.wrap_i64
          local.get 9
          i32.wrap_i64
          f32.load align=1
          f32.neg
          f32.store align=1
          local.get 6
          i32.wrap_i64
          local.get 9
          i32.wrap_i64
          f64.load offset=6 align=1
          f64.neg
          f64.store offset=6 align=1
          local.get 3
          i64.const 1
          i64.add
          local.set 3
          br 0 (;@3;)
        end
      end
      local.get 1
      i64.const 2
      i64.store8
      local.get 0
      i32.const 0
      i32.add
      local.set 10
      local.get 10
      i64.load8_u
      local.set 11
      local.get 0
      i32.const 0
      i32.add
      local.set 12
      local.get 12
      i64.load8_u
      local.set 13
      i64.const 0
      local.set 14
      local.get 14
      local.get 13
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 376
        i32.const 85
        i32.const 4
        call 6
        unreachable
      end
      local.get 12
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 15
      local.get 15
      i64.const 4294967295
      i64.and
      local.get 14
      i64.const 14
      i64.mul
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 461
        i32.const 85
        i32.const 4
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 16
      i64.or
      local.set 17
      local.get 17
      i32.wrap_i64
      f32.load align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 18
      local.get 18
      i64.load8_u
      local.set 19
      i64.const 0
      local.set 20
      local.get 18
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      local.get 20
      i64.const 14
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 546
        i32.const 85
        i32.const 4
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      local.set 23
      local.get 23
      i32.wrap_i64
      f32.load align=1
      f32.eq
      local.set 24
      local.get 0
      i32.const 0
      i32.add
      local.set 25
      local.get 25
      i64.load8_u
      local.set 26
      i64.const 0
      local.set 27
      local.get 25
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 28
      local.get 28
      i64.const 4294967295
      i64.and
      local.get 27
      i64.const 14
      i64.mul
      i64.add
      local.tee 29
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 631
        i32.const 85
        i32.const 4
        call 6
        unreachable
      end
      local.get 28
      i64.const -4294967296
      i64.and
      local.get 29
      i64.or
      local.set 30
      local.get 30
      i32.wrap_i64
      f64.load offset=6 align=1
      local.get 0
      i32.const 0
      i32.add
      local.set 31
      local.get 31
      i64.load8_u
      local.set 32
      i64.const 0
      local.set 33
      local.get 31
      i32.const 1
      i32.add
      i64.extend_i32_u
      local.set 34
      local.get 34
      i64.const 4294967295
      i64.and
      local.get 33
      i64.const 14
      i64.mul
      i64.add
      local.tee 35
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 716
        i32.const 85
        i32.const 4
        call 6
        unreachable
      end
      local.get 34
      i64.const -4294967296
      i64.and
      local.get 35
      i64.or
      local.set 36
      local.get 36
      i32.wrap_i64
      f64.load offset=6 align=1
      f64.eq
      local.set 37
      call 0
      local.set 38
      local.get 38
      i32.const 801
      i32.const 6
      call 4
      local.get 38
      local.get 11
      i32.const 0
      call 1
      local.get 38
      i32.const 807
      i32.const 1
      call 4
      local.get 38
      local.get 24
      call 3
      local.get 38
      i32.const 808
      i32.const 1
      call 4
      local.get 38
      local.get 37
      call 3
      local.get 38
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $prepare.1 (;12;) (type 5) (param i32)
    (local i32 i32 i32 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      local.get 0
      local.tee 2
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 809
        i32.const 85
        i32.const 3
        call 6
        unreachable
      end
      local.get 2
      local.set 3
      i64.const 2
      local.set 4
      i64.const 0
      local.set 5
      local.get 3
      i64.extend_i32_u
      local.set 6
      local.get 6
      i64.const 4294967295
      i64.and
      local.get 5
      i64.const 14
      i64.mul
      i64.add
      local.tee 7
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 894
        i32.const 85
        i32.const 3
        call 6
        unreachable
      end
      local.get 6
      i64.const -4294967296
      i64.and
      local.get 7
      i64.or
      local.set 8
      local.get 8
      i32.wrap_i64
      f32.const 0x1.4p+0 (;=1.25;)
      f32.store align=1
      local.get 0
      local.tee 9
      i32.eqz
      if ;; label = @2
        i32.const 4
        i32.const 979
        i32.const 85
        i32.const 3
        call 6
        unreachable
      end
      local.get 9
      local.set 10
      i64.const 2
      local.set 11
      i64.const 1
      local.set 12
      local.get 10
      i64.extend_i32_u
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      local.get 12
      i64.const 14
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1064
        i32.const 85
        i32.const 3
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.set 15
      local.get 15
      i32.wrap_i64
      f64.const -0x1.2ap+5 (;=-37.25;)
      f64.store offset=6 align=1
      call 0
      local.set 16
      local.get 16
      i32.const 1149
      i32.const 6
      call 4
      local.get 16
      call 5
    end
  )
  (func $goose.init (;13;) (type 10)
    (local i32 i32)
    i32.const 8
    local.set 1
    local.get 1
    f32.const 0x1.4p+0 (;=1.25;)
    f32.store align=1
    local.get 1
    f64.const 0x1.69p+5 (;=45.125;)
    f64.store offset=6 align=1
    local.get 1
    f32.const -0x1.4p+1 (;=-2.5;)
    f32.store offset=14 align=1
    local.get 1
    f64.const -0x1.2ap+5 (;=-37.25;)
    f64.store offset=20 align=1
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 36) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.gooseafter=,,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_owner.goosebefore")
)
