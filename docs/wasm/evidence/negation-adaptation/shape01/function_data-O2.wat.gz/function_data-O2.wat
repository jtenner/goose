(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i32) (result i64)))
  (type (;12;) (func (param i64) (result i64)))
  (type (;13;) (func (param i32 i32) (result i32)))
  (type (;14;) (func (param i64 i64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 3376)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 93
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 101
        i32.const 93
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32)
    i32.const 16
    call $goose.reserve_frame
    local.set 0
    block ;; label = @1
      local.get 0
      i32.const 0
      i32.add
      local.set 3
      local.get 3
      i32.const 0
      i32.add
      i64.const 7
      i64.store align=1
      local.get 3
      i32.const 8
      i32.add
      i64.const -8
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      i32.const 0
      call $run.1
      local.set 1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      local.set 4
      i64.const 2
      local.set 5
      i64.const 0
      local.set 6
      local.get 4
      local.set 7
      local.get 7
      i64.const 4294967295
      i64.and
      local.get 6
      i64.const 8
      i64.mul
      i64.add
      local.tee 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 194
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 8
      i64.or
      local.set 9
      i64.const 9
      local.set 10
      local.get 9
      local.get 10
      local.set 11
      i32.wrap_i64
      local.get 11
      i64.store align=1
      local.get 0
      i32.const 0
      i32.add
      i64.extend_i32_u
      call $parent.2
      local.set 2
      local.get 1
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 287
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 2
      i64.const -1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 380
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      call 0
      local.set 12
      local.get 12
      i32.const 473
      i32.const 13
      call 4
      local.get 12
      call 5
    end
    local.get 0
    global.set 0
  )
  (func $run.1 (;12;) (type 11) (param i64 i32) (result i64)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      local.get 1
      i32.const 1
      i32.add
      local.set 5
      local.get 5
      i32.const 29
      call $goose.reserve_data
      local.set 6
      local.get 5
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 6
      i64.extend_i32_u
      i64.or
      local.set 7
      local.get 7
      local.set 3
      local.get 7
      i64.const 1
      call $goose.memory_op.62
      local.get 0
      local.tee 8
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 486
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      i64.const 0
      local.set 9
      block ;; label = @2
        loop ;; label = @3
          local.get 9
          i64.const 2
          i64.ge_u
          br_if 1 (;@2;)
          local.get 7
          i64.const 4294967295
          i64.and
          i64.const 5
          i64.add
          local.tee 12
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 579
            i32.const 93
            i32.const 1
            call 6
            unreachable
          end
          local.get 7
          i64.const -4294967296
          i64.and
          local.get 12
          i64.or
          local.set 10
          local.get 10
          i64.const 4294967295
          i64.and
          local.get 9
          i64.const 8
          i64.mul
          i64.add
          local.tee 11
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 672
            i32.const 93
            i32.const 1
            call 6
            unreachable
          end
          local.get 10
          i64.const -4294967296
          i64.and
          local.get 11
          i64.or
          local.set 13
          local.get 8
          local.set 14
          local.get 14
          i64.const 4294967295
          i64.and
          local.get 9
          i64.const 8
          i64.mul
          i64.add
          local.tee 15
          i64.const 4294967295
          i64.gt_u
          if ;; label = @4
            i32.const 11
            i32.const 765
            i32.const 93
            i32.const 1
            call 6
            unreachable
          end
          local.get 14
          i64.const -4294967296
          i64.and
          local.get 15
          i64.or
          local.set 16
          local.get 13
          i64.const 0
          local.get 16
          call $goose.memory_op.41
          i64.sub
          call $goose.memory_op.55
          local.get 9
          i64.const 1
          i64.add
          local.set 9
          br 0 (;@3;)
        end
      end
      local.get 7
      i64.const 4
      i64.add
      i64.const 2
      call $goose.memory_op.60
      local.get 3
      local.set 17
      local.get 17
      call $goose.memory_op.53
      local.set 18
      i64.const 0
      local.set 19
      local.get 17
      local.set 20
      local.get 20
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 19
      i64.const 25
      i64.mul
      i64.add
      local.tee 21
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 858
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 20
      i64.const -4294967296
      i64.and
      local.get 21
      i64.or
      local.set 22
      local.get 22
      local.set 23
      local.get 23
      call $goose.memory_op.49
      i64.const 2
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 951
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 24
      local.get 24
      call $goose.memory_op.53
      local.set 25
      i64.const 0
      local.set 26
      local.get 24
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 26
      i64.const 25
      i64.mul
      i64.add
      local.tee 28
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1044
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 28
      i64.or
      local.set 29
      local.get 29
      local.set 30
      local.get 30
      call $goose.memory_op.49
      local.set 31
      i64.const 0
      local.set 32
      local.get 32
      local.get 31
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1137
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 30
      local.set 33
      local.get 33
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 32
      i64.const 8
      i64.mul
      i64.add
      local.tee 34
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1230
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 33
      i64.const -4294967296
      i64.and
      local.get 34
      i64.or
      call $goose.memory_op.41
      i64.const 0
      local.get 0
      local.tee 35
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1323
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 35
      local.set 36
      i64.const 2
      local.set 37
      i64.const 0
      local.set 38
      local.get 36
      local.set 39
      local.get 39
      i64.const 4294967295
      i64.and
      local.get 38
      i64.const 8
      i64.mul
      i64.add
      local.tee 40
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1416
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 39
      i64.const -4294967296
      i64.and
      local.get 40
      i64.or
      call $goose.memory_op.41
      i64.sub
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1509
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 41
      local.get 41
      call $goose.memory_op.53
      local.set 42
      i64.const 0
      local.set 43
      local.get 41
      local.set 44
      local.get 44
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 43
      i64.const 25
      i64.mul
      i64.add
      local.tee 45
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1602
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 44
      i64.const -4294967296
      i64.and
      local.get 45
      i64.or
      local.set 46
      local.get 46
      local.set 47
      local.get 47
      call $goose.memory_op.49
      local.set 48
      i64.const 1
      local.set 49
      local.get 49
      local.get 48
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 1695
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 47
      local.set 50
      local.get 50
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 49
      i64.const 8
      i64.mul
      i64.add
      local.tee 51
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1788
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 50
      i64.const -4294967296
      i64.and
      local.get 51
      i64.or
      call $goose.memory_op.41
      i64.const 8
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1881
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 52
      local.get 52
      call $goose.memory_op.53
      local.set 53
      i64.const 0
      local.set 54
      local.get 52
      local.set 55
      local.get 55
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 54
      i64.const 25
      i64.mul
      i64.add
      local.tee 56
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1974
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 55
      i64.const -4294967296
      i64.and
      local.get 56
      i64.or
      local.set 57
      local.get 57
      local.set 58
      local.get 58
      call $goose.memory_op.49
      local.set 59
      i64.const 0
      local.set 60
      local.get 60
      local.get 59
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2067
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 58
      local.set 61
      local.get 61
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 60
      i64.const 8
      i64.mul
      i64.add
      local.tee 62
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2160
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 61
      i64.const -4294967296
      i64.and
      local.get 62
      i64.or
      call $goose.memory_op.41
      local.get 3
      local.set 63
      local.get 63
      call $goose.memory_op.53
      local.set 64
      i64.const 0
      local.set 65
      local.get 63
      local.set 66
      local.get 66
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 65
      i64.const 25
      i64.mul
      i64.add
      local.tee 67
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2253
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 66
      i64.const -4294967296
      i64.and
      local.get 67
      i64.or
      local.set 68
      local.get 68
      local.set 69
      local.get 69
      call $goose.memory_op.49
      local.set 70
      i64.const 1
      local.set 71
      local.get 71
      local.get 70
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 2346
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 69
      local.set 72
      local.get 72
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 71
      i64.const 8
      i64.mul
      i64.add
      local.tee 73
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2439
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 72
      i64.const -4294967296
      i64.and
      local.get 73
      i64.or
      call $goose.memory_op.41
      i64.add
      local.set 4
      local.get 5
      local.get 6
      call $goose.restore_data
      br 0 (;@1;)
      local.get 5
      local.get 6
      call $goose.restore_data
    end
    local.get 4
  )
  (func $parent.2 (;13;) (type 12) (param i64) (result i64)
    (local i32 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 1
      local.set 5
      i32.const 29
      call $goose.reserve_memory.1
      local.set 6
      local.get 5
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 6
      i64.extend_i32_u
      i64.or
      local.set 7
      local.get 7
      local.set 2
      local.get 7
      i64.const 1
      local.set 8
      i32.wrap_i64
      local.get 8
      i64.store32 1 align=1
      local.get 7
      i64.const 0
      local.set 8
      i32.wrap_i64
      local.get 8
      i64.store8 1 offset=4
      i64.const 1
      local.set 9
      local.get 7
      i32.wrap_i64
      i64.load8_u 1 offset=4
      local.set 10
      local.get 10
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 2532
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2625
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.set 12
      local.get 12
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 10
      i64.const 8
      i64.mul
      i64.add
      local.tee 13
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2718
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 12
      i64.const -4294967296
      i64.and
      local.get 13
      i64.or
      local.set 11
      local.get 11
      i32.wrap_i64
      local.get 9
      i64.store 1 align=1
      local.get 7
      local.get 10
      i64.const 1
      i64.add
      local.set 8
      i32.wrap_i64
      local.get 8
      i64.store8 1 offset=4
      local.get 0
      i32.const 1
      call $run.1
      local.set 3
      local.get 2
      local.set 15
      local.get 15
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 16
      i64.const 0
      local.set 17
      local.get 15
      local.set 18
      local.get 18
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 17
      i64.const 25
      i64.mul
      i64.add
      local.tee 19
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2811
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 18
      i64.const -4294967296
      i64.and
      local.get 19
      i64.or
      local.set 20
      local.get 20
      local.set 21
      local.get 21
      i32.wrap_i64
      i64.load8_u 1
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 2904
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 2
      local.set 22
      local.get 22
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 23
      i64.const 0
      local.set 24
      local.get 22
      local.set 25
      local.get 25
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 24
      i64.const 25
      i64.mul
      i64.add
      local.tee 26
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 2997
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 25
      i64.const -4294967296
      i64.and
      local.get 26
      i64.or
      local.set 27
      local.get 27
      local.set 28
      local.get 28
      i32.wrap_i64
      i64.load8_u 1
      local.set 29
      i64.const 0
      local.set 30
      local.get 30
      local.get 29
      i64.ge_u
      if ;; label = @2
        i32.const 8
        i32.const 3090
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 28
      local.set 31
      local.get 31
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 30
      i64.const 8
      i64.mul
      i64.add
      local.tee 32
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 3183
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 31
      i64.const -4294967296
      i64.and
      local.get 32
      i64.or
      i32.wrap_i64
      i64.load 1 align=1
      i64.const 1
      i64.eq
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 3276
        i32.const 93
        i32.const 1
        call 6
        unreachable
      end
      local.get 3
      local.set 4
      local.get 6
      global.set 1
      br 0 (;@1;)
      local.get 6
      global.set 1
    end
    local.get 4
  )
  (func $goose.init (;14;) (type 10)
    (local i32)
  )
  (func $goose.start (;15;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_data (;16;) (type 13) (param i32 i32) (result i32)
    block (result i32) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i32.const 1
            i32.sub
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 1
          call $goose.reserve_memory.1
          br 2 (;@1;)
        end
        local.get 1
        call $goose.reserve_memory.2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.reserve_memory.1 (;17;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;18;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.62 (;19;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store32 align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store32 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store32 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.41 (;20;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.55 (;21;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.60 (;22;) (type 14) (param i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i64.store8
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          i64.store8 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        i64.store8 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.53 (;23;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load32_u align=1
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load32_u 1 align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load32_u 2 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.49 (;24;) (type 12) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.restore_data (;25;) (type 3) (param i32 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i32.const 1
            i32.sub
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 1
          i32.eqz
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          i64.extend_i32_u
          memory.size 1
          i64.extend_i32_u
          i64.const 16
          i64.shl
          i64.gt_u
          if ;; label = @4
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          local.get 1
          global.set 1
          br 2 (;@1;)
        end
        local.get 1
        i32.eqz
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        i64.extend_i32_u
        memory.size 2
        i64.extend_i32_u
        i64.const 16
        i64.shl
        i64.gt_u
        if ;; label = @3
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        local.get 1
        global.set 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goosefunction_data/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_fixed_negation_adapt_function_data.goose")
)
