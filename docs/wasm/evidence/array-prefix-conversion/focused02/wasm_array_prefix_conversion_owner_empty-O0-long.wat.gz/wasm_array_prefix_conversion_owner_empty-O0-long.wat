(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 688)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 94
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 102
        i32.const 94
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i32 i64 i64 i32 i32 i64 i64 i64 i64 i32 i64 i32 i32 i32 i64 i64 i32 i64 i64)
    block ;; label = @1
      i32.const 1
      local.set 3
      i32.const 1
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i32.wrap_i64
      i64.const 0
      i64.store8 1
      call 0
      local.set 6
      local.get 6
      i32.const 196
      i32.const 6
      call 4
      local.get 6
      call 5
      local.get 1
      local.set 7
      local.get 7
      call $goose.read_array_prefix
      local.set 10
      local.set 8
      i64.const 0
      local.set 11
      local.get 7
      local.set 13
      local.get 13
      i64.const 4294967295
      i64.and
      local.get 10
      i64.extend_i32_u
      i64.add
      local.get 11
      i64.const 1
      i64.mul
      i64.add
      local.tee 14
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 202
        i32.const 94
        i32.const 1
        call 6
        unreachable
      end
      local.get 13
      i64.const -4294967296
      i64.and
      local.get 14
      i64.or
      local.set 12
      i32.const 2
      local.set 9
      local.get 8
      i64.const 65535
      i64.gt_u
      if ;; label = @2
        i32.const 15
        i32.const 296
        i32.const 94
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 390
        i32.const 94
        i32.const 1
        call 6
        unreachable
      end
      local.get 8
      i64.const 1
      i64.mul
      i32.wrap_i64
      local.set 15
      local.get 15
      i64.extend_i32_u
      local.get 9
      i64.extend_i32_u
      i64.add
      local.tee 16
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 6
        i32.const 484
        i32.const 94
        i32.const 1
        call 6
        unreachable
      end
      local.get 16
      i32.wrap_i64
      local.set 17
      i32.const 2
      local.set 18
      local.get 17
      call $goose.reserve_memory.2
      local.set 19
      local.get 18
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 19
      i64.extend_i32_u
      i64.or
      local.set 20
      local.get 20
      local.set 2
      local.get 20
      local.get 8
      local.set 21
      i32.wrap_i64
      local.get 21
      i64.store16 2 align=1
      local.get 20
      local.get 9
      i64.extend_i32_u
      i64.add
      local.set 20
      local.get 20
      i32.wrap_i64
      local.get 12
      i32.wrap_i64
      i32.const 1
      memory.copy 2 1
      call 0
      local.set 22
      local.get 22
      i32.const 578
      i32.const 5
      call 4
      local.get 22
      call 5
      local.get 2
      local.set 23
      local.get 23
      i32.wrap_i64
      i64.load16_u 2 align=1
      i64.const 0
      i64.eq
      if (result i32) ;; label = @2
        local.get 1
        local.set 24
        local.get 24
        call $goose.read_array_prefix
        drop
        i64.const 0
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 583
        i32.const 94
        i32.const 1
        call 6
        unreachable
      end
      local.get 19
      global.set 2
      local.get 4
      global.set 1
    end
  )
  (func $goose.init (;12;) (type 10)
    (local i32)
  )
  (func $goose.start (;13;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;14;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.read_array_prefix (;15;) (type 11) (param i64) (result i64 i32)
    (local i64 i32 i64 i64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            local.tee 3
            i64.const 128
            i64.lt_u
            if ;; label = @5
              local.get 3
              local.set 1
              i32.const 1
              local.set 2
            else
              local.get 3
              i64.const 127
              i64.and
              local.set 1
              i32.const 1
              local.set 2
              block ;; label = @6
                loop ;; label = @7
                  local.get 0
                  i64.const 4294967295
                  i64.and
                  local.get 2
                  i64.extend_i32_u
                  i64.add
                  local.tee 4
                  i64.const 4294967295
                  i64.gt_u
                  if ;; label = @8
                    i32.const 11
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 4
                  i32.wrap_i64
                  i64.load8_u
                  local.set 3
                  local.get 2
                  i32.const 9
                  i32.eq
                  local.get 3
                  i64.const 1
                  i64.gt_u
                  i32.and
                  local.get 3
                  i64.eqz
                  i32.or
                  if ;; label = @8
                    i32.const 13
                    i32.const 0
                    i32.const 0
                    i32.const 0
                    call 6
                    unreachable
                  end
                  local.get 1
                  local.get 3
                  i64.const 127
                  i64.and
                  local.get 2
                  i32.const 7
                  i32.mul
                  i64.extend_i32_u
                  i64.shl
                  i64.or
                  local.set 1
                  local.get 2
                  i32.const 1
                  i32.add
                  local.set 2
                  local.get 3
                  i64.const 128
                  i64.and
                  i64.eqz
                  br_if 1 (;@6;)
                  br 0 (;@7;)
                end
              end
            end
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          local.tee 3
          i64.const 128
          i64.lt_u
          if ;; label = @4
            local.get 3
            local.set 1
            i32.const 1
            local.set 2
          else
            local.get 3
            i64.const 127
            i64.and
            local.set 1
            i32.const 1
            local.set 2
            block ;; label = @5
              loop ;; label = @6
                local.get 0
                i64.const 4294967295
                i64.and
                local.get 2
                i64.extend_i32_u
                i64.add
                local.tee 4
                i64.const 4294967295
                i64.gt_u
                if ;; label = @7
                  i32.const 11
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 4
                i32.wrap_i64
                i64.load8_u 1
                local.set 3
                local.get 2
                i32.const 9
                i32.eq
                local.get 3
                i64.const 1
                i64.gt_u
                i32.and
                local.get 3
                i64.eqz
                i32.or
                if ;; label = @7
                  i32.const 13
                  i32.const 0
                  i32.const 0
                  i32.const 0
                  call 6
                  unreachable
                end
                local.get 1
                local.get 3
                i64.const 127
                i64.and
                local.get 2
                i32.const 7
                i32.mul
                i64.extend_i32_u
                i64.shl
                i64.or
                local.set 1
                local.get 2
                i32.const 1
                i32.add
                local.set 2
                local.get 3
                i64.const 128
                i64.and
                i64.eqz
                br_if 1 (;@5;)
                br 0 (;@6;)
              end
            end
          end
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        local.tee 3
        i64.const 128
        i64.lt_u
        if ;; label = @3
          local.get 3
          local.set 1
          i32.const 1
          local.set 2
        else
          local.get 3
          i64.const 127
          i64.and
          local.set 1
          i32.const 1
          local.set 2
          block ;; label = @4
            loop ;; label = @5
              local.get 0
              i64.const 4294967295
              i64.and
              local.get 2
              i64.extend_i32_u
              i64.add
              local.tee 4
              i64.const 4294967295
              i64.gt_u
              if ;; label = @6
                i32.const 11
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 4
              i32.wrap_i64
              i64.load8_u 2
              local.set 3
              local.get 2
              i32.const 9
              i32.eq
              local.get 3
              i64.const 1
              i64.gt_u
              i32.and
              local.get 3
              i64.eqz
              i32.or
              if ;; label = @6
                i32.const 13
                i32.const 0
                i32.const 0
                i32.const 0
                call 6
                unreachable
              end
              local.get 1
              local.get 3
              i64.const 127
              i64.and
              local.get 2
              i32.const 7
              i32.mul
              i64.extend_i32_u
              i64.shl
              i64.or
              local.set 1
              local.get 2
              i32.const 1
              i32.add
              local.set 2
              local.get 3
              i64.const 128
              i64.and
              i64.eqz
              br_if 1 (;@4;)
              br 0 (;@5;)
            end
          end
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 1
    local.get 2
  )
  (func $goose.reserve_memory.2 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.goosebefore/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.gooseafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_array_prefix_conversion_owner_empty.goose")
  (export "test_stack_top_0" (global 0))
  (export "test_stack_top_1" (global 1))
  (export "test_stack_top_2" (global 2))
)
