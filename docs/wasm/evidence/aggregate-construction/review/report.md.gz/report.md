# Aggregate construction correctness review

Result: No confirmed correctness defects found.

This was a read-only review of the working diff against parent commit `d6429888fa8734804f42511884ebda1f11ebe34f` in `/home/dev/Projects/goose-wasm-backend`. No builds, tests, measurements, or child agents were run. Performance acceptance was outside this review scope.

## Reviewed inputs

- Complete tracked diff: `src/wasm_fixed.h`, `src/wasm_codegen.h`, `test/wasm_aggregate_admission.py`, and `test/wasm_backend.py`.
- All 18 new `test/wasm/wasm_aggregate_construction_*.goose` files and their expected output files.
- `test/wasm_aggregate_construction_checks.py`, `test/wasm_aggregate_construction_owner.mjs`, and `test/wasm_aggregate_construction_image.mjs`.
- Related source: fresh owner checks, fixed child checks, temporary construction, copy lowering, packed addresses, array prefixes, data reservations, storage planning, cleanup scopes, branch targets, default type checking, native default lowering, fixed layout bounds, and Wasm admission rules.
- Saved evidence summaries: `compiler-identity.json`, `build01/source-parent.txt`, `parent-first/results.json`, `parent-extra/results.json`, and `parent-observers/results.json` under `/tmp/goose-wasm-aggregate-construction-20261107`.

The saved result summaries contain 36 native-first cases at `-O0` and `-O2`. They record native passes and the expected parent Wasm rejection of aggregate fills or defaults. This review did not rerun or independently validate those executions.

## Source assessment

- Bounds and overflow: `ConstructRepeatedAggregate` checks the complete fresh destination, a nonzero checked element stride, the fixed or limited capacity, and the available image after the prefix. The division bound avoids count-times-stride overflow. The whole fresh reservation and child span checks cover the subsequent packed additions.
- Packed memory identity: the helper captures the destination with `EmitPackedAddress`, retains the destination's concrete or dynamic memory proof, and copies from a Memory 0 temporary through the existing `CopyBytes` dispatch. Nested array fields in fresh data elements retain their checked root span.
- Nested loop state: each helper invocation allocates its own base, position, and address locals. Nested construction cannot overwrite the outer loop state. The helper does not add a source-language loop target.
- Fill evaluation: `WithFixedTemporary` executes before the copy loop, including a zero-count fill. It constructs and captures the complete nominal image once. Later copies preserve reference values and the full element stride.
- Default evaluation: a nonempty fixed array calls `WithFixedTemporary` inside the loop, so field defaults execute once for each element. Empty fixed and limited defaults return before they require or evaluate an element initializer. This matches the default initializer rules in `typecheck_builtins.h`.
- Exit and cleanup: temporary reservation adds an ordered frame restore to a new cleanup scope before it constructs the value. Existing return, break, and continue lowering emits cleanup through that scope before branching to the source target. An early exit bypasses the copy and loop continuation. Ordinary iterations restore the temporary before the next iteration.
- Tests: the new cases cover side effect counts, empty constructors, nested fills, reference identity, fixed and limited arrays, enums, fresh data fields, memory growth, return, break, and continue. The owner observer checks active frame state during prints and the final restore. The image observer checks a complete Memory 0 image and includes deliberate damaged-copy variants.

## Unexecuted paths and evidence limits

No candidate execution was inspected or run by this reviewer. The parent stated that candidate02 was still running. Its results need review by the owner before final validation.

The new test sources do not directly combine a per-element default loop with nested default loops, a default initializer that exits through an inlined caller, or a deferred body that allocates during such an exit. The source paths were inspected, with no confirmed defect found. Memory32 boundary capacities and multi-byte limited-array prefixes were also assessed from source rather than executed.

Individual raw compiler, native, validator, engine, stdout, stderr, and exit artifacts in the saved evidence directories were not all read. The cited result summaries were read. No performance, code-size, allocation, or memory-footprint acceptance claim is made.

## Reviewed source identity

SHA-256 of the source read for the implementation:

```text
c1b51eca4f349442913ea3e4baf322148fa1897dfe1d6804fa183ce0073c3e06  src/wasm_fixed.h
e048e92e22b1ff3a0f333dfd8167acf07688b5e1da977b36db54f097a4baa800  src/wasm_codegen.h
```

