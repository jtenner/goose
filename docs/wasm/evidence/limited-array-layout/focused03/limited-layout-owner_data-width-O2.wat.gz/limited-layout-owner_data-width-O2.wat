(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64) (result i64)))
  (type (;12;) (func (param i64 i64 i32)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (memory (;2;) 1 65536)
  (global (;0;) (mut i32) i32.const 1920)
  (global (;1;) (mut i32) i32.const 1)
  (global (;2;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "data_memory_2" (memory 2))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 8
      i32.const 90
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 98
        i32.const 90
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    block ;; label = @1
      i32.const 1
      local.set 3
      i32.const 11
      call $goose.reserve_memory.1
      local.set 4
      local.get 3
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 4
      i64.extend_i32_u
      i64.or
      local.set 5
      local.get 5
      local.set 1
      local.get 5
      i64.const 1
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store32 1 align=1
      local.get 5
      i32.wrap_i64
      i64.const 9
      i64.store8 1 offset=4
      local.get 5
      i64.const 0
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=5
      i64.const 7
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load8_u 1 offset=5
      local.set 8
      local.get 8
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 188
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 278
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 8
      i64.const 1
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 368
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store8 1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=5
      i64.const 8
      local.set 7
      local.get 5
      i32.wrap_i64
      i64.load8_u 1 offset=5
      local.set 8
      local.get 8
      i64.const 3
      i64.ge_u
      if ;; label = @2
        i32.const 10
        i32.const 458
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const 4294967295
      i64.and
      i64.const 5
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 548
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 5
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 10
      local.get 10
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.get 8
      i64.const 1
      i64.mul
      i64.add
      local.tee 11
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 638
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 10
      i64.const -4294967296
      i64.and
      local.get 11
      i64.or
      local.set 9
      local.get 9
      i32.wrap_i64
      local.get 7
      i64.store8 1
      local.get 5
      local.get 8
      i64.const 1
      i64.add
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 1 offset=5
      local.get 5
      i32.wrap_i64
      i64.const 60000
      i64.store16 1 offset=9 align=1
      i32.const 2
      local.set 13
      i32.const 265
      call $goose.reserve_memory.2
      local.set 14
      local.get 13
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 14
      i64.extend_i32_u
      i64.or
      local.set 15
      local.get 15
      local.set 2
      local.get 15
      i64.const 1
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store32 2 align=1
      local.get 15
      i32.wrap_i64
      i64.const 7
      i64.store8 2 offset=4
      local.get 1
      local.set 16
      local.get 16
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 17
      i64.const 0
      local.set 18
      local.get 16
      local.set 19
      local.get 19
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 18
      i64.const 7
      i64.mul
      i64.add
      local.tee 20
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 728
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 19
      i64.const -4294967296
      i64.and
      local.get 20
      i64.or
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 818
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      call $prepare.1
      local.tee 22
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 908
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 22
      call $goose.memory_op.49
      local.set 23
      local.get 23
      i64.const 1
      i64.mul
      i32.wrap_i64
      local.set 24
      local.get 15
      i64.const 4294967295
      i64.and
      i64.const 7
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 998
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 15
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.get 22
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1088
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 22
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.get 24
      call $goose.copy_memory
      local.get 15
      local.get 23
      local.set 6
      i32.wrap_i64
      local.get 6
      i64.store8 2 offset=5 align=1
      local.get 15
      i32.wrap_i64
      i64.const 65000
      i64.store16 2 offset=263 align=1
      call 0
      local.set 25
      local.get 25
      i32.const 1178
      i32.const 5
      call 4
      local.get 25
      call 5
      local.get 2
      local.set 26
      local.get 26
      i32.wrap_i64
      i64.load32_u 2 align=1
      local.set 27
      i64.const 0
      local.set 28
      local.get 26
      local.set 29
      local.get 29
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 28
      i64.const 261
      i64.mul
      i64.add
      local.tee 30
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1183
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 29
      i64.const -4294967296
      i64.and
      local.get 30
      i64.or
      local.set 31
      local.get 31
      i64.const 4294967295
      i64.and
      i64.const 1
      i64.add
      local.tee 12
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1273
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 31
      i64.const -4294967296
      i64.and
      local.get 12
      i64.or
      local.set 32
      local.get 32
      i32.wrap_i64
      i64.load16_u 2 align=1
      i64.const 2
      i64.eq
      if (result i32) ;; label = @2
        local.get 2
        local.set 33
        local.get 33
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 34
        i64.const 0
        local.set 35
        local.get 33
        local.set 36
        local.get 36
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 35
        i64.const 261
        i64.mul
        i64.add
        local.tee 37
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1363
          i32.const 90
          i32.const 1
          call 6
          unreachable
        end
        local.get 36
        i64.const -4294967296
        i64.and
        local.get 37
        i64.or
        local.set 38
        local.get 38
        i64.const 4294967295
        i64.and
        i64.const 1
        i64.add
        local.tee 12
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1453
          i32.const 90
          i32.const 1
          call 6
          unreachable
        end
        local.get 38
        i64.const -4294967296
        i64.and
        local.get 12
        i64.or
        local.set 39
        local.get 39
        i32.wrap_i64
        i64.load16_u 2 align=1
        local.set 40
        i64.const 1
        local.set 41
        local.get 41
        local.get 40
        i64.ge_u
        if ;; label = @3
          i32.const 8
          i32.const 1543
          i32.const 90
          i32.const 1
          call 6
          unreachable
        end
        local.get 39
        local.set 42
        local.get 42
        i64.const 4294967295
        i64.and
        i64.const 2
        i64.add
        local.get 41
        i64.const 1
        i64.mul
        i64.add
        local.tee 43
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1633
          i32.const 90
          i32.const 1
          call 6
          unreachable
        end
        local.get 42
        i64.const -4294967296
        i64.and
        local.get 43
        i64.or
        i32.wrap_i64
        i64.load8_u 2
        i64.const 8
        i64.eq
      else
        i32.const 0
      end
      if (result i32) ;; label = @2
        local.get 2
        local.set 44
        local.get 44
        i32.wrap_i64
        i64.load32_u 2 align=1
        local.set 45
        i64.const 0
        local.set 46
        local.get 44
        local.set 47
        local.get 47
        i64.const 4294967295
        i64.and
        i64.const 4
        i64.add
        local.get 46
        i64.const 261
        i64.mul
        i64.add
        local.tee 48
        i64.const 4294967295
        i64.gt_u
        if ;; label = @3
          i32.const 11
          i32.const 1723
          i32.const 90
          i32.const 1
          call 6
          unreachable
        end
        local.get 47
        i64.const -4294967296
        i64.and
        local.get 48
        i64.or
        local.set 49
        local.get 49
        i32.wrap_i64
        i64.load16_u 2 offset=259 align=1
        i64.const 65000
        i64.eq
      else
        i32.const 0
      end
      i32.eqz
      if ;; label = @2
        i32.const 1
        i32.const 1813
        i32.const 90
        i32.const 1
        call 6
        unreachable
      end
      local.get 14
      global.set 2
      local.get 4
      global.set 1
    end
  )
  (func $prepare.1 (;12;) (type 11) (param i64) (result i64)
    (local i32 i64 i32)
    block ;; label = @1
      call 0
      local.set 3
      local.get 3
      i32.const 1903
      i32.const 6
      call 4
      local.get 3
      call 5
      local.get 0
      local.set 2
      br 0 (;@1;)
    end
    local.get 2
  )
  (func $goose.init (;13;) (type 10)
    (local i32)
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.reserve_memory.2 (;16;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 2
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 2
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 2
      i32.sub
      memory.grow 2
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 2
    local.get 1
  )
  (func $goose.memory_op.49 (;17;) (type 11) (param i64) (result i64)
    block (result i64) ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            local.get 0
            i32.wrap_i64
            i64.load8_u
            br 3 (;@1;)
          end
          local.get 0
          i32.wrap_i64
          i64.load8_u 1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        i64.load8_u 2
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.copy_memory (;18;) (type 12) (param i64 i64 i32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              local.get 0
              i64.const 32
              i64.shr_u
              i32.wrap_i64
              br_table 0 (;@5;) 1 (;@4;) 2 (;@3;) 3 (;@2;)
            end
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    block ;; label = @9
                      local.get 1
                      i64.const 32
                      i64.shr_u
                      i32.wrap_i64
                      br_table 0 (;@9;) 1 (;@8;) 2 (;@7;) 3 (;@6;)
                    end
                    local.get 0
                    i32.wrap_i64
                    local.get 1
                    i32.wrap_i64
                    local.get 2
                    memory.copy
                    br 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 0 1
                  br 2 (;@5;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 0 2
                br 1 (;@5;)
              end
              i32.const 7
              i32.const 0
              i32.const 0
              i32.const 0
              call 6
              unreachable
            end
            br 3 (;@1;)
          end
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  block ;; label = @8
                    local.get 1
                    i64.const 32
                    i64.shr_u
                    i32.wrap_i64
                    br_table 0 (;@8;) 1 (;@7;) 2 (;@6;) 3 (;@5;)
                  end
                  local.get 0
                  i32.wrap_i64
                  local.get 1
                  i32.wrap_i64
                  local.get 2
                  memory.copy 1 0
                  br 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 1 1
                br 2 (;@4;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 1 2
              br 1 (;@4;)
            end
            i32.const 7
            i32.const 0
            i32.const 0
            i32.const 0
            call 6
            unreachable
          end
          br 2 (;@1;)
        end
        block ;; label = @3
          block ;; label = @4
            block ;; label = @5
              block ;; label = @6
                block ;; label = @7
                  local.get 1
                  i64.const 32
                  i64.shr_u
                  i32.wrap_i64
                  br_table 0 (;@7;) 1 (;@6;) 2 (;@5;) 3 (;@4;)
                end
                local.get 0
                i32.wrap_i64
                local.get 1
                i32.wrap_i64
                local.get 2
                memory.copy 2 0
                br 3 (;@3;)
              end
              local.get 0
              i32.wrap_i64
              local.get 1
              i32.wrap_i64
              local.get 2
              memory.copy 2 1
              br 2 (;@3;)
            end
            local.get 0
            i32.wrap_i64
            local.get 1
            i32.wrap_i64
            local.get 2
            memory.copy 2 2
            br 1 (;@3;)
          end
          i32.const 7
          i32.const 0
          i32.const 0
          i32.const 0
          call 6
          unreachable
        end
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.gooseafter/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_limited_array_layout_owner_data.goosebefore")
  (export "test_stack_top_0" (global 0))
  (export "test_stack_top_1" (global 1))
  (export "test_stack_top_2" (global 2))
)
