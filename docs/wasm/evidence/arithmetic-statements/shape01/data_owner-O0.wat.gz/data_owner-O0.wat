(module
  (type (;0;) (func (result i32)))
  (type (;1;) (func (param i32 i64 i32)))
  (type (;2;) (func (param i32 f64 i32)))
  (type (;3;) (func (param i32 i32)))
  (type (;4;) (func (param i32 i32 i32)))
  (type (;5;) (func (param i32)))
  (type (;6;) (func (param i32 i32 i32 i32)))
  (type (;7;) (func (param f64 f64) (result f64)))
  (type (;8;) (func (param f64) (result i64)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func))
  (type (;11;) (func (param i64 i64)))
  (type (;12;) (func (param i64 f32)))
  (type (;13;) (func (param i64 f64)))
  (import "goose" "print_begin_v1" (func (;0;) (type 0) (result i32)))
  (import "goose" "print_int_v1" (func (;1;) (type 1) (param i32 i64 i32)))
  (import "goose" "print_float_v1" (func (;2;) (type 2) (param i32 f64 i32)))
  (import "goose" "print_bool_v1" (func (;3;) (type 3) (param i32 i32)))
  (import "goose" "print_bytes_v1" (func (;4;) (type 4) (param i32 i32 i32)))
  (import "goose" "print_end_v1" (func (;5;) (type 5) (param i32)))
  (import "goose" "fail_v1" (func (;6;) (type 6) (param i32 i32 i32 i32)))
  (import "goose" "exit_v1" (func (;7;) (type 5) (param i32)))
  (import "goose" "fmod_v1" (func (;8;) (type 7) (param f64 f64) (result f64)))
  (import "goose" "float_to_int_v1" (func (;9;) (type 8) (param f64) (result i64)))
  (memory (;0;) 1 65536)
  (memory (;1;) 1 65536)
  (global (;0;) (mut i32) i32.const 1216)
  (global (;1;) (mut i32) i32.const 1)
  (export "memory" (memory 0))
  (export "data_memory_1" (memory 1))
  (export "_start" (func $goose.start))
  (func $goose.reserve_frame (;10;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 0
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 5
      i32.const 36
      i32.const 83
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size
      i32.sub
      memory.grow
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 5
        i32.const 119
        i32.const 83
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 0
    local.get 1
  )
  (func $main.0 (;11;) (type 10)
    (local i32 i64 i32 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i32)
    block ;; label = @1
      i32.const 1
      local.set 2
      i32.const 18
      call $goose.reserve_memory.1
      local.set 3
      local.get 2
      i64.extend_i32_u
      i64.const 32
      i64.shl
      local.get 3
      i64.extend_i32_u
      i64.or
      local.set 4
      local.get 4
      local.set 1
      local.get 4
      i64.const 1
      local.set 5
      i32.wrap_i64
      local.get 5
      i64.store32 1 align=1
      local.get 4
      i32.wrap_i64
      i32.const 4
      i32.add
      i32.const 8
      i32.const 14
      memory.copy 1 0
      local.get 1
      local.set 6
      local.get 6
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 7
      i64.const 0
      local.set 8
      local.get 6
      local.set 9
      local.get 9
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 8
      i64.const 14
      i64.mul
      i64.add
      local.tee 10
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 202
        i32.const 83
        i32.const 4
        call 6
        unreachable
      end
      local.get 9
      i64.const -4294967296
      i64.and
      local.get 10
      i64.or
      i32.const 22
      i64.extend_i32_u
      call $prepare.1
      local.get 1
      local.set 11
      local.get 11
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 12
      i64.const 0
      local.set 13
      local.get 11
      local.set 14
      local.get 14
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 13
      i64.const 14
      i64.mul
      i64.add
      local.tee 15
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 285
        i32.const 83
        i32.const 4
        call 6
        unreachable
      end
      local.get 14
      i64.const -4294967296
      i64.and
      local.get 15
      i64.or
      local.set 16
      i32.const 22
      local.set 17
      local.get 16
      i32.wrap_i64
      local.get 16
      i32.wrap_i64
      f32.load 1 align=1
      local.get 17
      f32.load align=1
      f32.add
      f32.store 1 align=1
      local.get 16
      i32.wrap_i64
      local.get 16
      i32.wrap_i64
      f64.load 1 offset=6 align=1
      local.get 17
      f64.load offset=6 align=1
      f64.add
      f64.store 1 offset=6 align=1
      local.get 1
      local.set 18
      local.get 18
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 19
      i64.const 0
      local.set 20
      local.get 18
      local.set 21
      local.get 21
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 20
      i64.const 14
      i64.mul
      i64.add
      local.tee 22
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 368
        i32.const 83
        i32.const 4
        call 6
        unreachable
      end
      local.get 21
      i64.const -4294967296
      i64.and
      local.get 22
      i64.or
      local.set 23
      local.get 23
      i32.wrap_i64
      f32.load 1 align=1
      local.get 1
      local.set 24
      local.get 24
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 25
      i64.const 0
      local.set 26
      local.get 24
      local.set 27
      local.get 27
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 26
      i64.const 14
      i64.mul
      i64.add
      local.tee 28
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 451
        i32.const 83
        i32.const 4
        call 6
        unreachable
      end
      local.get 27
      i64.const -4294967296
      i64.and
      local.get 28
      i64.or
      local.set 29
      local.get 29
      i32.wrap_i64
      f32.load 1 align=1
      f32.eq
      local.set 30
      local.get 1
      local.set 31
      local.get 31
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 32
      i64.const 0
      local.set 33
      local.get 31
      local.set 34
      local.get 34
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 33
      i64.const 14
      i64.mul
      i64.add
      local.tee 35
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 534
        i32.const 83
        i32.const 4
        call 6
        unreachable
      end
      local.get 34
      i64.const -4294967296
      i64.and
      local.get 35
      i64.or
      local.set 36
      local.get 36
      i32.wrap_i64
      f64.load 1 offset=6 align=1
      local.get 1
      local.set 37
      local.get 37
      i32.wrap_i64
      i64.load32_u 1 align=1
      local.set 38
      i64.const 0
      local.set 39
      local.get 37
      local.set 40
      local.get 40
      i64.const 4294967295
      i64.and
      i64.const 4
      i64.add
      local.get 39
      i64.const 14
      i64.mul
      i64.add
      local.tee 41
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 617
        i32.const 83
        i32.const 4
        call 6
        unreachable
      end
      local.get 40
      i64.const -4294967296
      i64.and
      local.get 41
      i64.or
      local.set 42
      local.get 42
      i32.wrap_i64
      f64.load 1 offset=6 align=1
      f64.eq
      local.set 43
      call 0
      local.set 44
      local.get 44
      i32.const 700
      i32.const 6
      call 4
      local.get 44
      local.get 30
      call 3
      local.get 44
      i32.const 706
      i32.const 1
      call 4
      local.get 44
      local.get 43
      call 3
      local.get 44
      call 5
      local.get 3
      global.set 1
    end
  )
  (func $prepare.1 (;12;) (type 11) (param i64 i64)
    (local i32 i64 i64 i64 i64 i64 i32)
    block ;; label = @1
      local.get 0
      local.tee 3
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 707
        i32.const 83
        i32.const 3
        call 6
        unreachable
      end
      local.get 3
      f32.const 0x1.4p+0 (;=1.25;)
      call $goose.memory_op.56
      local.get 0
      local.tee 4
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 790
        i32.const 83
        i32.const 3
        call 6
        unreachable
      end
      local.get 4
      i64.const 4294967295
      i64.and
      i64.const 6
      i64.add
      local.tee 5
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 873
        i32.const 83
        i32.const 0
        call 6
        unreachable
      end
      local.get 4
      i64.const -4294967296
      i64.and
      local.get 5
      i64.or
      f64.const 0x1.69p+5 (;=45.125;)
      call $goose.memory_op.57
      local.get 1
      local.tee 6
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 956
        i32.const 83
        i32.const 3
        call 6
        unreachable
      end
      local.get 6
      f32.const -0x1.4p+1 (;=-2.5;)
      call $goose.memory_op.56
      local.get 1
      local.tee 7
      i64.eqz
      if ;; label = @2
        i32.const 4
        i32.const 1039
        i32.const 83
        i32.const 3
        call 6
        unreachable
      end
      local.get 7
      i64.const 4294967295
      i64.and
      i64.const 6
      i64.add
      local.tee 5
      i64.const 4294967295
      i64.gt_u
      if ;; label = @2
        i32.const 11
        i32.const 1122
        i32.const 83
        i32.const 0
        call 6
        unreachable
      end
      local.get 7
      i64.const -4294967296
      i64.and
      local.get 5
      i64.or
      f64.const -0x1.2ap+5 (;=-37.25;)
      call $goose.memory_op.57
      call 0
      local.set 8
      local.get 8
      i32.const 1205
      i32.const 6
      call 4
      local.get 8
      call 5
    end
  )
  (func $goose.init (;13;) (type 10)
    (local i32 i32 i32)
    i32.const 8
    local.set 1
    local.get 1
    f32.const 0x1.4p+0 (;=1.25;)
    f32.store align=1
    local.get 1
    f64.const 0x1.69p+5 (;=45.125;)
    f64.store offset=6 align=1
    i32.const 22
    local.set 2
    local.get 2
    f32.const -0x1.4p+1 (;=-2.5;)
    f32.store align=1
    local.get 2
    f64.const -0x1.2ap+5 (;=-37.25;)
    f64.store offset=6 align=1
  )
  (func $goose.start (;14;) (type 10)
    call $goose.init
    call $main.0
  )
  (func $goose.reserve_memory.1 (;15;) (type 9) (param i32) (result i32)
    (local i32 i64 i32)
    global.get 1
    local.tee 1
    i64.extend_i32_u
    local.get 0
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4294967295
    i64.gt_u
    if ;; label = @1
      i32.const 6
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
    local.get 2
    i64.const 65535
    i64.add
    i64.const 16
    i64.shr_u
    i32.wrap_i64
    local.tee 3
    memory.size 1
    i32.gt_u
    if ;; label = @1
      local.get 3
      memory.size 1
      i32.sub
      memory.grow 1
      i32.const -1
      i32.eq
      if ;; label = @2
        i32.const 6
        i32.const 0
        i32.const 0
        i32.const 0
        call 6
        unreachable
      end
    end
    local.get 2
    i32.wrap_i64
    global.set 1
    local.get 1
  )
  (func $goose.memory_op.56 (;16;) (type 12) (param i64 f32)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          f32.store align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        f32.store 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (func $goose.memory_op.57 (;17;) (type 13) (param i64 f64)
    block ;; label = @1
      block ;; label = @2
        block ;; label = @3
          block ;; label = @4
            local.get 0
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            br_table 0 (;@4;) 1 (;@3;) 2 (;@2;)
          end
          local.get 0
          i32.wrap_i64
          local.get 1
          f64.store align=1
          br 2 (;@1;)
        end
        local.get 0
        i32.wrap_i64
        local.get 1
        f64.store 1 align=1
        br 1 (;@1;)
      end
      i32.const 7
      i32.const 0
      i32.const 0
      i32.const 0
      call 6
      unreachable
    end
  )
  (data (;0;) (i32.const 0) "\00\00\00\00\00\00\00\00")
  (data (;1;) (i32.const 36) "/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.gooseafter=,/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goose/home/dev/Projects/goose-wasm-backend/test/wasm/wasm_compound_math_data_owner.goosebefore")
)
